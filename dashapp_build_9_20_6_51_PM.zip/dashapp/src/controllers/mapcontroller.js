'use strict';
/**
 * @ngdoc function
 * @name wexdashboard.controller:DashboardController
 * @description
 * # DashboardController
 * Controller of the wexdashboard home
 */
angular.module('wexdashboard')
  .controller('MapController', ['$scope','$rootScope','mapService',function($scope,$rootScope,mapService){

$rootscope.mapstateselected="";
$scope.filterDefaultDate = "01/01/2016-12/31/2016";

function init() {
     // load the initial data for map
   loadMapData($rootscope.mapstateselected);
};

// load mapdata for users states

function loadMapData(selectedstate){

  // call the service and filter out the data for scope variable.

   mapService.getMapData(selectedstate)
        .then(
          function( mydata ) {
            // Get the user states and then create the map object and fill the states color. When selectedstate has value then create a state map with counties.
            $scope.mapObject = {
                scope: 'usa',
                options: {
                  width: 600,
                  legendHeight: 60 // optionally set the padding for the legend
                },
                geographyConfig: {
                  highlighBorderColor: '#306596',
                  highlighBorderWidth: 2
                },
                fills: {
                  'HIGH': '#CC4731',
                  'MEDIUM': '#c31820',
                  'LOW': '#306596',
                  'defaultFill': '#DDDDDD'
                },
                data: {
                  "IN": {
                    "fillKey": "MEDIUM",
                  },
                  "TX": {
                    "fillKey": "MEDIUM",
                  }
                },
              };
          });
    };

  // Method to update the charts when map is clicked. Currently working only for one state at a time. Need to fix multiple state selection.

   $scope.updateActiveState = function(geography) {
    // get the selected state values
    $scope.stateName = geography.properties.name;
    $scope.stateCode = geography.id;
    console.log("statename = "+$scope.stateName);

    $scope.mapObject = {
      scope: 'usa',
      options: {
        width: 400,
        legendHeight: 60 // optionally set the padding for the legend
      },
      geographyConfig: {
        highlighBorderColor: '#306598',
        highlighBorderWidth: 2
      },
      fills: {
        'HIGH': '#CC4731',
        'MEDIUM': '#dcdcbd',
        'LOW': '#306596',
        'defaultFill': '#DDDDDD'
      },
      data: {
        "IN": {
          "fillKey": "MEDIUM",
        },
        "TX": {
          "fillKey": "MEDIUM",
        }
      },
      };
    };
console.log("calling the init");
init();
}]);

app.service('mapService', function ($http,$q) {

// Service method to get all states for the user.

return({
      getUserStates: getUserStates
});

// start call to get service data

function  getUserStates(selectedstate) {
// var request = $http({
//         method: "post",
//         url: "/AppBuilder/endpoint/userstates",
//         params: {
//                 category: category,
//                 datefilter: datefilter
//           }
//     });
//   //  console.log("getUserStates Service ended started");
//   return(request.then( handleSuccess, handleError ) );
    var temp = "";
    return temp;
  }
// end call to get data from service.
// Common method to handle the request from the server
function handleError( response ) {
    if (
        ! angular.isObject( response.data ) ||
        ! response.data.message
        ) {
        return( $q.reject( "An unknown error occurred." ) );
    }
    return( $q.reject( response.data.message ) );
}
function handleSuccess( response ) {
//  console.log("handling the success of the call ");
return( response.data);
}

});
