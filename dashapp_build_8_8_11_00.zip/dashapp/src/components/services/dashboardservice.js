'use strict';
/**
 * @ngdoc function
 * @name wexdashboard.services:billingService
 * @description
 * # billingService
 * data service (billingService) for the wexdashboard home
 */
 
//DataService containing all the data calls from backend.
    angular.module('wexdashboard', [])
      .service('billingService', function ($http,$q) {

      // Service method to get the billing hours
      // Return service methodes.
      return({
            getServiceData: getServiceData,
			getAnomaliesData: getAnomaliesData

      });

      // start call to get service data

      function  getServiceData(category,categoryvalue,filters,selectedkpi,subcategory,datefilter) {
     //   console.log("getServiceData Service Method started");
	//	console.log("Variable in getService Data are category = " + category + " categoryValue = " + categoryvalue + ",filters = " + filters + ",selectedkpi = " + selectedkpi + ",subcategory = " + subcategory + ",datefilter = "+ datefilter);
		  var request = $http({
              method: "post",
              url: "/AppBuilder/endpoint/dashboardendpoint",
			  params: {
                      category: category,
                      categoryvalue: "'" + categoryvalue + "'",
                      filters: filters,
					  selectedkpi: selectedkpi,
					  subcategory: subcategory,
					  datefilter: datefilter
				}
          });
        //  console.log("getServiceData Service ended started");
		  return(request.then( handleSuccess, handleError ) );
		}
      // end call to get data from service.

	  // start call to get service data

      //function  getAnomaliesData(category,categoryvalue,filters,selectedkpi,subcategory,datefilter) {
	  function  getAnomaliesData(stateS) {
     //   console.log("getServiceData Service Method started");
	//	console.log("Variable in getService Data are category = " + category + " categoryValue = " + categoryvalue + ",filters = " + filters + ",selectedkpi = " + selectedkpi + ",subcategory = " + subcategory + ",datefilter = "+ datefilter);
		var request = $http({
              method: "post",
              url: "/AppBuilder/endpoint/getAnomaly",
			  params: {
                      state: stateS,
                //      categoryvalue: "'" + categoryvalue + "'",
                //      filters: filters,
				//	  selectedkpi: selectedkpi,
				//	  subcategory: subcategory,
				//	  datefilter: datefilter
				}
          });
        //  console.log("getServiceData Service ended started");
		  return(request.then( handleSuccess, handleError ) );
		}
      // end call to get data from service.

      // Common method to handle the request from the server
      function handleError( response ) {
          if (
              ! angular.isObject( response.data ) ||
              ! response.data.message
              ) {
              return( $q.reject( "An unknown error occurred." ) );
          }
          return( $q.reject( response.data.message ) );
      }
      function handleSuccess( response ) {
		//  console.log("handling the success of the call ");
		  return( response.data);
      }

   });