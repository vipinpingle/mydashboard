$(function() {

    var start = moment().subtract(29, 'days');
    var end = moment();

   //function cb(start, end) {
    //  $('#reportrange span').html(('01/01/2016') + ' - ' + ('12/31/2016'));
   //}

   $('input[name="daterange"]').daterangepicker({
       //startDate: start,
       //endDate: end,
       ranges: {
          'Today': [moment(), moment()],
          'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
          'Last 7 Days': [moment().subtract(6, 'days'), moment()],
          'Last 30 Days': [moment().subtract(29, 'days'), moment()],
          'This Month': [moment().startOf('month'), moment().endOf('month')],
          'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
      '2016': ['1/1/2016', '12/31/2016'],
      '2015': ['1/1/2015', '12/31/2015'],
       '2015-2016': ['1/1/2015', '12/31/2016']


       }
 });
   //}, cb);

     //cb(start, end);

   function cb1(start, end) {
     $('#compTime1 span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
   }

   $('#compTime1').daterangepicker({
     startDate: '1/1/2016',
     endDate: '12/31/2016',
     ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
        '2016': ['1/1/2016', '12/31/2016'],
        '2015': ['1/1/2015', '12/31/2015'],
       '2015-2016': ['1/1/2015', '12/31/2016']


     }
   }, cb1);

     cb1(start, end);

     function cb2(start, end) {
     $('#compTime2 span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
   }

   $('#compTime2').daterangepicker({
     startDate: start,
     endDate: end,
     ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
        '2016': ['1/1/2016', '12/31/2016'],
        '2015': ['1/1/2015', '12/31/2015'],
       '2015-2016': ['1/1/2015', '12/31/2016']


     }
   }, cb2);

     cb2(start, end);

     function cb3(start, end) {
     $('#compTime3 span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
   }

   $('#compTime3').daterangepicker({
     startDate: start,
     endDate: end,
     ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
        '2016': ['1/1/2016', '12/31/2016'],
        '2015': ['1/1/2015', '12/31/2015'],
       '2015-2016': ['1/1/2015', '12/31/2016']


     }
   }, cb3);

     cb3(start, end);
   function cb4(start, end) {
     $('#compTime4 span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
   }

   $('#compTime4').daterangepicker({
     startDate: start,
     endDate: end,
     ranges: {
        'Today': [moment(), moment()],
        'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        'Last 7 Days': [moment().subtract(6, 'days'), moment()],
        'Last 30 Days': [moment().subtract(29, 'days'), moment()],
        'This Month': [moment().startOf('month'), moment().endOf('month')],
        'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
        '2016': ['1/1/2016', '12/31/2016'],
        '2015': ['1/1/2015', '12/31/2015'],
       '2015-2016': ['1/1/2015', '12/31/2016']


     }
   }, cb4);

     cb4(start, end);
   });
