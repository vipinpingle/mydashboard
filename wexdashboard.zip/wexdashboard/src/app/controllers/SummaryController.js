(function(){
  angular
       .module('app')
       .controller('SummaryController', [
          '$log', '$q', '$state',
          SummaryController
       ]);

  function SummaryController($log, $q, $state) {
    var vm = this;

    vm.title = $state.current.data.title;
  }
})();
