﻿<script type="text/javascript" src="/AppBuilder/dashapp/src/lib/angular-sanitize.min.js"></script>
<script type="text/javascript" src="/AppBuilder/dashapp/dist/scripts/ng-csv.min.js"></script>
<script>

/* off-canvas sidebar toggle */
$('[data-toggle=offcanvas]').click(function() {
    $('.row-offcanvas').toggleClass('active');
    //$('.collapse').toggleClass('in').toggleClass('hidden-xs').toggleClass('visible-xs');
    $('.collapsemain').toggleClass('col-md-8').toggleClass('col-md-11');
    $('.table_wrapper').toggleClass('wrapper_size');
    $('.expandrightview').toggleClass('firms_overview').toggleClass('firms_overviewexpanded');
});

//Title Append
$('#nav_title').append($('#pagetitle').val());

</script>

<script type="text/javascript">
  var counter = 0;
  var app = angular.module('wexdashboard', ['angularUtils.directives.dirPagination','FirmDataService','ui.bootstrap','ui.tree','wexdashboard.directives','wexdashboard.services','ngCsv']);

//   app.config(function($stateProvider, $urlRouterProvider) {
//   $urlRouterProvider.otherwise('all');
//   $stateProvider
//   .state('allstate', {
//     url: '/all',
//     templateUrl:'/AppBuilder/dashapp/src/views/firms/firmsview.html',
//     controller: 'FirmController'
//   })
// });

  app.filter("percentage", function(){
    return function(input, max){
      if(isNaN(input)){
        return input;
      }
      return input + '%';
    }
  });

  app.controller('FirmController',['$scope','$q','$window','$http','$filter',  'firmService','sharedParameterService', function($scope,$q,$window, $http,$filter, firmService, sharedParameterService) {
  //  console.log($window.exportWebServiceUrl);
  $scope.exportDataUrl = $window.exportWebServiceUrl + "/GetAnalysisData";
  //$scope.exportDataUrl = "http://wtsffz2d.unitopr.unitint.test.statefarm.org/WEXDS/Home/GetAnalysisData"
  // variable for pagination calls
  $scope.timekeeperkey = "timekeepername:descending";
  $scope.anomalykey = "anomaly_description:descending";
  $scope.currentPage = 1;
  //$scope.sortOrder = false;
  $scope.sharedParameterService = sharedParameterService;
  $scope.numberOfResults = "10";
  $scope.pageNumber = "1";
  $scope.pageNumI = "1";
  $scope.searchItem = "";
  $scope.sortByField = "firm_name";
  $scope.sortByFieldLabel = "Firm Name";
  $scope.totalPageCount = "";
  $scope.totalPageLineItemCount = "";
  $scope.firmList = "";
  $scope.showfirmdetails = false;
  $scope.firmLineItems = [];
  $scope.sortType = 'id';
  $scope.currentGroupId = "";
  $scope.sortReverse = false;
  $scope.searchItem = '';
  $scope.selectedFirmIdLineItem = "";
  $scope.sortLineItemByType = "itemnumber";
  $scope.filterByMatterNumber = "";
  $scope.highlighted="";
  $scope.highlighted="";
  $scope.staffLevelList = [];
  $scope.showSidebar = true;
  $scope.searchAnomalies = "";
  $scope.rowOpen = [];
  $scope.invoiceLineItemsAnomalies = [];
  //$scope.sortDefault = "Default";
  $scope.searchSelectAllSettings = { enableSearch: true, showCheckAll: false, showUncheckAll:false,keyboardControls: true, styleActive: true,scrollable: true,scrollableHeight: '200px'};
//  $scope.totalpagestimekeeperanomalies = 0;
  // PUSH Mock data for bar charts
  iData = [];
  //iData.push({key:"Spend",y: 0, color:"#c31820"},{key:"Budget",y: 0, color:"#cbcbcb"})
  iData.push({key:"Spend",y: 0, color:"#c31820"});
  $scope.invoiceSummary=iData;
  tmpArr = [];
  //tmpArr.push("Spend","Annual Budget")
  tmpArr.push("Spend");
  $scope.billcategories=tmpArr;

  fData = [];
  fData.push({key:"Firm",y: 0, color:"#92cd0d"},
                 {key:"State Average",y: 0, color:"#cbcbcb"})
  $scope.billingRate=fData;
  tmpArr = [];
  tmpArr.push("Firm","State Average")
  $scope.ratecategories=tmpArr;

  fData = [];
  fData.push({key:"Opened",y: 0, color:"#029fdb"},
                 {key:"Closed",y: 0, color:"#cbcbcb"})
  $scope.matterActivity=fData;
  tmpArr = [];
  tmpArr.push("Opened","Closed")
  $scope.anomolycategories=tmpArr;

  $scope.matterActivityBarLabel = "Matter Activity";
  $scope.invoiceBarLabel = "Total Invoice";
  $scope.billingRateBarLabel = "Blended Billing Rate";

  $scope.firmsortList = [
      {name : "Invoices", value : "total_invoices:descending"},
      {name : "Amount", value : "sum:descending"},
      {name : "Firm Name", value : "firm_name"},
      {name : "Open Matters Count", value : "noofopenmatters"}
  ];
  monthEmptyArray  = [null,null,null,null,null,null,null,null,null,null,null,null];
  $scope.mattercounts = [{name: "Open", data:monthEmptyArray},{name: "Closed", data:monthEmptyArray}];
  $scope.monthcategories = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  $scope.billingHours = "";

  // $scope.firmsExportAnomaliesFields = ["anomaly_group_id","item_date","matter_number","matter_name","invoice_line_item_id","firm_name","full_name","line_item_anomaly_id","anomaly_description","staff_level","state","county","court_type","task_id","rate",
  // "cat_code","judge","phase","hours","matter_id","task_code","matter_open_date","matter_close_date","expense"
  // ,"supervising_attorney","net_amt","dispute_type","matter_type","matter_status","team_lead","invoice_date","invoice_anomaly_id","trial_date"];

  $scope.firmsExportAnomaliesFields =  ["invoice_anomaly_id","anomaly_group_id","item_date","anomaly_type","anomaly_description","invoice_id","invoice_line_item_number","invoice_date","firm_name","full_name","rate","cat_code","net_amt","matter_number","matter_name",
  "staff_level","state","county","court_type","judge","phase","hours","task_code","matter_open_date","expense","expense_net_amount","supervising_attorney","dispute_type","matter_type","matter_sub_type","matter_status","matter_close_date","team_lead","trial_date","disposition","disposition_date"];

  $scope.exportAnomaliesData = function(selectedTabName) {
     $scope.exportForFirmsAnomaliesList = [];
     $scope.firmsLineItemAnomaliesDataArr = [];
     $scope.firmsAnomalyArr = [];
     $scope.exportFileName = "export-firm-anomalies-" + $scope.selectedFirmid + ".csv";
     return $q.all([firmService.getFirmsAnomaliesDataExport($scope.exportDataUrl,"V_ANALYSIS_ANOMALIES_METRICS_VIEW",$scope.selectedFirmid,"","","item_date:ascending","anomalies"), firmService.getFirmsAnomaliesDataExport($scope.exportDataUrl,"V_ANALYSIS_INVOICE_ANOMALIES_METRICS_VIEW",$scope.selectedFirmid,"","","invoice_date:ascending","anomalies")])
       .then(
         function (data) {
           $scope.firmsLineItemAnomaliesDataArr = buildFirmsLineItemAnomaliesDataFormatForExcel(data[0]);
           $scope.firmsAnomalyArr = buildFirmsAnomaliesDataFormatForExcel(data[1]);
           if($scope.firmsLineItemAnomaliesDataArr !== undefined && $scope.firmsAnomalyArr !== undefined){
               $scope.exportForFirmsAnomaliesList = $scope.firmsLineItemAnomaliesDataArr.concat($scope.firmsAnomalyArr);
             } else if($scope.firmsLineItemAnomaliesDataArr === undefined && $scope.firmsAnomalyArr !== undefined){
                $scope.exportForFirmsAnomaliesList = $scope.firmsAnomalyArr;
             } else if($scope.firmsLineItemAnomaliesDataArr !== undefined && $scope.firmsAnomalyArr === undefined){
                $scope.exportForFirmsAnomaliesList = $scope.firmsLineItemAnomaliesDataArr;
             } else {
               console.log("Both anomalies array are empty");
             }
            return $scope.exportForFirmsAnomaliesList;
         },
         function (error) {
             console.log("Error while calling export for anomalies" + error);
         }
       );
   }

 // Format the data for excel.
 function buildFirmsLineItemAnomaliesDataFormatForExcel(origData) {
    $scope.firmsLineItemAnomaliesDataArr = [];
    var anomaliesDataList = [];
    var dataArr = [];
    var tmp = "";
    if(origData.length > 0)
    {
      origData = origData.slice(0,-1);
    }
    for (var item in origData) {
     tmp = getFormattedDataAnomaliesRow(origData[item],"lineitem");
     dataArr.push(tmp);
    }
     var retVal = dataArr.map(function(each){
          return JSON.parse(each)
     });
     $scope.firmsLineItemAnomaliesDataArr = retVal.sort();
     return $scope.firmsLineItemAnomaliesDataArr;
  }

function buildFirmsAnomaliesDataFormatForExcel(origData) {
   $scope.firmsAnomalyArr = [];
   var anomaliesDataList = [];
   var dataArr = [];
   var tmp = "";
   if(origData.length > 0)
   {
     origData = origData.slice(0,-1);
   }
   for (var item in origData) {
    tmp = getFormattedDataAnomaliesRow(origData[item],"invoiceitem");
    dataArr.push(tmp);
   }
   //console.log(dataArr);
    var retVal = dataArr.map(function(each){
         return JSON.parse(each)
    });
   $scope.firmsAnomalyArr = retVal.sort();
   return $scope.firmsAnomalyArr;
 }

function getFormattedDataAnomaliesRow(data,type) {
      var fmtDataArr = [];
      var tmp = "";
      var tmpFormat = "";
       angular.forEach(data, function(element, index) {
        tmp = "";
        if(index =="size" || index=="date_id" || index=="location_id" || index=="firm_id" || index=="matter_id" || index=="task_id" || index=="person_id" || index=="case_length_bucket" || index =="invoice_line_item_id" || index=="line_item_anomaly_id" || index=="disb_id"){
        }  else if(index == 'invoice_date' ||  index=="item_date" ||  index=="matter_open_date" ||  index=="matter_close_date" || index=="trial_date" || index == 'disposition_date'){
            element = element.slice(0, -11);
            tmp = '{"' + index + '":"' + element + '"}';
            fmtDataArr.push(tmp);
        } else {
          var cleanupChar = element.replace(/,/g, ' ');
              cleanupChar = element.replace(/["\"]/g, "'");
              tmp = '{"' + index + '":"' + cleanupChar + '"}';
              fmtDataArr.push(tmp);
         }
        });
       fmtDataArr.sort();
       var newTmp = "";
       var newTmpFormat = "";
       var mydatatmp = "";
       angular.forEach(fmtDataArr,function(value,key){
           mydatatmp = fmtDataArr.map(function(each){
           return JSON.parse(each)
         });
       });

      for (var item in mydatatmp) {
        for(var subitem in mydatatmp[item]){
          newTmp += '"' + subitem + '":"' + mydatatmp[item][subitem] + '",';
         }
        }
        if(type == "lineitem"){
        //  newTmp += '"invoice_date":"NA",';
          newTmp += '"invoice_anomaly_id":"NA",';
          newTmp += '"anomaly_type":"lineitem"';
        }
        if(type == "invoiceitem"){
          newTmp += '"anomaly_group_id":"NA",';
          newTmp += '"item_date":"NA",';
          newTmp += '"staff_level":"NA",';
          newTmp += '"phase":"NA",';
          newTmp += '"hours":"NA",';
          newTmp += '"task_code":"NA",';
          newTmp += '"expense":"NA",';
          newTmp += '"net_amt":"0",';
          newTmp += '"full_name":"NA",';
          newTmp += '"rate":"0",';
          newTmp += '"anomaly_type":"invoice"';
        }
        newTmpFormat = "{" + newTmp + "}";
        return newTmpFormat;
    }

  var dList = getPeriodHierarchy();
    //console.log(JSON.stringify(dList));
    if(dList.length > 0)
    {
      $scope.selectedPageDateFilter = dList[0].title;
      $scope.expand_page_date_filter = false;
      $scope.sharedParameterService.setSharedParameter("datefilter",dList[0].id);
      $scope.datefilter = dList[0].id;
    }

    $scope.list = dList;

    $scope.mattersFilterList =  [{"id":"hours","title":"Hours"},{"id":"net_amt","title":"Spend"}];
    $scope.billingPeriodList = [{"id":"30", "title":"30 Days"},{"id":"90", "title":"90 Days"}, {"id":"180", "title":"180 Days"}]

$scope.ytdList = [
    {name : "2016", value : "01/01/2016-12/31/2016"},
    {name : "2015", value : "01/01/2015-12/31/2015"}
];

//$scope.firmAnomalies = {"totalNumberOfInvoices":"12","totalNumberOfLineItems":"76", "totalNumberOfAnomalies":"112"}
$scope.firmAnomalies = [];
$scope.timekeeperanomalieslist = [];
$scope.timekeeperinvoiceanomalieslist = [];

$scope.selectPeriod = function(selectedVal)
{
  if(selectedVal != '')
  {
  //  console.log(selectedVal);
    $scope.selectedPageDateFilter = selectedVal.split(":")[1];
    $scope.expand_page_date_filter = false;
    $scope.sharedParameterService.setSharedParameter("datefilter",selectedVal.split(":")[0]);
    $scope.datefilter = selectedVal.split(":")[0];
    //alert("selectPeriod");
    getFirmLineItemsData($scope.selectedFirmid,$scope.datefilter);
    $scope.show_DropDown = false;
    updateMatterActivityGraph();
  }
}

$scope.selectStaffLevel = function(selectedVal)
{
  if(selectedVal != '')
  {

    $scope.expand_staff_level_selection = false;
    $scope.selectedStaffLevel = selectedVal.split(":")[1];
    $scope.sharedParameterService.setSharedParameter("staffLevel",selectedVal.split(":")[0]);
  }
}

$scope.selectTkaStaffLevel = function(selectedVal,selectFirmId)
{
  staffFilter = "";
  if(selectedVal != '')
  {

    $scope.expand_tka_staff_level_selection = false;
    $scope.selectedTkaStaffLevel = selectedVal.split(":")[1];
    if(selectedVal.split(":")[0] !="")
    {
         staffFilter = "staff_level>>"+selectedVal.split(":")[0];
         console.log("$scope.selectedFirmid ***** = " + $scope.selectedFirmid);
    }
    if(selectFirmId != '')
    {
       staffFilter = "firm_id>>" + selectFirmId + "||%26%26" + staffFilter;
       console.log("$scope.selectedFirmid when selectFirmId ***** = " + staffFilter);
    }

    $scope.sharedParameterService.setSharedParameter("tkaStaffLevelFilter",staffFilter);
  } else {
    staffFilter = "firm_id>>" + selectFirmId + "||";
    console.log("$scope.selectedFirmid when selectFirmId and selectevalue is empty ***** = " + staffFilter);
  }

  $scope.sharedParameterService.setSharedParameter("tkaStaffLevelFilter",staffFilter);
  // call normalized table.
  getFirmsTimekeeperNormalizedAnomalies(staffFilter,"anomaly_description","full_name",$scope.datefilter);

}

$scope.selectTopMatterView = function(selectedVal)
{
  if(selectedVal != '')
  {
    $scope.expand_top10matters_view_selection = false;
    $scope.selectedTop10MattersView = selectedVal.split(":")[1];
    $scope.sharedParameterService.setSharedParameter("top10mattersview",selectedVal.split(":")[0]);
  }
}

$scope.staffChangeEventListeners = {
      onSelectionChanged: onStaffSelectionChanged
  };

  function onStaffSelectionChanged() {
  //  console.log($scope.selectStaffModel);
  }

 // Accordion
  $scope.oneAtATime = true;


 $scope.status = {
   isCustomHeaderOpen: false,
   isFirstOpen: true,
   isFirstDisabled: false,
   open: true
 };

   $scope.timekeepers=[
       {"id" : "1", "name": "Derek S Jamison", "title": "Partner ", "billingRate": "225", "billingToDate": "234,436", "openMattersCount": "5", "ytdOpenMatters": "9", "ytdClosedMatters": "5", "avgCostPerMatter": "13.5", "avgAnomalies": "3", "open": true },
       {"id" : "2","name": "Sharon S Johansen", "title": "Associate ", "billingRate": "170", "billingToDate": "334,436", "openMattersCount": "7", "ytdOpenMatters": "8", "ytdClosedMatters": "3", "avgCostPerMatter": "30", "avgAnomalies": "9", "open": false},
       {"id" : "3","name": "Kelly J Sherman", "title": "Managing Partner ", "billingRate": "876", "billingToDate": "134,092", "openMattersCount": "1", "ytdOpenMatters": "3", "ytdClosedMatters": "2", "avgCostPerMatter": "91.9", "avgAnomalies": "1", "open": false},
       {"id" : "4","name": "Rodrigo P Condozo", "title": "Partner ", "billingRate": "248", "billingToDate": "210,201", "openMattersCount": "8", "ytdOpenMatters": "10", "ytdClosedMatters": "2", "avgCostPerMatter": "42.1", "avgAnomalies": "14", "open": false}

   ];
   /*
   $scope.goToTimekeeper = function(timekeeper, tkNameCol)
   {
       $scope.selectedTimekeeper = timekeeper[tkNameCol];
       $scope.toShow = 'Timekeepers';
       $scope.sharedParameterService.setSharedParameter("loadTimekeeper","true");
       $scope.loadTimekeeper = true;
   }
   */


   $scope.goToTimekeeper = function(timekeeper, tkNameCol, isNewWindow) {
     if(isNewWindow) {
       //console.log("right-click activated");
       //window.open("/AppBuilder/firms?firm=" + $scope.selectedFirm.properties.firm_name[0] + "&tab=Timekeepers&tkname=" + timekeeper[tkNameCol], "fa")
     } else {
         $scope.selectedTimekeeper = timekeeper[tkNameCol];
         $scope.toShow = 'Timekeepers';
         $scope.sharedParameterService.setSharedParameter("loadTimekeeper","true");
         $scope.loadTimekeeper = true;
       }
   }

   $scope.goToAnomalies = function(timekeeper, tkNameCol, isNewWindow) {
     if (isNewWindow) {
       //console.log("right-click activated");
       //window.open("/AppBuilder/firms?firm=" + $scope.selectedFirm.properties.firm_name[0] + "&tab=Anomalies&tkname=" + timekeeper[tkNameCol], "fa")
     } else {
         $scope.searchAnomalies = timekeeper[tkNameCol];
         $scope.toShow = 'Anomalies';
         $scope.sharedParameterService.setSharedParameter("loadTimekeeper",undefined);
         $scope.getAnomalySearchedData($scope.searchAnomalies);
       }
   }

   $scope.loadTimekeeperTab = function()
   {
       $scope.toShow = 'Timekeepers'
       $scope.sharedParameterService.setSharedParameter("loadTimekeeper","true");
       $scope.loadTimekeeper = true;
   }

   $scope.expandTimekeeper = function(event, params )
   {
    //   console.log("Fired on expand timekeeper : " + params[1].value + " :: " + params[0].value.name);
    //   console.log(params[0].value);
       if(!$scope.sharedParameterService.getSharedParameter("topTKMattersKpi")){
           $scope.sharedParameterService.setSharedParameter("topTKMattersSort","hours");
           $scope.selectedTKMFilter = "Hours"
       }
       $scope.sharedParameterService.setSharedParameter("selectedTKIndex", params[1].value);
       $scope.sharedParameterService.setSharedParameter("timekeeperName"+params[1].value, params[0].value.name);
       updateTimekeeperSummary(params[0].value.name, params[1].value)

   }

  function updateTimekeeperSummary(timekeeper, selectedIndex)
  {
    dateFilter = $scope.datefilter;
    firmId = $scope.selectedFirmid;
    if(!$scope.timekeeperDetails)
    {
        $scope.timekeeperDetails = {};
    }
    if(!$scope.timekeeperDetails[selectedIndex])
    {
        $scope.timekeeperDetails[selectedIndex] = new Object();
    }
    firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget1")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                    //   console.log('AverageBillrate' + mydata.avgbillrate);
                       $scope.timekeeperDetails[selectedIndex].avgBillRate =  mydata.avgbillrate;
           });
    firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget2")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                    //   console.log('Billing to Date' + mydata.billing);
                       $scope.timekeeperDetails[selectedIndex].billing =  mydata.billing;
           });
    firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget3")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                    //   console.log('Matter Count' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].matterCount =  mydata.mattercount;
           });
     firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget4")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                    //   console.log('Cost Per Matter Matter ' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].costPerMatter =  mydata.costpermatter;
           });
    firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget6")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                    //   console.log('Cost Per Matter Matter ' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].avgAnomalies =  mydata.avganomalies;
           });
    firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget11")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                    //   console.log('Cost Per Matter Matter ' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].activeMatters =  mydata.activematters;
           });
     firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget12")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                    //   console.log('Cost Per Matter Matter ' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].avgStateLevelRate =  mydata.avgstatelevelrate;
           });
    firmService.getBillingActivity(firmId,timekeeper, dateFilter)
                 .then(
                    function( mydata ) {
                        $scope.billingHours = mydata;
                  //   console.log("$scope.billingHours = "+$scope.billingHours);
          });
  }


   $scope.expandAnomaly = function(event, params )
   {
  //  console.log("Fired on expand");
    $scope.sharedParameterService.setSharedParameter(params[0].name, params[0].value);
  //  console.log(event);
   }

   $scope.selectMatterFilter = function(selectedVal)
   {
//      console.log(selectedVal);
    //alert("selectPeriod");
      selectedIndex = $scope.sharedParameterService.getSharedParameter("selectedTKIndex");
      $scope.sharedParameterService.setSharedParameter("topTKMattersKpi", selectedVal.split(":")[0]);
     $scope.sharedParameterService.setSharedParameter("topTKMattersSort", selectedVal.split(":")[0]);
      $scope.selectedTKMFilter = selectedVal.split(":")[1];
      $scope.show_MFLDropDown = false;
   }

    $scope.selectBillingPeriod = function(selectedVal)
    {
  //    console.log(selectedVal);
    //alert("selectPeriod");

      $scope.show_BillingDropDown = false;
    }

    // Accordion
$scope.topspendingyearselected = $scope.ytdList[0].name;
$scope.tophoursbilledyearselected = $scope.ytdList[0].name;
$scope.topviolationsyearselected = $scope.ytdList[0].name;

  $scope.topspendingyearFilter = function() {
    if($scope.topspendingyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.topspendingyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadSpendingBudgetData($scope.selectedstateCode,selectedValue);
  }

  $scope.tophoursbilledyearsFilter = function() {
    if($scope.tophoursbilledyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.tophoursbilledyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadTopHoursBilledExpenditureData($scope.selectedstateCode,selectedValue);
  }

  $scope.topviolationssyearsFilter = function() {
    if($scope.topviolationsyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.topviolationsyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadTopFirmViolationsData($scope.selectedstateCode,selectedValue);
  }


  function getUrlRequestParameters()
  {
     decodedUrl = decodeURI(location.href);
     url = decodedUrl.split("?");
     retMap = {};
     if(url.length > 1)
     {
         prevParamName = "";
         reqParamArray = url[1].split("&");
         for (i in reqParamArray)
         {
           reqParam = reqParamArray[i].split("=");
           if(reqParam.length == 2)
           {
             retMap[reqParam[0]] = reqParam[1];
             prevParamName = reqParam[0];
           }
           else
           {
              retMap[prevParamName] = retMap[prevParamName] + "&" + reqParam[0];
           }
         }
     }
    return retMap;
  }

  function init() {
    currentYear = moment().format("YYYY");
    defaultDateFilter =  "";
    $scope.sharedParameterService.setSharedParameter("datefilter",defaultDateFilter);
    $scope.sharedParameterService.setSharedParameter("searchTimekeeper", "");
    $scope.sharedParameterService.setSharedParameter("searchAnomalies", "");
    $scope.datefilter = defaultDateFilter;
    $scope.expand_staff_level_selection = false;
    $scope.expand_top10matters_view_selection = false;
    urlparams = getUrlRequestParameters();
    $scope.skipToShow = false;
    $scope.sharedParameterService.setSharedParameter("loadTimekeeper",undefined);
    if(urlparams["firm"])
    {
      $scope.searchItem = urlparams["firm"];
      $scope.getSearchedData($scope.searchItem);
      if(urlparams["tab"])
      {
         $scope.toShow = urlparams["tab"];
         $scope.skipToShow = true;
      }
      if(urlparams["tab"] && urlparams["tab"] == 'Timekeepers' && urlparams["tkname"])
      {
         $scope.selectedTimekeeper = urlparams["tkname"];
         $scope.sharedParameterService.setSharedParameter("loadTimekeeper","true");
      }
      else if(urlparams["tab"] && urlparams["tab"] == 'Anomalies' && urlparams["tkname"])
      {
        $scope.searchAnomalies = urlparams["tkname"];
      }
    }
    else {
      getFirmListData($scope.numberOfResults,$scope.pageNumber, $scope.searchItem,$scope.sortByField);
    }
  }

  function updateMatterActivityGraph()
  {
      monthEmptyArray  = [null,null,null,null,null,null,null,null,null,null,null,null];
      $scope.dormantCases = monthEmptyArray;
      $scope.closedCases = monthEmptyArray;
      $scope.openCases = monthEmptyArray;
      firmService.getMatterActivity($scope.selectedFirmid, $scope.datefilter, "closed_count")
        .then(
        function(mydata){
            $scope.closedCases = extractToMonthArray(mydata);
        //  console.log ("Closed Cases : "+ $scope.closedCases)
          firmService.getMatterActivity($scope.selectedFirmid, $scope.datefilter, "open_count")
            .then(
              function(mydata){
                $scope.openCases = extractToMonthArray(mydata);
            //    console.log ("Open Cases : "+ $scope.openCases);

                $scope.mattercounts = [{name: "Open", data:$scope.openCases},{name: "Closed", data:$scope.closedCases}];
            //    console.log($scope.mattercounts);
          });
      });
  }

  function extractToMonthArray(monthlyData)
  {
       returnArray = [null,null,null,null,null,null,null,null,null,null,null,null]
       for(i = 0; i < monthlyData.length ; i++)
       {
         month = parseInt(monthlyData[i].name);
         returnArray[month - 1] = monthlyData[i].y;
       }
    //   console.log (returnArray);
       return returnArray;
  }
  function getFirmListData(numResults,pageNum,searchStr,sortByType){
    		  firmService.getFirmListServiceData(numResults,pageNum,searchStr,sortByType)
                .then(
                  function( mydata ) {
    			             $scope.firmList = mydata;
                       if($scope.firmList.length > 0)
                       {
                          $scope.getFirmLineItemsList($scope.firmList[0]);
                      }
                    //   console.log("returned data = " + JSON.stringify(mydata));
                       $scope.totalPageCount = mydata[numResults].total;
                    //   console.log("total page count returned" + $scope.totalPageCount);
    				    });
            };

     //calling the next page data for firm list items
     $scope.getNextPageFirmData = function(pageNumber) {
      //  console.log("Calling next page data with number = " + pageNumber);
      //  console.log("next page sortby = " + $scope.sortByField);
        $scope.pageNumberLineitem = pageNumber;
        getFirmListData($scope.numberOfResults,pageNumber,$scope.searchItem,$scope.sortByField);
      //  console.log("Calling next page data ended ");
     }

     //calling the search for firm list
     $scope.getSearchedData = function(searchedString) {
      //  $scope.searchItem = searchedString
        getFirmListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
     }

     $scope.getTimekeeperSearchedData = function(searchTimekeeper){
         $scope.sharedParameterService.setSharedParameter("searchTimekeeper", searchTimekeeper);
     }
     $scope.getAnomalySearchedData = function(searchAnomalies){
         $scope.sharedParameterService.setSharedParameter("searchAnomalies", searchAnomalies);
         getFirmsAnomaliesSummary($scope.selectedFirmid,$scope.datefilter,$scope.searchAnomalies,"widget1");
         getFirmsTimekeeperAnomalies($scope.selectedFirmid,$scope.datefilter,$scope.searchAnomalies,"widget2","Default");
         getFirmsTimekeeperInvoiceAnomalies($scope.selectedFirmid,$scope.datefilter,$scope.searchAnomalies,"widget4","Default");
     }

     //calling the search for firm list
     $scope.getSortedData = function(sortByField, sortByFieldLabel) {
          //$scope.sortByField = sortByField;
          $scope.sortByFieldLabel = sortByFieldLabel;

          sortByValue = sortByField.split(":");
          sortByFieldArr = $scope.sortByField.split(':');
          if(sortByFieldArr[0] == sortByValue[0])
          {
              if(sortByFieldArr[1] == 'descending')
              {
                 sortByValue[1] = 'ascending';
              }
              else
              {
                 sortByValue[1] = 'descending';
              }
          }
          else if (sortByValue.length == 1)
          {
            sortByValue.push("ascending");
          }

        $scope.sortByField = sortByValue[0]+":"+sortByValue[1];

          getFirmListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
     }
     //calling the sort for firm list
     $scope.getFirmListSorted = function(item) {
    //    console.log("sorting the field = " + item.name);
        sortByValue = item.value.split(":");
        sortByField = $scope.sortByField.split(':');
        if(sortByField.split(':')[0] == item.value.split(":")[0])
        {
              if(sortByField[1] == 'descending')
              {
                 sortByValue[1] = 'ascending';
              }
              else
              {
                 sortByValue[1] = 'descending';
              }
        }
        else if (sortByValue.length == 1)
        {
           sortByValue.push("ascending");
        }

        $scope.sortByField = sortByValue[0]+":"+sortByValue[1];
        getFirmListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
        $scope.sortByFieldLabel = item.name;
     }



   $scope.getSortClass = function(selectedFieldForSorting) {
     if ($scope.sortLineItemByType == selectedFieldForSorting) {
       return $scope.reverseSort
       ?'arrow-down'
       :'arrow-up';
     }
      return'';
    }

    $scope.sort = function(keyname){
        //    console.log("$scope.sortOrder " + $scope.sortOrder);
            $scope.sortOrder = !$scope.sortOrder;
            $scope.timekeeperanomalieslist = sortByKeyOrder($scope.timekeeperanomalieslist,keyname,$scope.sortOrder);
            $scope.sortKey = keyname;
    }

    $scope.sortString = function(keyname){
      //console.log(JSON.stringify($scope.timekeeperanomalieslist ));
      var tmpArray = [];
      sortByValueA = keyname.split(":");
      //console.log("keyname = " + keyname);
      if(sortByValueA[0] === "timekeepername") {
          if(sortByValueA[1] === "descending") {
              sortByValueA[1]  = 'ascending';
          } else {
              sortByValueA[1]  = 'descending';
            }
            $scope.timekeeperkey = 'timekeepername:'+sortByValueA[1];
          //  console.log("$scope.timekeeperkey = " + $scope.timekeeperkey);
          } else if(sortByValueA[0] === "anomaly_description") {
              if(sortByValueA[1] === "descending") {
                  sortByValueA[1]  = 'ascending';
              } else {
                  sortByValueA[1]  = 'descending';
                }
                $scope.anomalykey = 'anomaly_description:'+sortByValueA[1];
                //console.log("$scope.anomalykey = " + $scope.anomalykey);
              }
            $scope.sortOrderStr = !$scope.sortOrderStr;
            tmpArray = sortArrOfObjectsByParam($scope.timekeeperanomalieslist,sortByValueA[0],sortByValueA[1]);
            $scope.timekeeperanomalieslist = [];
            $scope.timekeeperanomalieslist = tmpArray;
            $scope.sortKey = sortByValueA[0];
    }

    $scope.sortByDetail = function(keyname, groupId){
            $scope.sortKeyDetail = keyname;   //set the sortKeyDetail to the param passed
            $scope.reverseInvDetail = !$scope.reverseInvDetail; //if true make it false and vice versa
            sortByKey($scope.invoiceLineItemsAnomalies[groupId],keyname);

    }
    $scope.sortInv = function(keyname){
            $scope.sortKeyInv = keyname;   //set the sortKeyInv to the param passed
            $scope.reverseInv = !$scope.reverseInv; //if true make it false and vice versa
            sortByKey($scope.timekeeperinvoiceanomalieslist,keyname);
    }
    function sortArrOfObjectsByParam(arrToSort, strObjParamToSortBy, sortAscending) {
    //  console.log("params to sort" + strObjParamToSortBy + " order = " + sortAscending);
      if(sortAscending == undefined) sortAscending = 'ascending';  // default to true
    //  console.log(sortAscending);
      if(sortAscending === 'ascending') {
        arrToSort.sort(function (a, b) {
          if(a[strObjParamToSortBy] && isNaN(a[strObjParamToSortBy])) {
            return a[strObjParamToSortBy].localeCompare(b[strObjParamToSortBy]);
          }else if(!isNaN(a[strObjParamToSortBy])) {
            return a[strObjParamToSortBy] - b[strObjParamToSortBy];
          } else {
            return 1;
          }
        });
    }
    else {
    //  console.log("in else loop" + sortAscending);
        arrToSort.sort(function (a, b) {
          if(b[strObjParamToSortBy] && isNaN(b[strObjParamToSortBy])) {
            return b[strObjParamToSortBy].localeCompare(a[strObjParamToSortBy]);
          } else if(!isNaN(b[strObjParamToSortBy])){
            return b[strObjParamToSortBy] - a[strObjParamToSortBy];
          }else {
            return 1;
          }
        });
  }
//  console.log(arrToSort);
  return arrToSort;
}


    function sortByKeyOrder(array,key,type) {
            //console.log("sortByKeyOrder key = " + key + " type = " + type);
            return array.sort(function(a, b) {
                  var x = a[key]; var y = b[key];
                  if (!type) {
                      return (x-y);
                  } else {
                      return (y-x);
                  }
              });

    }
     // Line itmes details call
    $scope.getFirmLineItemsList = function(item) {
      //  console.log("calling getFirmLineItemsList function on click with firmId = " + item.properties.firm_id[0]);

        //$scope.selectedFirmid = "338518"; // hardcoded for anomalies testing purpose.
        $scope.selectedFirmid = item.properties.firm_id[0];
        $scope.sharedParameterService.setSharedParameter("selectedFirmIdFilter","firm_id>>"+$scope.selectedFirmid);
        $scope.sharedParameterService.setSharedParameter("tkaStaffLevelFilter","firm_id>>"+$scope.selectedFirmid);

        $scope.selectedFirm = item;
        if(!$scope.skipToShow)
        {
          $scope.sharedParameterService.setSharedParameter("loadTimekeeper",undefined);
          $scope.toShow='Summary';
        }else{
          $scope.skipToShow = false;
        }
        var pageNumI = $scope.pageNumI = "1";
        var searchStrI = "";
        var sortByTypeI = "itemnumber";//$scope.sortLineItemByType;// ;
        $scope.highlighted="highlighted";
    //    console.log("I am calling firm list now " + pageNumI + ", " + searchStrI + "," + sortByTypeI);
        getFirmLineItemsData($scope.selectedFirmid,$scope.datefilter)
        $scope.sharedParameterService.setSharedParameter("searchTimekeeper", "");
        $scope.searchTimekeeper = "";
        $scope.show_firmDetailView = true;
    //    console.log("showfirmdetails " + $scope.showfirmdetails);
        $scope.sharedParameterService.setSharedParameter("staffLevel",undefined);
        $scope.sharedParameterService.setSharedParameter("firmId",item.properties.firm_id[0]);
        updateDropdowns($scope.selectedFirmid,$scope.datefilter);
        updateMatterActivityGraph();
        // call the firm timekeeper normalized anomalies data.
        var filters = "firm_id>>" + $scope.selectedFirmid + "||&&";
        getFirmsTimekeeperNormalizedAnomalies(filters,"anomaly_description","full_name",$scope.datefilter);

    }

    function getFirmsTimekeeperNormalizedAnomalies(filtersT,selectedkpi,subcategory,datefilter){
      $scope.firmtimekeepernormalizedanomalieslist = [];
      $("#timekeeperrowanomalieslist_spinner").removeClass("hide");
      firmService.getFirmsTimekeeperNormalizedAnomaliesData(filtersT,selectedkpi,subcategory,datefilter)
            .then(
              function( mydata ) {
                  $scope.firmtimekeepernormalizedanomalieslist = mydata.slice(0,-1);
                  $("#timekeeperrowanomalieslist_spinner").addClass("hide");
            });
      }

    // firm anomalies invoice lineitems for timekeeper
    $scope.getFirmAnomaliesInvoiceLineItems = function(timekeepergroupid, timekeepername) {
      var filters = "";
      var widgetName = "widget3";
      filters = "firm_id>>" + $scope.selectedFirmid + "&&anomaly_group_id>>" + timekeepergroupid ;
      //filters = "firm_id>>" + $scope.selectedFirmid + "&&anomaly_desc>>" + timekeepergroupid + "&&timekeeper_name>>" + timekeepername;
     //console.log("i am in this method getFirmAnomaliesInvoiceLineItems");
      firmService.getFirmsAnomaliesSummaryData(filters,$scope.datefilter,$scope.searchAnomalies,widgetName)
            .then(
              function( mydata ) {
                $scope.currentGroupId = timekeepergroupid;
                console.log("$scope.currentGroupId = " + $scope.currentGroupId);
                  $scope.invoiceLineItemsAnomalies[timekeepergroupid] = mydata;

            //      console.log("$scope.invoiceLineItemsAnomalies = "+$scope.invoiceLineItemsAnomalies);
                });

        }
      $scope.setCurrentRow = function(index){
        //console.log("index value = " + index);
        //console.log("rowOpen value = " + $scope.rowOpen.length);
          for (i = 0; i < $scope.rowOpen.length; i++) {
       //    console.log("i = " + i);
          //$scope.rowOpen[i] = false;
        }
      $scope.rowOpen[index] = true
    }
    // Function to update the view by dropdowns based on selected firmid
    function updateDropdowns(firmId,datefilter)
    {
       updateStaffLevelDropdown(firmId,datefilter);
       updateTop10MattersDropdown(firmId)
    }

    function updateStaffLevelDropdown(firmId,datefilter)
    {
    //   console.log("Staff level firm Id " + firmId + "::" +$scope.selectedFirmid );

       firmService.getFirmStaffLevels(firmId,datefilter)
                 .then(
                   function( mydata ) {
                     sList = [{id:"", title:"All"}];
                     firstItem = "";
                     for(key in mydata)
                     {
                         var item = new Object();
                         item.id = key;
                         item.title = key;
                         sList.push(item);
                     }
                     $scope.staffLevelList = sList;
                     if(sList.length > 0)
                     {
                       $scope.selectedStaffLevel = sList[0].id;
                       sList[0].isSelected = true;
                       $scope.sharedParameterService.setSharedParameter("staffLevel",sList[0].id);
                     }
                });
    }

    function updateTop10MattersDropdown(firmId)
    {
    //   console.log("Staff level firm Id " + firmId + "::" +$scope.selectedFirmid );


       sList = [{"id":"net_amt","title":"Spend"}, {"id":"age","title":"Age"}, {"id":"dormancy_days","title":"Dormant"}];

       $scope.top10MatterViewList = sList;

       $scope.selectedTop10MattersView = sList[0].title;
       sList[0].isSelected = true;
       $scope.sharedParameterService.setSharedParameter("top10mattersview",sList[0].id);
    }

    function getFirmsAnomaliesSummary(firmId,datefilter,searchString,widgetName){
      var filters = "";
      if(!firmId){
      //    console.log("firm_id is null or undefined in getFirmsAnomaliesSummary");
      } else {
        filters = "firm_id>>" + firmId;
      }

      firmService.getFirmsAnomaliesSummaryData(filters,datefilter,searchString,widgetName)
            .then(
              function( mydata ) {
                  $scope.firmAnomalies = mydata;
          //        console.log("$scope.firmAnomalies = "+$scope.firmAnomalies);
                });
      }

      function getFirmsTimekeeperAnomalies(firmId,datefilter,searchString,widgetName,sortType){
        var filters = "";
        filters = "firm_id>>" + firmId;
        $scope.timekeeperanomalieslist = [];
        $("#timekeeperrowlist_spinner").removeClass("hide");
        firmService.getFirmsAnomaliesSummaryData(filters,datefilter,searchString,widgetName)
              .then(
                function( mydata ) {
                    //$scope.timekeeperanomalieslist = mydata.slice(0,-1);
                    $scope.timekeeperanomalieslist = formatTimeekeeperList(mydata.slice(0,-1));
                    $scope.currentPage = 1;
                    $("#timekeeperrowlist_spinner").addClass("hide");
                  });
        }

        // format timekeeper list to add the counter
        function formatTimeekeeperList(mydata) {
              var newTimekeeperArr = [];
              var i = 1;
              for (var item in mydata) {
                 var newTmpFormat = "";
                  tmp = getFormattedTimekeeperRow(mydata[item]);
                  tmp += '"counter"' + ':"' + i +	 '"';
                  newTmpFormat = "{" + tmp + "}";
                  newTimekeeperArr.push(newTmpFormat);
                  i = i + 1;
                 }
                  var retTimekeeperList = newTimekeeperArr.map(function(each){
                       return JSON.parse(each)
                  });
              // console.log(retTimekeeperList);
                return retTimekeeperList;
              }

              function getFormattedTimekeeperRow(datarecord) {
                 var newTmp = "";
                 for (var item in datarecord) {
                    newTmp += '"' + item + '":"' + datarecord[item]	+	 '",';
                 }
                 return newTmp;
              }


        // function to retrieve timekeeper anomalies as invoice level and link it to invoice page.
        function getFirmsTimekeeperInvoiceAnomalies(firmId,datefilter,searchString,widgetName,sortType){
          var filters = "";
          var sortType = "";
          filters = "firm_id>>" + firmId;
          $scope.timekeeperinvoiceanomalieslist = [];
          $("#timekeeperrowlistinvoice_spinner").removeClass("hide");
          firmService.getFirmsAnomaliesSummaryData(filters,datefilter,searchString,widgetName)
                .then(
                  function( mydata ) {
                      $scope.timekeeperinvoiceanomalieslist = mydata;
                      $("#timekeeperrowlistinvoice_spinner").addClass("hide");
                    //  console.log("$scope.timekeeperinvoiceanomalieslist = "+JSON.stringify($scope.timekeeperinvoiceanomalieslist));
                      // if(sortType == "Default"){
                      //   sortByKey($scope.timekeeperinvoiceanomalieslist,"invoice_amt");
                      //   $scope.sortKeyInv = "invoice_amt";   //set the sortKeyInv to the param passed
                      //   $scope.reverseInv = !$scope.reverseInv; //if true make it false and vice versa
                      // }
                    });
          }
    // Callback function to retrieve data for firmlineitem details.
     function getFirmLineItemsData(firmId,dateFilter){
          //$scope.invoiceSummary=[{key:'Spend',y:0},{key:'Budget',y:0}];
          $scope.invoiceSummary=[{key:'Spend',y:0}];
          $scope.billingRate=[{key:'Firm',y:0},{key:'State Average',y:0}];
          $scope.matterActivity=[{key:'Opened',y:0},{key:'Closed',y:0}];
          $scope.costPerMatter = "";
          $scope.activeMatters = "";
          $scope.averageCaseLength = "";
          $scope.dormantMatters = "";
          firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget1")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                        iData = [];
                     var test = $filter('currency')(mydata.spending, '$');
                        //iData.push({key:"YTD Spend",y: mydata.spending, color:"#c31820"},{key:"Budget",y: mydata.budget, color:"#cbcbcb"})
                        iData.push({key:"YTD Spend",y: mydata.spending, color:"#c31820"});
                        $scope.invoiceSummary=iData;
           });
           firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget2")
                 .then(
                   function( mydata ) {
                      fData = [];
                      fData.push({key:"Firm",y: mydata.firmblendedrate, color:"#92cd0d"},
                                 {key:"State Average",y: mydata.stateblendedrate, color:"#cbcbcb"})
                      $scope.billingRate=fData;
           });
           firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget3")
                 .then(
                   function( mydata ) {
                       fData = [];
                       fData.push({key:"Opened",y: mydata.opencount, color:"#029fdb"},
                                  {key:"Closed",y: mydata.closedcount, color:"#cbcbcb"})
                       $scope.matterActivity=fData;
           });
           firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget4")
                 .then(
                   function( mydata ) {
                       $scope.costPerMatter = mydata.costpermatter;
           });
           firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget5")
                 .then(
                   function( mydata ) {
                       $scope.averageCaseLength = mydata.avgcaselength;
           });
           firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget11")
                 .then(
                   function( mydata ) {
                       $scope.activeMatters = mydata.activematters;
                       $scope.dormantMatters = mydata.dormantmatters;
           });
           getFirmsAnomaliesSummary(firmId,dateFilter,$scope.searchAnomalies,"widget1");
           getFirmsTimekeeperAnomalies(firmId,dateFilter,$scope.searchAnomalies,"widget2", "Default");
           getFirmsTimekeeperInvoiceAnomalies(firmId,dateFilter,$scope.searchAnomalies,"widget4","Default");

        };

    init();


}]);

//DataService containing all the data calls from backend.

	angular.module('FirmDataService', [])
      .service('firmService', function ($http,$q) {

      // Service method to get the firm listing
      // Return service methodes.
      return({
            getFirmListServiceData: getFirmListServiceData,
            getFirmLineItemsServiceData: getFirmLineItemsServiceData,
            getFirmStaffLevels : getFirmStaffLevels,
            getMatterActivity  :  getMatterActivity,
            getFirmsAnomaliesSummaryData:getFirmsAnomaliesSummaryData,
            getTimekeperData : getTimekeperData,
            getBillingActivity: getBillingActivity,
            getFirmsAnomaliesDataExport:getFirmsAnomaliesDataExport,
            getFirmsTimekeeperNormalizedAnomaliesData:getFirmsTimekeeperNormalizedAnomaliesData

      });

      function  getFirmsTimekeeperNormalizedAnomaliesData(filters,selectedkpi,subcategory,datefilter) {
      var request = $http({
                method: "post",
                url: "/AppBuilder/endpoint/getAnomalyNormalizedTable",
                data : {
                        filters: filters,
                        selectedkpi: selectedkpi,
                        subcategory: subcategory,
                        datefilter: datefilter
                      }
            });
        return(request.then( handleSuccess, handleError ) );
      }

      // start call to get firm list service data
      function  getFirmListServiceData(numResultsS,pageNumS,searchStrS,sortByTypeS) {
       var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/getFirmList",
      			        params: {
                              noofresults: numResultsS,
                              pagenumber: pageNumS,
                              searchstring: searchStrS,
                              sortbyfield: sortByTypeS
      				        }
              });
            return(request.then( handleSuccess, handleError ) );
      		}

          // start call to get firm list service data
          function  getFirmLineItemsServiceData(firmIdL, dateFileterL, widgetNameL) {

            console.log("Passing parameters in getFirmLineItemsServiceData " + "firmeIdL = " + firmIdL + " dateFileterL = " + dateFileterL + " widgetNameL = "
            + widgetNameL);
           var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/getFirmDetails",
          			        params: {
                                  firmid: firmIdL,
                                  datefilter: dateFileterL,
                                  widgetname: widgetNameL
          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
          		}

            // start call to get firm time keeper summary data
          function  getTimekeperData(firmIdL, timekeeperL , dateFileterL, widgetNameL) {

        //    console.log("Passing parameters in getTimekeperData " + "firmeIdL = " + firmIdL + " timekeeperL = " + timekeeperL + " dateFileterL = " + dateFileterL + " widgetNameL = "
        //    + widgetNameL);
           var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/getFirmTimekeeperDetails",
          			        params: {
                                  firmid: firmIdL,
                                  datefilter: dateFileterL,
                                  widgetname: widgetNameL,
                                  timekeeper : timekeeperL
          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
          		}

              // start call to get firm sumamry for total invoices, lineitem and total anomalies service data
              function  getFirmsAnomaliesSummaryData(filtersL,datefilterS,searchStringL,widgetNameL) {
               var request = $http({
                            method: "post",
                            url: "/AppBuilder/endpoint/FirmsAnomaliesSummary",
                            params: {
                                      datefilter: datefilterS,
                                      entity:"firm",
                                      filters:filtersL,
                                      searchfilter:searchStringL,
                                      widget: widgetNameL
                              }
                      });
                    return(request.then( handleSuccess, handleError ) );
                  }

    // start call to get firm stafflevelsdata
      function  getFirmStaffLevels(firmId,datefilterS) {
       var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/getAnalysisDropdownValues",
      			        params: {
                              datefilter: datefilterS,
                              FindFieldName: "staff_level",
                              FilterValue: "firm_id>>"+firmId
      				        }
              });
            return(request.then( handleSuccess, handleError ) );
      		}
    // start call to get firm monthly activity data
      function  getMatterActivity(firmId, dateFilter, caseStatus) {
       var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/getMatterActivity",
      			        params: {
                              category: "firm_id",
                              categoryvalue : firmId,
                              datefilter : dateFilter,
                              excludetotal : 'Y',
                              filters : '',
                              noofresults : 12,
                              selectedkpi : caseStatus,
                              subcategory : 'date:%m'
      				        }
              });
            return(request.then( handleSuccess, handleError ) );
      		}

          // start call to get billing activity data
            function  getBillingActivity(firmId, timekeeper, dateFilter) {
             var request = $http({
                          method: "post",
                          url: "/AppBuilder/endpoint/apoorvanalysischarts",
                          params: {
                                    category: "full_name",
                                    categoryvalue : timekeeper+"||",
                                    charttype:"timeline",
                                    datefilter : dateFilter,
                                    filters : "firm_id>>"+firmId,
                                    selectedkpi : "hours",
                                    subcategory : "full_name"
                            }
                    });
                  return(request.then( handleSuccess, handleError ) );
                  }

                  function getFirmsAnomaliesDataExport(dataUrlL,entityL,firmIdL,searchStrL,dateFilterL,sortByTypeL,selectedtab) {
                   var request = $http({
                                method: "GET",
                                url: dataUrlL,
                                params: {
                                        viewname:entityL,
                                        firmid:firmIdL,
                                        searchstring: searchStrL,
                                        datefilter: dateFilterL,
                                        sortby: sortByTypeL,
                                        tabname:selectedtab
                                  }
                          });
                        return(request.then( handleSuccess, handleError ) );
                      }

      // Common method to handle the request from the server
      function handleError( response ) {
        //console.log(response.data);
          if (
              ! angular.isObject( response.data ) ||
              ! response.data.message
              ) {
              return( $q.reject( "An unknown error occurred." ) );
          }
          return( $q.reject( response.data.message ) );
      }
      function handleSuccess( response ) {

      //  console.log(response.data);
		  return( response.data);
      }
	   // end call to get data from service.


	  });

var DEFAULT_ID = '__default';

function getPeriodHierarchy()
{
     var dList = [{id:"",title:"All Time"}];

    currentYear = moment().format("YYYY");
    i = 0;
    while( currentYear - i >= 2012)
    {

            var item = new Object();
            item.id = "01/01/" + (currentYear - i) + "-" + moment((currentYear - i)+"-01-01").endOf("year").format("MM/DD/YYYY");
            item.title = (currentYear - i);
            item.items = [];
            for(j = 1 ; j < 12; j+=3)
            {
                    qDateStr = "0"+j +"/01/" + (currentYear - i);
                    if(moment().fquarter(1).start > moment(qDateStr).fquarter(1).start)
                    {
                            var qItem = new Object();
                            qItem.id = moment(moment(qDateStr).fquarter(1).start).format("MM/DD/YYYY") +"-"+ moment(moment(qDateStr).fquarter(1).end).format("MM/DD/YYYY");
                            qItem.title = moment(qDateStr).fquarter(1).toString();
                            qItem.displayTitle = qItem.title + " " + (currentYear - i);
                            qItem.items = [];
                            for(k = j ; k < j+3; k++)
                            {
                                    var mItem = new Object();
                                    startDateStr = "";
                                    if(k < 10)
                                    {
                                            startDateStr = "0"+k +"/01" +"/"  + (currentYear - i);
                                        }
                                        else
                                        {
                                                startDateStr =  k +"/01"+ "/" +(currentYear - i);
                                        }
                                        //console.log(startDateStr);
                                        mItem.id = moment(startDateStr).format("MM/DD/YYYY") +"-"+ moment(startDateStr).endOf("month").format("MM/DD/YYYY");
                                        mItem.title = moment(startDateStr).format("MMM");
                                        mItem.displayTitle = mItem.title + " " + (currentYear - i);
                                    qItem.items.push(mItem)
                            }
                            item.items.push(qItem)
                    }
            }
            dList.push(item);
            i++;
    }
    return dList;
}

// PRINT Tab FUNCTION
function printTab(tabName) {

    var pdf = new jsPDF("l","pt","a3", true);
        combinedElement = document.body;
  		  if(tabName)
        {
          combinedElement = document.getElementById("printPlaceHolder");
          combinedElement.innerHTML =  document.getElementById("header").innerHTML +  document.getElementById(tabName).outerHTML;
          combinedElement.style.display = "";
          combinedElement.parentElement.style.marginTop="1000px"
      //    combinedElement.parentElement.style.width="1150px";
         	//convertHtmlElement = document.getElementById(tabName);
        }

        html2pdf(combinedElement, pdf, function(pdf) {
            combinedElement.style.display = "none";
            combinedElement.parentElement.style.marginTop="0px"
            combinedElement.innerHTML = "";
            if(tabName == "Summary")
            {
              pdf.addPage();
              html2pdf(document.getElementById("topMatterAndActivity"), pdf, function(pdf) {
                pdf.addPage();
                html2pdf(document.getElementById("top10Tables"), pdf, function(pdf) {
                   pdf.save("Firms-" + (new Date().getTime())+ ".pdf");
                },{width:1600});
              },{width:1600});
            }
            else{
              pdf.save("Firms-"+ tabName+"-" + (new Date().getTime())+ ".pdf");
            }
         },{width:1600}
        );
}

</script>
