'use strict';
/**
 * @ngdoc function
 * @name wexdashboard.controller:DashboardController
 * @description
 * # DashboardController
 * Controller of the wexdashboard home
 */
angular.module('wexdashboard')
  .controller('DashboardController', ['$scope','$state','billingService',function($scope,$state,billingService){

$scope.ytdList = [
    {name : "2016", value : "01/01/2016-12/31/2016"},
    {name : "2015", value : "01/01/2015-12/31/2015"}
];
$scope.mapstateselected="";
$scope.topspendingyearselected = $scope.ytdList[0].name;
$scope.topfirmyearselected = $scope.ytdList[0].name;
$scope.topanomaliesyearselected = $scope.ytdList[0].name;
$scope.spendingHours = "";
$scope.billedHours = "";
$scope.violationHours = "";
$scope.topTrackedMatters = "";
$scope.topStateExpenditureData = "";
$scope.topFirmAnomaliesData = "";
$scope.dataSpendingByBudgetLoaded = false;
$scope.dataHoursBilledLoaded = false;
$scope.dataViolationsLoaded = false;
$scope.dataTrackedMattersLoaded = false;
$scope.dataTopExpendituresLoaded = false;
$scope.dataTopAnamoliesLoaded = false;
$scope.filterDefaultDate = "01/01/2016-12/31/2016";
$scope.billingHoursDefaultDate = "01/01/2015-12/31/2016";
$scope.violationHoursDefaultDate = "01/01/2015-12/31/2016";

// both states widget 1d2
var spendingHoursCurrencyFormat = d3.format("$,.3s");

function init() {
     // load the initial data for dashboard
     console.log("loading the data");
   loadSpendingBudgetData($scope.filterDefaultDate);
   loadBillingHoursData($scope.billingHoursDefaultDate);
   loadVoilationData($scope.violationHoursDefaultDate);
   loadTrackedMattersData($scope.filterDefaultDate);
   loadTopFirmExpenditureData($scope.filterDefaultDate);
   loadTopFirmAnamoliesData($scope.filterDefaultDate);
};

// function for spending year filter change
$scope.topspendingyearFilter = function() {
  if($scope.topspendingyearselected == '2016'){
    selectedValue = $scope.ytdList[0].value;
  } else if($scope.topspendingyearselected == '2015'){
    selectedValue = $scope.ytdList[1].value;
  }
  loadSpendingBudgetData(selectedValue);
}

// function for firms year filter change
$scope.topfirmyearsFilter = function() {
  if($scope.topfirmyearselected == '2016'){
    selectedValue = $scope.ytdList[0].value;
  } else if($scope.topfirmyearselected == '2015'){
    selectedValue = $scope.ytdList[1].value;
  }
  loadTopFirmExpenditureData(selectedValue);
}



// function for anamolies year filter change
$scope.topanamoliesyearsFilter = function() {
  if($scope.topanomaliesyearselected == '2016'){
    selectedValue = $scope.ytdList[0].value;
  } else if($scope.topanomaliesyearselected == '2015'){
    selectedValue = $scope.ytdList[1].value;
  }
  loadTopFirmAnamoliesData(selectedValue);
}

// Method to be called from controller to get the spending update data from service.

function loadSpendingBudgetData(filterdate){

  var categoryS = "state";
  var categorySvalue = "";
  var filtersS = "";
  var selectedkpiS = "netamount";
 // var subcategoryS = "itemdate";
  var subcategoryS = "firmname";
 // var datefilterS = "01/01/2016-12/31/2016";
  var datefilterS = filterdate;
 // console.log("loadSpendingBudgetData = " + filterdate);
  // call the service and filter out the data for scope variable.

  billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
        .then(
          function( mydata ) {
      var spendingByBudget = d3.nest()
         //    .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.descending)
     .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
             .entries(mydata);
    // console.log("spending by budget filter = " +  spendingByBudget);
      $scope.spendingHours = spendingHoursCurrencyFormat(spendingByBudget);
        $scope.dataSpendingByBudgetLoaded = true;
    }
  );
    };

// end of retrieve spending method.

// load data for billing hours starts here
function loadBillingHoursData(filterdate){
  var categoryS = "state";
  var categorySvalue = "";
  var filtersS = "";
  var selectedkpiS = "hours";
  var subcategoryS = "itemdate";
  var datefilterS = filterdate;
  // call the service and filter out the data for scope variable.

   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
        .then(
          function( mydata ) {
            var billedByHours = d3.nest()
             .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.descending)
             .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
             .entries(mydata);
           //   console.log(JSON.stringify(billedByHours));
              $scope.billedHours = billedByHours;
              $scope.dataHoursBilledLoaded = true;
          }
        );
    };

// load data for billing hours ends here

// load data for violations starts here

function loadVoilationData(filterdate){
  var categoryS = "state";
  var categorySvalue = "";
  var filtersS = "";
  var selectedkpiS = "AnomalyDollars";
  var subcategoryS = "itemdate";
  var datefilterS = filterdate;

  // call the service and filter out the data for scope variable.
   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
        .then(
          function( mydata ) {
            var violationByHours = d3.nest()
             .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.ascending)
             .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
             .entries(mydata);
              $scope.violationHours = violationByHours;
              $scope.dataViolationsLoaded = true;
          }
        );
    };

// load data for violations ends here

// load data for tracked matters starts here

function loadTrackedMattersData(filterdate){
  var categoryS = "state";
  var categorySvalue = "";
  var filtersS = "";
  var selectedkpiS = "netamount";
  var subcategoryS = "mattername";
  var datefilterS =  filterdate;
  // call the service and filter out the data for scope variable.
   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
        .then(
          function( mydata ) {
    var trackedMatters = d3.nest()
      .key(function(d){ return d.name; })
      .rollup(function(leaves){
        return leaves.map(function(d){
          return d.value;
        }).sort(d3.descending).slice(0, 3);
    })
    .entries(mydata);
       $scope.topTrackedMatters = trackedMatters;
             $scope.dataTrackedMattersLoaded = true;
          }
        );
    };

// load data for violations ends here

// load data for expenditure matters starts here

function loadTopFirmExpenditureData(filterdate){

  var categoryS = "state";
  var categorySvalue = "";
  var filtersS = "";
  var selectedkpiS = "netamount";
  var subcategoryS = "firmname";
  var datefilterS = filterdate;
  // call the service and filter out the data for scope variable.

   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
        .then(
          function( mydata ) {
          //  console.log("localData for expediture data  = " + JSON.stringify(mydata));
            var topFirmByExpenditures = d3.nest()
            // .key(function(d) { return d.name}).sortKeys(d3.ascending)
     .key(function(d) { return d.name})
             .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
     .entries(mydata);
     var top5Firms = topFirmByExpenditures.slice(0,5);
              $scope.topStateExpenditureData = top5Firms;
              $scope.dataTopExpendituresLoaded = true;
          }
        );
    };

// load data for top expenditure ends here

// load data for firm anamolies starts here

function loadTopFirmAnamoliesData(filterdate){
//	  var categoryS = "state";
    // added for new query
  var stateS = "";
  var categorySvalue = "";
  var filtersS = "";
  var selectedkpiS = "AnomalyCount";
  var subcategoryS = "firmname";
  var datefilterS = filterdate;

  // call the service and filter out the data for scope variable.

   //billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
   billingService.getAnomaliesData(stateS)
        .then(
          function( mydata ) {
            //console.log("localData for expediture data  = " + JSON.stringify(mydata));
            var topFirmByAnamolies = d3.nest()
            // .key(function(d) { return d.name}).sortKeys(d3.descending)
             .key(function(d) { return d.name})
     .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
     .entries(mydata);
      var top5Anomalies = topFirmByAnamolies.slice(0,5);
              $scope.topFirmAnomaliesData = top5Anomalies;
              $scope.dataTopAnamoliesLoaded = true;
          }
        );
    };

// load data for top anamolies ends here

// setup the mapobject for rendering state map

$scope.mapObject = {
    scope: 'usa',
    options: {
      width: 600,
      legendHeight: 60 // optionally set the padding for the legend
    },
    geographyConfig: {
      highlighBorderColor: '#306596',
      highlighBorderWidth: 2
    },
    fills: {
      'HIGH': '#CC4731',
      'MEDIUM': '#c31820',
      'LOW': '#306596',
      'defaultFill': '#DDDDDD'
    },
    data: {
      "IN": {
        "fillKey": "MEDIUM",
      },
      "TX": {
        "fillKey": "MEDIUM",
      }
    },
  };

  // Method to update the charts when map is clicked. Currently working only for one state at a time. Need to fix multiple state selection.

   $scope.updateActiveState = function(geography) {
    // get the selected state values
    $scope.stateName = geography.properties.name;
    $scope.stateCode = geography.id;
    console.log("statename = "+$scope.stateName);

    $scope.mapObject = {
      scope: 'usa',
      options: {
        width: 400,
        legendHeight: 60 // optionally set the padding for the legend
      },
      geographyConfig: {
        highlighBorderColor: '#306598',
        highlighBorderWidth: 2
      },
      fills: {
        'HIGH': '#CC4731',
        'MEDIUM': '#dcdcbd',
        'LOW': '#306596',
        'defaultFill': '#DDDDDD'
      },
      data: {
        "IN": {
          "fillKey": "MEDIUM",
        },
        "TX": {
          "fillKey": "MEDIUM",
        }
      },
      };
    };
console.log("calling the init");
init();
}]);
