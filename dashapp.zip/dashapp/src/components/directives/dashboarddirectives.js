'use strict';

/**
 * @ngdoc directive
 * @name wexdashboard.directive:dashboard
 * @description
 * # dashboard
 */
var app = angular.module('wexdashboard');
// Reusable Directive for bar Chart - Use <div bar-chart data="stateBillingData" ></div> where data parameter should be different
app.directive('barChart', function($window){
return {
restrict:'EAC',
template:"",
scope:{
      data: '=data'
 },
link: function (scope,elem,attrs){
 var chartElement = elem[0];
 // variable to hold dc chart
 var chartFactory = dc['barChart'];
 // Create an unconfigured instance of the chart
 var sfBarChart = chartFactory(chartElement,'barchartgroup1');

 var dataToPlot;
var widgetCurrency = attrs["widgettype"];
//	console.log("widgetCurrency = " + widgetCurrency);
 var barLabelCurrencyFormat = d3.format(".3s");

if(widgetCurrency == "violationswidget") {
barLabelCurrencyFormat = d3.format("$,.3s");
}

// set the watch for the data changes. if the values are changed then update the bar chart, else draw the same.

 scope.$watch('data', function (newVal, oldVal) {
     if(newVal!=oldVal){

       dataToPlot = newVal;
       updateBarChart(dataToPlot);

     } else {

       dataToPlot = newVal;
       drawBarChart(dataToPlot);
      }
 });

function preSetupChartParameters() {

   sfBarChart
     .width(260)
     .height(270)
     .margins({top: 10, right: 50, bottom: 20, left: 40})
     .gap(0)
     .brushOn(false)
     .yAxisLabel("")
     .xUnits(dc.units.ordinal)
 }

function postSetupChartParameters(data) {

     sfBarChart
     .on('renderlet',function () {
     var barsData = [];
     var dataLabelValues = []; // place holder for adding data labels.
     var bars = sfBarChart.selectAll('.bar').each(function (d) {
   barsData.push(d);
     });
for(var i = 0; i < data.length ; i++)
{
//	console.log("dataLabelValues Data values = " + data[i].key );
 dataLabelValues.push(data[i].key);
};
dataLabelValues.reverse();
// //Remove old values (if found)
//console.log("bars value = " + barsData[0].values);
     d3.select(bars[0][0].parentNode).select('#inline-labels').remove();
     // //Create group for labels
     var gLabels = d3.select(bars[0][0].parentNode).append('g').attr('id', 'inline-labels');
     //  console.log("gLabels = " +gLabels);
     for (var i = bars[0].length - 1; i >= 0; i--) {
         var b = bars[0][i];
//	console.log("b=" + b);
 //Only create label if bar height is tall enough
         if (+b.getAttribute('height') < 18) continue;
 //console.log("barsData[i].values " + barsData[i].data.value);
 var myLabel = barLabelCurrencyFormat(barsData[i].data.value);
 var myLabelYtd = dataLabelValues[i];
//	console.log("myLabelYtd = " + myLabelYtd);
           gLabels.append("text")
           .text(myLabel)
   .attr("class","barlabelchart")
           .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
           .attr('y', +b.getAttribute('y') + 20)
           .attr('text-anchor', 'middle')
           .attr('fill', 'white')

   gLabels.append("text")
           .text(myLabelYtd)
   .attr("class","barlabelchartytd")
           .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
           .attr('y', +b.getAttribute('y') + 40)
           .attr('text-anchor', 'middle')
           .attr('fill', 'white')
           }
         });
     sfBarChart.yAxis().ticks(0); // hide the yAsix labels
     sfBarChart.xAxis().tickValues([]); // hide the xAxis labels
 }

 // Function to draw default bar chart

 function drawBarChart(data) {

 preSetupChartParameters();
 //console.log("data in drawBarChart = " + JSON.stringify(data));

 var dataToPlotFiltered = crossfilter(data);
 //console.log("data in drawBarChart filtered = " + JSON.stringify(dataToPlotFiltered));

 var yearsDim = dataToPlotFiltered.dimension(function (d) {
//console.log("years = " + d.key);
     return d.key;
 });
 var hoursGroup = yearsDim.group().reduceSum(function (d) {
   //  console.log("hoursGroup = " + d.values);
     return d.values;
 });

var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
var keys = sortByValues.map(function (d) { return d.key; });

 var chartcolortypeL = attrs["chartcolortype"];
  if(chartcolortypeL == 'blue') {

    var barColorRangeA ="#029fdb";
    var barColorRangeB = "#cbcbcb";
  } else {
    var barColorRangeA ="#cbcbcb";
    var barColorRangeB = "#c31820";
  }


//var initialScaleData = [600, 2000]; // this is the problem.
//var jsondata = JSON.parse(JSON.stringify(data));
var initialScaleData = [];
for(var i = 0; i < data.length ; i++)
 {
   //console.log("initial Scale Data values = " + data[i].values );
   initialScaleData.push(data[i].values);

};

//console.log('new array is ' + initialScaleData);
sfBarChart
   .dimension(yearsDim)
   .group(hoursGroup)
//   .x(d3.scale.ordinal().domain(1000))
.x(d3.scale.ordinal().domain(keys))
   .y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))

   .on('pretransition', function (sfBarChart) {
       var colors = d3.scale.ordinal().domain(yearsDim)
         .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820

   sfBarChart.selectAll('rect.bar').each(function(d){
             d3.select(this).attr("style", "fill: " + colors(d.data.key));
         });

   })
   postSetupChartParameters(data);
     dc.renderAll('barchartgroup1');
   }

 // Function to update the bar chart with changed data. This will be called based on the changed scope data.

 function updateBarChart(data) {

 preSetupChartParameters();
//  console.log(JSON.stringify(data));
 var dataToPlotFiltered = crossfilter(data);
 // console.log(JSON.stringify(dataToPlotFiltered));
 var yearsDim = dataToPlotFiltered.dimension(function (d) {
 //  console.log("years = " + d.year);
 return d.key;
 });
 var hoursGroup = yearsDim.group().reduceSum(function (d) {
 //    console.log("hoursGroup = " + d.hours);
     return d.values;
 });

var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
var keys = sortByValues.map(function (d) { return d.key; });

 var chartcolortypeL = attrs["chartcolortype"];
  if(chartcolortypeL == 'blue') {
    var barColorRangeA ="#029fdb";
    var barColorRangeB = "#cbcbcb";
  } else {
    var barColorRangeA ="#cbcbcb";
    var barColorRangeB = "#c31820";
  }
// var initialScaleData = [600, 2000];
//var jsondata = JSON.parse(JSON.stringify(data));
var initialScaleData = []; for(var i = 0; i < data.length ; i++) {initialScaleData.push(data[i].values)};
//console.log('new array is '+initialScaleData);
 sfBarChart
   .dimension(yearsDim)
   .group(hoursGroup)
 //  .x(d3.scale.ordinal().domain(1000))
.x(d3.scale.ordinal().domain(keys))
   .y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))
   .on('pretransition', function (sfBarChart) {
       var colors = d3.scale.ordinal().domain(yearsDim)
         .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820
         sfBarChart.selectAll('rect.bar').each(function(d){
             d3.select(this).attr("style", "fill: " + colors(d.data.key));
         });
   })
   postSetupChartParameters(data);

   dc.redrawAll('barchartgroup1');
   }
 }

};
});



// second Directive for bar Chart - Use <div bar-chart data="stateBillingData" ></div> where data parameter should be different
app.directive('baraChart', function($window){
return {
restrict:'EAC',
template:"",
scope:{
      data: '=data'
 },
link: function (scope,elem,attrs){
 var chartElement = elem[0];
 // variable to hold dc chart
 var chartFactory = dc['barChart'];
 // Create an unconfigured instance of the chart
 var sfBarAChart = chartFactory(chartElement,'barchartgroup2');

 var dataToPlot;
var widgetCurrency = attrs["widgettype"];
//	console.log("widgetCurrency = " + widgetCurrency);
 var barLabelCurrencyFormat = d3.format(".3s");

if(widgetCurrency == "violationswidget") {
barLabelCurrencyFormat = d3.format("$,.3s");
}

// set the watch for the data changes. if the values are changed then update the bar chart, else draw the same.

 scope.$watch('data', function (newVal, oldVal) {
     if(newVal!=oldVal){

       dataToPlot = newVal;
       updateBarAChart(dataToPlot);

     } else {

       dataToPlot = newVal;
       drawBarAChart(dataToPlot);
      }
 });

function preSetupChartParameters() {

   sfBarAChart
     .width(260)
     .height(270)
     .margins({top: 10, right: 50, bottom: 20, left: 40})
     .gap(0)
     .brushOn(false)
     .yAxisLabel("")
     .xUnits(dc.units.ordinal)
 }

function postSetupChartParameters(data) {

     sfBarAChart
     .on('renderlet',function () {
     var barsData = [];
     var dataLabelValues = []; // place holder for adding data labels.
     var bars = sfBarAChart.selectAll('.bar').each(function (d) {
           barsData.push(d);
     });
for(var i = 0; i < data.length ; i++)
{
//	console.log("dataLabelValues Data values = " + data[i].key );
 dataLabelValues.push(data[i].key);
};
dataLabelValues.reverse();
     // //Remove old values (if found)
//console.log("bars value = " + barsData[0].values);
     d3.select(bars[0][0].parentNode).select('#inline-labels').remove();
     // //Create group for labels
     var gLabels = d3.select(bars[0][0].parentNode).append('g').attr('id', 'inline-labels');
     //  console.log("gLabels = " +gLabels);
     for (var i = bars[0].length - 1; i >= 0; i--) {
         var b = bars[0][i];
 //console.log("b=" + b);
     //Only create label if bar height is tall enough
         if (+b.getAttribute('height') < 18) continue;
 //console.log("barsData[i].values " + barsData[i].data.value);
 var myLabel = barLabelCurrencyFormat(barsData[i].data.value);
 var myLabelYtd = dataLabelValues[i];
           gLabels.append("text")
           .text(myLabel)
   .attr("class","barlabelchart")
           .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
           .attr('y', +b.getAttribute('y') + 20)
           .attr('text-anchor', 'middle')
           .attr('fill', 'white')

   gLabels.append("text")
           .text(myLabelYtd)
   .attr("class","barlabelchartytd")
           .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
           .attr('y', +b.getAttribute('y') + 40)
           .attr('text-anchor', 'middle')
           .attr('fill', 'white')
           }
         });
     sfBarAChart.yAxis().ticks(0); // hide the yAsix labels
     sfBarAChart.xAxis().tickValues([]); // hide the xAxis labels
 }

 // Function to draw default bar chart

 function drawBarAChart(data) {

 preSetupChartParameters();
// console.log("data in drawBarChart = " + JSON.stringify(data));

 var dataToPlotFiltered = crossfilter(data);
 //console.log("data in drawBarChart filtered = " + JSON.stringify(dataToPlotFiltered));

 var yearsDim = dataToPlotFiltered.dimension(function (d) {
//console.log("years = " + d.key);
     return d.key;
 });
 var hoursGroup = yearsDim.group().reduceSum(function (d) {
   //  console.log("hoursGroup = " + d.values);
     return d.values;
 });

var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
var keys = sortByValues.map(function (d) { return d.key; });

 var chartcolortypeL = attrs["chartcolortype"];
  if(chartcolortypeL == 'blue') {

    var barColorRangeA ="#029fdb";
    var barColorRangeB = "#cbcbcb";
  } else {
    var barColorRangeA ="#cbcbcb";
    var barColorRangeB = "#c31820";
  }


//var initialScaleData = [600, 2000]; // this is the problem.
//var jsondata = JSON.parse(JSON.stringify(data));
var initialScaleData = [];
for(var i = 0; i < data.length ; i++)
 {
   //console.log("initial Scale Data values = " + data[i].values );
   initialScaleData.push(data[i].values);

};
//console.log('new array is ' + initialScaleData);
sfBarAChart
   .dimension(yearsDim)
   .group(hoursGroup)
   //.x(d3.scale.ordinal().domain(1000))
   .x(d3.scale.ordinal().domain(keys))
.y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))

   .on('pretransition', function (sfBarAChart) {
       var colors = d3.scale.ordinal().domain(yearsDim)
         .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820

   sfBarAChart.selectAll('rect.bar').each(function(d){
             d3.select(this).attr("style", "fill: " + colors(d.data.key));
         });

   })
   postSetupChartParameters(data);
     dc.renderAll('barchartgroup2');
   }

 // Function to update the bar chart with changed data. This will be called based on the changed scope data.

 function updateBarChart(data) {

 preSetupChartParameters();
//  console.log(JSON.stringify(data));
 var dataToPlotFiltered = crossfilter(data);
 // console.log(JSON.stringify(dataToPlotFiltered));
 var yearsDim = dataToPlotFiltered.dimension(function (d) {
 //  console.log("years = " + d.year);
 return d.key;
 });
 var hoursGroup = yearsDim.group().reduceSum(function (d) {
 //    console.log("hoursGroup = " + d.hours);
     return d.values;
 });

var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
var keys = sortByValues.map(function (d) { return d.key; });

 var chartcolortypeL = attrs["chartcolortype"];
  if(chartcolortypeL == 'blue') {
    var barColorRangeA ="#029fdb";
    var barColorRangeB = "#cbcbcb";
  } else {
    var barColorRangeA ="#cbcbcb";
    var barColorRangeB = "#c31820";
  }
// var initialScaleData = [600, 2000];
//var jsondata = JSON.parse(JSON.stringify(data));
var initialScaleData = []; for(var i = 0; i < data.length ; i++) {initialScaleData.push(data[i].values)};
//console.log('new array is '+initialScaleData);
 sfBarAChart
   .dimension(yearsDim)
   .group(hoursGroup)
   //.x(d3.scale.ordinal().domain(1000))
   .x(d3.scale.ordinal().domain(keys))
.y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))
   .on('pretransition', function (sfBarAChart) {
       var colors = d3.scale.ordinal().domain(yearsDim)
         .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820
         sfBarAChart.selectAll('rect.bar').each(function(d){
             d3.select(this).attr("style", "fill: " + colors(d.data.key));
         });
   })
   postSetupChartParameters(data);

   dc.redrawAll('barchartgroup2');
   }
 }

};
});


// second bar chart
// Reusable table chart directive. use <div sftable-chart chart-data="topFirmsData"></div> pass the char-data dynamically

app.directive('sftableChart', function($window){
return {
 restrict:'EAC',
 template:"",
scope:{
      data: '=data'
 },
 link: function (scope,elem,attrs){

   var formatCurrency = d3.format("$,");
   var chartElement = elem[0];
   // variable to hold dc table
   var chartFactory = dc['dataTable'];
   // Create an unconfigured instance of the chart
   var sfDataTableShell = chartFactory(chartElement,'table1group');

   //var dataForTable = scope[attrs.chartData];
var dataToPlotT;

scope.$watch('data', function (newVal, oldVal) {
     if(newVal!=oldVal){

       dataToPlotT = newVal;
       updateSfTableChart(dataToPlotT);

    } else {

 dataToPlotT = newVal;
 drawSfTableChart(dataToPlotT);
      }
 });

function drawSfTableChart(data) {

//console.log("data in drawSfTableChart == " + JSON.stringify(data));
var dataForTableFiltered = crossfilter(data);
var tableDim = dataForTableFiltered.dimension(function (d) {
return d.key;
});

sfDataTableShell
     .dimension(tableDim)
     .group(function(d) {return ''})
//  .size(5)
.columns([function (d) { return d.key; },
     function (d) { return formatCurrency(Math.ceil(d.values)); }])
     .sortBy(function (d) {
         return parseInt(d.values)})
     .order(d3.descending)
.on('renderlet', function (table) {
         d3.selectAll(".dc-table-group").each(function(){
         d3.select(this).style("display","none");
       })

 d3.selectAll("tr:nth-child(even)").each(function() {
         d3.select(this).style("background-color", "rgba(220, 221, 224, 0.33)");
         d3.select(this).style("width", "160px");
         d3.select(this).style("height", "50px");
 d3.select(this).style("font-family","'Roboto', sans-serif");
 d3.select(this).style("font-size","13px");
 })
 d3.selectAll("td:nth-child(even)").each(function() {
         d3.select(this).style("width", "160px");
         d3.select(this).style("padding-top", "12px");
 d3.select(this).style("font-size","15px");
 d3.select(this).style("color","#42464d");
 d3.select(this).style("text-align","right");
 d3.select(this).style("font-weight","bold");

 })

       d3.selectAll("td:nth-child(odd)").each(function() {
         d3.select(this).style("width", "160px");
         d3.select(this).style("height", "50px");
 d3.select(this).style("font-weight", "normal");
 d3.select(this).style("padding-top", "12px");
 d3.select(this).style("font-size","15px");
 d3.select(this).style("text-align","left");

 })
})
     dc.renderAll('table1group');
}


function updateSfTableChart(data) {

//console.log("data in updateSfTableChart = " + JSON.stringify(data));
var dataForTableFiltered = crossfilter(data);
var tableDim = dataForTableFiltered.dimension(function (d) {
     return d.key;
});

sfDataTableShell
     .dimension(tableDim)
     .group(function(d) {return ''})
    // .size(5)
     .columns([function (d) { return d.key; },
     function (d) { return formatCurrency(Math.ceil(d.values)); }])
     .sortBy(function (d) {
         return parseInt(d.values)})
     .order(d3.descending)
.on('renderlet', function (table) {
         d3.selectAll(".dc-table-group").each(function(){
         d3.select(this).style("display","none");
       })

 d3.selectAll("tr:nth-child(even)").each(function() {
         d3.select(this).style("background-color", "rgba(220, 221, 224, 0.33)");
         d3.select(this).style("width", "160px");
         d3.select(this).style("height", "50px");
 d3.select(this).style("font-family","'Roboto', sans-serif");
 d3.select(this).style("font-size","13px");
 })
 d3.selectAll("td:nth-child(even)").each(function() {
         d3.select(this).style("width", "160px");
         d3.select(this).style("padding-top", "12px");
 d3.select(this).style("font-size","15px");
 d3.select(this).style("color","#42464d");
 d3.select(this).style("text-align","right");
 d3.select(this).style("font-weight","bold");

 })

       d3.selectAll("td:nth-child(odd)").each(function() {
         d3.select(this).style("width", "160px");
         d3.select(this).style("height", "50px");
 d3.select(this).style("font-weight", "normal");
 d3.select(this).style("padding-top", "12px");
 d3.select(this).style("font-size","15px");
 d3.select(this).style("text-align","left");

 })
})

     dc.redrawAll('table1group');
}
}
}
});


// Reusable table chart directive. use <div sftable-chart chart-data="topFirmsData"></div> pass the char-data dynamically

app.directive('sftablechartanomaliesChart', function($window){
return {
 restrict:'EAC',
 template:"",
scope:{
      data: '=data'
 },
 link: function (scope,elem,attrs){

//   var formatCurrency = d3.format("$,.2f");
   var chartElement = elem[0];
   // variable to hold dc table
   var chartFactory = dc['dataTable'];
   // Create an unconfigured instance of the chart
   var sfDataTableShellA = chartFactory(chartElement,'table2group');

   //var dataForTable = scope[attrs.chartData];
var dataToPlotT;

scope.$watch('data', function (newVal, oldVal) {
     if(newVal!=oldVal){

       dataToPlotT = newVal;
       updateSfTableChartAnomaly(dataToPlotT);

    } else {

 dataToPlotT = newVal;
 drawSfTableChartAnomaly(dataToPlotT);
      }
 });

function drawSfTableChartAnomaly(data) {

var dataForTableFiltered = crossfilter(data);
var tableDim = dataForTableFiltered.dimension(function (d) {
     return d.key;
});

sfDataTableShellA
     .dimension(tableDim)
     .group(function(d) {return ''})
    // .size(5)
     .columns([function (d) { return d.key; },
     function (d) { return d.values; }])

     .order(d3.descending)
.sortBy(function (d) {
         return parseInt(d.values)})

     .on('renderlet', function (table) {
         d3.selectAll(".dc-table-group").each(function(){
         d3.select(this).style("display","none");
       })

 d3.selectAll("tr:nth-child(even)").each(function() {
         d3.select(this).style("background-color", "rgba(220, 221, 224, 0.33)");
         d3.select(this).style("width", "160px");
         d3.select(this).style("height", "50px");
 d3.select(this).style("font-family","'Roboto', sans-serif");
 d3.select(this).style("font-size","13px");
 })
 d3.selectAll("td:nth-child(even)").each(function() {
         d3.select(this).style("width", "160px");
         d3.select(this).style("padding-top", "12px");
 d3.select(this).style("font-size","15px");
 d3.select(this).style("color","#c31820");
 d3.select(this).style("text-align","right");
 d3.select(this).style("font-weight","bold");

 })

       d3.selectAll("td:nth-child(odd)").each(function() {
         d3.select(this).style("width", "160px");
         d3.select(this).style("height", "50px");
 d3.select(this).style("font-weight", "normal");
 d3.select(this).style("padding-top", "12px");
 d3.select(this).style("font-size","15px");
 d3.select(this).style("text-align","left");

       })
})
     dc.renderAll('table2group');
}

function updateSfTableChartAnomaly(data) {

//console.log("data in updateSfTableChart = " + JSON.stringify(data));
var dataForTableFiltered = crossfilter(data);
var tableDim = dataForTableFiltered.dimension(function (d) {
     return d.key;
});

sfDataTableShellA
     .dimension(tableDim)
     .group(function(d) {return ''})
   //  .size(5)
     .columns([function (d) { return d.key; },
     function (d) { return d.values; }])

     .order(d3.descending)
.sortBy(function (d) {
         return parseInt(d.values)})

     .on('renderlet', function (table) {
         d3.selectAll(".dc-table-group").each(function(){
         d3.select(this).style("display","none");
       })

 d3.selectAll("tr:nth-child(even)").each(function() {
         d3.select(this).style("background-color", "rgba(220, 221, 224, 0.33)");
         d3.select(this).style("width", "160px");
         d3.select(this).style("height", "50px");
 d3.select(this).style("font-family","'Roboto', sans-serif");
 d3.select(this).style("font-size","13px");
 })
 d3.selectAll("td:nth-child(even)").each(function() {
         d3.select(this).style("width", "160px");
         d3.select(this).style("padding-top", "12px");
 d3.select(this).style("font-size","15px");
 d3.select(this).style("color","#c31820");
 d3.select(this).style("text-align","right");
 d3.select(this).style("font-weight","bold");

 })

       d3.selectAll("td:nth-child(odd)").each(function() {
         d3.select(this).style("width", "160px");
         d3.select(this).style("height", "50px");
 d3.select(this).style("font-weight", "normal");
 d3.select(this).style("padding-top", "12px");
 d3.select(this).style("font-size","15px");
 d3.select(this).style("text-align","left");

       })
})
     dc.redrawAll('table2group');
}
}
}
});

// Reusable Directive for row bar Chart - Use <div rowbar-chart data="rowbarchartdata" ></div> where data parameter should be different
app.directive('rowbarnewChart', function($window){
return {
restrict:'EAC',
template:"",
scope:{
      data: '=data'
 },
link: function (scope,elem,attrs){
// both state widget 1d4
//set up svg using margin conventions - we'll need plenty of room on the left for labels

scope.$watch('data', function (newVal, oldVal) {
     if(newVal!=oldVal){

       barDataToPlot = newVal;
       drawBarChartNew(barDataToPlot);

     } else {

       barDataToPlot = newVal;
       drawBarChartNew(barDataToPlot);
      }
 });


function drawBarChartNew(data) {

var margin = {
     top: 15,
     right: 25,
     bottom: 15,
     left: 60
 };

var barPadding = 3.5;
var barPaddingOuter = 0.1;
var topData = data.slice(0,3);
 var width = 580 - margin.left - margin.right,
     height = 280 - margin.top - margin.bottom;
var rowbarLabelCurrencyFormat = d3.format("$,");
var x = d3.scale.linear()
     .range([0, width])
     .domain([0, d3.max(topData, function (d) {
         return d.values;
     })]);

 var y = d3.scale.ordinal()
     .rangeRoundBands([height , 0], barPadding, barPaddingOuter)
     .domain(topData.map(function (d) {
         return d.key;
     }));

// Add the div containing the whole chart
var chart = d3.select('#matterchart').append('div').attr('class', 'matterchart');

// Add one div per bar which will group together both labels and bars
var g = chart.selectAll('div')
.data(topData)
.enter()
.append('div')
.attr("class", "masterdiv")

// Add the labels
g.append("div")
.attr("class", "barlabel")
.text(function (d, i) { return d.key });

// Add the bars
var bars = g.append("div")
.attr("class", "rect")
.style("width", function (d) {
   return (x(d.values/1.2) + "px");
     })
.text(function (d) { return rowbarLabelCurrencyFormat(Math.ceil(d.values)); })

}
}
}
});
