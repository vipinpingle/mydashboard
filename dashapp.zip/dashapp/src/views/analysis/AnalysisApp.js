
<script type="text/javascript">

  //$('select').select2();
 $(function() {

     var start = moment().subtract(29, 'days');
     var end = moment();

    $('input[name="daterange"]').daterangepicker({
        //startDate: start,
        //endDate: end,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
		   '2016': ['1/1/2016', '12/31/2016'],
		   '2015': ['1/1/2015', '12/31/2015'],
		    '2015-2016': ['1/1/2015', '12/31/2016']


        }
	});

  $('input[name="timecomprange"]').daterangepicker({
      startDate: '1/1/2016',
			endDate: '12/31/2016',
      autoUpdateInput: false,
      locale: {
          cancelLabel: 'Clear'
      },
			ranges: {
			   'Today': [moment(), moment()],
			   'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
			   'Last 7 Days': [moment().subtract(6, 'days'), moment()],
			   'Last 30 Days': [moment().subtract(29, 'days'), moment()],
			   'This Month': [moment().startOf('month'), moment().endOf('month')],
			   'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
			   '2016': ['1/1/2016', '12/31/2016'],
			   '2015': ['1/1/2015', '12/31/2015'],
				'2015-2016': ['1/1/2015', '12/31/2016']
			}
		});

  });
  var app = angular.module('wexdashboard',['AnalysisDataService','ui.bootstrap','angularjs-dropdown-multiselect']);

  app.controller('analysisController',['$scope','$http','analysisService',function($scope, $http,analysisService) {


  function init() {

  console.log("initializing the fillStateList ");
  $scope.stateselect = "";
  $scope.kpiSelected= "";
	$scope.categorySelected = "";
	$scope.subcategorySelected= "";
	$scope.valueSelected = [];
	$scope.filtersSelected = "";
	$scope.timeselected = [];
	$scope.subcategoryvalues = [];
	$scope.subcategoryselect = '';
	$scope.datarange = "";
  $scope.timecompselected = "";
  $scope.initialtimecomp = true;

//  $scope.searchstatecategory="state";

  // flags to disable the drop down
	$scope.showcompTimeCategory = false; // for testing the bar chart. Need to fix the timecomparison
	$scope.showSubCategory = false;
  $scope.showStateCategory = false;
	$scope.hideCountyCategory = true;
	$scope.hideFirmCategory = true;
	$scope.hidePhaseCategory = true;
	$scope.hideTimeKeeperCategory = true;
	$scope.hideMatterNameCategory = true;
	$scope.hideExpenseCategory = true;
	$scope.hidePhaseCategory = true;
	$scope.hideTaskCategory = true;
	$scope.hideStaffCategory = true;
	$scope.hiderateCategory = true;
	$scope.hidetrialdateCategory= true;
	$scope.hidecaselengthCategory= true;
	$scope.hidemattertypeCategory= true;
	$scope.hidedisputetypeCategory= true;
	$scope.hidecourttypeCategory= true;
	$scope.hideteamleadCategory= true;
	$scope.hidesupervisingattorneyCategory= true;
	$scope.hideplaintiffcounselCategory= true;
	$scope.hideassignedcounselCategory= true;
	$scope.hidejudgeCategory= true;
	$scope.hidematterstatusCategory= true;
	$scope.hidematteropenCategory= true;
	$scope.hidemattercloseCategory= true;
	$scope.hideanomalytypeCategory= true;
	$scope.spending = false;
	$scope.hours = false;
	$scope.rate = false;
	$scope.blended = false;
	$scope.spendbudget = false;
	$scope.cpm = false;
	$scope.comparisions = false;
	$scope.anomalies = false;
// flags to disable drop downs or button ends here.

  $scope.statefieldname = "state";
  $scope.countyfieldname = "county";
  $scope.expensefieldname = "disbcode";
  $scope.firmfieldname = "firmname";
  $scope.matternamefieldname = "mattername";
  $scope.timekeeperfieldname = "fullname";
  $scope.taskcodefieldname = "taskcode";
  $scope.phasefieldname = "phase";
  $scope.stafffieldname = "tklevel";
  $scope.ratebucketfieldname = "rate_bucket";
  $scope.trialdatefieldname = "trialdate";
  $scope.lengthbucketfieldname = "length_bucket";
  $scope.mattertypefieldname = "mattertype";
  $scope.disputetypefieldname = "suittype";
  $scope.courttypefieldname = "courttype";
  $scope.teamleadfieldname = "team_lead";
  $scope.attorneyfieldname = "attorney";
  $scope.opposingcounselfieldname = "opposing_counsel";
  $scope.assignedcounselfieldname = "assigned_counsel";
  $scope.judgefieldname = "judge";
  $scope.opendatefieldname = "opendate";
  $scope.closedatefieldname = "closedate";
  $scope.anomalyfieldname = "anomaly";
  $scope.anomalydescriptionfieldname = "anom_desc";
  $scope.statusfieldname = "status";
  $scope.legendheader = "";
	$scope.legendmiddle = "";
	$scope.legendright = "";
	$scope.stateList = [];
	$scope.countyList = [];
	$scope.firmList = [];
	$scope.timekeeperList = [];
	$scope.matternameList = [];
	$scope.taskList = [];
	$scope.phaseList = [];
	$scope.staffList = [];
	$scope.expenseList = [];
	$scope.rateList = [];
	$scope.traildateList = [];
	$scope.caselengthList = [];
	$scope.mattertypeList = [];
	$scope.disputetypeList = [];
	$scope.courttypeList = [];
	$scope.teamleadList = [];
	$scope.supervisingattorneyList = [];
	$scope.plaintiffcounselList = [];
	$scope.assignedcounselList = [];
	$scope.judgeList = [];
	$scope.anomalytypeList = [];
	$scope.matterstatusList = [];
	$scope.matteropenList = [];
	$scope.mattercloseList = [];
	$scope.selectionList = [];
  $scope.selectionListOrder = ["state","county","firm","timekeeper","mattername","task","expense"];
  $scope.selectionListOrdercolumnname = ["state","county","firm","judge","mattername","task","itemtype"];
	$scope.matterTableData = "";
	$scope.dataForMatterTableLoaded = false;

// variables to display the values of the select drop down for the user notification
  $scope.displaySelectedStateValues = "";
  $scope.displaySelectedCountyValues = "";
  $scope.displaySelectedFirmValues = "";
  $scope.displaySelectedExpenseValues = "";
  $scope.displaySelectedTimekeeperValues = "";
  $scope.displaySelectedMatternameValues = "";
  $scope.displaySelectedTaskValues = "";
  $scope.displaySelectedPhaseValues = "";
  $scope.displaySelectedStaffValues = "";

  $scope.displaySelectedRateValues = "";
  $scope.displaySelectedTraildateValues = "";
  $scope.displaySelectedCaseLengthValues = "";
  $scope.displaySelectedMatterTypeValues = "";
  $scope.displaySelectedDisputeTypeValues = "";
  $scope.displaySelectedCourtTypeValues = "";
  $scope.displaySelectedTeamLeadValues = "";
  $scope.displaySelectedSupervisingAttorneyValues = "";
  $scope.displaySelectedPlaintiffCounselValues = "";
  $scope.displaySelectedAssignedCounselValues = "";
  $scope.displaySelectedJudgeValues = "";
  $scope.displaySelectedMatteropenValues = "";
  $scope.displaySelectedMattercloseValues = "";
  $scope.displaySelectedAnomalyTypeValues = "";
  $scope.displaySelectedMatterstatusValues = "";
  $scope.displaySelectedTimeCompValues = "";
  $scope.showPieChart = false;
  // new state variables for multi-select
  $scope.searchSelectAllSettings = { enableSearch: true, showCheckAll: false, showUncheckAll:false,keyboardControls: true, styleActive: true,scrollable: true,scrollableHeight: '200px'};
  $scope.searchSelectMatterSettings = { enableSearch: true, showCheckAll: false, showUncheckAll:false,keyboardControls: true, styleActive: true,scrollable: true,scrollableHeight: '300px'};
  // multi-select options starts here
  $scope.searchSelectStateModel = [];
  $scope.stateChangeEventListeners = {
      onSelectionChanged: onStateSelectionChanged
      // onItemDeselect: onItemDeselect,
      // onSelectAll: onSelectAll,
      // onDeselectAll: onDeselectAll
  };

  $scope.searchSelectCountyModel = [];
  $scope.countyChangeEventListeners = {
  	  onSelectionChanged: onCountySelectionChanged
  };

  $scope.searchSelectFirmModel = [];
  $scope.firmChangeEventListeners = {
  	  onSelectionChanged: onFirmSelectionChanged
  };

  $scope.searchSelectTimekeeperModel = [];
  $scope.timekeeperChangeEventListeners = {
      onSelectionChanged: onTimekeeperSelectionChanged
  };

  $scope.searchSelectMatterModel = [];
  $scope.matterChangeEventListeners = {
      onSelectionChanged: onMatterSelectionChanged
  };

  $scope.searchSelectTaskModel = [];
  $scope.taskChangeEventListeners = {
      onSelectionChanged: onTaskSelectionChanged
  };

  $scope.searchSelectStaffModel = [];
  $scope.staffChangeEventListeners = {
      onSelectionChanged: onStaffSelectionChanged
  };

  $scope.searchSelectPhaseModel = [];
  $scope.phaseChangeEventListeners = {
      onSelectionChanged: onPhaseSelectionChanged
  };

  $scope.searchSelectExpenseModel = [];
  $scope.expenseChangeEventListeners = {
      onSelectionChanged: onExpenseSelectionChanged
  };

  // filter drop downs

  $scope.searchSelectRateModel = [];
  $scope.rateChangeEventListeners = {
      onSelectionChanged: onRateSelectionChanged
  };

  $scope.searchSelectTrialDateModel = [];
  $scope.trialDateChangeEventListeners = {
      onSelectionChanged: onTrialDateSelectionChanged
  };
  $scope.searchSelectCaseLengthModel = [];
  $scope.caseLengthChangeEventListeners = {
      onSelectionChanged: onCaseLengthSelectionChanged
  };
  $scope.searchSelectMatterTypeModel = [];
  $scope.matterTypeChangeEventListeners = {
      onSelectionChanged: onMatterTypeSelectionChanged
  };
  $scope.searchSelectMatterStatusModel = [];
  $scope.matterStatusChangeEventListeners = {
      onSelectionChanged: onMatterStatusSelectionChanged
  };
  $scope.searchSelectMatterOpenDateModel = [];
  $scope.matterOpenDateChangeEventListeners = {
      onSelectionChanged: onMatterOpenDateSelectionChanged
  };
  $scope.searchSelectMatterCloseDateModel = [];
  $scope.matterCloseDateChangeEventListeners = {
      onSelectionChanged: onMatterCloseDateSelectionChanged
  };
  $scope.searchSelectDisputeTypeModel = [];
  $scope.disputeTypeChangeEventListeners = {
      onSelectionChanged: onDisputeTypeSelectionChanged
  };
  $scope.searchSelectCourtTypeModel = [];
  $scope.courtTypeChangeEventListeners = {
      onSelectionChanged: onCourtTypeSelectionChanged
  };
  $scope.searchSelectTeamLeadModel = [];
  $scope.teamLeadChangeEventListeners = {
      onSelectionChanged: onTeamLeadSelectionChanged
  };
  $scope.searchSelectSupervisingAttorneyModel = [];
  $scope.supervisingAttorneyChangeEventListeners = {
      onSelectionChanged: onSupervisingAttorneySelectionChanged
  };
  $scope.searchSelectPlaintiffModel = [];
  $scope.plaintiffChangeEventListeners = {
      onSelectionChanged: onPlaintiffSelectionChanged
  };
  $scope.searchSelectAssignedCounselModel = [];
  $scope.assignedCounselChangeEventListeners = {
      onSelectionChanged: onAssignedCounselSelectionChanged
  };
  $scope.searchSelectJudgeModel = [];
  $scope.judgeChangeEventListeners = {
      onSelectionChanged: onJudgeSelectionChanged
  };
  $scope.searchSelectAnomalyTypeModel = [];
  $scope.anomalyTypeChangeEventListeners = {
      onSelectionChanged: onAnomalyTypeSelectionChanged
  };
  fillStateList();
}

  // $scope.resetPage = function() {
  //   console.log("Resetting the page parameters");
  //   init();
  // }


  //Watch for date changes
  // $scope.$watch('timecompselected', function(newDate) {
  //     console.log('New date set: ', newDate);
  //     if(newDate != "" && $scope.initialtimecomp == "false") {
  //       $scope.showcompTimeCategory = "true";
  //       $scope.displaySelectedTimeCompValues = newDate;
  //     } else {
  //         $scope.showcompTimeCategory = "false";
  //         $scope.displaySelectedTimeCompValues = "";
  //     }
  //     console.log('$scope.showcompTimeCategory: ', $scope.showcompTimeCategory);
  // }, false);

  $('input[name="timecomprange"]').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
      $scope.$apply( function() {
          $scope.initialtimecomp = "true";
          $scope.showcompTimeCategory = false;
          $scope.timecompselected = "";
          $scope.displaySelectedTimeCompValues = "";
      });
  });

  $('input[name="timecomprange"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
      $scope.$apply( function() {
          $scope.initialtimecomp = "false";
          $scope.showcompTimeCategory = true;
          $scope.displaySelectedTimeCompValues = $scope.timecompselected;
          console.log("comp selected = " + $scope.timecompselected);
      });
  });

  // function setTimeCompInitialValue() {
  //   $scope.showcompTimeCategory =  false;
  //   $scope.timecompselected = "";
  //   $scope.displaySelectedTimeCompValues = "";
  // }

//	$scope.fillStateList = function() {
	function fillStateList() {
	console.log("Get the states list ");
   $scope.stateList = [];
   analysisService.getStatesList()
        .then(
              function( mydata ) {
              for(var i in mydata) {
                $scope.stateList.push(
                  {
                    id:i,
                    label: mydata[i].properties.state[0]
                  });
              };
		    });
    };

    // Method to return selectd values from dropdown and concate different values using pipe. Use Id of the dropdown when it is available
    function getSelectedValues(sourceParams){
      var sourceValue = "";
    //  console.log("getSelectedValues ***** function");
      console.log("getSelectedValues sourceParams length = " + sourceParams.length);
      for (i = 0; i < sourceParams.length; i++) {
        sourceValue = sourceValue + sourceParams[i].label + "||"; //need to add this after we update endpoint to handle multiple values  separated by ||
        console.log("Returned value from getSelectedValues = " + sourceValue);
      }
      return sourceValue;
    }

    // Method to return selectd values from dropdown and concate different values using pipe. Use Id of the dropdown when it is available
    function getSelectedMatterValues(sourceParams){
      var sourceValue = "";
      for (i = 0; i < sourceParams.length; i++) {
        sourceValue = sourceValue + getMatterId(sourceParams[i].label)  + "||"; //need to add this after we update endpoint to handle multiple values  separated by ||
        console.log("Returned value from getSelectedParams = " + sourceValue);
      }
      return sourceValue;
    }

    function getMatterId(matternamelabel) {
      var matterId = "";
      if(matternamelabel != "") {
          matterId = matternamelabel.split('->')[1];
      }
      return matterId;
    }

    // Method to return selectd values from dropdown and concate different values using pipe
    function getSelectedValuesForReport(sourceParams){
      $scope.valueSelected = [];
      var labelValue = "";
      for (i = 0; i < sourceParams.length; i++) {
        if($scope.categorySelected == $scope.matternamefieldname){
           labelValue = getMatterId(sourceParams[i].label)
        } else {
          labelValue = sourceParams[i].label
        }
        $scope.valueSelected.push(labelValue);
      }
      console.log("Returned value from getSelectedValuesForReport = " + $scope.valueSelected.length);
    }

    function contains(arrayItems, item) {
        return arrayItems.indexOf(item) > -1;
    }
    // This method will returns the formatted filtervalue required for the endpoints.
    function getSelectedParams(sourceParams,category){
      var selectedValue = "";
      if(sourceParams.length > 0) {
      if(category == $scope.matternamefieldname) {
        selectedValue = getSelectedMatterValues(sourceParams);
        return $scope.matternamefieldname + ">>" + selectedValue;
      }
      else {
        selectedValue = getSelectedValues(sourceParams);
        console.log("rrerwerwerwer" + selectedValue);
      }
    } else {
      console.log("Returning empty selectedValue from getSelectedParams = " + selectedValue);
      return selectedValue = "";

    }

      // for (i = 0; i < sourceParams.length; i++) {
      //   selectedValue = selectedValue + sourceParams[i].label + "||";
      //   console.log("Returned value from getSelectedParams = " + selectedValue);
      // }
      // if(category == $scope.matternamefieldname){
      //   return $scope.matternamefieldname + ">>" + selectedValue;
      // }
      if(category == $scope.statefieldname){
        return $scope.statefieldname + ">>" + selectedValue;
      }
      if(category == $scope.countyfieldname){
        return $scope.countyfieldname + ">>" + selectedValue;
      }
      if(category == $scope.firmfieldname){
        return $scope.firmfieldname + ">>" + selectedValue;
      }
      if(category == $scope.timekeeperfieldname){
        return $scope.timekeeperfieldname + ">>" + selectedValue;
      }
      if(category == $scope.taskcodefieldname){
        return $scope.taskcodefieldname + ">>" + selectedValue;
      }
      if(category == $scope.stafffieldname){
        return $scope.stafffieldname + ">>" + selectedValue;
      }
      if(category == $scope.phasefieldname){
        return $scope.phasefieldname + ">>" + selectedValue;
      }
      if(category == $scope.expensefieldname){
        return $scope.expensefieldname + ">>" + selectedValue;
      }
      if(category == $scope.ratebucketfieldname) {
        return $scope.ratebucketfieldname + ">>" + selectedValue;
      }
      if(category == $scope.trialdatefieldname) {
        return $scope.trialdatefieldname + ">>" + selectedValue;
      }
      if(category == $scope.lengthbucketfieldname) {
        return $scope.lengthbucketfieldname + ">>" + selectedValue;
      }
      if(category == $scope.mattertypefieldname) {
        return $scope.mattertypefieldname + ">>" + selectedValue;
      }
      if(category == $scope.disputetypefieldname) {
        return $scope.disputetypefieldname + ">>" + selectedValue;
      }
      if(category == $scope.courttypefieldname) {
        return $scope.courttypefieldname + ">>" + selectedValue;
      }
      if(category == $scope.teamleadfieldname) {
        return $scope.teamleadfieldname + ">>" + selectedValue;
      }
      if(category == $scope.attorneyfieldname) {
        return $scope.attorneyfieldname + ">>" + selectedValue;
      }
      if(category == $scope.opposingcounselfieldname) {
        return $scope.opposingcounselfieldname + ">>" + selectedValue;
      }
      if(category == $scope.assignedcounselfieldname) {
        return $scope.assignedcounselfieldname + ">>" + selectedValue;
      }
      if(category == $scope.judgefieldname) {
        return $scope.judgefieldname + ">>" + selectedValue;
      }
      if(category == $scope.statusfieldname) {
        return $scope.statusfieldname + ">>" + selectedValue;
      }
      if(category == $scope.opendatefieldname) {
        return $scope.opendatefieldname + ">>" + selectedValue;
      }
      if(category == $scope.closedatefieldname) {
        return $scope.closedatefieldname + ">>" + selectedValue;
      }
      if(category == $scope.anomalydescriptionfieldname) {
        return $scope.anomalydescriptionfieldname + ">>" + selectedValue;
      }
    };

    // Array.prototype.contains = function ( containsvalue ) {
    //   console.log("prototype arra fucntin " + containsvalue);
    //    for (i in this) {
    //        if (this[i] == containsvalue) return true;
    //    }
    //    return false;
    // }
    // function called when state drop down changed
    function onStateSelectionChanged() {
      var selectedState = getSelectedParams($scope.searchSelectStateModel,$scope.statefieldname);
      if(selectedState != "") {
        if($scope.searchSelectStateModel.length >= 0) {
          // update the drop downs
          $scope.hideCountyCategory = false;
          $scope.hideFirmCategory = false;
          $scope.hideTimeKeeperCategory = false;
          $scope.hideMatterNameCategory = false;
          $scope.hideTaskCategory = false;
          $scope.hideExpenseCategory = false;
          $scope.hidePhaseCategory = false;
          $scope.hideStaffCategory = false;
          updateCountyList(selectedState);
          updateFirmList(selectedState);
          updateMatterNameList(selectedState);
          updateTimeKeeperList(selectedState);
          updateTaskList(selectedState);
          updatePhaseList(selectedState);
          updateStaffList(selectedState);
          updateExpenseList(selectedState);
          updateAllFilters(selectedState);
          $scope.displaySelectedStateValues = $scope.searchSelectStateModel.map(function(el){return el.label}).join(",");
          // var selectStateItem = contains($scope.selectionList,$scope.statefieldname);
          // console.log("selectStateItem = " + selectStateItem);
          if(contains($scope.selectionList,$scope.statefieldname)){
            console.log("selection list already contains state");
          } else {
                $scope.selectionList.push($scope.statefieldname);
          }
          if($scope.displaySelectedStateValues>=0){
              //console.log("removing the state values as nothing is selected");
              index = $scope.selectionList.indexOf($scope.statefieldname);
              //console.log("state index from selection list = " + index);
            if(index > -1) {
              $scope.selectionList.splice(index,1);
              console.log("Removed the state from selection list");
            }
          }
      }
    } else {
        $scope.hideCountyCategory = true;
        $scope.hideFirmCategory = true;
        $scope.hideTimeKeeperCategory = true;
        $scope.hideMatterNameCategory = true;
        $scope.hideTaskCategory = true;
        $scope.hideExpenseCategory = true;
        $scope.hidePhaseCategory = true;
        $scope.hideStaffCategory = true;
        $scope.displaySelectedStateValues = "";
        $scope.countyList = [];
        $scope.searchSelectCountyModel = [];
        $scope.displaySelectedCountyValues = "";
        $scope.firmList = [];
        $scope.searchSelectFirmModel = [];
        $scope.displaySelectedFirmValues = "";
        $scope.timekeeperList = [];
        $scope.searchSelectStaffModel = [];
        $scope.displaySelectedTimekeeperValues = "";
        $scope.matternameList = [];
        $scope.searchSelectMatterModel = [];
        $scope.displaySelectedMatternameValues = "";
        $scope.taskList = [];
        $scope.searchSelectTaskModel = [];
        $scope.displaySelectedTaskValues = "";
        $scope.expenseList = [];
        $scope.searchSelectExpenseModel = [];
        $scope.displaySelectedExpenseValues = "";
        $scope.phaseList = [];
        $scope.searchSelectPhaseModel = [];
        $scope.displaySelectedPhaseValues = "";
        $scope.staffList = [];
        $scope.searchSelectStaffModel = [];
        $scope.displaySelectedStaffValues = "";
      //  console.log("=====***no updates fired from onStateSelectionChanged because no value is selected and set the display values and model to none***====== ");
      }
    };

    // function called when county drop down changed. Call only dropdowns which are affected by county selection
    function onCountySelectionChanged() {
      console.log("selecteditem in countyDropDownSelect");
      var selectedCounty = getSelectedParams($scope.searchSelectCountyModel,$scope.countyfieldname);
      if(selectedCounty != "") {
      if($scope.searchSelectCountyModel.length >= 0) {
        $scope.hideExpenseCategory = false;
        $scope.hideFirmCategory = false;
        $scope.hideTimeKeeperCategory = false;
        $scope.hideMatterNameCategory = false;
        $scope.hideTaskCategory = false;
        $scope.hidePhaseCategory = false;
        $scope.hideStaffCategory = false;
        updateFirmList(selectedCounty);
        updateTimeKeeperList(selectedCounty);
        updateMatterNameList(selectedCounty);
        updateTaskList(selectedCounty);
        updatePhaseList(selectedCounty);
        updateStaffList(selectedCounty);
        updateExpenseList(selectedCounty);
        updateAllFilters(selectedCounty);
        $scope.displaySelectedCountyValues = $scope.searchSelectCountyModel.map(function(el){return el.label}).join(",");
        if(contains($scope.selectionList,$scope.countyfieldname)){
          console.log("selection list already contains county");
        } else {
              $scope.selectionList.push($scope.countyfieldname);
        }
        if($scope.displaySelectedCountyValues>=0){
            //console.log("removing the county values as nothing is selected");
            index = $scope.selectionList.indexOf($scope.countyfieldname);
            //console.log("county index from selection list = " + index);
					if(index > -1) {
					  $scope.selectionList.splice(index,1);
            console.log("Removed the county from selection list");
          }
        }
      }
    } else {
        $scope.displaySelectedCountyValues = "";
      }
    };

    // function called when firm drop down changed. Call only dropdowns which are affected by firm selection
    function onFirmSelectionChanged() {
      console.log("selecteditem in firmDropDownSelect");
      var selectedFirm = getSelectedParams($scope.searchSelectFirmModel,$scope.firmfieldname);
      if(selectedFirm != "") {
      if($scope.searchSelectFirmModel.length >= 0) {
        $scope.hideExpenseCategory = false;
        $scope.hideTimeKeeperCategory = false;
        $scope.hideTaskCategory = false;
        $scope.hidePhaseCategory = false;
        $scope.hideStaffCategory = false;
        $scope.displaySelectedMatternameValues = "";
        $scope.searchSelectMatterModel = [];
        updateTimeKeeperList(selectedFirm);
        updateMatterNameList(selectedFirm);
        updateTaskList(selectedFirm);
        updatePhaseList(selectedFirm);
        updateStaffList(selectedFirm);
        updateExpenseList(selectedFirm);
        updateAllFilters(selectedFirm);
        $scope.displaySelectedFirmValues = $scope.searchSelectFirmModel.map(function(el){return el.label}).join(",");
        if(contains($scope.selectionList,$scope.firmfieldname)){
          console.log("selection list already contains firm");
        } else {
              $scope.selectionList.push($scope.firmfieldname);
        }
        if($scope.displaySelectedFirmValues>=0){
            //console.log("removing the firm values as nothing is selected");
            index = $scope.selectionList.indexOf($scope.firmfieldname);
            //console.log("firm index from selection list = " + index);
          if(index > -1) {
            $scope.selectionList.splice(index,1);
            console.log("Removed the firm from selection list");
          }
        }
      }
    } else {
        $scope.displaySelectedFirmValues = "";
      }
    };

    // function called when timekeeper drop down changed. Call only dropdowns which are affected by timekeeper selection
    function onTimekeeperSelectionChanged() {
      console.log("selecteditem in timekeeperDropDownSelect");
      var selectedTimekeeper = getSelectedParams($scope.searchSelectTimekeeperModel,$scope.timekeeperfieldname);
      if(selectedTimekeeper != "") {
      if($scope.searchSelectTimekeeperModel.length >= 0) {
        $scope.hideExpenseCategory = false;
        $scope.hideMatterNameCategory = false;
        $scope.hideTaskCategory = false;
        $scope.hidePhaseCategory = false;
        updateMatterNameList(selectedTimekeeper);
        updateTaskList(selectedTimekeeper);
        updatePhaseList(selectedTimekeeper);
        updateExpenseList(selectedTimekeeper);
        updateAllFilters(selectedTimekeeper);
        $scope.displaySelectedTimekeeperValues = $scope.searchSelectTimekeeperModel.map(function(el){return el.label}).join(",");
        if(contains($scope.selectionList,$scope.timekeeperfieldname)){
          console.log("selection list already contains timekeeper");
        } else {
              $scope.selectionList.push($scope.timekeeperfieldname);
            }
            if($scope.displaySelectedTimekeeperValues>=0){
                //console.log("removing the timekeeper values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.timekeeperfieldname);
                //console.log("timekeeper index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
                console.log("Removed the firm from selection list");
              }
            }
          }
        } else {
          $scope.displaySelectedTimekeeperValues = "";
        }
    };

    // function called when matter drop down changed. Call only dropdowns which are affected by matter selection
    function onMatterSelectionChanged() {
      console.log("selecteditem in matterDropDownSelect");
      var selectedMattername = getSelectedParams($scope.searchSelectMatterModel,$scope.matternamefieldname);
      if(selectedMattername != "") {
      if($scope.searchSelectMatterModel.length >= 0) {
        $scope.hideExpenseCategory = false;
        $scope.hideTimeKeeperCategory = false;
        $scope.hideTaskCategory = false;
        $scope.hidePhaseCategory = false;
        $scope.hideStaffCategory = false;
        $scope.displaySelectedFirmValues = "";
        $scope.searchSelectFirmModel = [];
        updateFirmList(selectedMattername);
				updateTimeKeeperList(selectedMattername);
				updateTaskList(selectedMattername);
				updatePhaseList(selectedMattername);
				updateStaffList(selectedMattername);
				updateExpenseList(selectedMattername);
        updateAllFilters(selectedMattername);
        $scope.displaySelectedMatternameValues = $scope.searchSelectMatterModel.map(function(el){return el.label}).join(",");
        if(contains($scope.selectionList,$scope.matternamefieldname)){
          console.log("selection list already contains mattername");
        } else {
              $scope.selectionList.push($scope.matternamefieldname);
            }
            if($scope.displaySelectedMatternameValues>=0){
                console.log("removing the matter name values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.matternamefieldname);
                console.log("mattername index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
                console.log("Removed the mattername from selection list");
              }
            }
        }
      } else {
        $scope.displaySelectedMatternameValues = "";
      }
    };

    // function called when task drop down changed. Call only dropdowns which are affected by task selection
    function onTaskSelectionChanged() {
      console.log("selecteditem in taskDropDownSelect");
      var selectedTask = getSelectedParams($scope.searchSelectTaskModel,$scope.taskcodefieldname);
      if(selectedTask != "") {
      if($scope.searchSelectTaskModel.length >= 0) {
        $scope.hideFirmCategory = false;
        $scope.hideTimeKeeperCategory = false;
        $scope.hideMatterNameCategory = false;
        $scope.hideStaffCategory = false;
        updateFirmList(selectedTask);
				updateTimeKeeperList(selectedTask);
				updateMatterNameList(selectedTask);
				updateStaffList(selectedTask);
        updateAllFilters(selectedTask);
        $scope.displaySelectedTaskValues = $scope.searchSelectTaskModel.map(function(el){return el.label}).join(",");
        if(contains($scope.selectionList,$scope.taskcodefieldname)){
          console.log("selection list already contains taskcode");
        } else {
              $scope.selectionList.push($scope.taskcodefieldname);
            }
            if($scope.displaySelectedTaskValues>=0){
                //console.log("removing the task values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.taskcodefieldname);
                //console.log("taskcode index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
                console.log("Removed the taskcode from selection list");
              }
            }
      }
      } else {
        $scope.displaySelectedTaskValues = "";
      }
    };

    // function called when staff drop down changed. Call only dropdowns which are affected by staff selection
    function onStaffSelectionChanged() {
      console.log("selecteditem in staffDropDownSelect");
      var selectedStaff = getSelectedParams($scope.searchSelectStaffModel,$scope.stafffieldname);
      if(selectedStaff != "") {
      if($scope.searchSelectStaffModel.length >= 0) {
        $scope.hideExpenseCategory = false;
        $scope.hideTimeKeeperCategory = false;
        $scope.hideMatterNameCategory = false;
        $scope.hideTaskCategory = false;
        $scope.hidePhaseCategory = false;
        updateTimeKeeperList(selectedStaff);
        updateMatterNameList(selectedStaff);
        updateTaskList(selectedStaff);
        updatePhaseList(selectedStaff);
        updateExpenseList(selectedStaff);
        updateAllFilters(selectedStaff);
        $scope.displaySelectedStaffValues = $scope.searchSelectStaffModel.map(function(el){return el.label}).join(",");
        if(contains($scope.selectionList,$scope.stafffieldname)){
          console.log("selection list already contains staff");
        } else {
              $scope.selectionList.push($scope.stafffieldname);
            }
            if($scope.displaySelectedStaffValues>=0){
                //console.log("removing the staff values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.stafffieldname);
                //console.log("staff index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
                console.log("Removed the staff from selection list");
              }
            }
      }
      } else {
        $scope.displaySelectedStaffValues = "";
      }
    };

    // function called when phase drop down changed. Call only dropdowns which are affected by phase selection
    function onPhaseSelectionChanged() {
      console.log("selecteditem in phaseDropDownSelect");
      var selectedPhase = getSelectedParams($scope.searchSelectPhaseModel,$scope.phasefieldname);
      if(selectedPhase != "") {
      if($scope.searchSelectPhaseModel.length >= 0) {
        $scope.hideExpenseCategory = false;
        $scope.hideFirmCategory = false;
        $scope.hideTimeKeeperCategory = false;
        $scope.hideMatterNameCategory = false;
        $scope.hideTaskCategory = false;
        $scope.hideStaffCategory = false;
        updateFirmList(selectedPhase);
        updateTimeKeeperList(selectedPhase);
        updateMatterNameList(selectedPhase);
        updateTaskList(selectedPhase);
        updateStaffList(selectedPhase);
        updateExpenseList(selectedPhase);
        updateAllFilters(selectedPhase);
        $scope.displaySelectedPhaseValues = $scope.searchSelectPhaseModel.map(function(el){return el.label}).join(",");
        if(contains($scope.selectionList,$scope.phasefieldname)){
          console.log("selection list already contains phase");
        } else {
              $scope.selectionList.push($scope.phasefieldname);
            }
            if($scope.displaySelectedPhaseValues>=0){
                //console.log("removing the phase values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.stafffieldname);
                //console.log("phase index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
                console.log("Removed the phase from selection list");
              }
            }
      }
      } else {
        $scope.displaySelectedPhaseValues = "";
      }
    };

    // function called when expense drop down changed. Call only dropdowns which are affected by expense selection
    function onExpenseSelectionChanged() {
      console.log("selecteditem in expenseDropDownSelect");
      var selectedExpense = getSelectedParams($scope.searchSelectExpenseModel,$scope.expensefieldname);
      if(selectedExpense != "") {
      if($scope.searchSelectExpenseModel.length >= 0) {
        $scope.hidePhaseCategory = false;
        $scope.hideFirmCategory = false;
        $scope.hideTimeKeeperCategory = false;
        $scope.hideMatterNameCategory = false;
        $scope.hideTaskCategory = false;
        $scope.hideStaffCategory = false;
        updateFirmList(selectedExpense);
				updateTimeKeeperList(selectedExpense);
				updateMatterNameList(selectedExpense);
				updateTaskList(selectedExpense);
				updateStaffList(selectedExpense);
				updatePhaseList(selectedExpense);
        updateAllFilters(selectedExpense);
        $scope.displaySelectedExpenseValues = $scope.searchSelectExpenseModel.map(function(el){return el.label}).join(",");
        if(contains($scope.selectionList,$scope.expensefieldname)){
          console.log("selection list already contains expense");
        } else {
              $scope.selectionList.push($scope.expensefieldname);
            }
            if($scope.displaySelectedExpenseValues>=0){
                //console.log("removing the expense values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.expensefieldname);
                //console.log("expense index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
                console.log("Removed the expense from selection list");
              }
            }
        }
      } else {
        $scope.displaySelectedPhaseValues = "";
    }
    };

    function onRateSelectionChanged() {
      if($scope.searchSelectRateModel.length >= 0) {
         $scope.displaySelectedRateValues = $scope.searchSelectRateModel.map(function(el){return el.label}).join(",");
      }
    };

    function onTrialDateSelectionChanged() {
      if($scope.searchSelectTrialDateModel.length >= 0) {
         $scope.displaySelectedTraildateValues = $scope.searchSelectTrialDateModel.map(function(el){return el.label}).join(",");
      }
    };

    function onCaseLengthSelectionChanged() {
      if($scope.searchSelectCaseLengthModel.length >= 0) {
         $scope.displaySelectedCaseLengthValues = $scope.searchSelectCaseLengthModel.map(function(el){return el.label}).join(",");
      }
    };

    function onMatterTypeSelectionChanged() {
      if($scope.searchSelectMatterTypeModel.length >= 0) {
         $scope.displaySelectedMatterTypeValues = $scope.searchSelectMatterTypeModel.map(function(el){return el.label}).join(",");
      }
    };

    function onMatterStatusSelectionChanged() {
      if($scope.searchSelectMatterStatusModel.length >= 0) {
         $scope.displaySelectedMatterstatusValues = $scope.searchSelectMatterStatusModel.map(function(el){return el.label}).join(",");
      }
    };

    function onMatterOpenDateSelectionChanged() {
      if($scope.searchSelectMatterOpenDateModel.length >= 0) {
         $scope.displaySelectedMatteropenValues = $scope.searchSelectMatterOpenDateModel.map(function(el){return el.label}).join(",");
      }
    };

    function onMatterCloseDateSelectionChanged() {
      if($scope.searchSelectMatterCloseDateModel.length >= 0) {
         $scope.displaySelectedMattercloseValues = $scope.searchSelectMatterCloseDateModel.map(function(el){return el.label}).join(",");
      }
    };

    function onDisputeTypeSelectionChanged() {
      if($scope.searchSelectDisputeTypeModel.length >= 0) {
         $scope.displaySelectedDisputeTypeValues = $scope.searchSelectDisputeTypeModel.map(function(el){return el.label}).join(",");
      }
    };

    function onCourtTypeSelectionChanged() {
      if($scope.searchSelectCourtTypeModel.length >= 0) {
         $scope.displaySelectedCourtTypeValues = $scope.searchSelectCourtTypeModel.map(function(el){return el.label}).join(",");
      }
    };

    function onTeamLeadSelectionChanged() {
      if($scope.searchSelectTeamLeadModel.length >= 0) {
         $scope.displaySelectedTeamLeadValues = $scope.searchSelectTeamLeadModel.map(function(el){return el.label}).join(",");
      }
    };

    function onSupervisingAttorneySelectionChanged() {
      if($scope.searchSelectSupervisingAttorneyModel.length >= 0) {
         $scope.displaySelectedSupervisingAttorneyValues = $scope.searchSelectSupervisingAttorneyModel.map(function(el){return el.label}).join(",");
      }
    };

    function onPlaintiffSelectionChanged() {
      if($scope.searchSelectPlaintiffModel.length >= 0) {
         $scope.displaySelectedPlaintiffCounselValues = $scope.searchSelectPlaintiffModel.map(function(el){return el.label}).join(",");
      }
    };

    function onAssignedCounselSelectionChanged() {
      if($scope.searchSelectAssignedCounselModel.length >= 0) {
         $scope.displaySelectedAssignedCounselValues = $scope.searchSelectAssignedCounselModel.map(function(el){return el.label}).join(",");
      }
    };

    function onJudgeSelectionChanged() {
      if($scope.searchSelectJudgeModel.length >= 0) {
         $scope.displaySelectedJudgeValues = $scope.searchSelectJudgeModel.map(function(el){return el.label}).join(",");
      }
    };

    function onAnomalyTypeSelectionChanged() {
      if($scope.searchSelectAnomalyTypeModel.length >= 0) {
         $scope.displaySelectedAnomalyTypeValues = $scope.searchSelectAnomalyTypeModel.map(function(el){return el.label}).join(",");
      }
    };

    // function called when county drop down changed
    function updateCountyList(selecteditem) {
         $scope.countyList = [];
         console.log("updated county selecteditem = " + selecteditem);
         $scope.countyList = getFiltersList(selecteditem,$scope.countyfieldname);
        //  console.log("$scope.countyList.length = " + $scope.countyList.length);
        //  if($scope.countyList.length <= 0) {
        //    $scope.searchSelectCountyModel = [];
        //  }
    };

    function updateExpenseList(selecteditem) {
        $scope.expenseList = [];
        $scope.expenseList = getFiltersList(selecteditem,$scope.expensefieldname);

    };

    function updateFirmList(selecteditem) {
       $scope.firmList = [];
       console.log("updated firm selecteditem = " + selecteditem);
       $scope.firmList = getFiltersList(selecteditem,$scope.firmfieldname);

    };

    function updateTimeKeeperList(selecteditem) {
       $scope.timekeeperList = [];
       $scope.timekeeperList = getFiltersList(selecteditem,$scope.timekeeperfieldname);
       console.log("updateTimeKeeperList = " + JSON.stringify($scope.timekeeperList));
    };

    function updateMatterNameList(selecteditem) {
       console.log("updating mattername list = "+selecteditem);
       analysisService.getMatterList(selecteditem)
           .then(
             function( mydata ) {
               $scope.matternameList = [];
               for(var i in mydata) {
                 //console.log(i);
                 //$scope.matternameList.push(i+ "||" +jsondata[i]); {id:'expense1'}
                 $scope.matternameList.push(
                   {
                     id: i,
                     label:mydata[i] + "->" + i
                   });
                }
            });

    };

    function updateTaskList(selecteditem) {
      $scope.taskList = [];
      $scope.taskList = getFiltersList(selecteditem,$scope.taskcodefieldname);

    };

    function updatePhaseList(selecteditem) {
      $scope.phaseList = [];
      $scope.phaseList = getFiltersList(selecteditem,$scope.phasefieldname);

    };

    function updateStaffList(selecteditem) {
      $scope.staffList = [];
      $scope.staffList = getFiltersList(selecteditem,$scope.stafffieldname);

    };

  // common function to get different lists from the backend service based on the params passed.
  //function getFiltersList(selecteditem,category,findfieldname){
  function getFiltersList(selecteditem,findfieldname){
       var dataList = [];
       console.log("updating filterlist" + selecteditem + "," + findfieldname);
       analysisService.getAnalysisData(selecteditem,findfieldname)
         .then(
           function( mydata ) {
             for(var i in mydata) {
                //console.log("getFiltersList function - " + i);
              //  dataList.push(i);
                 dataList.push(
                   { id:i,
                     label: i
                   });
               }
             });
        return dataList;
    };

	function updateAllFilters(selecteditem) {
		//if($scope.selectionList.length > 0) {
			console.log('updateAllFilters now: selecteditem value: '+selecteditem);

			// update the show hide filterselection
			 $scope.hiderateCategory = false;
			 $scope.hidetrialdateCategory= false;
			 $scope.hidecaselengthCategory= false;
			 $scope.hidemattertypeCategory= false;
			 $scope.hidedisputetypeCategory= false;
			 $scope.hidecourttypeCategory= false;
			 $scope.hideteamleadCategory= false;
			 $scope.hidesupervisingattorneyCategory= false;
			 $scope.hideplaintiffcounselCategory= false;
			 $scope.hideassignedcounselCategory= false;
			 $scope.hidejudgeCategory= false;
			 $scope.hidematterstatusCategory= false;
			 $scope.hidematteropenCategory= false;
			 $scope.hidemattercloseCategory= false;
		   $scope.hideanomalytypeCategory= false;

			$scope.rates = [];
			$scope.traildates = [];
			$scope.caselengths = [];
			$scope.mattertypes = [];
			$scope.disputetypes = [];
			$scope.courttypes = [];
			$scope.teamleads = [];
			$scope.supervisingattorneys = [];
			$scope.plaintiffcounsels = [];
			$scope.assignedcounsels = [];
			$scope.judges = [];
			$scope.matterstatuses = [];
			$scope.matteropens = [];
			$scope.mattercloses = [];
			$scope.anomalytypes = [];

      $scope.rateList= [];
      $scope.rateList = getFiltersList(selecteditem,$scope.ratebucketfieldname);
      $scope.displaySelectedRateValues = "";
      $scope.searchSelectRateModel = [];

      $scope.traildateList= [];
      $scope.traildateList = getFiltersList(selecteditem,$scope.trialdatefieldname);
      $scope.displaySelectedTraildateValues = "";
      $scope.searchSelectTrialDateModel = [];

      $scope.caselengthList= [];
      $scope.caselengthList = getFiltersList(selecteditem,$scope.lengthbucketfieldname);
      $scope.displaySelectedCaseLengthValues = "";
      $scope.searchSelectCaseLengthModel = [];

      $scope.mattertypeList= [];
      $scope.mattertypeList = getFiltersList(selecteditem,$scope.mattertypefieldname);
      $scope.displaySelectedMatterTypeValues = "";
      $scope.searchSelectMatterTypeModel = [];

      $scope.disputetypeList= [];
      $scope.disputetypeList = getFiltersList(selecteditem,$scope.disputetypefieldname);
      $scope.displaySelectedDisputeTypeValues = "";
      $scope.searchSelectDisputeTypeModel = [];

      $scope.courttypeList= [];
      $scope.courttypeList = getFiltersList(selecteditem,$scope.courttypefieldname);
      $scope.displaySelectedCourtTypeValues = "";
      $scope.searchSelectCourtTypeModel = [];

      $scope.teamleadList= [];
      $scope.teamleadList = getFiltersList(selecteditem,$scope.teamleadfieldname);
      $scope.displaySelectedTeamLeadValues = "";
      $scope.searchSelectTeamLeadModel = [];

      $scope.supervisingattorneyList= [];
      $scope.supervisingattorneyList = getFiltersList(selecteditem,$scope.attorneyfieldname);
      $scope.displaySelectedSupervisingAttorneyValues = "";
      $scope.searchSelectSupervisingAttorneyModel = [];

      $scope.plaintiffcounselList= [];
      $scope.plaintiffcounselList = getFiltersList(selecteditem,$scope.opposingcounselfieldname);
      $scope.displaySelectedPlaintiffCounselValues = "";
      $scope.searchSelectPlaintiffModel = [];

      $scope.assignedcounselList= [];
      $scope.assignedcounselList = getFiltersList(selecteditem,$scope.assignedcounselfieldname);
      $scope.displaySelectedAssignedCounselValues = "";
      $scope.searchSelectAssignedCounselModel = [];

      $scope.judgeList= [];
      $scope.judgeList = getFiltersList(selecteditem,$scope.judgefieldname);
      $scope.displaySelectedJudgeValues = "";
      $scope.searchSelectJudgeModel = [];

      $scope.matteropenList= [];
      $scope.matteropenList = getFiltersList(selecteditem,$scope.opendatefieldname);
      $scope.displaySelectedMatteropenValues = "";
      $scope.searchSelectMatterOpenDateModel = [];

      $scope.mattercloseList= [];
      $scope.mattercloseList = getFiltersList(selecteditem,$scope.closedatefieldname);
      $scope.displaySelectedMattercloseValues = "";
      $scope.searchSelectMatterCloseDateModel = [];

      $scope.anomalytypeList= [];
      $scope.anomalytypeList = getFiltersList(selecteditem,$scope.anomalydescriptionfieldname);
      $scope.displaySelectedAnomalyTypeValues = "";
      $scope.searchSelectAnomalyTypeModel = [];

      $scope.matterstatusList= [];
      $scope.matterstatusList = getFiltersList(selecteditem,$scope.statusfieldname);
      $scope.displaySelectedMatterstatusValues = "";
      $scope.searchSelectMatterStatusModel = [];

	};

	$scope.getCategorySelected = function() {
		$scope.categorySelected = $scope.selectionList[$scope.selectionList.length-1];
    console.log("getCategorySelected function ***** = " + $scope.categorySelected);
    if($scope.categorySelected == 'timekeeper')
			$scope.categorySelected = 'fullname';
		else if($scope.categorySelected == 'staff')
			$scope.categorySelected = 'tklevel';
		else if($scope.categorySelected == 'firm')
			$scope.categorySelected = 'firmname';
		else if($scope.categorySelected == 'expense')
			$scope.categorySelected = 'disbcode';
		else if($scope.categorySelected == 'task')
			$scope.categorySelected = 'taskcode';
	};

	$scope.getSelectedKPI = function() {
		if($scope.hours) {
			$scope.kpiSelected = 'hours';
		}
		else if($scope.spending) {
			$scope.kpiSelected = 'netamount';
		}
		else if($scope.anomalies) {
			$scope.kpiSelected = 'AnomalyCount';
		}

	};

	$scope.getFilters = function() {
		$scope.filtersSelected = "";
		if($scope.searchSelectRateModel.length >= 1) {
      console.log("$scope.searchSelectRateModel.length =" + $scope.searchSelectRateModel.length  + " value " + $scope.searchSelectRateModel[0]);
      var selectedRate = getSelectedParams($scope.searchSelectRateModel,$scope.ratebucketfieldname);
    	$scope.filtersSelected = $scope.filtersSelected + selectedRate + "&&";
		}
    if($scope.searchSelectTrialDateModel.length >= 1) {
      var selectedTrailDate = getSelectedParams($scope.searchSelectTrialDateModel,$scope.trialdatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedTrailDate + "&&";
    }
    if($scope.searchSelectCaseLengthModel.length >= 1) {
      var selectedCaseLength = getSelectedParams($scope.searchSelectCaseLengthModel,$scope.lengthbucketfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedCaseLength + "&&";
    }
    if($scope.searchSelectMatterTypeModel.length >= 1) {
      var selectedMatterType = getSelectedParams($scope.searchSelectMatterTypeModel,$scope.mattertypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterType + "&&";
    }
    if($scope.searchSelectDisputeTypeModel.length >= 1) {
      var selectedDisputeType = getSelectedParams($scope.searchSelectDisputeTypeModel,$scope.disputetypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedDisputeType + "&&";
    }
    if($scope.searchSelectCourtTypeModel.length >= 1) {
      var selectedCourtType = getSelectedParams($scope.searchSelectCourtTypeModel,$scope.courttypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedCourtType + "&&";
    }
    if($scope.searchSelectTeamLeadModel.length >= 1) {
      var selectedTeamLead = getSelectedParams($scope.searchSelectTeamLeadModel,$scope.teamleadfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedTeamLead + "&&";
    }
    if($scope.searchSelectSupervisingAttorneyModel.length >= 1) {
      var selectedSupervisingAttorney = getSelectedParams($scope.searchSelectSupervisingAttorneyModel,$scope.attorneyfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedSupervisingAttorney + "&&";
    }
    if($scope.searchSelectPlaintiffModel.length >= 1) {
      var selectedPlaintiff = getSelectedParams($scope.searchSelectPlaintiffModel,$scope.opposingcounselfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedPlaintiff + "&&";
    }
    if($scope.searchSelectAssignedCounselModel.length >= 1) {
      var selectedAssignedCounsel = getSelectedParams($scope.searchSelectAssignedCounselModel,$scope.assignedcounselfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedAssignedCounsel + "&&";
    }
    if($scope.searchSelectJudgeModel.length >= 1) {
      var selectedJudge = getSelectedParams($scope.searchSelectJudgeModel,$scope.judgefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedJudge + "&&";
    }
    if($scope.searchSelectMatterStatusModel.length >= 1) {
      var selectedMatterStatus = getSelectedParams($scope.searchSelectMatterStatusModel,$scope.statusfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterStatus + "&&";
    }
    if($scope.searchSelectMatterOpenDateModel.length >= 1) {
      var selectedMatterOpenDate = getSelectedParams($scope.searchSelectMatterOpenDateModel,$scope.opendatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterOpenDate + "&&";
    }
    if($scope.searchSelectMatterCloseDateModel.length >= 1) {
      var selectedMatterCloseDate = getSelectedParams($scope.searchSelectMatterCloseDateModel,$scope.closedatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterCloseDate + "&&";
    }
    if($scope.searchSelectAnomalyTypeModel.length >= 1) {
      var selectedAnomalyType = getSelectedParams($scope.searchSelectAnomalyTypeModel,$scope.anomalydescriptionfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedAnomalyType + "&&";
    }
    if($scope.selectionList.length > 1) {
      if($scope.searchSelectStateModel.length >=1) {
        var selectedState = getSelectedParams($scope.searchSelectStateModel,$scope.statefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedState + "&&";
      }
      else if($scope.searchSelectCountyModel.length >= 1) {
        var selectedCounty = getSelectedParams($scope.searchSelectCountyModel,$scope.countyfieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedCounty + "&&";
      }
      else if($scope.searchSelectFirmModel.length >= 1) {
        var selectedFirm = getSelectedParams($scope.searchSelectFirmModel,$scope.firmfieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedFirm + "&&";
      }
      else if($scope.searchSelectMatterModel.length >= 1) {
        var selectedMatterName = getSelectedParams($scope.searchSelectMatterModel,$scope.matternamefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedMatterName + "&&";
      }
      else if($scope.searchSelectPhaseModel.length >= 1) {
        var selectedPhase = getSelectedParams($scope.searchSelectPhaseModel,$scope.phasefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedPhase + "&&";
      }
      else if($scope.searchSelectExpenseModel.length >= 1) {
        var selectedExpense = getSelectedParams($scope.searchSelectExpenseModel,$scope.expensefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedExpense + "&&";
      }
      else if($scope.searchSelectTaskModel.length >= 1) {
        var selectedTask = getSelectedParams($scope.searchSelectTaskModel,$scope.taskcodefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedTask + "&&";
      }
      else if($scope.searchSelectTimekeeperModel >= 1) {
        var selectedTimekeeper = getSelectedParams($scope.searchSelectTimekeeperModel,$scope.timekeeperfieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedTimekeeper + "&&";
      }
      else if($scope.searchSelectStaffModel.length >= 1) {
        var selectedStaff = getSelectedParams($scope.searchSelectStaffModel,$scope.stafffieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedStaff + "&&";
      }
  }
		console.log("FILTER SELECTION IS::::"+$scope.filtersSelected);
	};

	$scope.getValueSelected = function() {
//		$scope.valueSelected = [];
    console.log("categorySelected = ******* " + $scope.categorySelected);
		if($scope.categorySelected == 'state') {
			getSelectedValuesForReport($scope.searchSelectStateModel);
		}
		else if($scope.categorySelected == 'county') {
			getSelectedValuesForReport($scope.searchSelectCountyModel);
		}
		else if($scope.categorySelected == 'firmname') {
      console.log("category selected in firmname loop **************")
			getSelectedValuesForReport($scope.searchSelectFirmModel);
		}
		else if($scope.categorySelected == 'mattername') {
			getSelectedValuesForReport($scope.searchSelectMatterModel);
		}
		else if($scope.categorySelected == 'phase') {
			getSelectedValuesForReport($scope.searchSelectPhaseModel);
		}
		else if($scope.categorySelected == 'disbcode') {
			getSelectedValuesForReport($scope.searchSelectExpenseModel);
		}
		else if($scope.categorySelected == 'taskcode') {
			getSelectedValuesForReport($scope.searchSelectTaskModel);
		}
		else if($scope.categorySelected == 'fullname') {
			getSelectedValuesForReport($scope.searchSelectTimekeeperModel);
		}
		else if($scope.categorySelected == 'tklevel') {
			getSelectedValuesForReport($scope.searchSelectStaffModel);
		}

		console.log("getValueSelected ******* = " + $scope.valueSelected);
	};

	$scope.getDefaultSubcategory = function(subcategory) {
		console.log('get default subcategory:'+subcategory);
		if(subcategory != "") {
			if(subcategory == 'State') {
				$scope.subcategorySelected = 'state';
			}
			else if(subcategory == 'County') {
				$scope.subcategorySelected = 'county';
			}
			else if(subcategory == 'Firm') {
				$scope.subcategorySelected = 'firmname';
			}
			else if(subcategory == 'Matter') {
				$scope.subcategorySelected = 'mattername';
			}
			else if(subcategory == 'Phase') {
				$scope.subcategorySelected = 'phase';
			}
			else if(subcategory == 'Expense') {
				$scope.subcategorySelected = 'disbcode';
			}
			else if(subcategory == 'Task') {
				$scope.subcategorySelected = 'taskcode';
			}
			else if(subcategory == 'Time Keeper') {
				$scope.subcategorySelected = 'fullname';
			}
			else if(subcategory == 'Staff') {
				$scope.subcategorySelected = 'tklevel';
			}
			else if(subcategory == 'Anomaly') {
				$scope.subcategorySelected = 'anom_desc';
			}
		}
		else {
			if($scope.categorySelected == 'state') {
				$scope.subcategorySelected = 'mattername';
			}
			else if($scope.categorySelected == 'county') {
				$scope.subcategorySelected = 'mattername';
			}
			else if($scope.categorySelected == 'firmname') {
				$scope.subcategorySelected = 'fullname';
			}
			else if($scope.categorySelected == 'mattername') {
				$scope.subcategorySelected = 'fullname';
			}
			else if($scope.categorySelected == 'phase') {
				$scope.subcategorySelected = 'task';
			}
			else if($scope.categorySelected == 'disbcode') {
				$scope.subcategorySelected = 'fullname';
			}
			else if($scope.categorySelected == 'taskcode') {
				$scope.subcategorySelected = 'fullname';
			}
			else if($scope.categorySelected == 'fullname') {
				$scope.subcategorySelected = 'phase';
			}
			else if($scope.categorySelected == 'tklevel') {
				$scope.subcategorySelected = 'mattername';
			}
		}
		console.log('Sub category selected is'+$scope.subcategorySelected);
	};

	function getNameToBeDisplayed(name) {

		if(name == 'state') {
				return 'State';
			}
			else if(name == 'county') {
				return 'County';
			}
			else if(name == 'firmname') {
				return 'Firm Name';
			}
			else if(name == 'mattername') {
				return 'Matter';
			}
			else if(name == 'phase') {
				return 'Phase';
			}
			else if(name == 'disbcode') {
				return 'Expense';
			}
			else if(name == 'taskcode') {
				return 'Task';
			}
			else if(name == 'fullname') {
				return 'Time Keeper';
			}
			else if(name == 'tklevel') {
				return 'Staff Level';
			}
			else if(name == 'netamount') {
				return 'Spending ($)';
			}
			else if(name == 'hours') {
				return 'Hours';
			}
			else if(name == 'AnomalyCount') {
				return 'Anomaly Count';
			}
			else if(name == 'anom_desc') {
				return 'Anomaly Description';
			}
			return 'no mapping found';
	};


	function createPieHighChart(returneddata) {
		//var dataTmp = [];
		//dataTmp = dataTmp.map(function(returnedData) { return JSON.stringify(returnedData); });

		var json = eval("([" +returneddata+ "])");

		console.log(json);
		//var dataarray = JSON.parse(returneddata);
		//console.log(dataarray);
		//var dataarraymew = [];
		//dataarraymew.push(dataarray);
		//console.log(dataarraymew);
		var kpi = getNameToBeDisplayed($scope.kpiSelected);
		var cat = getNameToBeDisplayed($scope.categorySelected);
		var sub = getNameToBeDisplayed($scope.subcategorySelected);
		var title = cat + ' : ' +kpi + ' - Viewing By: '+sub;
			$(".legendArea2").html("<div></div>");
			$("#legendHeaderLeft2").html("<div>"+sub+"</div>");
			$("#legendHeaderMiddle2").html("<div>Percentage</div>");
			$("#legendHeaderRight2").html("<div>"+ kpi+"</div>");
    var tot=0;
			for (var j = 0; j < json.length; j++) {
				tot=tot+json[j].y;
			}
			var x=0;
			for(var i=1;i<json.length+1;i++) {
				if(i%10 == 1)x=0;
				$(".legendArea2").append("<div class='row'><div id='percLegendField' class='displayBlock col-lg-6'><div class='circle displayBlock' id='colorLegend' style='" + "background:" + Highcharts.getOptions().colors[x] + "'></div>" + json[i-1].name + "</div><div id='nameLegendField' class='percentageBlock col-lg-2'>"+(((json[i-1].y)/tot)*100).toFixed(2) + "%</div><div class='col-lg-2' id='nameLegendField'>" + JSON.stringify(json[i-1].y) + "</div></div></br>");
				x++;
			}			tot=0;


		Highcharts.setOptions({
			colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584']
		});

		Highcharts.chart('piechart', {
						chart: {
							plotBackgroundColor: null,
							plotBorderWidth: null,
							plotShadow: false,
							type: 'pie'
						},
						title: {
							text: title,
              margin: 7,
              style: {
        		fontFamily: 'Roboto',
            fontSize: 18,
            fontWeight: 600,
            color: '#6e6e6e'
        },
              align: 'left',
                      style: {
                    fontSize: '18px',
                    color: '#6e6e6e'
        }
						},
						tooltip: {
							pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
						},
      colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584'],
						plotOptions: {
							pie: {
								allowPointSelect: true,
								cursor: 'pointer',
                size: 250,
                center: ["50%", "50%"],
								dataLabels: {
									enabled: false,
									formatter: function() {
										return Math.round(this.percentage*100)/100 + ' %';
									},
									distance: -30,
									color:'white'
								},
								showInLegend: true
							}
						},
						credits: {
							enabled: false
						},
						legend: {
              enabled: false

						},

						series: [{
							name: kpi,
							colorByPoint: true,
							data: json
						}]
					});
	};

	function createBarChart(returneddata) {
		var json = eval("([" +returneddata+ "])");
		console.log("createBarChart json = " + json);
		var kpi = getNameToBeDisplayed($scope.kpiSelected);
		var cat = getNameToBeDisplayed($scope.categorySelected);
		var sub = getNameToBeDisplayed($scope.subcategorySelected);
		var title = cat + ' : ' +kpi + ' - Viewing By: '+sub;

		$scope.legendheader = sub;
		$scope.legendmiddle = "Percentage(%)";
		$scope.legendright = kpi;

		var cats = [];
		if($scope.showcompTimeCategory) {
			cats = $scope.timeselected;
		}
		else {
			cats = $scope.valueSelected;
		}
		$('.tabLayout').empty();
		for(var i=0;i<cats.length;i++){
			$('.tabLayout').append("<a class='tabButton' id='tabBut"+i+"' tabindex='"+i+"'>"+cats[i]+"        </a>");
		}
		var tot =0;
		$(".legendArea").html("<div></div>");
		$(".legendHeaderLeft").html("<div></div>");
			$(".legendHeaderMiddle").html("<div></div>");
			$(".legendHeaderRight").html("<div></div>");
		$(".tabButton").click(function () {
			$(".legendMid").hide();
			$(".legendArea").html("<div></div>");
			$(".legendHeaderLeft").html("<div>"+ sub+"</div>");
			$(".legendHeaderMiddle").html("<div>Percentage</div>");
			$(".legendHeaderRight").html("<div>"+ kpi+"</div>");
			for (var j = 0; j < json.length; j++) {
				tot=tot+json[j].data[this.tabIndex];
			}
			var x=0;
			for(var i=1;i<json.length+1;i++) {
				if(json[i-1].data[this.tabIndex]==0){
					x=x+1;
					continue;
				}
				if(i%10 == 1)x=0;
					$(".legendArea").append("<div class='row'><div id='percLegendField' class='displayBlock col-lg-6'><div class='circle displayBlock' id='colorLegend' style='" + "background:" + Highcharts.getOptions().colors[x] + "'></div>" + json[i-1].name + "</div><div id='nameLegendField' class='percentageBlock col-lg-2'>"+(((json[i-1].data[this.tabIndex])/tot)*100).toFixed(2) + "%</div><div class='col-lg-2' id='nameLegendField'>" + JSON.stringify(json[i-1].data[this.tabIndex]) + "</div><div></br>");
				x++;
			}
			tot=0;
		});


		Highcharts.setOptions({
			colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584']
		});

		Highcharts.chart('barchart', {
		chart: {
			type: 'column'
		},
		title: {
							text: title,
              margin: 20,
              align: 'left',
                      style: {
                    fontSize: '18px',
                    color: '#6e6e6e'
                      }
        },
          colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584'],
		xAxis: {
			categories: cats
		},
		yAxis: {
			min: 0,
			title: {
				text: kpi
			},
			stackLabels: {
				enabled: true,
				style: {
					fontWeight: 'bold',
					color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
				}
			}
		},
		legend : {
			enabled: false

            },
		tooltip: {
			headerFormat: '<b>{point.x}</b><br/>',
			pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
		},
		credits: {
			enabled: false
		},

		plotOptions: {
			column: {
				stacking: 'normal',
				dataLabels: {
					enabled: false,
					color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
				}
			}
		},
		series: json

	});


	};

	function createTimeLineChart(returneddata) {
		var jsonData = eval("([" +returneddata+ "])");
		console.log("create timelinechart= "+JSON.stringify(jsonData));
		var chart;

		var nameValues = [];
		for(var m=1;m<jsonData.length;m++) {
			nameValues.push(JSON.stringify(jsonData[m]));
		}
		console.log('namvalues:'+nameValues);

		var dates = [];
		for(var i=0;i<jsonData[0].data.length;i++) {
			dates.push(jsonData[0].data[i]);
		}
		console.log('dates'+dates);
		var categories = [];
		for(var j=0;j<dates.length;j++) {
			categories.push(dates[j]);
		}
		console.log('categories1'+categories);

		var obj = {};
		var arr = [];
		for(var z=0;z<categories.length;z++){
			obj[categories[z]] = z;
		}
		categories.sort(function(s1,s2){
			var sdate1 = s1.split('/');
			var sdate2 = s2.split('/');
			var date1 = sdate1[1]+'/'+sdate1[0]+'/'+sdate1[2];
			var date2 = sdate2[1]+'/'+sdate2[0]+'/'+sdate2[2];
			var aa = date1.split('/').reverse().join(),
			bb = date2.split('/').reverse().join();
			return aa < bb ? -1 : (aa > bb ? 1 : 0);

		});
	   console.log('categories after sort'+categories);
                for(var c=0;c<categories.length;c++){
                    arr.push(JSON.stringify(obj[categories[c]]));
                }
		console.log('arr is'+arr);

                var arr1 = [];
                for(var m=0;m<JSON.parse("["+nameValues+"]").length;m++) {
                    for(var b=0;b<JSON.parse("["+nameValues+"]")[0].data.length;b++){
                        arr1.push(JSON.parse("["+nameValues+"]")[m].data[b]);
                    }
                }
                var x = 0;
                for(var r=0;r<nameValues.length;r++) {
                    var arr2 = {};
                    for (var w = x; w < x+arr.length; w++) {
                        arr2[arr[w-x]] = arr1[w];
                    }
                    var jsonArrayData = [];
                    /*console.log(jsonData[r+1].data.length);*/
                    for(var v=0;v<jsonData[r+1].data.length;v++) {
                        /*console.log("arr2 "+arr2[v]);*/
                        jsonArrayData.push(arr2[v]);
                    }
                    jsonData[r+1].data = jsonArrayData;
                    /*console.log(JSON.stringify(jsonData));*/
                    x=x+arr.length;
                }
                var max = arr1.reduce(function(a, b) {
                    return Math.max(a, b);
                });
                var min = arr1.reduce(function (a, b) {
                    return Math.min(a,b);
                });
                var finalJson = [];
                for(var t=1;t<jsonData.length;t++){
                    finalJson.push(JSON.stringify(jsonData[t]));
                }

                var finaldatatodisplay = JSON.parse("["+finalJson+"]");

				var kpi = getNameToBeDisplayed($scope.kpiSelected);
				var cat = getNameToBeDisplayed($scope.categorySelected);
				var sub = getNameToBeDisplayed($scope.subcategorySelected);
				var title = cat + ' : ' +kpi;
				Highcharts.chart('timelinechart', {
                chart: {

                },
                title: {
							text: title,
             margin: 20,
              align: 'left',
                      style: {
                    fontSize: '18px',
                    color: '#6e6e6e'
        }
                },
                plotOptions: {
                    line: {
                        marker: {
                            enabled: false
                        }
                    }
                },
              colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584'],
                subtitle: {
                    text: ''
                },
                yAxis: {
                    title: {
                        text: kpi
                    },
                    minorGridLineWidth: 0,
                    gridLineWidth: 0,
					max: max,
					min: min
                },
                xAxis: {
                    title: {
                        text: 'Date'
                    },
                    categories: categories
                },
                series: finaldatatodisplay,
                navigation: {
                    menuItemStyle: {
                        fontSize: '10px'
                    }
                },
				credits: {
					enabled: false
				},

                legend : {
                    itemWidth: 800,
                    x: 90,
                    useHTML: true,
                    labelFormatter: function() {
                        var total = 0;
                        for(var i=this.yData.length; i--;) { total += this.yData[i]; };
                        return "<div style='display: inline-table; width: 500px;'>"+this.name+ "</div><div style='text-align:right;display: inline-table; width:50px;'>"+ total.toFixed(2)+"</div>";
                    }
                }

            });

	};

	$scope.populateSubCategorySelection = function() {
		$scope.subcategoryvalues = [];
		$scope.showSubCategory = true;
		if($scope.categorySelected == 'state') {
			$scope.subcategoryvalues.push('County');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
				$scope.subcategoryvalues.push('Anomaly');
		}
		else if($scope.categorySelected == 'county') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
				$scope.subcategoryvalues.push('Anomaly');
			}
		else if($scope.categorySelected == 'firmname') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'mattername') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'phase') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'disbcode') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'task') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'fullname') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Task');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'tklevel') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');
		}
		console.log('Array of values is'+$scope.subcategoryvalues);
	};
	$scope.getDateFilter = function() {
    $scope.timeselected = [];
    var timeCompSelectedValue = "";
    $scope.datarange = document.getElementById("daterange").value;
    timeCompSelectedValue = document.getElementById("timecomprange").value;
    $scope.timeselected.push($scope.datarange);
    if(timeCompSelectedValue != "") {
      $scope.datarange = $scope.datarange + '||' + timeCompSelectedValue;
      $scope.timeselected.push(timeCompSelectedValue);
      console.log("time comp selected = " + timeCompSelectedValue);
    }
};

	function createMattertable(data) {
		//console.log("data in createMatterTable = " + data);
		var jsonData = eval(data);
		//console.log("create matter table "+JSON.stringify(jsonData));
		$scope.matterTableData = jsonData;
		$scope.dataForMatterTableLoaded = true;
		$scope.$apply();
	};

	$scope.convertTime = function(datetoconvert) {
		var d = new Date(datetoconvert);
		var t= d.getTime();

		return Math.round(t /1000);
	};

	$scope.executeReport = function() {
		// get the last entered filter from selectionList.  TODO - change the name for staff and timekeeper
		$scope.getCategorySelected();
    console.log("executeReport getCategorySelected = " + $scope.categorySelected);
		$scope.getValueSelected();
    console.log("$scope.valueSelected.length = "+ $scope.valueSelected.length);
		$scope.getFilters();
		// returns the KPI that has been selected
		$scope.getSelectedKPI();
		// returns the default SubCategory
		$scope.getDefaultSubcategory($scope.subcategoryselect);

		$scope.populateSubCategorySelection();
		// get all the filters put them in this format filtername-filtervalue,filtername-filtervalue
  	$scope.getDateFilter();
    console.log('datarange value is:'+$scope.datarange);
		console.log('filters is:'+$scope.filtersSelected);
		console.log("category is"+ $scope.categorySelected + ", category value is: "+$scope.valueSelected[0] + ", selected kpi:" + $scope.kpiSelected +", sub category is:" + $scope.subcategorySelected);
    if($scope.valueSelected.length == 1) {
      $scope.showPieChart = true;
      console.log("**value of $scope.valueSelected.length = " + $scope.valueSelected.length);
    }
    if($scope.valueSelected.length == 1 && $scope.categorySelected == "mattername") {
      $scope.dataForMatterTableLoaded = true;
      console.log("mattername data table loaded flag if matter is selected = " + $scope.dataForMatterTableLoaded);
    } else {

      $scope.dataForMatterTableLoaded = false;
      console.log("mattername data table loaded flag else matter is selected = " + $scope.dataForMatterTableLoaded);
    }
		var categoryString = "";
			for(var i in $scope.valueSelected ) {
				categoryString = categoryString + $scope.valueSelected[i] + "||";
			}
      console.log("categoryString before charts loop = " + categoryString);
		// timeComparision
    console.log("showcompTimeCategory before running the charts report******* " + $scope.showcompTimeCategory);
		if($scope.showcompTimeCategory) {
			$.ajax({
			  url      : "/AppBuilder/endpoint/AnalysisCharts",
			  type     : "POST",
			  data     : {category: $scope.categorySelected, categoryvalue: $scope.valueSelected[0], datefilter: $scope.datarange, filters: $scope.filtersSelected, selectedkpi: $scope.kpiSelected, subcategory: $scope.subcategorySelected,charttype:"timecomparison"},
			  success  : function(data) {
				console.log("AnalysisCharts endpoint for timecomparison data = " + data);
				createBarChart(data);
			  }
			});
     $scope.showPieChart = false;
		}
		else if($scope.valueSelected.length == 1) {
      console.log("inside piechart loop " + $scope.valueSelected.length);
			$.ajax({
				  url      : "/AppBuilder/endpoint/AnalysisCharts",
				  type     : "POST",
				  data     : {category: $scope.categorySelected, categoryvalue: $scope.valueSelected[0], datefilter: $scope.datarange, filters: $scope.filtersSelected,  selectedkpi: $scope.kpiSelected, subcategory: $scope.subcategorySelected,charttype:"pie"},
				  success  : function(data) {

						console.log("AnalysisCharts endpoint for pie rOutput:"+ data);

						createPieHighChart(data);
				  }
			});
      $scope.showPieChart = true;
		}
		else {
      // replaced barchartendpoint with analysischarts endpoint
		console.log('asfkndasflnkldsf:'+categoryString);
    $scope.showPieChart = false;
		$.ajax({
		  url      : "/AppBuilder/endpoint/AnalysisCharts",
		  type     : "POST",
		  data     : {category: $scope.categorySelected, categoryvalue: categoryString, filters: $scope.filtersSelected, datefilter: $scope.datarange, selectedkpi: $scope.kpiSelected, subcategory: $scope.subcategorySelected,charttype:"bar"},
		  success  : function(data) {
						console.log("Output for bar chart is:"+ data);
						createBarChart(data);
		  }
		});

		}
		// timelinechart - category and sub category are the same
    console.log("timelinechart before ********* =" +$scope.showcompTimeCategory );
		if(!$scope.showcompTimeCategory) {
      $.ajax({
				  url      : "/AppBuilder/endpoint/AnalysisCharts",
				  type     : "POST",
				  data     : {category: $scope.categorySelected, categoryvalue: categoryString, filters: $scope.filtersSelected, datefilter: $scope.datarange, selectedkpi: $scope.kpiSelected, subcategory: $scope.categorySelected,charttype:"timeline"},
				  success  : function(data) {
					console.log("Output for timeline chart is:"+ data);
					createTimeLineChart(data);
				  }
			});
		}

		if($scope.valueSelected.length == 1 && $scope.categorySelected == "mattername") {
			console.log("data for this mattername is:"+$scope.valueSelected[0] );
			$.ajax({
			  url      : "/AppBuilder/endpoint/scenario5",
			  type     : "POST",
			  data     : {mattername: $scope.valueSelected[0]},
			  success  : function(data) {
				  createMattertable(data);
			  }
			});
		}
	};
  init();
}]);

// Analysis data service

var AnalysisDataService = angular.module('AnalysisDataService', [])
    .service('analysisService', function ($http,$q) {

    // Service method to get the analysis data
    // Return service methodes.
    return({
          getStatesList: getStatesList,
          getAnalysisData: getAnalysisData,
          getMatterList: getMatterList
    });

    // start call to get state list
    function  getStatesList() {
        var request = $http({
                  method: "post",
                  url: "/AppBuilder/endpoint/GetStates",
            });
          return(request.then( handleSuccess, handleError ) );
        }

    // start call to get analysis data
    //function getAnalysisData(selecteditem,category,findfieldname) {
      function getAnalysisData(filtervalue,findfieldname) {
      console.log("getAnalysisData for fields filtervalue = " + filtervalue + " findfieldname = " + findfieldname);
      var request = $http({
                method: "post",
                url: "/AppBuilder/endpoint/AnalysisEndpoint",
                params: {
                        //  FilterName: category,
                          FilterValue: filtervalue,
                          FindFieldName: findfieldname
                      }
              });
            return(request.then( handleSuccess, handleError ) );
        }
        // start call to get matter list
        function getMatterList(selecteditem) {
          console.log("getMatterList for fields selecteditem = " + selecteditem);
          var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/getMatterDropDown",
                    params: {
                              FilterValue: selecteditem
                          }
                  });
                return(request.then( handleSuccess, handleError ) );
            }
    // Common method to handle the request from the server
    function handleError( response ) {
        if (
            ! angular.isObject( response.data ) ||
            ! response.data.message
            ) {
                console.log("Returning the error " + response.data);
            return( $q.reject( "An unknown error occurred." ) );
        }
        return( $q.reject( response.data.message ) );
    }
    function handleSuccess( response ) {
      console.log("Returning the response " + response.data);
      return( response.data);
    }
   // end call to get data from service.
  });


</script>
