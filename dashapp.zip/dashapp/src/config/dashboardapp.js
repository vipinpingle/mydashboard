var app = angular.module('wexdashboard', ['datamaps','DataService','ui.router']);
  app.config(function($stateProvider, $urlRouterProvider) {
  $urlRouterProvider.otherwise('all');
  $stateProvider
  .state('allstate', {
    url: '/all',
    templateUrl:'/AppBuilder/dashapp/src/views/dashboard/dashboardview.html',
    controller: 'MainController'
  })
});

app.controller('MainController', ['$scope','$state','billingService',function($scope,$state,billingService){

function getStateMapCoordinates(stateM) {
var centerS = "";
var scaleS = "";
// center is always longitude, latitude
var statemapcoordinates = {"TX": {"center": [-95, 31],"scale": 1400},"IN": {"center": [-81, 40],"scale": 3500}};
   angular.forEach(statemapcoordinates, function(value, key) {
       if(key==stateM) {
         centerS = value.center;
         scaleS = value.scale;
       }
    });
    return {
      'projectcenter': centerS,
      'projectscale': scaleS
    };
};
$scope.ytdList = [
    {name : "2016", value : "01/01/2016-12/31/2016"},
    {name : "2015", value : "01/01/2015-12/31/2015"}
];
$scope.selectedmapState = "All";
$scope.selectedstateCode = "";
$scope.topspendingyearselected = $scope.ytdList[0].name;
$scope.topfirmyearselected = $scope.ytdList[0].name;
$scope.topanomaliesyearselected = $scope.ytdList[0].name;
$scope.spendingHours = "";
$scope.billedHours = "";
$scope.violationHours = "";
$scope.topTrackedMatters = "";
$scope.topStateExpenditureData = "";
$scope.topFirmAnomaliesData = "";
$scope.dataSpendingByBudgetLoaded = false;
$scope.dataHoursBilledLoaded = false;
$scope.dataViolationsLoaded = false;
$scope.dataTrackedMattersLoaded = false;
$scope.dataTopExpendituresLoaded = false;
$scope.dataTopAnamoliesLoaded = false;
$scope.filterDefaultDate = "01/01/2016-12/31/2016";
$scope.billingHoursDefaultDate = "01/01/2015-12/31/2016";
$scope.violationHoursDefaultDate = "01/01/2015-12/31/2016";
var spendingHoursCurrencyFormat = d3.format("$,.3s");

$scope.resetToAllStates = function(allstatekey) {
  console.log("inside resetToAllStates = " + allstatekey);
  $scope.selectedstateCode = "";
  loadMap(allstatekey,$scope.selectedstateCode);
  loadSpendingBudgetData($scope.selectedstateCode,$scope.filterDefaultDate);
  loadBillingHoursData($scope.selectedstateCode,$scope.billingHoursDefaultDate);
  loadVoilationData($scope.selectedstateCode,$scope.violationHoursDefaultDate);
  loadTrackedMattersData($scope.selectedstateCode,$scope.filterDefaultDate);
  loadTopFirmExpenditureData($scope.selectedstateCode,$scope.filterDefaultDate);
  loadTopFirmAnamoliesData($scope.selectedstateCode,$scope.filterDefaultDate);
}

function init() {
     loadMap($scope.selectedmapState,$scope.selectedstateCode);
     loadSpendingBudgetData($scope.selectedstateCode,$scope.filterDefaultDate);
     loadBillingHoursData($scope.selectedstateCode,$scope.billingHoursDefaultDate);
     loadVoilationData($scope.selectedstateCode,$scope.violationHoursDefaultDate);
     loadTrackedMattersData($scope.selectedstateCode,$scope.filterDefaultDate);
     loadTopFirmExpenditureData($scope.selectedstateCode,$scope.filterDefaultDate);
     loadTopFirmAnamoliesData($scope.selectedstateCode,$scope.filterDefaultDate);
  };

  $scope.topspendingyearFilter = function() {
    if($scope.topspendingyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.topspendingyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadSpendingBudgetData($scope.selectedstateCode,selectedValue);
  }

  $scope.topfirmyearsFilter = function() {
    if($scope.topfirmyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.topfirmyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadTopFirmExpenditureData($scope.selectedstateCode,selectedValue);
  }

  $scope.topanamoliesyearsFilter = function() {
    if($scope.topanomaliesyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.topanomaliesyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadTopFirmAnamoliesData($scope.selectedstateCode,selectedValue);
  }

  function loadSpendingBudgetData(selectedStateS,filterdate){

    var categoryS = "state";
    var categorySvalue = selectedStateS;
    var filtersS = "";
    var selectedkpiS = "netamount";
    var subcategoryS = "firmname";
    var datefilterS = filterdate;
    billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
          .then(
            function( mydata ) {
                var spendingByBudget = d3.nest()
               .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
               .entries(mydata);
               $scope.spendingHours = spendingHoursCurrencyFormat(spendingByBudget);
               $scope.dataSpendingByBudgetLoaded = true;
             });
      };

  function loadBillingHoursData(selectedStateS,filterdate){
    var categoryS = "state";
    var categorySvalue = selectedStateS;
    var filtersS = "";
    var selectedkpiS = "hours";
    var subcategoryS = "itemdate";
    var datefilterS = filterdate;

     billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
          .then(
            function( mydata ) {
              var billedByHours = d3.nest()
               .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.descending)
               .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
               .entries(mydata);
                $scope.billedHours = billedByHours;
                $scope.dataHoursBilledLoaded = true;
            }
          );
      };

  function loadVoilationData(selectedStateS,filterdate){
    var categoryS = "state";
    var categorySvalue = selectedStateS;
    var filtersS = "";
    var selectedkpiS = "AnomalyDollars";
    var subcategoryS = "itemdate";
    var datefilterS = filterdate;

    billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
          .then(
            function( mydata ) {
              var violationByHours = d3.nest()
               .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.ascending)
               .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
               .entries(mydata);
                $scope.violationHours = violationByHours;
                $scope.dataViolationsLoaded = true;
            }
          );
      };

  function loadTrackedMattersData(selectedStateS,filterdate){
    var categoryS = "state";
    var categorySvalue = selectedStateS;
    var filtersS = "";
    var selectedkpiS = "netamount";
    var subcategoryS = "mattername";
    var datefilterS =  filterdate;
    billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
          .then(
            function( mydata ) {
            var trackedMatters = d3.nest()
              .key(function(d){ return d.name; })
              .rollup(function(leaves){
                return leaves.map(function(d){
                  return d.value;
                }).sort(d3.descending).slice(0, 3);
            })
            .entries(mydata);
               $scope.topTrackedMatters = trackedMatters;
               $scope.dataTrackedMattersLoaded = true;
            });
      };

  function loadTopFirmExpenditureData(selectedStateS,filterdate){
    var categoryS = "state";
    var categorySvalue = selectedStateS;
    var filtersS = "";
    var selectedkpiS = "netamount";
    var subcategoryS = "firmname";
    var datefilterS = filterdate;
    billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
          .then(
            function( mydata ) {
              var topFirmByExpenditures = d3.nest()
              .key(function(d) { return d.name})
              .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
              .entries(mydata);
              var top5Firms = topFirmByExpenditures.slice(0,5);
              $scope.topStateExpenditureData = top5Firms;
              $scope.dataTopExpendituresLoaded = true;
            }
          );
      };

  function loadTopFirmAnamoliesData(selectedStateS,filterdate){
    var datefilterS = filterdate;
     billingService.getAnomaliesData(selectedStateS,datefilterS)
          .then(
            function( mydata ) {
              var topFirmByAnamolies = d3.nest()
               .key(function(d) { return d.name})
               .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
               .entries(mydata);
               var top5Anomalies = topFirmByAnamolies.slice(0,5);
                $scope.topFirmAnomaliesData = top5Anomalies;
                $scope.dataTopAnamoliesLoaded = true;
            }
          );
      };

  function loadMap(selectedmapState,selectedstateCode) {
    if(selectedmapState != "All") {
      var fileUrl = "/AppBuilder/dashapp/src/lib/maps/USA/" + selectedstateCode + ".topo.json";
    //  console.log("fileUrl = " + fileUrl);
      var stateObjectName = selectedmapState + '.geo';
    //  console.log("stateObjectName = " + stateObjectName);
      var scaledCenter = getStateMapCoordinates(selectedstateCode);
    //  console.log("loadMap = " + scaledCenter.projectcenter);
      $scope.mapObject = {
      geographyConfig: {
            dataUrl: fileUrl
          },
          scope: stateObjectName,
          options: {
            width: 600,
            height: 350,
            legendHeight: 60 // optionally set the padding for the legend
          },
          projection: '',
          setProjection: function(element) {
            var projection = d3.geo.mercator()
               .center(scaledCenter.projectcenter)
               .rotate([4.4, 0])
               .scale(scaledCenter.projectscale)
              // GA -77.60896022270053,32.361291820877184 , scale 2000
              .translate([element.offsetWidth / 2, element.offsetHeight / 2]);
            var path = d3.geo.path().projection(projection);
            return {path: path, projection: projection};
            },
           fills: {
            defaultFill: '#c31820',
            lt50: 'rgba(0,244,244,0.9)',
            gt50: '#c31820'
          },
          // data: {
          //   '071': {fillKey: 'lt50' },
          //   '001': {fillKey: 'gt50' }
          // },
        };
    } else {

    $scope.mapObject = {
        scope: 'usa',
        options: {
          width: 600,
          legendHeight: 60 // optionally set the padding for the legend
        },
        geographyConfig: {
          highlighBorderColor: '#306596',
          highlighBorderWidth: 2
        },
        fills: {
          'HIGH': '#CC4731',
          'MEDIUM': '#c31820',
          'LOW': '#306596',
          'defaultFill': '#DDDDDD'
        },
        data: {
          "IN": {
            "fillKey": "MEDIUM",
          },
          "TX": {
            "fillKey": "MEDIUM",
          }
        },
      };
    }
  }
     $scope.updateActiveState = function(geography) {
      $scope.stateName = geography.properties.name;
      $scope.stateCode = geography.id;
      console.log("statename = "+$scope.stateName);
      loadMap($scope.stateName,$scope.stateCode);
      loadSpendingBudgetData($scope.stateCode,$scope.filterDefaultDate);
      loadBillingHoursData($scope.stateCode,$scope.billingHoursDefaultDate);
      loadVoilationData($scope.stateCode,$scope.violationHoursDefaultDate);
      loadTrackedMattersData($scope.stateCode,$scope.filterDefaultDate);
      loadTopFirmExpenditureData($scope.stateCode,$scope.filterDefaultDate);
      loadTopFirmAnamoliesData($scope.stateCode,$scope.filterDefaultDate);
      $scope.selectedstateCode = $scope.stateCode;
      $scope.$apply();
    };

    init();
}]);

  // Reusable Directive for bar Chart - Use <div bar-chart data="stateBillingData" ></div> where data parameter should be different
  app.directive('barChart', function($window){
  return {
    restrict:'EAC',
    template:"",
    scope:{
           data: '=data'
      },
    link: function (scope,elem,attrs){
      var chartElement = elem[0];
      var chartFactory = dc['barChart'];
      var sfBarChart = chartFactory(chartElement,'barchartgroup1');
      var dataToPlot;
      var widgetCurrency = attrs["widgettype"];
      var barLabelCurrencyFormat = d3.format(".3s");

      if(widgetCurrency == "violationswidget") {
        barLabelCurrencyFormat = d3.format("$,.3s");
      }
      scope.$watch('data', function (newVal, oldVal) {
          if(newVal!=oldVal){
            dataToPlot = newVal;
            updateBarChart(dataToPlot);
          } else {
            dataToPlot = newVal;
            drawBarChart(dataToPlot);
           }
      });

    function preSetupChartParameters() {
        sfBarChart
          .width(200)
          .height(270)
          .margins({top: 10, right: 10, bottom: 20, left: 10})
          .gap(0)
          .brushOn(false)
          .yAxisLabel("")
          .xUnits(dc.units.ordinal)
      }

    function postSetupChartParameters(data) {
          sfBarChart
          .on('renderlet',function () {
          var barsData = [];
          var dataLabelValues = []; // place holder for adding data labels.
          var bars = sfBarChart.selectAll('.bar').each(function (d) {
        barsData.push(d);
          });
    for(var i = 0; i < data.length ; i++)
    {
      dataLabelValues.push(data[i].key);
    };
    dataLabelValues.reverse();
    d3.select(bars[0][0].parentNode).select('#inline-labels').remove();
    var gLabels = d3.select(bars[0][0].parentNode).append('g').attr('id', 'inline-labels');
    for (var i = bars[0].length - 1; i >= 0; i--) {
        var b = bars[0][i];
    if (+b.getAttribute('height') < 18) continue;
      var myLabel = barLabelCurrencyFormat(barsData[i].data.value);
      var myLabelYtd = dataLabelValues[i];
                gLabels.append("text")
                .text(myLabel)
                .attr("class","barlabelchart")
                .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
                .attr('y', +b.getAttribute('y') + 20)
                .attr('text-anchor', 'middle')
                .attr('fill', 'white')
                gLabels.append("text")
                .text(myLabelYtd)
                .attr("class","barlabelchartytd")
                .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
                .attr('y', +b.getAttribute('y') + 40)
                .attr('text-anchor', 'middle')
                .attr('fill', 'white')
                }
              });
          sfBarChart.yAxis().ticks(0); // hide the yAsix labels
          sfBarChart.xAxis().tickValues([]); // hide the xAxis labels
      }

      function drawBarChart(data) {

      preSetupChartParameters();
      var dataToPlotFiltered = crossfilter(data);
      var yearsDim = dataToPlotFiltered.dimension(function (d) {
          return d.key;
      });
      var hoursGroup = yearsDim.group().reduceSum(function (d) {
          return d.values;
      });

      var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
      var keys = sortByValues.map(function (d) { return d.key; });
      var chartcolortypeL = attrs["chartcolortype"];
      if(chartcolortypeL == 'blue') {
         var barColorRangeA ="#029fdb";
         var barColorRangeB = "#cbcbcb";
       } else {
         var barColorRangeA ="#cbcbcb";
         var barColorRangeB = "#c31820";
       }
       var initialScaleData = [];
       for(var i = 0; i < data.length ; i++)
       {
        initialScaleData.push(data[i].values);
      };

      sfBarChart
        .dimension(yearsDim)
        .group(hoursGroup)
        .x(d3.scale.ordinal().domain(keys))
        .y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))
        .on('pretransition', function (sfBarChart) {
            var colors = d3.scale.ordinal().domain(yearsDim)
            .range([barColorRangeA, barColorRangeB]);
        sfBarChart.selectAll('rect.bar').each(function(d){
            d3.select(this).attr("style", "fill: " + colors(d.data.key));
        });
      })
        postSetupChartParameters(data);
          dc.renderAll('barchartgroup1');
        }

      function updateBarChart(data) {

      preSetupChartParameters();
      var dataToPlotFiltered = crossfilter(data);
      var yearsDim = dataToPlotFiltered.dimension(function (d) {
        return d.key;
      });
      var hoursGroup = yearsDim.group().reduceSum(function (d) {
          return d.values;
      });
      var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
      var keys = sortByValues.map(function (d) { return d.key; });
      var chartcolortypeL = attrs["chartcolortype"];
       if(chartcolortypeL == 'blue') {
         var barColorRangeA ="#029fdb";
         var barColorRangeB = "#cbcbcb";
       } else {
         var barColorRangeA ="#cbcbcb";
         var barColorRangeB = "#c31820";
       }
       var initialScaleData = []; for(var i = 0; i < data.length ; i++) {initialScaleData.push(data[i].values)};
      sfBarChart
        .dimension(yearsDim)
        .group(hoursGroup)
        .x(d3.scale.ordinal().domain(keys))
        .y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))
        .on('pretransition', function (sfBarChart) {
            var colors = d3.scale.ordinal().domain(yearsDim)
              .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820
              sfBarChart.selectAll('rect.bar').each(function(d){
                  d3.select(this).attr("style", "fill: " + colors(d.data.key));
              });
        })
        postSetupChartParameters(data);
        dc.redrawAll('barchartgroup1');
        }
      }
    };
});

  app.directive('baraChart', function($window){
  return {
    restrict:'EAC',
    template:"",
    scope:{
           data: '=data'
      },
    link: function (scope,elem,attrs){
      var chartElement = elem[0];
      var chartFactory = dc['barChart'];
      var sfBarAChart = chartFactory(chartElement,'barchartgroup2');
      var dataToPlot;
      var widgetCurrency = attrs["widgettype"];
      var barLabelCurrencyFormat = d3.format(".3s");
      if(widgetCurrency == "violationswidget") {
        barLabelCurrencyFormat = d3.format("$,.3s");
      }
      scope.$watch('data', function (newVal, oldVal) {
          if(newVal!=oldVal){
            dataToPlot = newVal;
            updateBarAChart(dataToPlot);
          } else {
            dataToPlot = newVal;
            drawBarAChart(dataToPlot);
           }
      });

    function preSetupChartParameters() {
        sfBarAChart
          .width(260)
          .height(270)
          .margins({top: 10, right: 50, bottom: 20, left: 40})
          .gap(0)
          .brushOn(false)
          .yAxisLabel("")
          .xUnits(dc.units.ordinal)
      }

    function postSetupChartParameters(data) {
          sfBarAChart
          .on('renderlet',function () {
          var barsData = [];
          var dataLabelValues = []; // place holder for adding data labels.
          var bars = sfBarAChart.selectAll('.bar').each(function (d) {
                barsData.push(d);
          });
          for(var i = 0; i < data.length ; i++)
          {
            dataLabelValues.push(data[i].key);
          };
          dataLabelValues.reverse();
          d3.select(bars[0][0].parentNode).select('#inline-labels').remove();
          var gLabels = d3.select(bars[0][0].parentNode).append('g').attr('id', 'inline-labels');
          for (var i = bars[0].length - 1; i >= 0; i--) {
              var b = bars[0][i];
              if (+b.getAttribute('height') < 18) continue;
              var myLabel = barLabelCurrencyFormat(barsData[i].data.value);
              var myLabelYtd = dataLabelValues[i];
                gLabels.append("text")
                .text(myLabel)
                .attr("class","barlabelchart")
                .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
                .attr('y', +b.getAttribute('y') + 20)
                .attr('text-anchor', 'middle')
                .attr('fill', 'white')

                gLabels.append("text")
                .text(myLabelYtd)
                .attr("class","barlabelchartytd")
                .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
                .attr('y', +b.getAttribute('y') + 40)
                .attr('text-anchor', 'middle')
                .attr('fill', 'white')
                }
              });
          sfBarAChart.yAxis().ticks(0); // hide the yAsix labels
          sfBarAChart.xAxis().tickValues([]); // hide the xAxis labels
      }

      function drawBarAChart(data) {
        preSetupChartParameters();
        var dataToPlotFiltered = crossfilter(data);
        var yearsDim = dataToPlotFiltered.dimension(function (d) {
        return d.key;
      });
      var hoursGroup = yearsDim.group().reduceSum(function (d) {
        return d.values;
      });

      var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
      var keys = sortByValues.map(function (d) { return d.key; });
      var chartcolortypeL = attrs["chartcolortype"];
       if(chartcolortypeL == 'blue') {
         var barColorRangeA ="#029fdb";
         var barColorRangeB = "#cbcbcb";
       } else {
         var barColorRangeA ="#cbcbcb";
         var barColorRangeB = "#c31820";
       }
       var initialScaleData = [];
       for(var i = 0; i < data.length ; i++)
        {
          initialScaleData.push(data[i].values);
        };
        sfBarAChart
        .dimension(yearsDim)
        .group(hoursGroup)
        .x(d3.scale.ordinal().domain(keys))
        .y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))
        .on('pretransition', function (sfBarAChart) {
            var colors = d3.scale.ordinal().domain(yearsDim)
              .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820
              sfBarAChart.selectAll('rect.bar').each(function(d){
                  d3.select(this).attr("style", "fill: " + colors(d.data.key));
              });
        })
        postSetupChartParameters(data);
          dc.renderAll('barchartgroup2');
        }

      function updateBarAChart(data) {
        preSetupChartParameters();
        var dataToPlotFiltered = crossfilter(data);
        var yearsDim = dataToPlotFiltered.dimension(function (d) {
        return d.key;
      });
      var hoursGroup = yearsDim.group().reduceSum(function (d) {
        return d.values;
      });

      var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
      var keys = sortByValues.map(function (d) { return d.key; });
      var chartcolortypeL = attrs["chartcolortype"];
      if(chartcolortypeL == 'blue') {
         var barColorRangeA ="#029fdb";
         var barColorRangeB = "#cbcbcb";
       } else {
         var barColorRangeA ="#cbcbcb";
         var barColorRangeB = "#c31820";
       }
      var initialScaleData = []; for(var i = 0; i < data.length ; i++) {initialScaleData.push(data[i].values)};
      sfBarAChart
        .dimension(yearsDim)
        .group(hoursGroup)
        .x(d3.scale.ordinal().domain(keys))
        .y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))
        .on('pretransition', function (sfBarAChart) {
            var colors = d3.scale.ordinal().domain(yearsDim)
              .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820
              sfBarAChart.selectAll('rect.bar').each(function(d){
                  d3.select(this).attr("style", "fill: " + colors(d.data.key));
              });
        })
        postSetupChartParameters(data);
        dc.redrawAll('barchartgroup2');
        }
      }
    };
});

app.directive('rowbarChart', function($window){
  return {
   restrict:'EAC',
    template:"",
    scope:{
           data: '=data'
      },
  link: function (scope,elem,attrs){
   scope.$watch('data', function (newVal, oldVal) {
          if(newVal!=oldVal){
            barDataToPlot = newVal;
            updateRowBarChart(barDataToPlot);
          } else {
            barDataToPlot = newVal;
            drawRowBarChart(barDataToPlot);
           }
      });
  function drawRowBarChart(data) {
  var margin = {
          top: 15,
          right: 25,
          bottom: 15,
          left: 60
      };

  var barPadding = 3.5;
  var barPaddingOuter = 0.1;
  var topData = data.slice(0,3);
      var width = 580 - margin.left - margin.right,
          height = 280 - margin.top - margin.bottom;
  var rowbarLabelCurrencyFormat = d3.format("$,");
  var x = d3.scale.linear()
          .range([0, width])
          .domain([0, d3.max(topData, function (d) {
              return d.values;
          })]);

  var y = d3.scale.ordinal()
          .rangeRoundBands([height , 0], barPadding, barPaddingOuter)
          .domain(topData.map(function (d) {
              return d.key;
          }));

  var chart = d3.select('#matterchart').append('div').attr('class', 'matterchart');
  var g = chart.selectAll('div')
    .data(topData)
    .enter()
    .append('div')
    .attr("class", "masterdiv")

    g.append("div")
    .attr("class", "barlabel")
    .text(function (d, i) { return d.key });

var bars = g.append("div")
    .attr("class", "rect")
    .style("width", function (d) {
        return (x(d.values/1.2) + "px");
          })
    .style("padding","10px")
    .text(function (d) { return rowbarLabelCurrencyFormat(Math.ceil(d.values)); })
    }

    // update the horizontal chart.
    function updateRowBarChart(data) {
    var old = d3.selectAll('.matterchart');
    old.remove();
    var margin = {
            top: 15,
            right: 25,
            bottom: 15,
            left: 60
        };
    var barPadding = 3.5;
    var barPaddingOuter = 0.1;
    var topData = data.slice(0,3);
    var width = 580 - margin.left - margin.right,
        height = 280 - margin.top - margin.bottom;
    var rowbarLabelCurrencyFormat = d3.format("$,");
    var x = d3.scale.linear()
            .range([0, width])
            .domain([0, d3.max(topData, function (d) {
                return d.values;
            })]);

        var y = d3.scale.ordinal()
            .rangeRoundBands([height , 0], barPadding, barPaddingOuter)
            .domain(topData.map(function (d) {
                return d.key;
            }));

    var chart = d3.select('#matterchart').append('div').attr('class', 'matterchart');
    var g = chart.selectAll('div')
      .data(topData)
      .enter()
      .append('div')
      .attr("class", "masterdiv")
      g.append("div")
      .attr("class", "barlabel")
      .text(function (d, i) { return d.key });

    var bars = g.append("div")
      .attr("class", "rect")
      .style("width", function (d) {
          return (x(d.values/1.2) + "px");
            })
      .style("padding","10px")
      .text(function (d) { return rowbarLabelCurrencyFormat(Math.ceil(d.values)); })
      }
    }
  }
});

var DataService = angular.module('DataService', [])
    .service('billingService', function ($http,$q) {
    return({
          getServiceData: getServiceData,
          getAnomaliesData: getAnomaliesData
      });

    function  getServiceData(category,categoryvalue,filters,selectedkpi,subcategory,datefilter) {
    var request = $http({
            method: "post",
            url: "/AppBuilder/endpoint/dashboardendpoint",
            params: {
                    category: category,
                    categoryvalue: "'" + categoryvalue + "'",
                    filters: filters,
                    selectedkpi: selectedkpi,
                    subcategory: subcategory,
                    datefilter: datefilter
                  }
        });
    return(request.then( handleSuccess, handleError ) );
  }

  function  getAnomaliesData(stateS,datefilterS) {
  var request = $http({
            method: "post",
            url: "/AppBuilder/endpoint/getAnomaly",
            params: {
                    state: stateS,
                    datefilter: datefilterS
                }
        });
    return(request.then( handleSuccess, handleError ) );
  }

  function handleError( response ) {
        if (
            ! angular.isObject( response.data ) ||
            ! response.data.message
            ) {
            return( $q.reject( "An unknown error occurred." ) );
        }
        return( $q.reject( response.data.message ) );
    }
    function handleSuccess( response ) {
      return( response.data);
    }
 });
