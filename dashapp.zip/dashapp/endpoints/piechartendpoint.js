data = {}
category = params[:category]
subcategory = params[:subcategory]
categoryvalue = params[:categoryvalue]
selectedkpi = params[:selectedkpi]
filters = params[:filters].split(",,")
filterstring =nil
datefilter = params[:datefilter].split("-")


facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
facet_by_hours = sum(xpath('$'+selectedkpi)).with_facet_id('kpi_id')

categoryfilterstring = field(category).contains(categoryvalue)

if filters.any?
filters.each do |filterwhole|
  filterwholearray = filterwhole.split("--")
  if filterstring.nil?
       filterstring = categoryfilterstring.and(field(filterwholearray.at(0)).contains(filterwholearray.at(1)))
  else
    filterstring = filterstring.and(field(filterwholearray.at(0)).contains(filterwholearray.at(1)))
  end
end
else
  filterstring = categoryfilterstring
end
searchstringwithoutdate = filterstring
if datefilter.any?
      dateStart = datefilter[0].split("/")
      actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

      dateEnd = datefilter[1].split("/")
      actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)


  filterstring = filterstring.and(field("itemdate").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("itemdate").isGreaterThan(actualStartDate.to_time.to_i.to_java))

        end

if selectedkpi == "AnomalyCount"
    facets = entity_type('LineItemAnomaly').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|
      data[firm.value] = firm.getChildren.first.value
    end

    #facets = entity_type('LineItemAnomaly').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    #arr = []
    #facets.get_facet('subcategory_id').facet_values.each do |firm|

    #  if data.key?(firm.value)
    #    data[firm.value] = data[firm.value]+firm.getChildren.first.value
    #  else
    #    data[firm.value] = firm.getChildren.first.value
    #  end
    # end

  else
     facets = entity_type('Analysis').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|
      data[firm.value] = firm.getChildren.first.value
    end
  end


#facets = entity_type('Analysis').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
#arr = []
#facets.get_facet('subcategory_id').facet_values.each do |firm|
#  data[firm.value] = firm.getChildren.first.value
#  end

#data

data = data.sort_by {|k,v| v}.reverse

datanew = {}
i = 1
totalrest = 0
data.each do |key,value|
  if(i < 10)
    datanew.store(key,value)
  else

      totalrest = totalrest + value
      datanew.store("others",totalrest)

  end

  i = i + 1
end

series = ""
datanew.each_with_index do |(key, val), i|
    series << "\{\"name\":\"#{key}\",y: #{val}\}"
  unless i == datanew.size - 1
      series << ","
    end
  end
  series.gsub!('nil','null')

series.html_safe
