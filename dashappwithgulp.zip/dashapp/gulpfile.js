//gulpfile.js
var gulp = require('gulp');
var concat = require('gulp-concat');
var rename = require('gulp-rename');
var uglify = require('gulp-uglify');

//script paths

//var jsFiles = 'src/lib/*.js',
  var jsDest = 'dist/scripts';

gulp.task('externalscripts', function(){
	return gulp.src(['src/lib/angular.min.js', 
					 'src/lib/ui-bootstrap-tpls-2.5.0.js', 
					 'src/lib/angular-ui-router.min.js',
					 'src/lib/d3.js',
					 'src/lib/dirPagination.js',
					 'src/lib/underscore-min.js',
					 'src/lib/ui-tree.js',
					 'src/lib/moment.js',
					 'src/lib/moment-fquarter.js',
					 'src/lib/moment-timezone.js',
					 'src/lib/moment-timezone-with-data.js',
					 'src/lib/angularjs-dropdown-multiselect.min.js',
					 'src/lib/highcharts-regression.js',
					 'src/lib/daterangepicker.js',
					 'src/lib/FileSaver.min.js'])
		  .pipe(concat('external.scripts.js'))
		  .pipe(rename('external.scripts.min.js'))
          .pipe(uglify())
          .pipe(gulp.dest(jsDest));
});