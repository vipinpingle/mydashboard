filtervalue = []
unless params[:FilterValue].to_s.empty?
filtername = params[:FilterValue].split(">>")[0]
filtervalue = params[:FilterValue].split(">>")[1].split("||")
end
datefilter = params[:datefilter].split("-")
if datefilter.any?
actualStartDate = ""
  actualEndDate = ""

  dateStart = datefilter[0].split("/")
  actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)
  dateEnd =datefilter[1].split("/")
  actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)
end

findfieldname = params[:FindFieldName]
returnarray = {}

filterstring =nil
    if filtervalue.any?
      filtervalue.each do |filterwhole|
        if filterstring.nil?
          filterstring = field(filtername).contains(filterwhole)
        else
        filterstring = filterstring.or(field(filtername).contains(filterwhole))
        end
      end
    else
    end
if datefilter.any?

        if filterstring.nil?
filterstring = field("item_date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java).and(field("item_date").isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
        else
          filterstring = filterstring.and(field("item_date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("item_date").isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
        end
end

if findfieldname == "anomaly_description"
  entity_type("AnalysisAnomaly_Matrix").where(filterstring).faceted_by(field("anomaly_description").with_facet_id('findfieldid').with_maximum_facet_values_of(-1)).faceting.get_facet('findfieldid').facet_values.each do |result|
  returnarray[result.value] = result.ndocs
  end
else
  print "\n***findfieldname****\n"
  print findfieldname
entity_type("Analysis_Matrix").where(filterstring).faceted_by(field(findfieldname).with_facet_id('findfieldid').with_maximum_facet_values_of(-1)).faceting.get_facet('findfieldid').facet_values.each do |result|
  print "\nresult=\n"
  print result
  if findfieldname.include? "date"
  t = Time.at(result.value.to_i)
  returnarray[t.strftime("%m/%d/%Y")] = result.ndocs
  else
    returnarray[result.value] = result.ndocs
  end
#end
end
end
if filtername == "anomaly_description"
  entity_type("AnalysisAnomaly_Matrix").where(filterstring).faceted_by(field("anomaly_description").with_facet_id('findfieldid').with_maximum_facet_values_of(-1)).faceting.get_facet('findfieldid').facet_values.each do |result|
  returnarray[result.value] = result.ndocs
end
end
returnarray = Hash[ returnarray.sort_by { |key, val| key } ]
returnarray.to_json
#
