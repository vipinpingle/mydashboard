
<script src="/AppBuilder/dashapp/src/lib/html2pdf.js"></script>
<script type="text/javascript" src="/AppBuilder/dashapp/src/lib/angular-sanitize.min.js"></script>
<script type="text/javascript" src="/AppBuilder/dashapp/dist/scripts/ng-csv.min.js"></script>
<script type="text/javascript" src="/AppBuilder/dashapp/src/lib/daterangepicker.js"></script>
<link rel="stylesheet" type="text/css" href="/AppBuilder/dashapp/src/stylesheets/datepicker.css">
<script>
/* off-canvas sidebar toggle */
$('[data-toggle=offcanvas]').click(function() {
    $('.row-offcanvas').toggleClass('active');
    ////$('.collapse').toggleClass('in').toggleClass('hidden-xs').toggleClass('visible-xs');
    $('.collapsemain').toggleClass('col-md-8').toggleClass('col-md-11');
      $('.mattersOverview').toggleClass('matter_overview').toggleClass('matter_overviewExpanded');

});
 $('#nav_title').append($('#pagetitle').val());
</script>

<script type="text/javascript">

var app = angular.module('wexdashboard',['angularUtils.directives.dirPagination','InvoiceDataService','ui.router','ui.bootstrap','wexdashboard.directives','wexdashboard.services','ngCsv']);

app.controller('InvoiceController',['$scope','$q','$state','invoiceService','sharedParameterService','paginationService',function($scope, $q, $state,invoiceService, sharedParameterService, paginationService) {

// variable for pagination calls
$scope.exportFileName = "";
$scope.numberOfResults = "10";
$scope.numberOfResultsLineItem = "10";
$scope.pageNumber = "1";
$scope.pageNumI = "1";
$scope.pageNumID = "1";
$scope.searchItem = "";
$scope.sortByField = "invoice_date";
$scope.sortByFieldLabel = "Date";
$scope.totalPageCount = "";
$scope.totalPageLineItemCount = "";
$scope.totalPageLineItemDisbCount = "";
$scope.invList = "";
$scope.showSidebar = true;
$scope.anomaliespagenumber = "1";
//  $scope.showinvdetails = false;
$scope.showAnomalyDescription = false;
$scope.invoiceLineItems = [];
$scope.disbursementsLineItems = [];
$scope.invoiceAnomaliesList = [];
$scope.invoiceTimekeepersList = [];
$scope.invoiceSummaryFeesTotalHours = "";
$scope.invoiceSummaryTotalNetAmount = "";
$scope.invoiceSummaryInvoiceTotal = "";
$scope.invoiceSummaryDisbursementFees = "";
$scope.invoiceSummaryGrandTotalAmount = "";
$scope.invoiceSummaryAverageFeesTotal = "";
$scope.invoicediscount = "";
$scope.sortType = 'id';
$scope.sortReverse = false;
$scope.searchItem = '';
  $scope.selectedTab = "";
$scope.selectedInvoiceIdLineItem = "";
$scope.lineItemSummarySelectedKpi = "net_amt,hours";
$scope.lineItemSummarySortByField = "net_amt:ascending";
$scope.lineItemSummarySubcategory = "timekeeper";
$scope.sortLineItemByType = "invoice_line_item_number";
$scope.filterByMatterNumber = '';
$scope.searchAnomalies = "";
$scope.anomaliesSummaryList = [];
$scope.rowOpen = [];
  $scope.invoiceLineItemsAnomalies = [];
$scope.highlighted="";
$scope.invsortList = [
    {name : "Date", value : "invoice_date:descending"},
    {name : "Matter Name", value : "matter_name"},
    {name : "Matter Number", value : "matter_number"},
    {name : "Firm Name", value : "firm_name"},
    {name : "Invoice Amount", value : "invoice_total:descending"}

];

$scope.invoiceExportHeaderFields = ["invoice_id","invoice_line_item_number","item_date","firm_name","matter_name","matter_number","timekeeper","staff_level","task_code","task_desc","rate","hours","adjustments","internal_adjustments","expense","bill_amt","net_amt","anomaly_description","disb_desc","notes"];
// invoiceid needs to be added in invoiceExportAnomaliesFields. removed ,"case_length_bucket" as it is not in correct format
$scope.invoiceExportAnomaliesFields = ["anomaly_group_id","item_date","matter_number","matter_name","invoice_line_item_id","firm_name","full_name","line_item_anomaly_id","anomaly_description","staff_level","state","county","court_type","task_id","rate",
"cat_code","judge","phase","hours","matter_id","task_code","matter_open_date","expense"
,"supervising_attorney","net_amt","dispute_type","matter_type","matter_status","team_lead","invoice_date","closedate","invoice_anomaly_id","trial_date"];

//["anomaly_group_id","item_date","matter_number","matter_name","invoice_line_item_id","firm_name","full_name","line_item_anomaly_id","anomaly_description","staff_level","state","county","court_type","task_id","rate","cat_code","judge","phase","hours","matter_id","task_code","matter_open_date","expense"
//,"supervising_attorney","net_amt","dispute_type","matter_type","matter_status","team_lead"];

$scope.sharedParameterService = sharedParameterService;
$scope.paginationService = paginationService;
$scope.toggleShowSidebar = function(){
  $scope.showSidebar = !$scope.showSidebar;
//  console.log($scope.showSidebar);
}
$scope.selectInvoice = function(event, params )
   {
  //  	console.log("Fired on selectInvoice : " + event  + " :: " + params[0].value);
   	if( params[0].value != undefined && ($scope.selectedInvoiceid == undefined ||  params[0].value.properties.invoice_id[0] != $scope.selectedInvoiceid[0]))
	{
		$scope.getInvoiceLineItemsList(params[0].value,'default');
    $scope.getInvoiceLineItemsDisbList(params[0].value,'default');
 	}
	 //console.log(event);
    $scope.anomaliespagenumber = "1";
    console.log("$scope.anomaliespagenumber = " + $scope.anomaliespagenumber);
   }

   $('#daterange').daterangepicker({
         ranges: {
           '2017': ['1/1/2017', '12/31/2017'],
		       '2016': ['1/1/2016', '12/31/2016'],
           '2015': ['1/1/2015', '12/31/2015'],
		       '2014': ['1/1/2014', '12/31/2014'],
           '2013': ['1/1/2013', '12/31/2013'],
           '2012': ['1/1/2012', '12/31/2012']
        }
   });

   $('#daterange').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
  //    console.log($(this).val());
  //    console.log($scope.sharedParameterService);
      $scope.sharedParameterService.setSharedParameter('datefilter', $(this).val());
      $scope.expand_date_filter = false;
       $scope.datefilter = picker.startDate.format('MM/DD/YYYY') + ' ' +  picker.endDate.format('MM/DD/YYYY')
      $scope.$apply( function() {
//	console.log($scope);
	    });
    });

function init() {
  $scope.toShow='Summary';
  $scope.sharedParameterService.setSharedParameter('invListSort', 'invoice_date:descending');

  $scope.sharedParameterService.setSharedParameter('searchItem', '');
  $scope.sharedParameterService.setSharedParameter('firmname', "");
  $scope.sharedParameterService.setSharedParameter('matternumber', "");
  urlparams = getUrlRequestParameters();
  if(urlparams["firmname"])
  {
    $scope.datefilter = '01/01/2012 12/31/2017';
    $scope.sharedParameterService.setSharedParameter('datefilter', '01/01/2012 - 12/31/2017');
    $scope.sharedParameterService.setSharedParameter('firmname', urlparams["firmname"]);
  }else if(urlparams["matternumber"])
  {
    $scope.datefilter = '01/01/2012 12/31/2017';
    $scope.sharedParameterService.setSharedParameter('datefilter', '01/01/2012 - 12/31/2017');
    $scope.sharedParameterService.setSharedParameter('matternumber', urlparams["matternumber"]);
  }else if(urlparams["invoiceid"])
  {
    $scope.datefilter = '01/01/2012 12/31/2017';
    $scope.sharedParameterService.setSharedParameter('datefilter', '01/01/2012 - 12/31/2017');
    $scope.sharedParameterService.setSharedParameter('searchItem', urlparams["invoiceid"]);
    $scope.searchItem = urlparams["invoiceid"];
//    console.log("urlparams is invoice id " + urlparams["invoiceid"]);
  }
  else{
     $scope.sharedParameterService.setSharedParameter('datefilter', '01/01/2016 - 12/31/2016');
     $scope.datefilter = '01/01/2016 12/31/2016';
  }
  if(urlparams["invoicelineitemnumber"])
  {
    $scope.pageNumI = Math.ceil(parseInt(urlparams["invoicelineitemnumber"])/$scope.numberOfResultsLineItem);
    $scope.skipPageReset = true;
    $scope.skipPageReset = true;
  }
 }

  function getUrlRequestParameters()
  {
     decodedUrl = decodeURI(location.href);
     url = decodedUrl.split("?");
     retMap = {};
     if(url.length > 1)
     {
         prevParamName = "";
         reqParamArray = url[1].split("&");
         for (i in reqParamArray)
         {
           reqParam = reqParamArray[i].split("=");
           if(reqParam.length == 2)
           {
             retMap[reqParam[0]] = reqParam[1];
             prevParamName = reqParam[0];
           }
           else
           {
              retMap[prevParamName] = retMap[prevParamName] + "&" + reqParam[0];
           }
         }
     }
    return retMap;
  }

  $scope.exportInvoiceData = function(selectTabName){
        var type = "",
        sortByType = "item_date:ascending",
        searchStr = "",
        entity = "InvoiceDetailsAndAnomalies",
        firmId = "",
        invoiceId = $scope.selectedInvoiceid;
        $scope.dataList = [];
        if(selectTabName == "Matters") {
           $scope.exportFileName = "export-invoice-matters-" + $scope.selectedMatternumber + ".csv";
           return invoiceService.getInvoiceDataExport(entity,invoiceId,$scope.selectedMatternumber,firmId,searchStr,sortByType,type,$scope.selectedTab)
                 .then(
                   function( mydata ) {
                     $scope.dataList =  buildDataFormatForExcel(mydata);
                     return $scope.dataList;
                });
        } else if(selectTabName == "Summary") {
           $scope.exportFileName = "export-invoice-" + $scope.selectedInvoiceid + ".csv";
           return invoiceService.getInvoiceDataExport(entity,invoiceId,"",firmId,searchStr,sortByType,type,$scope.selectedTab)
                 .then(
                   function( mydata ) {
                     $scope.dataList =  buildDataFormatForExcel(mydata);
                     return $scope.dataList;
                });
            }
          //  console.log("export data = " + JSON.stringify($scope.dataList));
      };

      // Format the data for excel.
      function buildDataFormatForExcel(origData) {
         $scope.exportForInvoiceList = [];
         var dataArr = [];
         var tmp = "";
         for (var item in origData) {
          tmp = getFormattedDataRow(origData[item].properties) ;
          dataArr.push(tmp);
         }
          var retVal = dataArr.map(function(each){
               return JSON.parse(each)
          });
          $scope.exportForInvoiceList = retVal.sort();
          return $scope.exportForInvoiceList;
       }

       // Formated the each set of data for excel.
       function getFormattedDataRow(data) {
             var fmtDataArr = [];
             var tmp = "";
             var tmpFormat = "";
             angular.forEach(data, function(element, index) {
               tmp = "";
               myexp = "";
               if(index=="expense" && element[0] == 'NA'){
                 fmtDataArr.push('{"bill_amt":"0"}');
                 var myexp = '{"' + index + '":"' + element[0] + '"}';
                 fmtDataArr.push(myexp);
               } else if(index=="expense" && element[0] != 'NA'){
                 fmtDataArr.push('{"hours":"0"}');
                 fmtDataArr.push('{"rate":"0"}');
                 fmtDataArr.push('{"staff_level":"NA"}');
                 fmtDataArr.push('{"timekeeper":"NA"}');
                 myexp = '{"' + index + '":"' + element[0] + '"}';
                 fmtDataArr.push(myexp);
               }  else if(index =="size" || index=="rate_bucket"){
               }
               else if(index == "anomalies"){
                 var anomaly = element[0].replace(/["{"]/g, "");
                 var againFmt = anomaly.replace(/["}"]/g, " ");
                 //var replaceFmt = againFmt.replace(/["NULL"]/g, "NA");
                 var mytmp = '{"anomaly_description":"' + againFmt + '"}';
                 fmtDataArr.push(mytmp);
               }
               else {
                  var cleanupChar = element[0].replace(/,/g, ' ');
                  cleanupChar = element[0].replace(/["\"]/g, "'");
                  tmp = '{"' + index + '":"' + cleanupChar + '"}';
                  fmtDataArr.push(tmp);
               }

               });
              fmtDataArr.sort();
              var newTmp = "";
              var newTmpFormat = "";
              var mydatatmp = ""
              angular.forEach(fmtDataArr,function(value,key){
                  mydatatmp = fmtDataArr.map(function(each){
                  return JSON.parse(each)
                });
              });
             for (var item in mydatatmp) {
               for(var subitem in mydatatmp[item]){
                 newTmp += '"' + subitem + '":"' + mydatatmp[item][subitem] + '",';
               	}
               }
              var lastChar = newTmp.slice(-1);
               if (lastChar == ',') {
                 newTmp = newTmp.slice(0, -1);
               }
               newTmpFormat = "{" + newTmp + "}";
               return newTmpFormat;
           }

           $scope.exportAnomaliesData = function(selectedTabName) {
             console.log("calling anomalies export");
              $scope.exportForInvoiceAnomaliesList = [];
              $scope.invoiceLineItemAnomaliesDataArr = [];
              $scope.invoiceAnomalyArr = [];
              $scope.exportFileName = "export-invoice-anomalies-" + $scope.selectedInvoiceid + ".csv";
              return $q.all([invoiceService.getInvoiceDataExport("AnalysisAnomaly_Matrix",$scope.selectedInvoiceid,"","","","item_date:ascending","anomaly_description","Anomalies"), invoiceService.getInvoiceDataExport("AnalysisInvoiceAnomalies",$scope.selectedInvoiceid,"","","","item_date:ascending","anomaly_description","Anomalies")])
                .then(
                  function (data) {
                  //  console.log(data);
                    $scope.invoiceLineItemAnomaliesDataArr = buildInvoiceLineItemAnomaliesDataFormatForExcel(data[0]);
                    $scope.invoiceAnomalyArr = buildInvoiceAnomaliesDataFormatForExcel(data[1]);
                    if($scope.invoiceLineItemAnomaliesDataArr !== undefined && $scope.invoiceAnomalyArr !== undefined){
                        $scope.exportForInvoiceAnomaliesList = $scope.invoiceLineItemAnomaliesDataArr.concat($scope.invoiceAnomalyArr);
                      } else if($scope.invoiceLineItemAnomaliesDataArr === undefined && $scope.invoiceAnomalyArr !== undefined){
                         $scope.exportForInvoiceAnomaliesList = $scope.invoiceAnomalyArr;
                      } else if($scope.invoiceLineItemAnomaliesDataArr !== undefined && $scope.invoiceAnomalyArr === undefined){
                         $scope.exportForInvoiceAnomaliesList = $scope.invoiceLineItemAnomaliesDataArr;
                      } else {
                        console.log("Both anomalies array are empty");
                      }
                    //  console.log( $scope.exportForInvoiceAnomaliesList);
                    return $scope.exportForInvoiceAnomaliesList;
                  },
                  function (error) {
                      console.log("Error while calling export for anomalies" + error);
                  }
                );
            }

          // Format the data for excel.
          function buildInvoiceLineItemAnomaliesDataFormatForExcel(origData) {
             $scope.invoiceLineItemAnomaliesDataArr = [];
             var anomaliesDataList = [];
             var dataArr = [];
             var tmp = "";
             for (var item in origData) {
              //tmp = getFormattedDataAnomaliesRow(origData[item].properties) ;
              tmp = getFormattedDataAnomaliesRow(origData[item].properties,"lineitem");
              dataArr.push(tmp);
             }
             //console.log("dataArra = " + JSON.stringify(dataArr));
              var retVal = dataArr.map(function(each){
                   return JSON.parse(each)
              });
              $scope.invoiceLineItemAnomaliesDataArr = retVal.sort();
              return $scope.invoiceLineItemAnomaliesDataArr;
           }

        function buildInvoiceAnomaliesDataFormatForExcel(origData) {
            $scope.invoiceAnomalyArr = [];
            var anomaliesDataList = [];
            var dataArr = [];
            var tmp = "";
            for (var item in origData) {
             tmp = getFormattedDataAnomaliesRow(origData[item].properties,"invoiceitem");
             dataArr.push(tmp);
            }
            //console.log(dataArr);
             var retVal = dataArr.map(function(each){
                  return JSON.parse(each)
             });
            $scope.invoiceAnomalyArr = retVal.sort();
            return $scope.invoiceAnomalyArr;
          }

         function getFormattedDataAnomaliesRow(data,type) {
               var fmtDataArr = [];
               var tmp = "";
               var tmpFormat = "";
              // console.log("type" + type);
               angular.forEach(data, function(element, index) {
                 tmp = "";
                 if(index=="tk_rate"){
                   var myrate = '{"rate":"' + element[0] + '"}';
                   fmtDataArr.push(myrate);
                 }
                 else if(index =="size" || index=="date_id" || index=="location_id" || index=="firm_id" || index=="person_id" || index=="case_length_bucket" || index=="close_date" || index=="rate"){
                 } else {
                   var cleanupChar = element[0].replace(/,/g, ' ');
                       cleanupChar = element[0].replace(/["\"]/g, "'");
                       tmp = '{"' + index + '":"' + cleanupChar + '"}';
                       fmtDataArr.push(tmp);
                  }
                 });
                fmtDataArr.sort();
                var newTmp = "";
                var newTmpFormat = "";
                var mydatatmp = "";
                angular.forEach(fmtDataArr,function(value,key){
                    mydatatmp = fmtDataArr.map(function(each){
                    return JSON.parse(each)
                  });
                });

               for (var item in mydatatmp) {
                 for(var subitem in mydatatmp[item]){
                   newTmp += '"' + subitem + '":"' + mydatatmp[item][subitem] + '",';
                  }
                 }
                 if(type == "lineitem"){
                   newTmp += '"invoice_date":"NA",';
                   newTmp += '"invoice_anomaly_id":"NA",';
                   newTmp += '"trial_date":"NA",';
                   newTmp += '"task_id":"NA"';
                   //newTmp += '"rate":"NA"';
                 }
                 if(type == "invoiceitem"){
                   newTmp += '"anomaly_group_id":"NA",';
                   newTmp += '"item_date":"NA",';
                   newTmp += '"invoice_line_item_id":"NA",';
                   newTmp += '"staff_level":"NA",';
                   newTmp += '"phase":"NA",';
                   newTmp += '"hours":"NA",';
                   newTmp += '"task_code":"NA",';
                   newTmp += '"expense":"NA",';
                   newTmp += '"net_amt":"NA",';
                   newTmp += '"full_name":"NA",';
                   newTmp += '"line_item_anomaly_id":"NA",';
                   newTmp += '"rate":"NA"';
                 }
                 //console.log(newTmp);
                // var lastChar = newTmp.slice(-1);
                //  if (lastChar == ',') {
                //    newTmp = newTmp.slice(0, -1);
                //  }
                 newTmpFormat = "{" + newTmp + "}";
              //   console.log("newTmpFormat");
                 return newTmpFormat;
             }

   //calling the search for invoice list
   $scope.getSearchedData = function(searchedString) {
      	 $scope.sharedParameterService.setSharedParameter('searchItem', searchedString);
   }


  //calling the search for matters list
  $scope.getInvListSorted = function(sortByField, sortByFieldLabel) {
       $scope.sortByFieldLabel = sortByFieldLabel;
       sortByValue = sortByField.split(":");
       sortByFieldArr = $scope.sortByField.split(':');
       if(sortByFieldArr[0] == sortByValue[0])
       {
           if( (sortByFieldArr.length == 1 && sortByValue.length > 1 && sortByValue[1] == 'descending') ||(sortByFieldArr[1] == 'descending'))
           {
              sortByValue[1] = 'ascending';
           }
           else
           {
              sortByValue[1] = 'descending';
           }
       }
       else if (sortByValue.length == 1)
       {
         sortByValue.push("ascending");
       }

       $scope.sortByField = sortByValue[0]+":"+sortByValue[1];
	     $scope.sharedParameterService.setSharedParameter('invListSort',  $scope.sortByField);
   }

  // sorting invoice details table

  $scope.sortInvDetailTable = function(selectedFieldForSorting) {
     var searchLineItem = "";
      sortParamStr = "";
      matterNumber = "";
     //$scope.sortLineItemByType = selectedFieldForSorting;
      $scope.reverseSort=($scope.sortLineItemByType == selectedFieldForSorting)?
      ! $scope.reverseSort:false;
  //    console.log("selectedFieldForSorting = " + selectedFieldForSorting);
  //    console.log("scope.sortLineItemByType = " + $scope.sortLineItemByType);
  //    console.log("Reversesort = " +  $scope.reverseSort);
      $scope.sortLineItemByType = selectedFieldForSorting;
      sortParamStr = selectedFieldForSorting;
      if( $scope.reverseSort === true)
      {
         sortParamStr = sortParamStr + ":descending";
      }
      $scope.sortLineItemByType = selectedFieldForSorting;
      if($scope.toShow == 'Matters')
      {
        matterNumber = $scope.selectedMatternumber;
      }   //getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResults,$scope.pageNumI,searchLineItem,$scope.sortLineItemByType);
            getInvoiceLineItemsData($scope.selectedInvoiceid, matterNumber ,$scope.numberOfResultsLineItem,$scope.pageNumI,searchLineItem,sortParamStr);
      }

      $scope.sortInvDetailDisbTable = function(selectedFieldForSorting) {
         var searchLineItem = "";
          sortParamStr = "";
          matterNumber = "";
          $scope.reverseSortD=($scope.sortLineItemByDisbType == selectedFieldForSorting)?
          ! $scope.reverseSortD:false;
    //      console.log("selectedFieldForSorting = " + selectedFieldForSorting);
    //      console.log("scope.sortLineItemByType = " + $scope.sortLineItemByDisbType);
    //      console.log("Reversesort = " +  $scope.reverseSortD);
          $scope.sortLineItemByDisbType = selectedFieldForSorting;
          sortParamStr = selectedFieldForSorting;
          if( $scope.reverseSortD === true)
          {
             sortParamStr = sortParamStr + ":descending";
          }
          $scope.sortLineItemByDisbType = selectedFieldForSorting;
          if($scope.toShow == 'Matters')
          {
            matterNumber = $scope.selectedMatternumber;
          }          getInvoiceLineItemsDisbursementData($scope.selectedInvoiceid, matterNumber, $scope.numberOfResultsLineItem,$scope.pageNumI,searchLineItem,sortParamStr);
          }

  $scope.getSortClass = function(selectedFieldForSorting) {
   if ($scope.sortLineItemByType == selectedFieldForSorting) {
     return $scope.reverseSort
     ?'arrow-down'
     :'arrow-up';
   }
    return'';
  }

  $scope.getSummarySortClass = function(selectedFieldForSorting) {
   if ($scope.summarySortByField == selectedFieldForSorting) {
     return $scope.summarySortOrderAsc
     ?'dark-arrow-up'
     :'dark-arrow-down';
   }
    return'';
  }

  $scope.getSortDisbClass = function(selectedFieldForSorting) {
   if ($scope.sortLineItemByDisbType == selectedFieldForSorting) {
     return $scope.reverseSortD
     ?'arrow-down'
     :'arrow-up';
   }
    return'';
  }


  //calling the next page for invoicelineitems data
    $scope.getNextPageInvoiceLineItems = function(pageNumLineItem) {
       var searchLineItem = $scope.searchInvoiceLineItem ;
      matterNumber= '';
    //   var sortLineItemType =  "itemnumber";
       $scope.pageNumI = pageNumLineItem;
       sortParamStr =  $scope.sortLineItemByType;
       if( $scope.reverseSort === true)
       {
             sortParamStr = sortParamStr + ":descending";
       }
      if($scope.toShow == 'Matters')
      {
        matterNumber = $scope.selectedMatternumber;
      }
      getInvoiceLineItemsData($scope.selectedInvoiceid,matterNumber, $scope.numberOfResultsLineItem,$scope.pageNumI,searchLineItem,sortParamStr);
    }

  $scope.setInvLineListPageNum = function(){
      if($scope.paginationService.isRegistered("lineItemList") && $scope.skipPageReset)
      {
        $scope.paginationService.setCurrentPage("lineItemList",$scope.pageNumI);
        $scope.skipPageReset = false;
      }
  }

  //calling the next page for invoicelinedisbitems data
 $scope.getNextPageInvoiceDisbLineItems = function(pageNumLineItem) {
    var searchLineItem = $scope.searchInvoiceLineItem;
 //   var sortLineItemType =  "itemnumber";
    $scope.pageNumID = pageNumLineItem;
    matterNumber= '';
    sortParamStrD = $scope.sortLineItemByDisbType;
       if(sortParamStrD === undefined)
 {
   sortParamStrD = "invoice_line_item_number"
 }
 if( $scope.reverseSortD === true)
       {
            sortParamStrD = sortParamStrD + ":descending";
       }
   if($scope.toShow == 'Matters')
      {
        matterNumber = $scope.selectedMatternumber;
      } getInvoiceLineItemsDisbursementData($scope.selectedInvoiceid, matterNumber,$scope.numberOfResultsLineItem,$scope.pageNumID,searchLineItem,sortParamStrD);
 }
    // Line itmes details call
  $scope.getInvoiceLineItemsList = function(item,selectedtab) {
    $scope.selectedTab =  selectedtab;
  //    console.log("calling to get line items selectedtab value " + selectedtab);
      $scope.selectedInvoice = item;
      $scope.selectedInvoiceTotal = item.properties.adjustment;
      if(selectedtab == "default") {
  //      console.log("calling getInvoiceLineItemsList function on click with invoiceId = " + item.properties.invoice_id);
        $scope.selectedState =  item.properties.state;
        $scope.selectedFirmname = item.properties.firm_name;
        $scope.selectedMattername = item.properties.matter_name;
        $scope.selectedMatternumber = item.properties.matter_number;
        $scope.selectedInvoiceid = item.properties.invoice_id;

      }
      //$scope.selectedInvoiceid = "338518"; // hardcoded for anomalies testing purpose.
      if(selectedtab == 'matters') {
        $scope.selectedMattername = item.properties.matter_name;
        $scope.selectedMatternumber = item.properties.matter_number;
	      $scope.lineItemSummaryCategory = "matter_number";
        $scope.lineItemSummaryCategoryValue = $scope.selectedMatternumber;
    //    console.log("lineItemSummaryCategoryValue***** = " + $scope.lineItemSummaryCategoryValue);
        $scope.toShow = 'Matters';
      } else if(selectedtab == 'anomalies') {
        $scope.filterByMatterNumber = ""; // add logic for anomalies
        $scope.toShow = 'Anomalies';
        $scope.anomaliespagenumber = "1";

      } else {
        $scope.lineItemSummaryCategory = "invoice_id";
        $scope.lineItemSummaryCategoryValue = $scope.selectedInvoiceid;
	      $scope.selectedMatternumber = ""
        $scope.toShow = 'Summary';
        }
      $scope.sharedParameterService.setSharedParameter('selectedInvoiceId',$scope.selectedInvoiceid);
      getInvoiceTimekeepersData($scope.lineItemSummaryCategory,$scope.lineItemSummaryCategoryValue,$scope.selectedInvoiceTotal);
      getInvoiceLevelAnomaliesData($scope.selectedInvoiceid);
      if(!$scope.skipPageReset)
      {
        $scope.pageNumI = "1"
      }
      var pageNumI = $scope.pageNumI;
      if($scope.paginationService.isRegistered("disblineItemList"))
      {
        $scope.paginationService.setCurrentPage("disblineItemList",1);
      }
      if($scope.paginationService.isRegistered("lineItemList"))
      {
        $scope.paginationService.setCurrentPage("lineItemList",pageNumI);
      }
      //
      var searchStrI = "";
      var sortByTypeI = "invoice_line_item_number";//$scope.sortLineItemByType;// ;
      $scope.highlighted="highlighted";
      $scope.searchInvoiceLineItem = "";
      getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.selectedMatternumber,$scope.numberOfResultsLineItem,pageNumI,searchStrI,sortByTypeI)
      getInvoiceLineItemsDisbursementData($scope.selectedInvoiceid,$scope.selectedMatternumber,$scope.numberOfResultsLineItem,$scope.pageNumI,searchStrI,sortByTypeI);
    //  exportInvoiceData($scope.selectedInvoiceid,$scope.selectedMatternumber,"","","","");
    //  exportInvoiceAnomaliesData($scope.selectedInvoiceid,"","","","","",$scope.selectedTab);
    //  exportInvoiceLineitemAnomaliesData($scope.selectedInvoiceid,"","","","","",$scope.selectedTab);
      $scope.showinvdetails = true;
  }

  $scope.getInvoiceLineItemsDisbList = function(item,selectedtab) {
    //  console.log("calling to get line items selectedtab value " + selectedtab);
      if(selectedtab == "default") {
    //    console.log("calling getInvoiceLineItemsDisbList function on click with invoiceId = " + item.properties.invoice_id);
        $scope.selectedState =  item.properties.state;
        $scope.selectedFirmname = item.properties.firm_name;
        $scope.selectedMattername = item.properties.matter_name;
        $scope.selectedMatternumber = item.properties.matter_number;
        $scope.selectedInvoiceid = item.properties.invoice_id;
      }
      if(selectedtab == 'matters') {
	      $scope.selectedMattername = item.properties.matter_name;
        $scope.selectedMatternumber = item.properties.matter_number;
	      $scope.lineItemSummaryCategory = "matter_number";
        $scope.lineItemSummaryCategoryValue = $scope.selectedMatternumber;
    //    console.log("lineItemSummaryCategoryValue***** = " + $scope.lineItemSummaryCategoryValue);
        $scope.toShow = 'Matters';
      } else if(selectedtab == 'anomalies') {
        $scope.filterByMatterNumber = ""; // add logic for anomalies
        $scope.selectedInvoiceid = item.properties.invoice_id;
        $scope.toShow = 'Anomalies';
      } else {
        $scope.lineItemSummaryCategory = "invoice_id";
        $scope.lineItemSummaryCategoryValue = $scope.selectedInvoiceid;
        $scope.toShow = 'Summary';
        }

      var pageNumI = "1";
      var searchStrI = "";
      var sortByTypeI = "invoice_line_item_number";//$scope.sortLineItemByType;// ;
      $scope.searchInvoiceLineItem = "";
    //  console.log("I am calling invoice list for disbursements now " + $scope.selectedInvoiceid + ", " + pageNumI + ", " + searchStrI + "," + sortByTypeI);
      getInvoiceLineItemsDisbursementData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResultsLineItem,pageNumI,searchStrI,sortByTypeI)
      $scope.showinvdetails = true;
  }

     $scope.getInvLineItemSearchedData = function(searchedString, searchType) {
     	$scope.pageNumI = 1;
     	sortParamStr =  $scope.sortLineItemByType;
             if( $scope.reverseSort === true)
             {
                sortParamStr = sortParamStr + ":descending";
             }
               	sortParamStrD = $scope.sortLineItemByDisbType;
                       if(sortParamStrD === undefined)
               	{
               		sortParamStrD = "invoice_line_item_number"
               	}
               	if( $scope.reverseSortD === true)
             {
                  sortParamStrD = sortParamStrD + ":descending";
             }

     	    getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.selectedMatternumber,$scope.numberOfResults,$scope.pageNumI,searchedString,sortParamStr);
        	getInvoiceLineItemsDisbursementData($scope.selectedInvoiceid,$scope.selectedMatternumber,$scope.numberOfResultsLineItem,$scope.pageNumI,searchedString,sortParamStrD);
        }

     $scope.getInvSummarySorted = function(sortByField) {

         $scope.summarySortOrderAsc = !$scope.summarySortOrderAsc;

         if($scope.summarySortByField != sortByField)
         {
           $scope.summarySortOrderAsc = true;
         }
         if($scope.summarySortOrderAsc)
         {
           $scope.invoiceTimekeepersList.sort(function(obj1, obj2){
             if(isNaN(obj1[sortByField])){
               return (obj1[sortByField] > obj2[sortByField])
             }else
             {
               return (obj1[sortByField] -  obj2[sortByField] )
             }
           });
         }else{
           $scope.invoiceTimekeepersList.reverse(function(obj1, obj2){
             if(isNaN(obj1[sortByField])){
               return (obj1[sortByField] > obj2[sortByField])
             }else
             {
               return (obj1[sortByField] -  obj2[sortByField] )
             }
           });
         }
         $scope.summarySortByField = sortByField;
     }


  // Callback function to retrieve data for invoicelineitem details.
   function getInvoiceTimekeepersData(cat,catvalue,invTotal){
        formatNumber = d3.format(".2f");
        var totalFeesHours = 0;
        var totalNetAmount = 0;

        invoiceService.getInvoiceLevelTimekeeperServiceData(cat,catvalue,$scope.lineItemSummarySelectedKpi,$scope.lineItemSummarySortByField,$scope.lineItemSummarySubcategory,"lineitem")
               .then(
                 function( mydata ) {
                     $scope.invoiceTimekeepersList = mydata;//formatDataForTimeKeeper(mydata);
                     $scope.summarySortByField = "spending"
                     $scope.summarySortOrderAsc = false;
                     $scope.invoiceTimekeepersList = $scope.invoiceTimekeepersList.slice(0, $scope.invoiceTimekeepersList.length - 1); invoiceService.getInvoiceLevelTimekeeperServiceData(cat,catvalue,$scope.lineItemSummarySelectedKpi,$scope.lineItemSummarySortByField,$scope.lineItemSummarySubcategory,"expense")
                           .then(
                                function( mydata1 ) {
                                 // $scope.invoiceTimekeepersDisbList = mydata1;//formatDataForTimeKeeper(mydata);
                                  $scope.invoiceSummaryDisbursementFees = mydata1;

                                  for(var i =0; i<= $scope.invoiceTimekeepersList.length-1; i++){
                                   totalNetAmount = totalNetAmount + parseFloat($scope.invoiceTimekeepersList[i].rate * $scope.invoiceTimekeepersList[i].hours);
                                   totalFeesHours = totalFeesHours + parseFloat($scope.invoiceTimekeepersList[i].hours);
                                   }
              //                    console.log("totalNetAmount" + totalNetAmount);
                                  var grandTotal = parseFloat(mydata1) + parseFloat(totalNetAmount) + parseFloat(invTotal); // subtract adjustments at invoice level.
                                  $scope.invoiceSummaryFeesTotalHours = formatNumber(totalFeesHours);
                                  $scope.invoiceSummaryTotalNetAmount = formatNumber(totalNetAmount);
                                  $scope.invoiceSummaryInvoiceTotal = formatNumber(totalNetAmount);
                                  $scope.invoiceSummaryGrandTotalAmount = formatNumber(grandTotal);
                                  $scope.invoiceSummaryAverageFeesTotal = formatNumber(parseFloat(totalNetAmount)/parseFloat(totalFeesHours))
                                  $scope.invoicediscount = invTotal[0];
                         });
            });

          //formatDataForTimeKeeper($scope.invoiceTimekeepersList,$scope.invoiceTimekeepersDisbList);
      };

    // Callback function to retrieve data for invoicelineitem details.
        function getInvoiceLineItemsData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType){
             invoiceService.getInvoiceLineItemsServiceData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType,"lineitem",$scope.selectedTab)
                    .then(
                      function( mydata ) {
                     $scope.invoiceLineItems = mydata.slice(0,-1);
                     $scope.totalPageLineItemCount = mydata[mydata.length - 1].total;
     		           });

           };
          // Callback function to retrieve data for invoicelineitem details.
       function getInvoiceLineItemsDisbursementData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType){
            invoiceService.getInvoiceLineItemsServiceData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType,"expense",$scope.selectedTab)
                   .then(
                     function( mydata ) {
                         $scope.disbursementsLineItems = mydata.slice(0,-1);
                         $scope.totalPageDisburseLineItemCount = mydata[mydata.length - 1].total;
		               });
          };
      // Callback function to retrieve data for invoice anomalies.
       function getInvoiceLevelAnomaliesData(invoiceId){
            invoiceService.getInvoiceLevelAnomaliesServiceData(invoiceId)
                   .then(
                     function( mydata ) {
                         $scope.invoiceAnomaliesList = mydata;
                         if(mydata[0] !== undefined) {
                         if (mydata[0].properties.invoice_anomaly_description !== undefined){
                             $scope.showAnomalyDescription = true;
                          } else {
                            $scope.showAnomalyDescription = false;
                          }
                        } else {
                           $scope.showAnomalyDescription = false;
                        }
                  });
          };

      // method for anomalies start tab

       $scope.getInvoiceLineItemsListAnomalies = function(item,selectedtab) {
          $scope.selectedInvoice = item;
          if(selectedtab == 'anomalies') {
            $scope.toShow = 'Anomalies';
            $scope.anomaliespagenumber = "1";
            console.log("$scope.anomaliespagenumber = " + $scope.anomaliespagenumber );
            if($scope.paginationService.isRegistered("timekeeperrowlist"))
              {
                $scope.paginationService.setCurrentPage("timekeeperrowlist",1);
              }
              if($scope.paginationService.isRegistered("timekeeperrowlistinvoice"))
                {
                  $scope.paginationService.setCurrentPage("timekeeperrowlistinvoice",1);
                }
          }
           // call the method to initialize anomalies tab data
          getAnomaliesSummaryList($scope.selectedInvoiceid,"",$scope.searchAnomalies,"widget1");
          getTimekeeperAnomaliesList($scope.selectedInvoiceid,"",$scope.searchAnomalies,"widget2", "Default");
          getTimekeeperInvoiceAnomaliesList($scope.selectedInvoiceid,"",$scope.searchAnomalies,"widget4","Default");

          // call the anomalies excel export
          //exportInvoiceLineitemAnomaliesData($scope.selectedInvoiceid,"","","","","",$scope.selectedTab);
          //exportAnomaliesData($scope.selectedInvoiceid);
        }

        // anomalies invoice lineitems for timekeeper
        $scope.getAnomaliesSummaryInvoiceLineItems = function(invoiceId,timekeepergroupid) {
          var filters = "";
          var widgetName = "widget3";
          filters = "invoice_id>>" + invoiceId + "&&anomaly_group_id>>" + timekeepergroupid;
          console.log("i am in this method getAnomaliesSummaryInvoiceLineItems" + invoiceId + " timekeepergroupid = " + timekeepergroupid);
          invoiceService.getAnomaliesSummaryData(filters,"",$scope.searchAnomalies,widgetName)
                .then(
                  function( mydata ) {
                    $scope.currentGroupId = timekeepergroupid;
                  //  console.log("$scope.currentGroupId = " + $scope.currentGroupId);
                      $scope.invoiceLineItemsAnomalies[timekeepergroupid] = mydata;
                //      console.log("$scope.invoiceLineItemsAnomalies = "+$scope.invoiceLineItemsAnomalies);
                    });

            }

          $scope.getAnomalySearchedData = function(searchAnomalies){
                    $scope.sharedParameterService.setSharedParameter("searchAnomalies", searchAnomalies);
                    $scope.searchAnomalies = searchAnomalies;
                    getAnomaliesSummaryList($scope.selectedInvoiceid,"",$scope.searchAnomalies,"widget1");
                    getTimekeeperAnomaliesList($scope.selectedInvoiceid,"",$scope.searchAnomalies,"widget2", "Default");
                    getTimekeeperInvoiceAnomaliesList($scope.selectedInvoiceid,"",$scope.searchAnomalies,"widget4","Default");
          }

          $scope.sort = function(keyname){
                  $scope.sortKey = keyname;   //set the sortKey to the param passed
                  $scope.reverse = !$scope.reverse; //if true make it false and vice versa
                  console.log("sort keyname = " + $scope.sortKey);
                  sortByKey($scope.timekeeperanomalieslist,keyname);

          }

          $scope.sortByDetail = function(keyname, groupId){
                  $scope.sortKeyDetail = keyname;   //set the sortKeyDetail to the param passed
                  $scope.reverseInvDetail = !$scope.reverseInvDetail; //if true make it false and vice versa
                  sortByKey($scope.invoiceLineItemsAnomalies[groupId],keyname);
          }
          $scope.sortInv = function(keyname){
                  $scope.sortKeyInv = keyname;   //set the sortKeyInv to the param passed
                  $scope.reverseInv = !$scope.reverseInv; //if true make it false and vice versa
                  sortByKey($scope.timekeeperinvoiceanomalieslist,keyname);
          }
          function sortByKey(array, key) {
                  return array.sort(function(a, b) {
                  var x = a[key]; var y = b[key];
                  return ((x < y) ? -1 : ((x > y) ? 1 : 0));
                });
          }

        $scope.setCurrentRow = function(index){
            //console.log("index value = " + index);
            //console.log("rowOpen value = " + $scope.rowOpen.length);
              for (i = 0; i < $scope.rowOpen.length; i++) {
           //    console.log("i = " + i);
             // $scope.rowOpen[i] = false;
            }
          $scope.rowOpen[index] = true
        }

        function getAnomaliesSummaryList(invoiceId,datefilter,searchString,widgetName){
          var filters = "";
          if(!invoiceId){
          //    console.log("invoiceId is null or undefined in getAnomaliesSummaryList");
          } else {
            filters = "invoice_id>>" + invoiceId;
          }

          invoiceService.getAnomaliesSummaryData(filters,datefilter,searchString,widgetName)
                .then(
                  function( mydata ) {
                      $scope.anomaliesSummaryList = mydata;
              //        console.log("$scope.anomaliesSummaryList = "+$scope.anomaliesSummaryList);
                    });
          }

          function getTimekeeperAnomaliesList(invoiceId,datefilter,searchString,widgetName,sortType){
            var filters = "";
            filters = "invoice_id>>" + invoiceId;
            $scope.timekeeperanomalieslist = [];
            $("#timekeeperrowlist_spinner").removeClass("hide");
            invoiceService.getAnomaliesSummaryData(filters,datefilter,searchString,widgetName)
                  .then(
                    function( mydata ) {
                      if(mydata.length > 0)
                      {
                        $scope.timekeeperanomalieslist = mydata.slice(0,-1);
                      }
                      $("#timekeeperrowlist_spinner").addClass("hide");
                  //      console.log("$scope.timekeeperanomalieslist = "+$scope.timekeeperanomalieslist);
                  //      $scope.totalpagestimekeeperanomalies = mydata[mydata.length - 1].total;
                        // if(sortType == "Default"){
                        //   sortByKey($scope.timekeeperanomalieslist,"lineitemcount");
                        // }
                        $scope.anomaliespagenumber = "1";
                      });
            }

            // function to retrieve timekeeper anomalies as invoice level and link it to invoice page.
            function getTimekeeperInvoiceAnomaliesList(invoiceId,datefilter,searchString,widgetName,sortType){
              var filters = "";
              var sortType = "";
              filters = "invoice_id>>" + invoiceId;
              $scope.timekeeperinvoiceanomalieslist = [];
              $("#timekeeperrowlistinvoice_spinner").removeClass("hide");
              invoiceService.getAnomaliesSummaryData(filters,datefilter,searchString,widgetName)
                    .then(
                      function( mydata ) {
                          $scope.timekeeperinvoiceanomalieslist = mydata;
                          $("#timekeeperrowlistinvoice_spinner").addClass("hide");
                        //  console.log("$scope.timekeeperinvoiceanomalieslist = "+JSON.stringify($scope.timekeeperinvoiceanomalieslist));
                          // if(sortType == "Default"){
                          //   sortByKey($scope.timekeeperinvoiceanomalieslist,"invoice_amt");
                          //   $scope.sortKeyInv = "invoice_amt";   //set the sortKeyInv to the param passed
                          //   $scope.reverseInv = !$scope.reverseInv; //if true make it false and vice versa
                          // }
                        });
              }

        // method for anomalies end tab


  init();
}]);


//DataService containing all the data calls from backend.

var InvoiceDataService = angular.module('InvoiceDataService', [])
    .service('invoiceService', function ($http,$q) {

    // Service method to get the invoice listing
    // Return service methodes.
    return({
          getInvoiceListServiceData: getInvoiceListServiceData,
          getInvoiceLineItemsServiceData: getInvoiceLineItemsServiceData,
          getInvoiceLevelAnomaliesServiceData: getInvoiceLevelAnomaliesServiceData,
          getInvoiceLevelTimekeeperServiceData: getInvoiceLevelTimekeeperServiceData,
          getAnomaliesSummaryData:getAnomaliesSummaryData,
          getInvoiceDataExport:getInvoiceDataExport
    });

    // start call to get invoice list service data
    function  getInvoiceListServiceData(numResultsS,pageNumS,searchStrS,sortByTypeS) {
     var request = $http({
                  method: "post",
                  url: "/AppBuilder/endpoint/getInvoiceList",
                  params: {
                            pagenumber: pageNumS,
                            searchstring: searchStrS,
                            sortbyfield: sortByTypeS
                    }
            });
          return(request.then( handleSuccess, handleError ) );
        }

        // start call to get invoice list service data
        function  getInvoiceLineItemsServiceData(invoiceIdL,matterNumberL,numResultsL,pageNumL,searchStrL,sortByTypeL,typeL,selectedtab) {

  console.log("Passing parameters in getInvoiceLineItemsServiceData " + "invoiceIdL* = " + invoiceIdL + " matterNumberL = " + matterNumberL + " numResultsL = "
          + numResultsL + " pageNumL = " + pageNumL + " searchStrL = " +searchStrL + " sortByTypeL = " + sortByTypeL + " typeL = " + typeL);
         var request = $http({
                      method: "post",
                      url: "/AppBuilder/endpoint/getInvoiceDetails",
                      params: {
                                invoiceid: invoiceIdL,
                                matternumber: matterNumberL,
                                noofresults: numResultsL,
                                pagenumber: pageNumL,
                                searchstring: searchStrL,
                                sortbyfield: sortByTypeL,
                                type:typeL,
                            tabname:selectedtab

                        }
                });
              return(request.then( handleSuccess, handleError ) );
            }

            // start call to get invoice level anomalies service data
            function  getInvoiceLevelAnomaliesServiceData(invoiceIdL) {

            console.log("Passing parameters in getInvoiceLevelAnomaliesServiceData " + "invoiceIdL = " + invoiceIdL);
            var request = $http({
                          method: "post",
                          url: "/AppBuilder/endpoint/getInvoiceAnomoly",
                          params: {
                                    invoiceid: invoiceIdL
                            }
                    });
                  return(request.then( handleSuccess, handleError ) );
                }
                // start call to get invoice level anomalies service data
                function  getInvoiceLevelTimekeeperServiceData(categoryT,categoryvalueT,selectedkpiT,sortbyfieldT,subcategoryT,typeT) {

                console.log("Passing parameters in getInvoiceLevelTimekeeperServiceData " + "categoryT = " + categoryT + " categoryvalueT = " + categoryvalueT + " selectedkpiT = " + selectedkpiT +
                " sortbyfieldT = " + sortbyfieldT + " subcategoryT = " + subcategoryT + " typeT = " + typeT);
  //category(invoice_id or matter_number), categoryvalue(actual value based on category), selectedkpi(net_amt,hours), sortbyfield(net_amt:ascending of hours:ascending),
  //subcategory (timekeeper), type (lineitem for lineitems and expense for disbursements)
                var request = $http({
                              method: "post",
                              url: "/AppBuilder/endpoint/getInvoiceTimekeeperDetails",
                              params: {
                                        category: categoryT,
                                        categoryvalue: categoryvalueT,
                                        selectedkpi: selectedkpiT,
                                        sortbyfield:sortbyfieldT,
                                        subcategory:subcategoryT,
                                        type:typeT,
                                        datefilter: "",
                                        filters: "",
                                        noofresults: ""
                                }
                        });
                      return(request.then( handleSuccess, handleError ) );
                    }

                    // start call to get invoices sumamry for total invoices, lineitem and total anomalies service data
                    function  getAnomaliesSummaryData(filtersL,datefilterS,searchStringL,widgetNameL) {
                     var request = $http({
                                  method: "post",
                                  url: "/AppBuilder/endpoint/FirmsAnomaliesSummary",
                                  params: {
                                            datefilter: datefilterS,
                                            entity:"invoice",
                                            filters:filtersL,
                                            searchfilter:searchStringL,
                                            widget: widgetNameL
                                    }
                            });
                          return(request.then( handleSuccess, handleError ) );
                        }

                        // get invoices export data.
                        function  getInvoiceDataExport(entityL,invoiceIdL,matterNumberL,firmIdL,searchStrL,sortByTypeL,typeL,selectedtab) {

                      //    console.log("Passing parameters in getInvoiceDataForExport " + "invoiceIdL = " + invoiceIdL + " matterNumberL = " + matterNumberL
                      //    + " searchStrL = " +searchStrL + " sortByTypeL = " + sortByTypeL + " typeL = " + typeL);
                         var request = $http({
                                      method: "post",
                                      url: "/AppBuilder/endpoint/getInvoiceDataForExport",
                                      params: {
                                                entityname:entityL,
                                                invoiceid: invoiceIdL,
                                                matternumber: matterNumberL,
                                                firmid:firmIdL,
                                                searchstring: searchStrL,
                                                sortbyfield: sortByTypeL,
                                                type:typeL,
                                                tabname:selectedtab
                                        }
                                });
                              return(request.then( handleSuccess, handleError ) );
                            }

    // Common method to handle the request from the server
    function handleError( response ) {
        if (
            ! angular.isObject( response.data ) ||
            ! response.data.message
            ) {
            return( $q.reject( "An unknown error occurred." ) );
        }
        return( $q.reject( response.data.message ) );
    }
    function handleSuccess( response ) {
    return( response.data);
    }
   // end call to get data from service.
  });

    function printArea(areaName){
      var pdf = new jsPDF('p', 'pt', 'letter');
        var canvas = pdf.canvas;
        canvas.height = 72 * 11;
        canvas.width=72 * 8.5;
        /*pdf.fromHTML(document.getElementById(areaName), 2, 2, {
          'elementHandlers': specialElementHandlers
          }, function(){
            var blob = pdf.output('blob');
            window.open(URL.createObjectURL(blob));
           }
        ); */
        convertHtmlElement = document.body;
  		  if(areaName)
        {
         	convertHtmlElement = document.getElementById(areaName);
        }
        html2pdf(convertHtmlElement, pdf, function(pdf) {
            var blob = pdf.output('blob');
            window.open(URL.createObjectURL(blob));
         }
        );
    }

    // PRINT Tab FUNCTION
    function printTab(tabName) {

      var pdf = new jsPDF("l","pt","a3", true);
        combinedElement = document.body;
  		  if(tabName)
        {
          combinedElement = document.getElementById("printPlaceHolder");
          combinedElement.innerHTML =  document.getElementById("header").innerHTML +  document.getElementById(tabName).outerHTML;
          combinedElement.style.display = "";
          combinedElement.parentElement.style.marginTop="1000px"
         	//convertHtmlElement = document.getElementById(tabName);
        }

        html2pdf(combinedElement, pdf, function(pdf) {
            combinedElement.style.display = "none";
            combinedElement.parentElement.style.marginTop="0px"
            combinedElement.innerHTML = "";
           pdf.save("Invoices-"+ tabName+"-" + (new Date().getTime())+ ".pdf");
         },{width:1600}
        );
    }

    function saveArea(areaName){
      var saveContents = "";
      var l = 0;
      var doc = new jsPDF("p","pt","a4");
      var canvas = doc.canvas;
      canvas.height = 72*11;
      canvas.width = 72*8.5;

      if(document.getElementById("printStyles"))
      {
        saveContents = document.getElementById("printStyles").innerHTML;
      }
      styleTags = document.getElementsByTagName("style");
      for(l=0; l < styleTags.length; l++)
      {
         saveContents = saveContents + styleTags[l].outerHTML;
      }
      saveContents = saveContents + document.getElementById(areaName).innerHTML
      console.log('save button was clicked');
      doc.fromHTML(saveContents, 5, 5, {
          'elementHandlers': specialElementHandlers
      }, function(){
        doc.save('invoices-overview-'+(new Date().getTime())+'.pdf')
      });
      /*kendo.drawing
        .drawDOM("#"+areaName,
        {
          paperSize: "A4",
          margin: { top: "1cm", bottom: "1cm" },
          scale: 0.8,
          height: 500
        })
        .then(function(group){
        kendo.drawing.pdf.saveAs(group, "Exported.pdf")
      });*/
    }

    var specialElementHandlers = {
      '#container': function (element, renderer) {
          return true;
      }
    };

</script>
