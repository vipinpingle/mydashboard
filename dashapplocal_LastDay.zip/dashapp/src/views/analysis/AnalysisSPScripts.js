<script type="text/javascript">
 $(function() {
     var start = moment().subtract(29, 'days');
     var end = moment();
     var currYear = '';
     var pervYear = '';
     var prevToPrevYear = '';

    $('input[name="daterange"]').daterangepicker({
        //startDate: start,
        //endDate: end,
        ranges: {
           '2017': ['1/1/2017', '12/31/2017'],
		       '2016': ['1/1/2016', '12/31/2016'],
           '2015': ['1/1/2015', '12/31/2015'],
		       '2014': ['1/1/2014', '12/31/2014'],
           '2013': ['1/1/2013', '12/31/2013'],
           '2012': ['1/1/2012', '12/31/2012']
        }
	});

  $('input[name="timecomprange"]').daterangepicker({
      startDate: '1/1/2016',
			endDate: '12/31/2016',
      autoUpdateInput: false,
      locale: {
          cancelLabel: 'Clear'
      },
			ranges: {
			     '2017': ['1/1/2017', '12/31/2017'],
		       '2016': ['1/1/2016', '12/31/2016'],
           '2015': ['1/1/2015', '12/31/2015'],
		       '2014': ['1/1/2014', '12/31/2014'],
           '2013': ['1/1/2013', '12/31/2013'],
           '2012': ['1/1/2012', '12/31/2012']
			}
		});

    $('input[name="trialdaterange"]').daterangepicker({
        startDate: '1/1/2016',
        endDate: '12/31/2016',
        autoUpdateInput: false,
        locale: {
            cancelLabel: 'Clear'
        },
        ranges: {

        }
      });

      $('input[name="matteropendaterange"]').daterangepicker({
          startDate: '1/1/2016',
          endDate: '12/31/2016',
          autoUpdateInput: false,
          "opens": "left",
          locale: {
              cancelLabel: 'Clear'
          },
          ranges: {

          }
        });

        $('input[name="matterclosedaterange"]').daterangepicker({
            startDate: '1/1/2016',
            endDate: '12/31/2016',
            autoUpdateInput: false,
            "opens": "left",
            locale: {
                cancelLabel: 'Clear'
            },
            ranges: {

            }
          });
  });
  var app = angular.module('wexdashboard',['AnalysisDataService','ui.bootstrap','angularjs-dropdown-multiselect']);

  app.filter('filterHtmlChars', function(){
     return function(string) {
         return string.replace(/&amp;/g, '&');
     }
  });

  app.filter('getColorByName', function() {
  return function(dataset, key, tab) {
  //console.log(dataset);
  var retColor = "";
    for (i=0; i<dataset.length; i++) {
    //	console.log(dataset[i].name);
      if (dataset[i].name == key) {
      		{
          angular.forEach(dataset[i].data[0], function(element, index) {
             if(index === "x" && element === tab){
                return retColor = dataset[i].color;
             }
          	})
          }
      }
    }
    return retColor;
  }
});
      //KPI Buttons color changes

app.controller("navbarCtrl", function($scope) {

  $scope.kpibutton1 = "kpi_inactive";
  $scope.kpibutton2 = "kpi_inactive";
  $scope.kpibutton3 = "kpi_inactive";

  $scope.switchButtons = function(item) {
    $scope.kpibutton1 = "kpi_inactive";
    $scope.$parent.spending = false;
    $scope.kpibutton2 = "kpi_inactive";
    $scope.$parent.hours = false;
    $scope.kpibutton3 = "kpi_inactive";
    $scope.$parent.anomalies = false;
    $scope.kpibutton4 = "kpi_inactive";
    $scope.$parent.rate = false;
    //console.log($scope.$parent);
    switch (item) {
      case 1:
        $scope.kpibutton1 = "kpi_active";
        $scope.$parent.spending = true;
        break; // it encounters this break so will not continue into 'default:'
      case 2:
        $scope.kpibutton2 = "kpi_active";
        $scope.$parent.hours = true;
        break;
      case 3:
        $scope.kpibutton3 = "kpi_active";
        $scope.$parent.anomalies = true;
        break;
      case 4:
        $scope.kpibutton4 = "kpi_active";
        $scope.$parent.rate = true;
        break;
      default:
        console.log('default')
          // fall-through
    }
  }
});

  app.controller('analysisController',['$scope','$http','$filter','$window','analysisService',function($scope, $http,$filter,$window,analysisService) {
  $scope.serviceDataUrl = $window.exportWebServiceUrl + "/GetChartsData";
  function init() {
  $scope.highchartsDataTable = [];
  $scope.matterOpenTimeLine = false;
  $scope.matternumberselected = false;
  $scope.stateselect = "";
  $scope.kpiSelected= "";
	$scope.categorySelected = "";
	$scope.subcategorySelected= "";
	$scope.valueSelected = [];
	$scope.filtersSelected = "";
	$scope.timeselected = [];
	$scope.subcategoryvalues = [];
	$scope.subcategoryselect = 'Time Keeper';
	$scope.datarange = "";
  $scope.timecompselected = "";
  $scope.firmOrMatterParentSelected = "";
  $scope.initialtimecomp = true;
  $scope.showcompTimeCategory = false;
  $scope.showTrialdateCategory = false;
  $scope.showMatterOpendateCategory = false;
  $scope.showMatterOpendateCategory = false;
	$scope.showSubCategory = false;
  $scope.showStateCategory = false;
	$scope.rate = false;
	$scope.blended = false;
	$scope.spendbudget = false;
	$scope.cpm = false;
	$scope.comparisions = false;
	$scope.anomalies = false;
  $scope.averagesList = [];
  $scope.statefieldname = "state";
  $scope.countyfieldname = "county";
  $scope.expensefieldname = "expense";
  $scope.firmfieldname = "firm_name";
  $scope.firmIDfieldname = "Firm_ID";
  $scope.matternamefieldname = "matter_number";
  $scope.timekeeperfieldname = "full_name";
  $scope.taskcodefieldname = "task_code";
  $scope.phasefieldname = "phase";
  $scope.phasecodefieldname = "phase_code";
  $scope.stafffieldname = "staff_level";
  $scope.timekeeperlevelfieldname = "TK_LEVEL";
  $scope.ratebucketfieldname = "rate_bucket_new";
  $scope.ratebucketSPfieldname = "RATE_BUCKET";
  $scope.trialdatefieldname = "trial_date";
  $scope.trialdatestatusfieldname = "trial_status";
  $scope.trialstatusfieldname = "trial";
  $scope.catcodefieldname = "cat_code";
  $scope.lengthbucketfieldname = "case_length_bucket";
  $scope.caselengthbucketfieldname = "CaseLengthBucket";
  $scope.mattertypefieldname = "matter_type";
  $scope.disputetypefieldname = "dispute_type";
  $scope.suittypefieldname = "suit_type";
  $scope.courttypefieldname = "court_type";
  $scope.teamleadfieldname = "team_lead";
  $scope.attorneyfieldname = "supervising_attorney";
  $scope.attorneySPfieldname = "attorney";
  $scope.opposingcounselfieldname = "opposing_firm_id";
  $scope.daysfromstartfieldname = "daysfromstart";
  $scope.matteropendaysbucketfieldname = "MatterOpenDaysBucket";
  $scope.judgefieldname = "judge";
  $scope.opendatefieldname = "matter_open_date";
  $scope.closedatefieldname = "matter_close_date";
  $scope.anomalyfieldname = "anomaly";
  $scope.anomalytypefieldname = "anomaly_type";
  $scope.anomalydescriptionfieldname = "anomaly_description" ;
  $scope.statusfieldname = "matter_status";
  $scope.statusSPfieldname = "status";
  $scope.legendheader = "";
	$scope.legendmiddle = "";
	$scope.legendright = "";
	$scope.stateList = [];
	$scope.countyList = [];
	$scope.firmList = [];
	$scope.timekeeperList = [];
	$scope.matternameList = [];
	$scope.taskList = [];
	$scope.phaseList = [];
	$scope.staffList = [];
	$scope.expenseList = [];
	$scope.rateList = [];
	$scope.traildateList = [];
  $scope.trialdatestatusList = [];
  $scope.catecodeList = [];
	$scope.caselengthList = [];
	$scope.mattertypeList = [];
	$scope.disputetypeList = [];
	$scope.courttypeList = [];
	$scope.teamleadList = [];
	$scope.supervisingattorneyList = [];
	$scope.plaintiffcounselList = [];
	$scope.daysfromstartList = [];
	$scope.judgeList = [];
	$scope.anomalytypeList = [];
	$scope.matterstatusList = [];
	$scope.matteropenList = [];
	$scope.mattercloseList = [];
	$scope.selectionList = [];
  $scope.selectionListOrder = ["state","county","firm","timekeeper","mattername","task","expense"];
  $scope.selectionListOrdercolumnname = ["state","county","firm","judge","mattername","task","itemtype"];
	$scope.matterTableData = "";
	$scope.dataForMatterTableLoaded = false;
  $scope.graphTotal = "";
  $scope.pieTotal = "";
  $scope.displaySelectedStateValues = "";
  $scope.displaySelectedCountyValues = "";
  $scope.displaySelectedFirmValues = "";
  $scope.displaySelectedExpenseValues = "";
  $scope.displaySelectedTimekeeperValues = "";
  $scope.displaySelectedMatternameValues = "";
  $scope.displaySelectedTaskValues = "";
  $scope.displaySelectedPhaseValues = "";
  $scope.displaySelectedStaffValues = "";
  $scope.displaySelectedRateValues = "";
  $scope.displaySelectedTraildateValues = "";
  $scope.displaySelectedTrialDateStatusValues = "";
  $scope.displaySelectedCatCodeValues = "";
  $scope.displaySelectedCaseLengthValues = "";
  $scope.displaySelectedMatterTypeValues = "";
  $scope.displaySelectedDisputeTypeValues = "";
  $scope.displaySelectedCourtTypeValues = "";
  $scope.displaySelectedTeamLeadValues = "";
  $scope.displaySelectedSupervisingAttorneyValues = "";
  $scope.displaySelectedPlaintiffCounselValues = "";
  $scope.displaySelectedDaysFromStartValues = "";
  $scope.displaySelectedJudgeValues = "";
  $scope.displaySelectedMatteropenValues = "";
  $scope.displaySelectedMattercloseValues = "";
  $scope.displaySelectedAnomalyTypeValues = "";
  $scope.displaySelectedMatterstatusValues = "";
  $scope.displaySelectedTimeCompValues = "";
  $scope.showPieChart = false;
  $scope.loadGraph = false;
  $scope.loadTimelineGraph = false;
  $scope.searchSelectAllSettings = { enableSearch: true, showCheckAll: false, showUncheckAll:false,keyboardControls: true, styleActive: true,scrollable: true,scrollableHeight: '200px'};
  $scope.searchSelectMatterSettings = { enableSearch: true, showCheckAll: false, showUncheckAll:false,keyboardControls: true, styleActive: true,scrollable: true,scrollableHeight: '300px'};
  $scope.searchSelectStateModel = [];
  $scope.stateChangeEventListeners = {
      onSelectionChanged: onStateSelectionChanged
  };
  $scope.searchSelectCountyModel = [];
  $scope.countyChangeEventListeners = {
  	  onSelectionChanged: onCountySelectionChanged
  };
  $scope.searchSelectFirmModel = [];
  $scope.firmChangeEventListeners = {
  	  onSelectionChanged: onFirmSelectionChanged
  };
  $scope.searchSelectTimekeeperModel = [];
  $scope.timekeeperChangeEventListeners = {
      onSelectionChanged: onTimekeeperSelectionChanged
  };
  $scope.searchSelectMatterModel = [];
  $scope.matterChangeEventListeners = {
      onSelectionChanged: onMatterSelectionChanged
  };
  $scope.searchSelectTaskModel = [];
  $scope.taskChangeEventListeners = {
      onSelectionChanged: onTaskSelectionChanged
  };
  $scope.searchSelectStaffModel = [];
  $scope.staffChangeEventListeners = {
      onSelectionChanged: onStaffSelectionChanged
  };
  $scope.searchSelectPhaseModel = [];
  $scope.phaseChangeEventListeners = {
      onSelectionChanged: onPhaseSelectionChanged
  };
  $scope.searchSelectExpenseModel = [];
  $scope.expenseChangeEventListeners = {
      onSelectionChanged: onExpenseSelectionChanged
  };
  $scope.searchSelectRateModel = [];
  $scope.rateChangeEventListeners = {
      onSelectionChanged: onRateSelectionChanged
  };
  $scope.searchSelectTrialDateModel = [];
  $scope.trialDateChangeEventListeners = {
      onSelectionChanged: onTrialDateSelectionChanged
  };
  $scope.searchSelectTrialDateStatusModel = [];
  $scope.trialDateStatusChangeEventListeners = {
      onSelectionChanged: onTrialDateStatusSelectionChanged
  };
  $scope.searchSelectCatCodeModel = [];
  $scope.catCodeChangeEventListeners = {
      onSelectionChanged: onCatCodeSelectionChanged
  };
  $scope.searchSelectCaseLengthModel = [];
  $scope.caseLengthChangeEventListeners = {
      onSelectionChanged: onCaseLengthSelectionChanged
  };
  $scope.searchSelectMatterTypeModel = [];
  $scope.matterTypeChangeEventListeners = {
      onSelectionChanged: onMatterTypeSelectionChanged
  };
  $scope.searchSelectMatterStatusModel = [];
  $scope.matterStatusChangeEventListeners = {
      onSelectionChanged: onMatterStatusSelectionChanged
  };
  $scope.searchSelectMatterOpenDateModel = [];
  $scope.matterOpenDateChangeEventListeners = {
      onSelectionChanged: onMatterOpenDateSelectionChanged
  };
  $scope.searchSelectMatterCloseDateModel = [];
  $scope.matterCloseDateChangeEventListeners = {
      onSelectionChanged: onMatterCloseDateSelectionChanged
  };
  $scope.searchSelectDisputeTypeModel = [];
  $scope.disputeTypeChangeEventListeners = {
      onSelectionChanged: onDisputeTypeSelectionChanged
  };
  $scope.searchSelectCourtTypeModel = [];
  $scope.courtTypeChangeEventListeners = {
      onSelectionChanged: onCourtTypeSelectionChanged
  };
  $scope.searchSelectTeamLeadModel = [];
  $scope.teamLeadChangeEventListeners = {
      onSelectionChanged: onTeamLeadSelectionChanged
  };
  $scope.searchSelectSupervisingAttorneyModel = [];
  $scope.supervisingAttorneyChangeEventListeners = {
      onSelectionChanged: onSupervisingAttorneySelectionChanged
  };
  $scope.searchSelectPlaintiffModel = [];
  $scope.plaintiffChangeEventListeners = {
      onSelectionChanged: onPlaintiffSelectionChanged
  };
  $scope.searchSelectDaysFromStartModel = [];
  $scope.daysFromStartChangeEventListeners = {
      onSelectionChanged: onDaysFromStartSelectionChanged
  };
  $scope.searchSelectJudgeModel = [];
  $scope.judgeChangeEventListeners = {
      onSelectionChanged: onJudgeSelectionChanged
  };
  $scope.searchSelectAnomalyTypeModel = [];
  $scope.anomalyTypeChangeEventListeners = {
      onSelectionChanged: onAnomalyTypeSelectionChanged
  };
  fillStateList();
}
    $scope.changerange = function() {
//        console.log("tada");
        $scope.displaySelectedStateValues = "";
        $scope.countyList = [];
        $scope.searchSelectCountyModel = [];
        $scope.displaySelectedCountyValues = "";
        $scope.firmList = [];
        $scope.searchSelectFirmModel = [];
        $scope.displaySelectedFirmValues = "";
        $scope.timekeeperList = [];
        $scope.searchSelectStaffModel = [];
        $scope.displaySelectedTimekeeperValues = "";
        $scope.matternameList = [];
        $scope.searchSelectMatterModel = [];
        $scope.displaySelectedMatternameValues = "";
        $scope.taskList = [];
        $scope.searchSelectTaskModel = [];
        $scope.displaySelectedTaskValues = "";
        $scope.expenseList = [];
        $scope.searchSelectExpenseModel = [];
        $scope.displaySelectedExpenseValues = "";
        $scope.phaseList = [];
        $scope.searchSelectPhaseModel = [];
        $scope.displaySelectedPhaseValues = "";
        $scope.staffList = [];
        $scope.searchSelectStaffModel = [];
        $scope.displaySelectedStaffValues = "";
        $scope.getDateFilter();
        $scope.displaySelectedDaterangeValues = $scope.datarange;
        fillStateList();
      };

 function updateChartHeader(cat, kpi){
   $('.chartHeaderLeft').empty().html(function(){
      return '<p>' + kpi + '</p>';
    });
 }

 $('input[name="timecomprange"]').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
      $scope.$apply( function() {
          $scope.initialtimecomp = "true";
          $scope.showcompTimeCategory = false;
          $scope.timecompselected = "";
      });
  });

  $('input[name="timecomprange"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
      $scope.$apply( function() {
          $scope.initialtimecomp = "false";
          $scope.showcompTimeCategory = true;
          var timecompdatevalue = getDateFilterForTimeFilters("timecomprange");
          $scope.displaySelectedTimeCompValues = timecompdatevalue;
          console.log("compasdfasdfasdfasfasdf selected = " + $scope.displaySelectedTimeCompValues);
      });
  });

  $('input[name="trialdaterange"]').on('cancel.daterangepicker', function(ev, picker) {
       $(this).val('');
       $scope.$apply( function() {
           $scope.initialtimecomp = "true";
           $scope.showTrialdateCategory = false;
           $scope.searchSelectTrialDateModel = [];
           $scope.displaySelectedTraildateValues = "";
       });
   });

  $('input[name="trialdaterange"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
      $scope.$apply( function() {
          $scope.initialtimecomp = "false";
          $scope.showTrialdateCategory = true;
          var trialdatevalue = getDateFilterForTimeFilters("trialdaterange");
          $scope.displaySelectedTraildateValues = trialdatevalue;
          $scope.searchSelectTrialDateModel.push(trialdatevalue);
      });
  });

    $('input[name="matteropendaterange"]').on('cancel.daterangepicker', function(ev, picker) {
         $(this).val('');
         $scope.$apply( function() {
             $scope.initialtimecomp = "true";
             $scope.showMatterOpendateCategory = false;
             $scope.searchSelectMatterOpenDateModel = [];
             $scope.displaySelectedMatteropenValues = "";
         });
     });

  $('input[name="matteropendaterange"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
      $scope.$apply( function() {
          $scope.initialtimecomp = "false";
          $scope.showMatterOpendateCategory = true;
          var matteropendatevalue = getDateFilterForTimeFilters("matteropendaterange");
          $scope.displaySelectedMatteropenValues = matteropendatevalue;
          $scope.searchSelectMatterOpenDateModel.push(matteropendatevalue);
      });
  });

  $('input[name="matterclosedaterange"]').on('cancel.daterangepicker', function(ev, picker) {
         $(this).val('');
         $scope.$apply( function() {
             $scope.initialtimecomp = "true";
             $scope.showMatterClosedateCategory = false;
             $scope.searchSelectMatterCloseDateModel = [];
             $scope.displaySelectedMattercloseValues = "";
         });
     });

  $('input[name="matterclosedaterange"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
      $scope.$apply( function() {
          $scope.initialtimecomp = "false";
          $scope.showMatterClosedateCategory = true;
          var matterclosedatevalue = getDateFilterForTimeFilters("matterclosedaterange");
          $scope.displaySelectedMattercloseValues = matterclosedatevalue;
          $scope.searchSelectMatterCloseDateModel.push(matterclosedatevalue);
      });
  });

	function fillStateList() {
   $scope.stateList = [];
    $scope.getDateFilter();
   analysisService.getAnalysisData("","state",$scope.datarange)
        .then(
              function( mydata ) {
              for(var i in mydata) {
                $scope.stateList.push(
                  {
                    id:i,
                    label: i
                  });
              };
		    });
    };

    // Method to return selectd values from dropdown and concate different values using pipe. Use Id of the dropdown when it is available
    function getSelectedValues(sourceParams){
      var sourceValue = "";
      for (i = 0; i < sourceParams.length; i++) {
        sourceValue = sourceValue + sourceParams[i].label + "||"; //need to add this after we update endpoint to handle multiple values separated by ||
      }
      return sourceValue;
    }

    function getSelectedValuesById(sourceParams){
      var sourceValue = "";
      for (i = 0; i < sourceParams.length; i++) {
        sourceValue = sourceValue + sourceParams[i].id + "||";
      }
      return sourceValue;
    }

    function getSelectedNonStandardValues(sourceParams,category){
      var sourceValue = "";
      for (i = 0; i < sourceParams.length; i++) {
        if(category == $scope.matternamefieldname) {
        sourceValue = sourceValue + getMatterId(sourceParams[i].label)  + "||"; //need to add this after we update endpoint to handle multiple values  separated by ||
      } else {o
        sourceValue = sourceValue + getNonStandardId(sourceParams[i].label)  + "||";
      }
      }
      return sourceValue;
    }

    function getNonStandardId(namelabel) {
      var returnId = "";
      if(namelabel != "") {
          returnId = namelabel.split('->')[0];
      }
      return returnId;
    }

    function getMatterId(matternamelabel) {
      var matterId = "";
      if(matternamelabel != "") {
          matterId = matternamelabel.split('->')[0];
      }
      return matterId;
    }

    function getMatterNameValue(valueCheck) {
          var matterNameTmp = "";
          for (i = 0; i < $scope.searchSelectMatterModel.length; i++) {
              if($scope.searchSelectMatterModel[i].label.split('->')[0] == valueCheck) {
                  matterNameTmp = $scope.searchSelectMatterModel[i].label.split('->')[1];
               }
        };
      return matterNameTmp;
    }

    // Method to return selectd values from dropdown and concate different values using pipe
    function getSelectedValuesForReport(sourceParams){
      $scope.valueSelected = [];
      var labelValue = "";
      for (i = 0; i < sourceParams.length; i++) {
        if($scope.categorySelected == $scope.matternamefieldname){
           labelValue = getMatterId(sourceParams[i].label)
        }
        else if($scope.categorySelected == $scope.firmfieldname){
             labelValue = sourceParams[i].id
        }
        else if(($scope.categorySelected == $scope.expensefieldname) || ($scope.categorySelected == $scope.taskcodefieldname)){
           labelValue = getNonStandardId(sourceParams[i].label)
        }
        else {
          labelValue = sourceParams[i].label
        }
        $scope.valueSelected.push(labelValue);
      }
    }

    function contains(arrayItems, item) {
        return arrayItems.indexOf(item) > -1;
    }
    // This method will returns the formatted filtervalue required for the endpoints.
    function getSelectedParams(sourceParams,category){
      var selectedValue = "";
      if(sourceParams.length > 0) {
      if(category == $scope.matternamefieldname) {
        selectedValue = getSelectedNonStandardValues(sourceParams);
        return $scope.matternamefieldname + ">>" + selectedValue;
      }
      if(category == $scope.expensefieldname) {
        selectedValue = getSelectedNonStandardValues(sourceParams);
        return $scope.expensefieldname + ">>" + selectedValue;
      }
      if(category == $scope.taskcodefieldname) {
        selectedValue = getSelectedNonStandardValues(sourceParams);
        return $scope.taskcodefieldname + ">>" + selectedValue;
      }
      if(category == $scope.opposingcounselfieldname) {
        selectedValue = getSelectedValuesById(sourceParams);
        return $scope.opposingcounselfieldname + ">>" + selectedValue;
      }
      else {
        selectedValue = getSelectedValues(sourceParams);
      }
      } else {
        return selectedValue = "";
      }
      if(category == $scope.statefieldname){
        return $scope.statefieldname + ">>" + selectedValue;
      }
      if(category == $scope.countyfieldname){
        return $scope.countyfieldname + ">>" + selectedValue;
      }
      if(category == $scope.firmfieldname){
        return $scope.firmfieldname + ">>" + selectedValue;
      }
      if(category == $scope.timekeeperfieldname){
        return $scope.timekeeperfieldname + ">>" + selectedValue;
      }
      if(category == $scope.taskcodefieldname){
        return $scope.taskcodefieldname + ">>" + selectedValue;
      }
      if(category == $scope.stafffieldname){
        return $scope.stafffieldname + ">>" + selectedValue;
      }
      if(category == $scope.phasefieldname){
        return $scope.phasefieldname + ">>" + selectedValue;
      }
      if(category == $scope.expensefieldname){
        return $scope.expensefieldname + ">>" + selectedValue;
      }
      if(category == $scope.ratebucketfieldname) {
        return $scope.ratebucketfieldname + ">>" + selectedValue;
      }
      if(category == $scope.trialdatefieldname) {
        return $scope.trialdatefieldname + ">>" + getDateFilterForTimeFilters("trialdaterange");
      }
      if(category == $scope.catcodefieldname) {
          return $scope.catcodefieldname + ">>" + selectedValue;
      }
      if(category == $scope.trialdatestatusfieldname) {
          return $scope.trialdatestatusfieldname + ">>" + selectedValue;
      }
      if(category == $scope.lengthbucketfieldname) {
        return $scope.lengthbucketfieldname + ">>" + selectedValue;
      }
      if(category == $scope.mattertypefieldname) {
        return $scope.mattertypefieldname + ">>" + selectedValue;
      }
      if(category == $scope.disputetypefieldname) {
        return $scope.disputetypefieldname + ">>" + selectedValue;
      }
      if(category == $scope.courttypefieldname) {
        return $scope.courttypefieldname + ">>" + selectedValue;
      }
      if(category == $scope.teamleadfieldname) {
console.log("value of teamlead="+selectedValue.trim());
        return $scope.teamleadfieldname + ">>" + selectedValue.trim();
      }
      if(category == $scope.attorneyfieldname) {
        return $scope.attorneyfieldname + ">>" + selectedValue;
      }
      if(category == $scope.daysfromstartfieldname) {
        return $scope.daysfromstartfieldname + ">>" + selectedValue;
      }
      if(category == $scope.judgefieldname) {
        return $scope.judgefieldname + ">>" + selectedValue;
      }
      if(category == $scope.statusfieldname) {
        return $scope.statusfieldname + ">>" + selectedValue;
      }
      if(category == $scope.opendatefieldname) {
        return $scope.opendatefieldname + ">>" + getDateFilterForTimeFilters("matteropendaterange");
      }
      if(category == $scope.closedatefieldname) {
        return $scope.closedatefieldname + ">>" + getDateFilterForTimeFilters("matterclosedaterange");
      }
      if(category == $scope.anomalydescriptionfieldname) {
        return $scope.anomalydescriptionfieldname + ">>" + selectedValue;
      }
    }

    function onStateSelectionChanged() {
      var selectedState = getSelectedParams($scope.searchSelectStateModel,$scope.statefieldname);
      if(selectedState != "") {
        if($scope.searchSelectStateModel.length >= 0) {
          updateCountyList(selectedState);
          updateFirmList(selectedState);
          updateMatterNameList(selectedState);
          updateTimeKeeperList(selectedState);
          updateTaskList(selectedState);
          updatePhaseList(selectedState);
          updateStaffList(selectedState);
          updateExpenseList(selectedState);
          updateAllFilters(selectedState);
          $scope.displaySelectedStateValues = $scope.searchSelectStateModel.map(function(el){return el.label}).join("||");
          if(contains($scope.selectionList,$scope.statefieldname)){
          } else {
                $scope.selectionList.push($scope.statefieldname);
          }
          if($scope.displaySelectedStateValues>=0){
              index = $scope.selectionList.indexOf($scope.statefieldname);
            if(index > -1) {
              $scope.selectionList.splice(index,1);
            }
          }
      }
    } else {
        $scope.displaySelectedStateValues = "";
        $scope.countyList = [];
        $scope.searchSelectCountyModel = [];
        $scope.displaySelectedCountyValues = "";
        $scope.firmList = [];
        $scope.searchSelectFirmModel = [];
        $scope.displaySelectedFirmValues = "";
        $scope.timekeeperList = [];
        $scope.searchSelectStaffModel = [];
        $scope.displaySelectedTimekeeperValues = "";
        $scope.matternameList = [];
        $scope.searchSelectMatterModel = [];
        $scope.displaySelectedMatternameValues = "";
        $scope.taskList = [];
        $scope.searchSelectTaskModel = [];
        $scope.displaySelectedTaskValues = "";
        $scope.expenseList = [];
        $scope.searchSelectExpenseModel = [];
        $scope.displaySelectedExpenseValues = "";
        $scope.phaseList = [];
        $scope.searchSelectPhaseModel = [];
        $scope.displaySelectedPhaseValues = "";
        $scope.staffList = [];
        $scope.searchSelectStaffModel = [];
        $scope.displaySelectedStaffValues = "";
      }
    };

    function onCountySelectionChanged() {
      var selectedCounty = getSelectedParams($scope.searchSelectCountyModel,$scope.countyfieldname);
      if(selectedCounty != "") {
      if($scope.searchSelectCountyModel.length >= 0) {
        updateFirmList(selectedCounty);
        updateTimeKeeperList(selectedCounty);
        updateMatterNameList(selectedCounty);
        updateTaskList(selectedCounty);
        updatePhaseList(selectedCounty);
        updateStaffList(selectedCounty);
        updateExpenseList(selectedCounty);
        updateAllFilters(selectedCounty);
        $scope.displaySelectedCountyValues = $scope.searchSelectCountyModel.map(function(el){return el.label}).join("||");
        if(contains($scope.selectionList,$scope.countyfieldname)){
        } else {
              $scope.selectionList.push($scope.countyfieldname);
        }
        if($scope.displaySelectedCountyValues>=0){
            index = $scope.selectionList.indexOf($scope.countyfieldname);
					if(index > -1) {
					  $scope.selectionList.splice(index,1);
          }
        }
      }
    } else {
        $scope.displaySelectedCountyValues = "";
      }
    };

    function onTimekeeperSelectionChanged() {
      var selectedTimekeeper = getSelectedParams($scope.searchSelectTimekeeperModel,$scope.timekeeperfieldname);
      if(selectedTimekeeper != "") {
      if($scope.searchSelectTimekeeperModel.length >= 0) {
        updateMatterNameList(selectedTimekeeper);
        updateTaskList(selectedTimekeeper);
        updatePhaseList(selectedTimekeeper);
        updateExpenseList(selectedTimekeeper);
        updateAllFilters(selectedTimekeeper);
        $scope.displaySelectedTimekeeperValues = $scope.searchSelectTimekeeperModel.map(function(el){return el.label}).join("||");
        if(contains($scope.selectionList,$scope.timekeeperfieldname)){
        } else {
              $scope.selectionList.push($scope.timekeeperfieldname);
            }
            if($scope.displaySelectedTimekeeperValues>=0){
                index = $scope.selectionList.indexOf($scope.timekeeperfieldname);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
              }
            }
          }
        } else {
          $scope.displaySelectedTimekeeperValues = "";
        }
    };

    function onFirmSelectionChanged() {
      if($scope.searchSelectMatterModel ==0 && $scope.searchSelectFirmModel ==0) {
         $scope.firmOrMatterParentSelected = "";
         $scope.displaySelectedFirmValues = "";
      } else {
         if($scope.searchSelectMatterModel<1) {
         $scope.firmOrMatterParentSelected = "firmsdd";
       }
      }
        var selectedFirm = getSelectedParams($scope.searchSelectFirmModel,$scope.firmfieldname);
        if($scope.firmOrMatterParentSelected == "firmsdd") {
          $scope.displaySelectedMatternameValues = "";
          updateMatterNameList(selectedFirm);
        }
        if(selectedFirm != "") {
        $scope.displaySelectedFirmValues = $scope.searchSelectFirmModel.map(function(el){return el.label}).join("||");
          if(contains($scope.selectionList,$scope.firmfieldname)){
          } else {
                $scope.selectionList.push($scope.firmfieldname);
          }
          if($scope.displaySelectedFirmValues>=0){
              index = $scope.selectionList.indexOf($scope.firmfieldname);
            if(index > -1) {
              $scope.selectionList.splice(index,1);
            }
          }
          updateTimeKeeperList(selectedFirm);
          updateTaskList(selectedFirm);
          updatePhaseList(selectedFirm);
          updateStaffList(selectedFirm);
          updateExpenseList(selectedFirm);
          updateAllFilters(selectedFirm);
          }  else {
            $scope.displaySelectedFirmValues = "";
          }
    };

    function onMatterSelectionChanged() {
      if($scope.searchSelectMatterModel ==0 && $scope.searchSelectFirmModel ==0) {
         $scope.firmOrMatterParentSelected = "";
         $scope.displaySelectedMatternameValues = "";
      } else {
         if($scope.searchSelectFirmModel.length<1) {
          $scope.firmOrMatterParentSelected = "mattersdd";
        }
      }
          var selectedMattername = getSelectedParams($scope.searchSelectMatterModel,$scope.matternamefieldname);
          if($scope.firmOrMatterParentSelected == "mattersdd") {
              updateFirmList(selectedMattername);
              $scope.displaySelectedFirmValues = "";
            }
          if(selectedMattername != "") {
            $scope.displaySelectedMatternameValues = $scope.searchSelectMatterModel.map(function(el){return el.label}).join("||");
            if(contains($scope.selectionList,$scope.matternamefieldname)){
            } else {
                  $scope.selectionList.push($scope.matternamefieldname);
                }
                if($scope.displaySelectedMatternameValues>=0){
                    index = $scope.selectionList.indexOf($scope.matternamefieldname);
                  if(index > -1) {
                    $scope.selectionList.splice(index,1);
                  }
                }
            updateTimeKeeperList(selectedMattername);
            updateTaskList(selectedMattername);
            updatePhaseList(selectedMattername);
            updateStaffList(selectedMattername);
            updateExpenseList(selectedMattername);
            updateAllFilters(selectedMattername);
            }else {
              $scope.displaySelectedMatternameValues = "";
            }
    };

    function onTaskSelectionChanged() {
      var selectedTask = getSelectedParams($scope.searchSelectTaskModel,$scope.taskcodefieldname);
      if(selectedTask != "") {
      if($scope.searchSelectTaskModel.length >= 0) {
        updateFirmList(selectedTask);
				updateTimeKeeperList(selectedTask);
				updateMatterNameList(selectedTask);
				updateStaffList(selectedTask);
        updateAllFilters(selectedTask);
        $scope.displaySelectedTaskValues = $scope.searchSelectTaskModel.map(function(el){return el.label.trim()}).join("||");
        if(contains($scope.selectionList,$scope.taskcodefieldname)){
        } else {
              $scope.selectionList.push($scope.taskcodefieldname);
            }
            if($scope.displaySelectedTaskValues>=0){
                index = $scope.selectionList.indexOf($scope.taskcodefieldname);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
              }
            }
      }
      } else {
        $scope.displaySelectedTaskValues = "";
      }
    };

    function onStaffSelectionChanged() {
      var selectedStaff = getSelectedParams($scope.searchSelectStaffModel,$scope.stafffieldname);
      if(selectedStaff != "") {
      if($scope.searchSelectStaffModel.length >= 0) {
        updateTimeKeeperList(selectedStaff);
        updateMatterNameList(selectedStaff);
        updateTaskList(selectedStaff);
        updatePhaseList(selectedStaff);
        updateExpenseList(selectedStaff);
        updateAllFilters(selectedStaff);
        $scope.displaySelectedStaffValues = $scope.searchSelectStaffModel.map(function(el){return el.label}).join("||");
        if(contains($scope.selectionList,$scope.stafffieldname)){
        } else {
              $scope.selectionList.push($scope.stafffieldname);
            }
            if($scope.displaySelectedStaffValues>=0){
                index = $scope.selectionList.indexOf($scope.stafffieldname);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
              }
            }
          }
      } else {
        $scope.displaySelectedStaffValues = "";
      }
    };

    function onPhaseSelectionChanged() {
      var selectedPhase = getSelectedParams($scope.searchSelectPhaseModel,$scope.phasefieldname);
      if(selectedPhase != "") {
      if($scope.searchSelectPhaseModel.length >= 0) {
        updateFirmList(selectedPhase);
        updateTimeKeeperList(selectedPhase);
        updateMatterNameList(selectedPhase);
        updateTaskList(selectedPhase);
        updateStaffList(selectedPhase);
        updateExpenseList(selectedPhase);
        updateAllFilters(selectedPhase);
        $scope.displaySelectedPhaseValues = $scope.searchSelectPhaseModel.map(function(el){return el.label}).join("||");
        if(contains($scope.selectionList,$scope.phasefieldname)){
        } else {
              $scope.selectionList.push($scope.phasefieldname);
            }
            if($scope.displaySelectedPhaseValues>=0){
                index = $scope.selectionList.indexOf($scope.stafffieldname);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
              }
            }
          }
      } else {
        $scope.displaySelectedPhaseValues = "";
      }
    };

    function onExpenseSelectionChanged() {
      var selectedExpense = getSelectedParams($scope.searchSelectExpenseModel,$scope.expensefieldname);
      if(selectedExpense != "") {
      if($scope.searchSelectExpenseModel.length >= 0) {
        updateFirmList(selectedExpense);
				updateTimeKeeperList(selectedExpense);
				updateMatterNameList(selectedExpense);
				updateTaskList(selectedExpense);
				updateStaffList(selectedExpense);
				updatePhaseList(selectedExpense);
        updateAllFilters(selectedExpense);
        $scope.displaySelectedExpenseValues = $scope.searchSelectExpenseModel.map(function(el){return el.label}).join("||");
        if(contains($scope.selectionList,$scope.expensefieldname)){
        } else {
              $scope.selectionList.push($scope.expensefieldname);
            }
            if($scope.displaySelectedExpenseValues>=0){
                index = $scope.selectionList.indexOf($scope.expensefieldname);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
              }
            }
        }
      } else {
        $scope.displaySelectedExpenseValues = "";
    }
    };

    function onRateSelectionChanged() {
      if($scope.searchSelectRateModel.length >= 0) {
         $scope.displaySelectedRateValues = $scope.searchSelectRateModel.map(function(el){return el.label}).join("||");
      }
    };

    function onTrialDateSelectionChanged() {
      if($scope.searchSelectTrialDateModel.length >= 0) {
         $scope.displaySelectedTraildateValues = $scope.searchSelectTrialDateModel.map(function(el){return el.label}).join("||");
      }
    };

    function onTrialDateStatusSelectionChanged() {
      if($scope.searchSelectTrialDateStatusModel.length >= 0) {
         $scope.displaySelectedTrialDateStatusValues = $scope.searchSelectTrialDateStatusModel.map(function(el){return el.label}).join("||");
      }
    };

    function onCatCodeSelectionChanged() {
      if($scope.searchSelectCatCodeModel.length >= 0) {
         $scope.displaySelectedCatCodeValues = $scope.searchSelectCatCodeModel.map(function(el){return el.label}).join("||");
      }
    };

    function onCaseLengthSelectionChanged() {
      if($scope.searchSelectCaseLengthModel.length >= 0) {
         $scope.displaySelectedCaseLengthValues = $scope.searchSelectCaseLengthModel.map(function(el){return el.label.trim()}).join("||");
      }
    };

    function onMatterTypeSelectionChanged() {
      if($scope.searchSelectMatterTypeModel.length >= 0) {
         $scope.displaySelectedMatterTypeValues = $scope.searchSelectMatterTypeModel.map(function(el){return el.label}).join("||");
      }
    };

    function onMatterStatusSelectionChanged() {
      if($scope.searchSelectMatterStatusModel.length >= 0) {
         $scope.displaySelectedMatterstatusValues = $scope.searchSelectMatterStatusModel.map(function(el){return el.label}).join("||");
      }
    };

    function onMatterOpenDateSelectionChanged() {
      if($scope.searchSelectMatterOpenDateModel.length >= 0) {
         $scope.displaySelectedMatteropenValues = $scope.searchSelectMatterOpenDateModel.map(function(el){return el.label}).join("||");
      }
    };

    function onMatterCloseDateSelectionChanged() {
      if($scope.searchSelectMatterCloseDateModel.length >= 0) {
         $scope.displaySelectedMattercloseValues = $scope.searchSelectMatterCloseDateModel.map(function(el){return el.label}).join("||");
      }
    };

    function onDisputeTypeSelectionChanged() {
      if($scope.searchSelectDisputeTypeModel.length >= 0) {
         $scope.displaySelectedDisputeTypeValues = $scope.searchSelectDisputeTypeModel.map(function(el){return el.label}).join("||");
      }
    };

    function onCourtTypeSelectionChanged() {
      if($scope.searchSelectCourtTypeModel.length >= 0) {
         $scope.displaySelectedCourtTypeValues = $scope.searchSelectCourtTypeModel.map(function(el){return el.label}).join("||");
      }
    };

    function onTeamLeadSelectionChanged() {
      if($scope.searchSelectTeamLeadModel.length >= 0) {
         $scope.displaySelectedTeamLeadValues = $scope.searchSelectTeamLeadModel.map(function(el){return el.label}).join("||");
      }
    };

    function onSupervisingAttorneySelectionChanged() {
      if($scope.searchSelectSupervisingAttorneyModel.length >= 0) {
         $scope.displaySelectedSupervisingAttorneyValues = $scope.searchSelectSupervisingAttorneyModel.map(function(el){return el.label}).join("||");
      }
    };

    function onPlaintiffSelectionChanged() {
      if($scope.searchSelectPlaintiffModel.length >= 0) {
         $scope.displaySelectedPlaintiffCounselValues = $scope.searchSelectPlaintiffModel.map(function(el){return el.label}).join("||");
      }
    };

    function onDaysFromStartSelectionChanged() {
      if($scope.searchSelectDaysFromStartModel.length >= 0) {
         $scope.displaySelectedDaysFromStartValues = $scope.searchSelectDaysFromStartModel.map(function(el){return el.label}).join("||");
      }
    };

    function onJudgeSelectionChanged() {
      if($scope.searchSelectJudgeModel.length >= 0) {
         $scope.displaySelectedJudgeValues = $scope.searchSelectJudgeModel.map(function(el){return el.label}).join("||");
      }
    };

    function onAnomalyTypeSelectionChanged() {
      if($scope.searchSelectAnomalyTypeModel.length >= 0) {
         $scope.displaySelectedAnomalyTypeValues = $scope.searchSelectAnomalyTypeModel.map(function(el){return el.label}).join("||");
      }
    };

    function updateCountyList(selecteditem) {
         $scope.countyList = [];
         $scope.countyList = getFiltersList(selecteditem,$scope.countyfieldname);
    };

    function updateExpenseList(selecteditem) {
      $scope.getDateFilter();
      analysisService.getExpenseOrTaskCodeList(selecteditem,$scope.datarange,"expense")
          .then(
            function( mydata ) {
              $scope.expenseList = [];
              for(var i in mydata) {
                $scope.expenseList.push(
                  {
                    id: i,
                    label:mydata[i] + "->" + i
                  });
               }
           });
    };

    function updateFirmList(selecteditem) {
       $scope.firmList = [];
       $scope.firmList = getFiltersList(selecteditem,$scope.firmfieldname);

    };

    function updateTimeKeeperList(selecteditem) {
       $scope.timekeeperList = [];
       $scope.timekeeperList = getFiltersList(selecteditem,$scope.timekeeperfieldname);

    };

    function updateMatterNameList(selecteditem) {
          $scope.getDateFilter();

       analysisService.getMatterList(selecteditem,$scope.datarange)
           .then(
             function( mydata ) {
               $scope.matternameList = [];
               for(var i in mydata) {
                 $scope.matternameList.push(
                   {
                     id: i,
                     label: i + "->" + mydata[i]
                   });
                }

            });
    };

    function SortByName(x,y) {
      return ((x.label == y.label) ? 0 : ((x.label > y.label) ? 1 : -1 ));
    };

    function updateTaskList(selecteditem) {
      $scope.getDateFilter();
      analysisService.getExpenseOrTaskCodeList(selecteditem,$scope.datarange,"task_code")
          .then(
            function( mydata ) {
              $scope.taskList = [];
              for(var i in mydata) {
                $scope.taskList.push(
                  {
                    id: i,
                    label:mydata[i] + "->" + i
                  });
               }
           });
    };

    function updatePhaseList(selecteditem) {
      $scope.phaseList = [];
      $scope.phaseList = getFiltersList(selecteditem,$scope.phasefieldname);
    };

    function updateStaffList(selecteditem) {
      $scope.staffList = [];
      $scope.staffList = getFiltersList(selecteditem,$scope.stafffieldname);
    };

  function getFiltersList(selecteditem,findfieldname){
     $scope.getDateFilter();
	   $scope.getFilters(false);
     if($scope.filtersSelected != ""){
	     selecteditem = $scope.filtersSelected;
     }
     var dataList = [];
     analysisService.getAnalysisData(selecteditem,findfieldname,$scope.datarange)
         .then(
           function( mydata ) {
             if(findfieldname == $scope.firmfieldname){
             for(var i in mydata) {
                 dataList.push(
                   { id:i,
                     label: mydata[i].replace('&amp;', '&')
                   });
               }
             } else {
               for(var i in mydata) {
                   dataList.push(
                     { id:i,
                       label: i.replace('&amp;', '&')
                     });
                 }
             }
             });
        return dataList;
    };

    function getPlantiffCounsilList(selecteditem){
      $scope.getDateFilter();
      var dataListTmp = [];
      $scope.getFilters(false);
	    selecteditem = $scope.filtersSelected;
      analysisService.getPlantiffCounsilData(selecteditem,$scope.datarange)
           .then(
             function( mydata ) {
               for(var i in mydata) {
                   dataListTmp.push(
                     { id:i,
                       label: mydata[i].replace(/&amp;/g, '&')
                     });
                 }
                sortArrOfObjectsByParam(dataListTmp, "label");
         });
         return dataListTmp;
      };

    function sortArrOfObjectsByParam(arrToSort, strObjParamToSortBy, sortAscending) {
     if(sortAscending == undefined) sortAscending = true;
     if(sortAscending) {
        arrToSort.sort(function (a, b) {
              return a.label > b.label ? 1 : (a.label < b.label ? -1 : 0);
        });
    }
    else {
        arrToSort.sort(function (a, b) {
           return a.label < b.label ? 1 : (a.label > b.label ? -1 : 0);
        });
    }
  }

  function updateAllFilters(selecteditem) {
			$scope.rates = [];
			$scope.traildates = [];
      $scope.traildatestatus = [];
			$scope.caselengths = [];
			$scope.mattertypes = [];
			$scope.disputetypes = [];
			$scope.courttypes = [];
			$scope.teamleads = [];
			$scope.supervisingattorneys = [];
			$scope.plaintiffcounsels = [];
			$scope.daysfromstart = [];
			$scope.judges = [];
			$scope.matterstatuses = [];
			$scope.matteropens = [];
			$scope.mattercloses = [];
			$scope.anomalytypes = [];

      $scope.rateList= [];
      $scope.rateList = getFiltersList(selecteditem,$scope.ratebucketfieldname);
      $scope.displaySelectedRateValues = "";
      $scope.searchSelectRateModel = [];

      $scope.traildateList= [];
      $scope.traildateList = getFiltersList(selecteditem,$scope.trialdatefieldname);
      $scope.displaySelectedTraildateValues = "";
      $scope.searchSelectTrialDateModel = [];

      $scope.trialdatestatusList= [];
      $scope.trialdatestatusList = getFiltersList(selecteditem,$scope.trialdatestatusfieldname);
      $scope.displaySelectedTrialDateStatusValues = "";
      $scope.searchSelectTrialDateStatusModel = [];

      $scope.catcodeList= [];
      $scope.catcodeList = getFiltersList(selecteditem,$scope.catcodefieldname);
      $scope.displaySelectedCatCodeValues = "";
      $scope.searchSelectCatCodeModel = [];

      $scope.caselengthList= [];
      $scope.caselengthList = getFiltersList(selecteditem,$scope.lengthbucketfieldname);
      $scope.displaySelectedCaseLengthValues = "";
      $scope.searchSelectCaseLengthModel = [];

      $scope.mattertypeList= [];
      $scope.mattertypeList = getFiltersList(selecteditem,$scope.mattertypefieldname);
      $scope.displaySelectedMatterTypeValues = "";
      $scope.searchSelectMatterTypeModel = [];

      $scope.disputetypeList= [];
      $scope.disputetypeList = getFiltersList(selecteditem,$scope.disputetypefieldname);
      $scope.displaySelectedDisputeTypeValues = "";
      $scope.searchSelectDisputeTypeModel = [];

      $scope.courttypeList= [];
      $scope.courttypeList = getFiltersList(selecteditem,$scope.courttypefieldname);
      $scope.displaySelectedCourtTypeValues = "";
      $scope.searchSelectCourtTypeModel = [];

      $scope.teamleadList= [];
      $scope.teamleadList = getFiltersList(selecteditem,$scope.teamleadfieldname);
      $scope.displaySelectedTeamLeadValues = "";
      $scope.searchSelectTeamLeadModel = [];

      $scope.supervisingattorneyList= [];
      $scope.supervisingattorneyList = getFiltersList(selecteditem,$scope.attorneyfieldname);
      $scope.displaySelectedSupervisingAttorneyValues = "";
      $scope.searchSelectSupervisingAttorneyModel = [];

      $scope.plaintiffcounselList= [];
      $scope.plaintiffcounselList = getPlantiffCounsilList(selecteditem);
      $scope.displaySelectedPlaintiffCounselValues = "";
      $scope.searchSelectPlaintiffModel = [];

      $scope.daysfromstartList= [];
      $scope.daysfromstartList = getFiltersList(selecteditem,$scope.daysfromstartfieldname);
      $scope.displaySelectedDaysFromStartValues = "";
      $scope.searchSelectDaysFromStartModel = [];

      $scope.judgeList= [];
      $scope.judgeList = getFiltersList(selecteditem,$scope.judgefieldname);
      $scope.displaySelectedJudgeValues = "";
      $scope.searchSelectJudgeModel = [];

      $scope.matteropenList= [];
      $scope.matteropenList = getFiltersList(selecteditem,$scope.opendatefieldname);
      $scope.displaySelectedMatteropenValues = "";
      $scope.searchSelectMatterOpenDateModel = [];

      $scope.mattercloseList= [];
      $scope.mattercloseList = getFiltersList(selecteditem,$scope.closedatefieldname);
      $scope.displaySelectedMattercloseValues = "";
      $scope.searchSelectMatterCloseDateModel = [];

      $scope.anomalytypeList= [];
      $scope.anomalytypeList = getFiltersList(selecteditem,$scope.anomalydescriptionfieldname);
      $scope.displaySelectedAnomalyTypeValues = "";
      $scope.searchSelectAnomalyTypeModel = [];

      $scope.matterstatusList= [];
      $scope.matterstatusList = getFiltersList(selecteditem,$scope.statusfieldname);
      $scope.displaySelectedMatterstatusValues = "";
      $scope.searchSelectMatterStatusModel = [];

	};

	$scope.getCategorySelected = function() {
		$scope.categorySelected = $scope.selectionList[$scope.selectionList.length-1];
    if($scope.categorySelected == 'timekeeper')
			$scope.categorySelected = 'full_name';
		else if($scope.categorySelected == 'staff')
			$scope.categorySelected = 'staff_level';
		else if($scope.categorySelected == 'firm')
			$scope.categorySelected = 'firm_name';
		else if($scope.categorySelected == 'expense')
			$scope.categorySelected = 'expense';
		else if($scope.categorySelected == 'task')
			$scope.categorySelected = 'task_code';
      else if($scope.categorySelected == 'matter_number') // added matter_name for firm + matter combination
  			$scope.categorySelected = 'matter_number';
	};

	$scope.getSelectedKPI = function() {
		if($scope.hours) {
			$scope.kpiSelected = 'hours';
		}
		else if($scope.spending) {
			$scope.kpiSelected = 'net_amt';
		}
		else if($scope.anomalies) {
			$scope.kpiSelected = 'anomaly_description';
		}
    else if($scope.rate){
      $scope.kpiSelected = 'rate';
    }
	};

	$scope.getFilters = function(returnfilters) {
		$scope.filtersSelected = "";
		if(returnfilters) {
		if($scope.searchSelectRateModel.length >= 1 && $scope.categorySelected != $scope.ratebucketfieldname) {
      var selectedRate = getSelectedParams($scope.searchSelectRateModel,$scope.ratebucketfieldname);
    	$scope.filtersSelected = $scope.filtersSelected + selectedRate + "&";
		}
    if($scope.searchSelectTrialDateModel.length >= 1 && $scope.categorySelected != $scope.trialdatefieldname ) {
      var selectedTrailDate = getSelectedParams($scope.searchSelectTrialDateModel,$scope.trialdatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedTrailDate + "&";
    }
    if($scope.searchSelectTrialDateStatusModel.length >= 1 && $scope.categorySelected != $scope.trialdatestatusfieldname) {
      var selectedTrialDateStatus = getSelectedParams($scope.searchSelectTrialDateStatusModel,$scope.trialdatestatusfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedTrialDateStatus + "&";
    }
    if($scope.searchSelectCatCodeModel.length >= 1 && $scope.categorySelected != $scope.catcodefieldname) {
      var selectedCatCode = getSelectedParams($scope.searchSelectCatCodeModel,$scope.catcodefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedCatCode + "&";
    }
    if($scope.searchSelectCaseLengthModel.length >= 1 && $scope.categorySelected != $scope.lengthbucketfieldname) {
      var selectedCaseLength = getSelectedParams($scope.searchSelectCaseLengthModel,$scope.lengthbucketfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedCaseLength + "&";
    }
    if($scope.searchSelectMatterTypeModel.length >= 1 && $scope.categorySelected != $scope.mattertypefieldname) {
      var selectedMatterType = getSelectedParams($scope.searchSelectMatterTypeModel,$scope.mattertypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterType + "&";
    }
    if($scope.searchSelectDisputeTypeModel.length >= 1 && $scope.categorySelected != $scope.disputetypefieldname) {
      var selectedDisputeType = getSelectedParams($scope.searchSelectDisputeTypeModel,$scope.disputetypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedDisputeType + "&";
    }
    if($scope.searchSelectCourtTypeModel.length >= 1 && $scope.categorySelected != $scope.courttypefieldname) {
      var selectedCourtType = getSelectedParams($scope.searchSelectCourtTypeModel,$scope.courttypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedCourtType + "&";
    }
    if($scope.searchSelectTeamLeadModel.length >= 1 && $scope.categorySelected != $scope.teamleadfieldname) {
      var selectedTeamLead = getSelectedParams($scope.searchSelectTeamLeadModel,$scope.teamleadfieldname);
      //console.log("selectedTeamLead="+ selectedTeamLead);
      $scope.filtersSelected = $scope.filtersSelected + selectedTeamLead.trim() + "&";
    }
    if($scope.searchSelectSupervisingAttorneyModel.length >= 1 && $scope.categorySelected != $scope.attorneyfieldname) {
      var selectedSupervisingAttorney = getSelectedParams($scope.searchSelectSupervisingAttorneyModel,$scope.attorneyfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedSupervisingAttorney + "&";
    }
    if($scope.searchSelectPlaintiffModel.length >= 1 && $scope.categorySelected != $scope.opposingcounselfieldname) {
      var selectedPlaintiff = getSelectedParams($scope.searchSelectPlaintiffModel,$scope.opposingcounselfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedPlaintiff + "&";
    }
    if($scope.searchSelectDaysFromStartModel.length >= 1 && $scope.categorySelected != $scope.daysfromstartfieldname) {
      var selectedDaysFromStart = getSelectedParams($scope.searchSelectDaysFromStartModel,$scope.daysfromstartfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedDaysFromStart + "&";
    }
    if($scope.searchSelectJudgeModel.length >= 1 && $scope.categorySelected != $scope.judgefieldname) {
      var selectedJudge = getSelectedParams($scope.searchSelectJudgeModel,$scope.judgefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedJudge + "&";
    }
    if($scope.searchSelectMatterStatusModel.length >= 1 && $scope.categorySelected != $scope.statusfieldname) {
      var selectedMatterStatus = getSelectedParams($scope.searchSelectMatterStatusModel,$scope.statusfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterStatus + "&";
    }
    if($scope.searchSelectMatterOpenDateModel.length >= 1 && $scope.categorySelected != $scope.opendatefieldname) {
      var selectedMatterOpenDate = getSelectedParams($scope.searchSelectMatterOpenDateModel,$scope.opendatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterOpenDate + "&";
    }
    if($scope.searchSelectMatterCloseDateModel.length >= 1 && $scope.categorySelected != $scope.closedatefieldname) {
      var selectedMatterCloseDate = getSelectedParams($scope.searchSelectMatterCloseDateModel,$scope.closedatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterCloseDate + "&";
    }
    if($scope.searchSelectAnomalyTypeModel.length >= 1 && $scope.categorySelected != $scope.anomalydescriptionfieldname) {
      var selectedAnomalyType = getSelectedParams($scope.searchSelectAnomalyTypeModel,$scope.anomalydescriptionfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedAnomalyType + "&";
    }
		}
    if($scope.selectionList.length >= 1) {
      if($scope.searchSelectStateModel.length >=1 && $scope.categorySelected != $scope.statefieldname) {
        var selectedState = getSelectedParams($scope.searchSelectStateModel,$scope.statefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedState + "&";
      }
      if($scope.searchSelectCountyModel.length >= 1 && $scope.categorySelected != $scope.countyfieldname) {
        var selectedCounty = getSelectedParams($scope.searchSelectCountyModel,$scope.countyfieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedCounty + "&";
      }
      if($scope.searchSelectFirmModel.length >= 1 && $scope.categorySelected != $scope.firmfieldname) {
        var selectedFirm = getSelectedParams($scope.searchSelectFirmModel,$scope.firmfieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedFirm + "&";
      }
      if($scope.searchSelectMatterModel.length >= 1 && $scope.categorySelected != $scope.matternamefieldname) {
        var selectedMatterName = getSelectedParams($scope.searchSelectMatterModel,$scope.matternamefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedMatterName + "&";
      }
      if($scope.searchSelectPhaseModel.length >= 1 && $scope.categorySelected != $scope.phasefieldname) {
        var selectedPhase = getSelectedParams($scope.searchSelectPhaseModel,$scope.phasefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedPhase + "&";
      }
      if($scope.searchSelectExpenseModel.length >= 1 && $scope.categorySelected != $scope.expensefieldname) {
        var selectedExpense = getSelectedParams($scope.searchSelectExpenseModel,$scope.expensefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedExpense + "&";
      }
      if($scope.searchSelectTaskModel.length >= 1 && $scope.categorySelected != $scope.taskcodefieldname) {
        var selectedTask = getSelectedParams($scope.searchSelectTaskModel,$scope.taskcodefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedTask + "&";
      }
      if($scope.searchSelectTimekeeperModel >= 1 && $scope.categorySelected != $scope.timekeeperfieldname) {
        var selectedTimekeeper = getSelectedParams($scope.searchSelectTimekeeperModel,$scope.timekeeperfieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedTimekeeper + "&";
      }
      if($scope.searchSelectStaffModel.length >= 1 && $scope.categorySelected != $scope.stafffieldname) {
        var selectedStaff = getSelectedParams($scope.searchSelectStaffModel,$scope.stafffieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedStaff + "&";
      }
  }
	};

  // method only used in executeReport as we are invoking stored procedure and it needs different format.
  $scope.getFiltersSP = function(returnfilters) {
    $scope.filtersSelected = "";
    if(returnfilters) {
    if($scope.searchSelectRateModel.length >= 1 && $scope.categorySelected != $scope.ratebucketfieldname) {
      var selectedRate = getSelectedParamsSP($scope.searchSelectRateModel,$scope.ratebucketfieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedRate + "&";
    }
    if($scope.searchSelectTrialDateModel.length >= 1 && $scope.categorySelected != $scope.trialdatefieldname ) {
      var selectedTrailDate = getSelectedParamsSP($scope.searchSelectTrialDateModel,$scope.trialdatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedTrailDate + "&";
    }
    if($scope.searchSelectTrialDateStatusModel.length >= 1 && $scope.categorySelected != $scope.trialdatestatusfieldname) {
      var selectedTrialDateStatus = getSelectedParamsSP($scope.searchSelectTrialDateStatusModel,$scope.trialdatestatusfieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedTrialDateStatus + "&";
    }
    if($scope.searchSelectCatCodeModel.length >= 1 && $scope.categorySelected != $scope.catcodefieldname) {
      var selectedCatCode = getSelectedParamsSP($scope.searchSelectCatCodeModel,$scope.catcodefieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedCatCode + "&";
    }
    if($scope.searchSelectCaseLengthModel.length >= 1 && $scope.categorySelected != $scope.lengthbucketfieldname) {
      var selectedCaseLength = getSelectedParamsSP($scope.searchSelectCaseLengthModel,$scope.lengthbucketfieldname);
      $scope.filtersSelected =  $scope.filtersSelected + "WEX_" + selectedCaseLength + "&";
    }
    if($scope.searchSelectMatterTypeModel.length >= 1 && $scope.categorySelected != $scope.mattertypefieldname) {
      var selectedMatterType = getSelectedParamsSP($scope.searchSelectMatterTypeModel,$scope.mattertypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedMatterType + "&";
    }
    if($scope.searchSelectDisputeTypeModel.length >= 1 && $scope.categorySelected != $scope.disputetypefieldname) {
      var selectedDisputeType = getSelectedParamsSP($scope.searchSelectDisputeTypeModel,$scope.disputetypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedDisputeType + "&";
    }
    if($scope.searchSelectCourtTypeModel.length >= 1 && $scope.categorySelected != $scope.courttypefieldname) {
      var selectedCourtType = getSelectedParamsSP($scope.searchSelectCourtTypeModel,$scope.courttypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedCourtType + "&";
    }
    if($scope.searchSelectTeamLeadModel.length >= 1 && $scope.categorySelected != $scope.teamleadfieldname) {
      var selectedTeamLead = getSelectedParamsSP($scope.searchSelectTeamLeadModel,$scope.teamleadfieldname);
      //console.log("selectedTeamLead="+ selectedTeamLead);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" +  selectedTeamLead + "&";
    }
    if($scope.searchSelectSupervisingAttorneyModel.length >= 1 && $scope.categorySelected != $scope.attorneyfieldname) {
      var selectedSupervisingAttorney = getSelectedParamsSP($scope.searchSelectSupervisingAttorneyModel,$scope.attorneyfieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedSupervisingAttorney + "&";
    }
    if($scope.searchSelectPlaintiffModel.length >= 1 && $scope.categorySelected != $scope.opposingcounselfieldname) {
      var selectedPlaintiff = getSelectedParamsSP($scope.searchSelectPlaintiffModel,$scope.opposingcounselfieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedPlaintiff + "&";
    }
    if($scope.searchSelectDaysFromStartModel.length >= 1 && $scope.categorySelected != $scope.daysfromstartfieldname) {
      var selectedDaysFromStart = getSelectedParamsSP($scope.searchSelectDaysFromStartModel,$scope.daysfromstartfieldname);
      $scope.filtersSelected =$scope.filtersSelected +  "WEX_" + selectedDaysFromStart + "&";
    }
    if($scope.searchSelectJudgeModel.length >= 1 && $scope.categorySelected != $scope.judgefieldname) {
      var selectedJudge = getSelectedParamsSP($scope.searchSelectJudgeModel,$scope.judgefieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedJudge + "&";
    }
    if($scope.searchSelectMatterStatusModel.length >= 1 && $scope.categorySelected != $scope.statusfieldname) {
      var selectedMatterStatus = getSelectedParamsSP($scope.searchSelectMatterStatusModel,$scope.statusfieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedMatterStatus + "&";
    }
    if($scope.searchSelectMatterOpenDateModel.length >= 1 && $scope.categorySelected != $scope.opendatefieldname) {
      var selectedMatterOpenDate = getSelectedParamsSP($scope.searchSelectMatterOpenDateModel,$scope.opendatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedMatterOpenDate + "&";
    }
    if($scope.searchSelectMatterCloseDateModel.length >= 1 && $scope.categorySelected != $scope.closedatefieldname) {
      var selectedMatterCloseDate = getSelectedParamsSP($scope.searchSelectMatterCloseDateModel,$scope.closedatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedMatterCloseDate + "&";
    }
    if($scope.searchSelectAnomalyTypeModel.length >= 1 && $scope.categorySelected != $scope.anomalydescriptionfieldname) {
      var selectedAnomalyType = getSelectedParamsSP($scope.searchSelectAnomalyTypeModel,$scope.anomalydescriptionfieldname);
      $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedAnomalyType + "&";
    }
    }
    if($scope.selectionList.length >= 1) {
      if($scope.searchSelectStateModel.length >=1 && $scope.categorySelected != $scope.statefieldname) {
        var selectedState = getSelectedParamsSP($scope.searchSelectStateModel,$scope.statefieldname);
        $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedState + "&";
      }
      if($scope.searchSelectCountyModel.length >= 1 && $scope.categorySelected != $scope.countyfieldname) {
        var selectedCounty = getSelectedParamsSP($scope.searchSelectCountyModel,$scope.countyfieldname);
        $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedCounty + "&";
      }
      if($scope.searchSelectFirmModel.length >= 1 && $scope.categorySelected != $scope.firmfieldname) {
        var selectedFirm = getSelectedParamsSP($scope.searchSelectFirmModel,$scope.firmfieldname);
        $scope.filtersSelected =  $scope.filtersSelected + "WEX_" + selectedFirm + "&";
      }
      if($scope.searchSelectMatterModel.length >= 1 && $scope.categorySelected != $scope.matternamefieldname) {
        var selectedMatterName = getSelectedParamsSP($scope.searchSelectMatterModel,$scope.matternamefieldname);
        $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedMatterName + "&";
      }
      if($scope.searchSelectPhaseModel.length >= 1 && $scope.categorySelected != $scope.phasefieldname) {
        var selectedPhase = getSelectedParamsSP($scope.searchSelectPhaseModel,$scope.phasefieldname);
        $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedPhase + "&";
      }
      if($scope.searchSelectExpenseModel.length >= 1 && $scope.categorySelected != $scope.expensefieldname) {
        var selectedExpense = getSelectedParamsSP($scope.searchSelectExpenseModel,$scope.expensefieldname);
        $scope.filtersSelected =  $scope.filtersSelected + "WEX_" +selectedExpense + "&";
      }
      if($scope.searchSelectTaskModel.length >= 1 && $scope.categorySelected != $scope.taskcodefieldname) {
        var selectedTask = getSelectedParamsSP($scope.searchSelectTaskModel,$scope.taskcodefieldname);
        $scope.filtersSelected =  $scope.filtersSelected + "WEX_" + selectedTask + "&";
      }
      if($scope.searchSelectTimekeeperModel >= 1 && $scope.categorySelected != $scope.timekeeperfieldname) {
        var selectedTimekeeper = getSelectedParamsSP($scope.searchSelectTimekeeperModel,$scope.timekeeperfieldname);
        $scope.filtersSelected =  $scope.filtersSelected + "WEX_" + selectedTimekeeper + "&";
      }
      if($scope.searchSelectStaffModel.length >= 1 && $scope.categorySelected != $scope.stafffieldname) {
        var selectedStaff = getSelectedParamsSP($scope.searchSelectStaffModel,$scope.stafffieldname);
        $scope.filtersSelected = $scope.filtersSelected + "WEX_" + selectedStaff + "&";
      }
  }
  };

  // this method is specific for execute report getSelectedParamsSP
  function getSelectedNonStandardValuesSP(sourceParams,category){
    var sourceValue = "";
    for (i = 0; i < sourceParams.length; i++) {
      if(category == $scope.matternamefieldname) {
      sourceValue = sourceValue + getMatterId(sourceParams[i].label)  + ",";
    } else {
      sourceValue = sourceValue + getNonStandardId(sourceParams[i].label)  + ",";
    }
    }
    return sourceValue;
  }

  function getSelectedValuesSP(sourceParams){
    var sourceValue = "";
    for (i = 0; i < sourceParams.length; i++) {
      sourceValue = sourceValue + sourceParams[i].label + ","; //need to add this after we update endpoint to handle multiple values separated by ||
    }
    return sourceValue;
  }

  function getSelectedValuesByIdSP(sourceParams){
    var sourceValue = "";
    for (i = 0; i < sourceParams.length; i++) {
      sourceValue = sourceValue + sourceParams[i].id + ",";
    }
    return sourceValue;
  }

  function getDateFilterForTimeFiltersSP(elementName) {
   var timeSelectedValue = "";
   var daterangetmp = document.getElementById(elementName).value;
   dateTmp = daterangetmp.split("-");
   if(elementName === "trialdaterange"){
     timeSelectedValue = "WEX_trial_dateRangeStart=" + dateTmp[0] + "&WEX_trial_dateRangeEnd=" + dateTmp[1];
   }
   if(elementName === "matteropendaterange"){
     timeSelectedValue = "WEX_open_dateRangeStart=" + dateTmp[0] + "&WEX_open_dateRangeEnd=" + dateTmp[1];
   }
   if(elementName === "matterclosedaterange"){
     timeSelectedValue = "WEX_close_dateRangeStart=" + dateTmp[0] + "&WEX_close_dateRangeEnd=" + dateTmp[1];
   }
   return timeSelectedValue;
  };

  // This method will returns the formatted filtervalue required for the stored procedure only.
  function getSelectedParamsSP(sourceParams,category){
    var selectedValue = "";
    if(sourceParams.length > 0) {
    if(category == $scope.matternamefieldname) {
      selectedValue = getSelectedNonStandardValuesSP(sourceParams);
      return $scope.matternamefieldname + "=" + selectedValue;
    }
    if(category == $scope.expensefieldname) {
      selectedValue = getSelectedNonStandardValuesSP(sourceParams);
      return $scope.expensefieldname + "=" + selectedValue;
    }
    if(category == $scope.taskcodefieldname) {
      selectedValue = getSelectedNonStandardValuesSP(sourceParams);
      return $scope.taskcodefieldname + "=" + selectedValue;
    }
    if(category == $scope.opposingcounselfieldname) {
      selectedValue = getSelectedValuesByIdSP(sourceParams);
      return $scope.opposingcounselfieldname + "=" + selectedValue;
    }
    else {
      selectedValue = getSelectedValuesSP(sourceParams);
    }
    } else {
      return selectedValue = "";
    }
    if(category == $scope.statefieldname){
      return $scope.statefieldname + "=" + selectedValue;
    }
    if(category == $scope.countyfieldname){
      return $scope.countyfieldname + "=" + selectedValue;
    }
    if(category == $scope.firmfieldname){
      selectedValue = getSelectedValuesByIdSP(sourceParams);
      return $scope.firmIDfieldname + "=" + selectedValue;
    }
    if(category == $scope.timekeeperfieldname){
      return $scope.timekeeperfieldname + "=" + selectedValue;
    }
    if(category == $scope.taskcodefieldname){
      return $scope.taskcodefieldname + "=" + selectedValue;
    }
    if(category == $scope.stafffieldname){
      // return $scope.stafffieldname + "=" + selectedValue;
      return $scope.timekeeperlevelfieldname + "=" + selectedValue;

    }
    if(category == $scope.phasefieldname){
      return $scope.phasecodefieldname + "=" + selectedValue;
    }
    if(category == $scope.expensefieldname){
      return $scope.expensefieldname + "=" + selectedValue;
    }
    if(category == $scope.ratebucketfieldname) {
      //return $scope.ratebucketfieldname + "=" + selectedValue;
      return $scope.ratebucketSPfieldname + "=" + selectedValue;
    }
    if(category == $scope.trialdatefieldname) {
      return getDateFilterForTimeFiltersSP("trialdaterange");
    }
    if(category == $scope.catcodefieldname) {
        return $scope.catcodefieldname + "=" + selectedValue;
    }
    if(category == $scope.trialdatestatusfieldname) {
      //  return $scope.trialdatestatusfieldname + "=" + selectedValue;
        return $scope.trialstatusfieldname + "=" + selectedValue;
    }
    if(category == $scope.lengthbucketfieldname) {
    //  return $scope.lengthbucketfieldname + "=" + selectedValue;
      return $scope.caselengthbucketfieldname + "=" + selectedValue;
    }
    if(category == $scope.mattertypefieldname) {
      return $scope.mattertypefieldname + "=" + selectedValue;
    }
    if(category == $scope.disputetypefieldname) {
    //  return $scope.disputetypefieldname + "=" + selectedValue;
      return $scope.suittypefieldname + "=" + selectedValue;
    }
    if(category == $scope.courttypefieldname) {
      return $scope.courttypefieldname + "=" + selectedValue;
    }
    if(category == $scope.teamleadfieldname) {
      return $scope.teamleadfieldname + "=" + selectedValue.trim();
    }
    if(category == $scope.attorneyfieldname) {
      return $scope.attorneySPfieldname + "=" + selectedValue;
    }
    if(category == $scope.daysfromstartfieldname) {
    //  return $scope.daysfromstartfieldname + "=" + selectedValue;
      return $scope.matteropendaysbucketfieldname + "=" + selectedValue;

    }
    if(category == $scope.judgefieldname) {
      return $scope.judgefieldname + "=" + selectedValue;
    }
    if(category == $scope.statusfieldname) {
      //return $scope.statusfieldname + "=" + selectedValue;
      return $scope.statusSPfieldname + "=" + selectedValue;

    }
    if(category == $scope.opendatefieldname) {
      return getDateFilterForTimeFiltersSP("matteropendaterange");
    }
    if(category == $scope.closedatefieldname) {
      return getDateFilterForTimeFiltersSP("matterclosedaterange");
    }
    if(category == $scope.anomalydescriptionfieldname) {
      //return $scope.anomalydescriptionfieldname + "=" + selectedValue;
      return $scope.anomalytypfieldname + "=" + selectedValue;
    }
  }

  $scope.getMatterValueSelected = function() {
        $scope.selectedMatterCategoryValues = [];
        for (i = 0; i < $scope.searchSelectMatterModel.length; i++) {
             labelValue = $scope.searchSelectMatterModel[i].label.split('->')[1];
             $scope.selectedMatterCategoryValues.push(labelValue);
          }
      };

	$scope.getValueSelected = function() {
		if($scope.categorySelected == 'state') {
			getSelectedValuesForReport($scope.searchSelectStateModel);
		}
		else if($scope.categorySelected == 'county') {
			getSelectedValuesForReport($scope.searchSelectCountyModel);
		}
		else if($scope.categorySelected == 'firm_name') {
			getSelectedValuesForReport($scope.searchSelectFirmModel);
		}
		else if($scope.categorySelected == 'matter_number') {
			getSelectedValuesForReport($scope.searchSelectMatterModel);
		}
		else if($scope.categorySelected == 'phase') {
			getSelectedValuesForReport($scope.searchSelectPhaseModel);
		}
		else if($scope.categorySelected == 'expense') {
			getSelectedValuesForReport($scope.searchSelectExpenseModel);
		}
		else if($scope.categorySelected == 'task_code') {
			getSelectedValuesForReport($scope.searchSelectTaskModel);
		}
		else if($scope.categorySelected == 'full_name') {
			getSelectedValuesForReport($scope.searchSelectTimekeeperModel);
		}
		else if($scope.categorySelected == 'staff_level') {
			getSelectedValuesForReport($scope.searchSelectStaffModel);
		}
	};

	$scope.getDefaultSubcategory = function(subcategory) {
		if(subcategory != "") {
			if(subcategory == 'State') {
				$scope.subcategorySelected = 'state';
			}
			else if(subcategory == 'County') {
				$scope.subcategorySelected = 'county';
			}
			else if(subcategory == 'Firm') {
				$scope.subcategorySelected = 'firm_name';
			}
			else if(subcategory == 'Matter') {
				$scope.subcategorySelected = 'matter_number';
			}
			else if(subcategory == 'Phase') {
				$scope.subcategorySelected = 'phase';
			}
			else if(subcategory == 'Expense') {
				$scope.subcategorySelected = 'expense';
			}
			else if(subcategory == 'Task') {
				$scope.subcategorySelected = 'task_code';
			}
			else if(subcategory == 'Time Keeper') {
				$scope.subcategorySelected = 'full_name';
			}
			else if(subcategory == 'Staff') {
				$scope.subcategorySelected = 'staff_level';
			}
			else if(subcategory == 'Anomaly') {
				$scope.subcategorySelected = 'anomaly_description';
			}
		}
		else {
			if($scope.categorySelected == 'state') {
				$scope.subcategorySelected = 'matter_number';
			}
			else if($scope.categorySelected == 'county') {
				$scope.subcategorySelected = 'matter_number';
			}
			else if($scope.categorySelected == 'firm_name') {
				$scope.subcategorySelected = 'full_name';
			}
			else if($scope.categorySelected == 'matter_number') {
				$scope.subcategorySelected = 'firm_name';
			}
			else if($scope.categorySelected == 'phase') {
				$scope.subcategorySelected = 'task_code';
			}
			else if($scope.categorySelected == 'expense') {
				$scope.subcategorySelected = 'matter_number';
			}
			else if($scope.categorySelected == 'task_code') {
				$scope.subcategorySelected = 'full_name';
			}
			else if($scope.categorySelected == 'full_name') {
				$scope.subcategorySelected = 'phase';
			}
			else if($scope.categorySelected == 'staff_level') {
				$scope.subcategorySelected = 'matter_number';
			}
		}
	};

	function getNameToBeDisplayed(name) {
		if(name == 'state') {
				return 'State';
			}
			else if(name == 'county') {
				return 'County';
			}
			else if(name == 'firm_name') {
				return 'Firm Name';
			}
			else if(name == 'matter_number') {
				return 'Matter';
			}
			else if(name == 'phase') {
				return 'Phase';
			}
			else if(name == 'expense') {
				return 'Expense';
			}
			else if(name == 'task_code') {
				return 'Task';
			}
			else if(name == 'full_name') {
				return 'Time Keeper';
			}
			else if(name == 'staff_level') {
				return 'Staff Level';
			}
			else if(name == 'net_amt') {
				return 'Spending ($)';
			}
			else if(name == 'hours') {
				return 'Hours';
			}
			else if(name == 'anomaly_description') {
				return 'Anomaly Count';
			}
			else if(name == 'anomaly_description') {
				return 'Anomaly Description';
			}
			return 'no mapping found';
	};

  function getSubCategoryForAverages(name) {
    if(name == 'matter_number') {
        return 'matter';
      }
      else if(name == 'county') {
        return 'County';
      }
      else if(name == 'firm_name') {
        return 'firm';
      }
      else if(name == 'phase') {
        return 'phase';
      }
      else if(name == 'task_code') {
        return 'taskcode';
      }
      else if(name == 'full_name') {
        return 'timekeeper';
      }
      else if(name == 'staff_level') {
        return 'level';
      }
      else if(name == 'anomaly_description') {
        return 'anomaly';
			}
  };

  function getAveragesList(kpi,state,subcategory){
       analysisService.getAveragesData(kpi,state,subcategory)
              .then(
                function( mydata ) {
                    $scope.averagesList = mydata;
              });
     };

    function removeUniqueAnomalyCount(returneddata) {
      return returneddata;
    };

	function createPieHighChart(returneddata) {
    var dataViewTable = document.getElementsByClassName("highcharts-data-table");
  //  console.log("dataViewTable = " + dataViewTable.length);
    $(dataViewTable).remove();
    var json = [];
    var othersVal = 0;
    var kpi = getNameToBeDisplayed($scope.kpiSelected);
		var cat = getNameToBeDisplayed($scope.categorySelected);
		var sub = getNameToBeDisplayed($scope.subcategorySelected);
		var title = cat + ' : ' +kpi + ' - Viewing By: '+sub;
    var patt = /spending/gi;
    if(returneddata.length > 0 ){
    //  console.log("changing loadGraph flag=" + $scope.loadGraph);
      $scope.loadGraph = false;
    }
    $scope.currencyKpi = patt.test(kpi);
    var anomalyarray = [];
    for(i in returneddata) {
        if(returneddata[i].name == 'unique_anomaly_count') {
          anomalyarray = returneddata.splice(i,1);
          break;
        }
      }
    if(returneddata.length > 20)
    {
      for(i in returneddata)
      {
        if (i < 19)
        {
          json[i] = returneddata[i]
        }else
        {
            othersVal = othersVal + returneddata[i].y;
        }
      }
      if (othersVal > 0)
      {
        totalitems = (returneddata.length - 19)
        json[19] = {"name":"Others", "y": othersVal, "totalitems": totalitems, "average" : (othersVal/totalitems)}
        if(sub === "Matter")
        {
          json[19].matter_name = "Others";
        }
      }
    }else {
      json = returneddata;
    }

    var fulljson = JSON.parse(JSON.stringify(returneddata));
    updateChartHeader(cat, kpi);
    // build legend table
    var table = $('div.legendTable > table');
    table.empty();
    var thead = $('<thead></thead>');
    var tbody = $('<tbody></tbody>');
    var theadRow = $('<tr></tr>');
    theadRow.append('<th>'+sub+'</th>');
    theadRow.append('<th class="text-center">Percentage</th>');
    theadRow.append('<th class="text-right">'+kpi+'</th>');
    thead.append(theadRow);
    Highcharts.setOptions({
			colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D']
		});
    var tot=0;
    var pTotal = 0;
			for (var j = 0; j < json.length; j++) {
				tot=tot+json[j].y;
			}
			var x=0;
			for(var i=1;i<json.length+1;i++) {
        var thirdColumnValue;

        if($scope.currencyKpi){
          thirdColumnValue = $filter('currency')(JSON.stringify(json[i-1].y), '$');
        }else{
          thirdColumnValue = $filter('number')(JSON.stringify(json[i-1].y), 2);
        }
        var rowHtml = '<td class="percLegendField text-left">' +
            '<div class="circle displayBlock" id="colorLegend" style="background: '+Highcharts.getOptions().colors[i-1] + '"></div>'
            if(sub == 'Matter')
            {
              rowHtml = rowHtml + '<a href="/AppBuilder/matters?matter='+ json[i-1].name+'">'
              rowHtml = rowHtml + '<div>' + json[i-1].matter_name + '</div>'
            }else if(sub == 'Firm Name')
            {
               rowHtml = rowHtml + '<a href="/AppBuilder/firms?firm='+ json[i-1].name+'">'
               rowHtml = rowHtml + '<div>' + json[i-1].name + '</div>'
            } else if(sub == 'Time Keeper'){
               if (json[i-1].name != 'Others')
               {
                 rowHtml = rowHtml + '<a href="/AppBuilder/firms?firm='+ json[i-1].firm_name +'&tab=Timekeepers&tkname='+json[i-1].name +'">' + json[i-1].name + '</a>'
                 rowHtml = rowHtml + '<div> - '+ json[i-1].staff_level +' (' + json[i-1].firm_name + ')</div>';
               }else{
                 rowHtml = rowHtml + json[i-1].name;
               }
            }else {
              rowHtml = rowHtml + '<div>' + json[i-1].name + '</div>'
            }
            if(sub == 'Matter' || sub == 'Firm Name')
            {
              rowHtml = rowHtml +'</a>'
            }

            rowHtml = rowHtml +'</td>' +
            '<td id="nameLegendField" class="percentageBlock">' +
            (((json[i-1].y)/tot)*100).toFixed(2) + '%' +
            '</td>' +
            '<td id="nameLegendField" class="text-right">' +
            thirdColumnValue +
            '</td>';
            pTotal = pTotal + json[i-1].y;
        var newRow = $('<tr></tr/>').append(rowHtml);
        tbody.append(newRow);

				x++;
			}
      $scope.pieTotal = pTotal;
      lItem = 0;
      for (var t = 0; t < json.length; t++) {
        if(json[t].name=="Others") {
          lItem = json.length-1 + json[t].totalitems;
        } else {
          lItem = json.length;
        }
      }
      $scope.averageCal = pTotal/lItem;
      newRow = $('<tr><td colspan="3"><div class="hspace"><div></td></tr/>');
      tbody.append(newRow);
      var newRow = '<tr><td class="text-left"><b>Total</b></td><td></td><td class="text-right"><b>';
      if($scope.currencyKpi){
          newRow = newRow + $filter('currency')($scope.pieTotal) ;
      }else{
        newRow = newRow + $filter('number')($scope.pieTotal,2);
      }
      newRow = newRow + '</b></td></tr/>';
      tbody.append(newRow);
    if(kpi == "Anomaly Count") {
     var newRow = '<tr><td class="text-left"><b>Unique Anomaly Count</b></td><td></td><td class="text-right"><b>';
     newRow = newRow + $filter('number')(anomalyarray[0].y);
     newRow = newRow + '</b></td></tr/>';
     tbody.append(newRow);
    }
      newRow = $('<tr><td colspan="3"><div class="hspace"><div></td></tr/>');
      tbody.append(newRow);
      newRow = '<tr><td class="text-left"><b>Average</b></td><td></td><td class="text-right"><b>';
      if($scope.currencyKpi){
         newRow = newRow + $filter('currency')($scope.averageCal) ;
      }else{
        newRow = newRow + $filter('number')($scope.averageCal, 2);
      }
      newRow = newRow + '</b></td></tr/>'
      tbody.append(newRow);
      table.append(thead);
      table.append(tbody);
      tot=0;
    if(Highcharts.getOptions().exporting.buttons.contextButton.menuItems.indexOf($scope.highchartsDataTable) == -1){
        Highcharts.getOptions().exporting.buttons.contextButton.menuItems.splice(8, 0, $scope.highchartsDataTable[0]);
      }

    $scope.pieChartPointArray = ['y'];
    if(sub == 'Time Keeper')
    {
      $scope.pieChartPointArray = ['firm_name:Firm Name','y'];
    }else if(sub == 'Matter')
    {
      $scope.pieChartPointArray = ['matter_name:Matter Name','y'];
    }
		Highcharts.chart('piechart', {
						chart: {
							plotBackgroundColor: null,
							plotBorderWidth: null,
							plotShadow: false,
							type: 'pie',
              width: 275,
              height: 275
						},

          title: { text: '' },
						tooltip: {
              shared: false,
              formatter: function() {
               var text = '';
                if(this.point.name == 'Others') {
                  text =  ((this.point.name).replace(/&amp;/g, '&')) + ': <b>' + Highcharts.numberFormat(this.point.percentage, 1) +'%</b> <br/>Average: '+ Highcharts.numberFormat(this.point.average,2) +'  <br/>Total Items: '+this.point.totalitems;
                } else {
                  text = ((this.point.name).replace(/&amp;/g, '&')) + ': <b>' + Highcharts.numberFormat(this.point.percentage, 1) + '%';
                }
                return text;
              }
						},
      colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D'],
						plotOptions: {
							pie: {
								allowPointSelect: true,
								cursor: 'pointer',
                size: 250,
                center: ["50%", "50%"],
								dataLabels: {
									enabled: false,
									formatter: function() {
										return Math.round(this.percentage*100)/100 + ' %';
									},
									distance: -30,
									color:'white'
								},
								showInLegend: true
							}
						},
						credits: {
							enabled: false
						},
						legend: {
              enabled: false

						},
						series: [{
							name: kpi,
							colorByPoint: true,
							data: json
						}],
						rawseries: [{
              pointArrayMap : $scope.pieChartPointArray,
							name: kpi,
							colorByPoint: true,
							data: fulljson,
              customXAxis: {
                title:{
                  text:sub
                }
              }
						}]
					});
	};

  function addColor(dataToColor){
    Highcharts.setOptions({
    colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D']
   });
    var retDataToColor = [];
    for(i = 0 ; i < dataToColor.length; i ++)
    {
      dataToColor[i].color =  Highcharts.getOptions().colors[i];
      retDataToColor.push(dataToColor[i]);
    }
    return retDataToColor;
  }

	function createBarChart(returneddata) {
    $scope.loadGraph = true;
    var json =  returneddata;
    var subJson = [];
    var  i = 0;
    var anomalyarray = [];
    if(returneddata.length > 0 ){
      $scope.loadGraph = false;
    }
		for(i in returneddata) {
        if(returneddata[i].name == 'unique_anomaly_count') {
          anomalyarray = returneddata.splice(i,1);
          break;
        }
      }
    if(returneddata.length > 1)
    {
      var noOfBars = returneddata[0].data.length;
      var fullBarArrays = [];
      var barArrays = [];
      var j = 0;
      var currentBarIndex = 0
      var othersBarTotal = 0;
      var othersIndex  = 0;
      for (j=0; j < noOfBars; j++)
      {
        barArrays[j] = [];
        fullBarArrays[j] = [];
      }
      var logVal = "";
      for (i = 0; i < returneddata.length; i++)
      {
          for (j = 0; j < noOfBars; j++)
          {
            if(returneddata[i].data[j]!=0)
            {
              fullBarArrays[j].push(returneddata[i]);
            }
            logVal = logVal + i + ","+j +","+returneddata[i].data[j]+ ",";
          }
          logVal = logVal + "\n";
      }
      for(i = 0 ; i < noOfBars; i ++)
      {
        logVal = "";
        othersIndex = 0;
        othersBarTotal = 0;
        if(fullBarArrays[i].length > 20)
        {
          var othersData = []
          for(j = 0 ; j < fullBarArrays[i].length ; j++)
          {
            var k=0;

            if(j < 19)
            {
              barRow =  JSON.parse(JSON.stringify(fullBarArrays[i][j]))
              for(k = 0 ; k < noOfBars; k ++)
              {
                if(k != i){
                  barRow.data[k] = 0;
                }
              }
              barArrays[i].push(barRow);
            }else{
               othersBarTotal += fullBarArrays[i][j].data[i];
               othersIndex++;
            }
            logVal = logVal + i +","+j +","+ fullBarArrays[i][j].data[i] + "\n";
          }
          for(k = 0 ; k < noOfBars; k ++)
          {
              if(k != i){
                othersData.push(0)
              }else{
                othersData.push({"average": (othersBarTotal/ othersIndex), "totalitems": othersIndex, "y": othersBarTotal });
              }
          }
          barArrays[i][19] = { "name":"Others", "data" : othersData};
        }
        else
        {
          for(j = 0 ; j < fullBarArrays[i].length ; j++)
          {
            var k=0;
            barRow =  JSON.parse(JSON.stringify(fullBarArrays[i][j]))
          //  console.log("barRow = " + JSON.stringify(barRow));
            for(k = 0 ; k < noOfBars; k ++)
            {
              if(k != i){
                barRow.data[k] = 0;
              }
            }
            barArrays[i].push(barRow);
          }
        }
      }
      for(i = 0 ; i < noOfBars; i ++)
      {
        subJson = subJson.concat(addColor(barArrays[i]));
      }
        json = subJson;
    }

    returneddataClone = JSON.parse(JSON.stringify(returneddata));
    var fullJson  = [];
    var filterData = [];
    var colorIndex = 0;
    var retVal = {};
    var myd = [];
    angular.forEach(returneddata, function(element, index) {
	     var tmp1 = "";
       angular.forEach(element, function(el, index) {
                  if(index === "data") {
                    for(j=0;j<el.length;j++){
                    	tmp1 = getData(element,j,colorIndex);
                      myd.push(tmp1);
                    }
                  }
     });
     colorIndex = colorIndex + 1;
     if(colorIndex >= 19){
       colorIndex = 0;
     }

 });

 var retVal = myd.map(function(each){
    return JSON.parse(each)
  });

  fullJson = retVal.sort(function(a,b) {
 		return b.data[0].y-a.data[0].y;
});

function getData(mydat,k,colorIndex){
 	var retMyTmp = [];
  var newTmpFormat = "";
  var newFinal = "";
  angular.forEach(mydat, function(el1, index1) {
   var temp = [];
   if(index1 === "data"){
   temp = [];
   temp.push('[{"x":'+ parseInt(k) + ',"y":' + el1[k] + '}]');
   	retMyTmp += '"' + index1 + '":' + temp + '';

   } else {
    retMyTmp += '"' + index1 + '":"' + el1 + '",';
   }

});
   retMyTmp += ',"color":"' + Highcharts.getOptions().colors[colorIndex] + '"';
	 newFinal = "{" + retMyTmp + "}";
   return newFinal;

}

function sortByValue(dataToSort,indexvalue) {
 var retSortedData = dataToSort.sort(function(a,b) {
//  return b.data[indexvalue].y-a.data[indexvalue].y;
  return b.data[indexvalue]-a.data[indexvalue];
  });
  return retSortedData;
}

    var kpi = getNameToBeDisplayed($scope.kpiSelected);
		var cat = getNameToBeDisplayed($scope.categorySelected);
		var sub = getNameToBeDisplayed($scope.subcategorySelected);
  	var title = cat + ' : ' +kpi + ' - Viewing By: '+sub;
    var patt = /spending/gi;
    $scope.currencyKpi = patt.test(kpi);
		$scope.legendheader = sub;
		$scope.legendmiddle = "Percentage(%)";
		$scope.legendright = kpi;
    updateChartHeader(cat, kpi);
		var cats = [];
		if($scope.showcompTimeCategory) {
			cats = $scope.timeselected;
	  } else if(cat == "Matter") {
      cats = $scope.selectedMatterCategoryValues;
    }else {
			cats = $scope.valueSelected;
  	}
    $('ul#legendTabs').empty();
    for(var i=0;i<cats.length;i++){
      $('ul#legendTabs').append("<li><a class='tabButton' id='tabBut"+i+"' tabindex='"+i+"'>"+cats[i]+"        </a></li>");
		}
    var tot =0;
    var lastSelectedTab;
    var lTotal = 0;
    var lItem = 0;
    var oItem = 0;
    var total = 0;
		$(".legendHeaderLeft").html("<div></div>");
		$(".legendHeaderMiddle").html("<div></div>");
		$(".legendHeaderRight").html("<div></div>");
		$(".tabButton").click(function () {
      var table = $('div.legendTable > table');
      table.empty();
      var thead = $('<thead></thead>');
      var tbody = $('<tbody></tbody>');
      $(this).parents('ul#legendTabs').find('li').removeClass('active');
      $(this).parent().addClass('active');
			$(".legendMid").hide();
      var theadRow = $('<tr></tr>');
      theadRow.append('<th>'+sub+'</th>');
      theadRow.append('<th class="text-center">Percentage</th>');
      theadRow.append('<th class="text-right">'+kpi+'</th>');
      thead.append(theadRow);
			Highcharts.setOptions({
			colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D']
		});
    json = sortByValue(json,this.tabIndex);
    for (var j = 0; j < json.length; j++) {
      if(json[j].name == "Others") {
        if(json[j].data[this.tabIndex] == 0) {
        }
        else {
			    tot=tot+json[j].data[this.tabIndex].y;
        }
      }
      else
      {
         tot=tot+json[j].data[this.tabIndex];
        }
			}
			var x=0;
			for(var i=1;i<json.length+1;i++) {
				if(json[i-1].data[this.tabIndex]==0){
					x=x+1;
					continue;
				}
				if(i%20 == 1){
          x=0;
        }else{
         x = x % 20;
        }
        var rowHtml;
        var regex = /spending/gi;
        var key = json[i-1].name;
        var indexTab = this.tabIndex;
        var colorstmp = $filter('getColorByName')(fullJson, key,indexTab);
        if(json[i-1].name == "Others") {
          var thirdColumnVal;
          if($scope.currencyKpi){
            thirdColumnVal = $filter('currency')(json[i-1].data[this.tabIndex].y);
          }else{
             thirdColumnVal = $filter('number')(json[i-1].data[this.tabIndex].y, 2);
          }
          rowHtml  = '<td class="percLegendField text-left">' +
            '<div class="circle displayBlock" id="colorLegend" style="background: '+colorstmp + '"></div>'
            rowHtml = rowHtml + '<div>' + json[i-1].name + '</div>'
            rowHtml = rowHtml + '</td>' +
            '<td id="nameLegendField" class="percentageBlock">' +
            (((json[i-1].data[this.tabIndex].y)/tot)*100).toFixed(2) + '%' +
            '</td>' +
            '<td id="nameLegendField">' +
            thirdColumnVal +
            '</td>';
             lTotal = lTotal + json[i-1].data[this.tabIndex].y;
             if(json[i-1].data[this.tabIndex].y > 0)
             {
               rowHtml  = '<td class="percLegendField text-left">' +
               '<div class="circle displayBlock" id="colorLegend" style="background: '+colorstmp + '"></div>'
               rowHtml = rowHtml + '<div>' + json[i-1].name + '</div>'
               rowHtml = rowHtml + '</td>' + '<td id="nameLegendField" class="percentageBlock">' ;
               rowHtml = rowHtml +(((json[i-1].data[this.tabIndex].y)/tot)*100).toFixed(2) + '%';
               kpiValue = json[i-1].data[this.tabIndex].y;
               if(regex.test(kpi)){
                  thirdColumnVal = $filter('currency')(kpiValue);
                }else{
                 thirdColumnVal = $filter('number')(kpiValue,2);
                }
               rowHtml = rowHtml + '</td>' ;
               rowHtml = rowHtml + '<td id="nameLegendField" class="text-right">' +
                          thirdColumnVal + '</td>';
               var newRow = $('<tr></tr/>').append(rowHtml);
                tbody.append(newRow);
               break;
             }
        }
          else{
            var thirdColumnVal;
            var kpiValue = 0;
          if(json[i-1].name != 'Others')
          {
            kpiValue = json[i-1].data[this.tabIndex];
          }else{
            kpiValue = json[i-1].data[this.tabIndex].y;
          }

          if(regex.test(kpi)){
            thirdColumnVal = $filter('currency')(kpiValue);
          }else{
             thirdColumnVal = $filter('number')(kpiValue,2);
          }
            rowHtml  = '<td class="percLegendField text-left">' +
            '<div class="circle displayBlock" id="colorLegend" style="background: '+colorstmp + '"></div>'
            if (json[i-1].name != 'Others')
            {
             if(sub == 'Matter')
             {
              rowHtml = rowHtml + '<a href="/AppBuilder/matters?matter='+ json[i-1].name+'">'
              rowHtml = rowHtml + '<div>' + json[i-1].matter_name + '</div>'
             }else if(sub == 'Firm Name')
             {
               rowHtml = rowHtml + '<a href="/AppBuilder/firms?firm='+ json[i-1].name+'">'
               rowHtml = rowHtml + '<div>' + json[i-1].name + '</div>'
             } else if(sub == 'Time Keeper'){
               rowHtml = rowHtml + '<a href="/AppBuilder/firms?firm='+ json[i-1].firm_name +'&tab=Timekeepers&tkname='+json[i-1].name +'">' + json[i-1].name + '</a>'
               rowHtml = rowHtml + '<div> - ' + json[i-1].staff_level + ' (' + json[i-1].firm_name + ')</div>'
             }
             else {
              rowHtml = rowHtml + '<div>' + json[i-1].name + '</div>'
             }
             if(sub == 'Matter' || sub == 'Firm Name')
             {
               rowHtml = rowHtml + '</a>'
             }
            }else{
              rowHtml = rowHtml + '<div>' + json[i-1].name + '</div>'
            }
            rowHtml = rowHtml + '</td>' +
            '<td id="nameLegendField" class="percentageBlock">' ;
            if(json[i-1].name != 'Others')
            {
              rowHtml = rowHtml + (((json[i-1].data[this.tabIndex])/tot)*100).toFixed(2) + '%';
            }else
            {
              rowHtml = rowHtml +(((json[i-1].data[this.tabIndex].y)/tot)*100).toFixed(2) + '%';
            }

            rowHtml = rowHtml + '</td>' ;
            rowHtml = rowHtml + '<td id="nameLegendField" class="text-right">' +
            thirdColumnVal +
            '</td>';
            if(json[i-1].name != 'Others')
            {
              lTotal = lTotal + json[i-1].data[this.tabIndex];
            }else{
               lTotal = lTotal + json[i-1].data[this.tabIndex].y;
            }
            lItem = lItem + 1;
          }
        var newRow = $('<tr></tr/>').append(rowHtml);
        tbody.append(newRow);
        x++;
			}
        lItem = 0;
        mItem = 0;
        for (var t = 0; t < json.length; t++) {
           if(json[t].name=="Others") {
           lItem = json[t].data[this.tabIndex].totalitems;
           if(lItem){
             mItem = lItem + 19;
             break;
           }
         } else {
           if(json[t].data[this.tabIndex] != 0){
             mItem = mItem + 1;
           }else if (mItem > 0){
             break;

           }
         }
        }
        $scope.graphTotal = lTotal;
        $scope.averageCal = lTotal/mItem;
        mItem = 0;
        newRow = $('<tr><td colspan="3"><div class="hspace"><div></td></tr/>');
        tbody.append(newRow);
        newRow = '<tr><td class="text-left"><b>Total</b></td><td></td><td class="text-right"><b>';
        if($scope.currencyKpi){
         newRow = newRow +  $filter('currency')($scope.graphTotal)
        }else{
          newRow = newRow +  $filter('number')($scope.graphTotal,2)
        }
        newRow = newRow + '</b></td></tr/>';
        tbody.append(newRow);

        if(kpi == "Anomaly Count") {
          newRow = '<tr><td class="text-left"><b>Unique Anomaly Count</b></td><td></td><td class="text-right"><b>';
          newRow = newRow +  $filter('number')(anomalyarray[0].data[this.tabIndex],2)
          newRow = newRow + '</b></td></tr/>';
          tbody.append(newRow);
        }
        newRow = '<tr><td class="text-left"><b>Average</b></td><td></td><td class="text-right"><b>';
        if($scope.currencyKpi){
           newRow = newRow + $filter('currency')($scope.averageCal)
        }else{
          newRow = newRow + $filter('number')($scope.averageCal, 2)
        }
        newRow = newRow + '</b></td></tr/>';
        tbody.append(newRow);
        table.append(thead);
        table.append(tbody);
        lTotal = 0;
    	  tot=0;
		});

    $("#tabBut0").trigger("click");
    var index = Highcharts.getOptions().exporting.buttons.contextButton.menuItems.map(function(o){
      if(o && o.textKey){
        return o.textKey;
      }
    }).indexOf("viewData");
    $scope.highchartsDataTable = Highcharts.getOptions().exporting.buttons.contextButton.menuItems.splice(index, 1);
  //  var jsonForGraph = fullJson;
    Highcharts.chart('barchart', {
		chart: {
			type: 'column'
		},
    title: { text: '' },
//    colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D'],
		xAxis: {
			categories: cats
		},
		yAxis: {
			min: 0,
			title: {
				text: kpi
			},
			stackLabels: {
				enabled: true,
				style: {
					fontWeight: 'bold',
					color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
				}
			}
		},
		legend : {
			enabled: false,
    },
		tooltip: {
		  shared: false,
              formatter: function() {
               var text = '';
                if(this.series.name == 'Others') {
                  text = ((this.series.name).replace(/&amp;/g, '&')) + ': <b>' +Highcharts.numberFormat(this.point.y, 1) + '</b> <br/>Average: '+ Highcharts.numberFormat(this.point.average,2) +'  <br/>Total Items: '+this.point.totalitems;
                } else {
                  text = ((this.series.name).replace(/&amp;/g, '&')) + ': <b> ' + Highcharts.numberFormat(this.point.y, 1);
                }
                return text;
              }
    },
		credits: {
			enabled: false
		},
		plotOptions: {
			column: {
				stacking: 'normal',
				dataLabels: {
					enabled: false,
					color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
				}
			}
		},
		series: fullJson
    ,rawseries: fullJson
	});
	};

    function formatOptionsForTimeline(options){
        var seriesOptions = options.slice();
        var newOptions = [];
        for(var i = 0; i < seriesOptions.length; i++){
         var linkId = seriesOptions[i]["name"].replace(/\s/g, "");
         var newSeries = jQuery.extend(true, {}, seriesOptions[i]);
         newSeries["type"] = "line";
         newSeries["id"] = linkId;
         newOptions.push(newSeries);
         newOptions.push({
            name: seriesOptions[i]["name"] + " - Trend",
            linkedTo: linkId,
            showInLegend: true,
            enableMouseTracking: false,
            type: 'trendline',
            algorithm: 'linear'
         });
       }
      return newOptions;
    }

    function createChart(seriesOptions) {
        var kpi = getNameToBeDisplayed($scope.kpiSelected);
				var cat = getNameToBeDisplayed($scope.categorySelected);
				var sub = getNameToBeDisplayed($scope.subcategorySelected);
				var title = cat + ' : ' +kpi;
        window.chart = new Highcharts.StockChart({
            chart: {
                renderTo: 'timelinechart'
            },
            rangeSelector: {
            allButtonsEnabled: true,
            buttons: [{
                type: 'month',
                count: 3,
                text: 'Day',
                dataGrouping: {
                  approximation: "sum",
                    forced: true,
                    units: [['day', [1]]]
                }
            }, {
                type: 'year',
                count: 1,
                text: 'Week',
                dataGrouping: {
                                    approximation: "sum",
                    forced: true,
                    units: [['week', [1]]]
                }
            }, {
                type: 'all',
                text: 'Month',
                dataGrouping: {
                    approximation: "sum",
                    forced: true,
                    units: [['month', [1]]]
                }
            }],
            buttonTheme: {
                width: 60
            },
            selected: 2
        },
          credits: {
    			enabled: false
    		},
          tooltip: {
            pointFormat: '<span style="color:{series.color}">{series.name}</span>: <b>{point.y}</b><br/>',
            valueDecimals: 2,
            split: true
        },
            series: seriesOptions,
          legend : {
            enabled: true,
                    itemWidth: 800,
                    x: 90,
                    useHTML: true,
                    labelFormatter: function() {
                        var total = 0;
                        for(var i=this.yData.length; i--;) { total += this.yData[i]; };
                         var regex = /spending/gi;
                         var labelVal;
                         if(regex.test(kpi)){
                          labelVal = $filter('currency')(total.toFixed(2), '$');
                         }else{
                          labelVal = total.toFixed(2);
                         }
                        return "<div style='display: inline-table; width: 480px;'>"+this.name+"</div><div style='text-align:right;display: inline-table; width:50px; font-size:14px; margin-left:-5%;'>"+ labelVal +"</div>";
                    }
                }

        }, function(chart) {
            setTimeout(function() {
                $('input.highcharts-range-selector', $('#' + chart.options.chart.renderTo)).datepicker()
            }, 0)
        });
    $.datepicker.setDefaults({
        dateFormat: 'yy-mm-dd',
        onSelect: function(dateText) {
            this.onchange();
            this.onblur();
        }
    });
}

$scope.toggleMatterOpenTimeLine = function() {
	$scope.matterOpenTimeLine = !$scope.matterOpenTimeLine
  createTimeLineChart();
};

function createTimeLineChart() {
  //$scope.loadTimelineGraph = true;
  var seriesOptions = [];
  var matterOpenSeriesOptions = [];
    var j = 0;
    var success = 0;
    for(var i in $scope.valueSelected ) {
			//  console.log("category is"+$scope.categorySelected + "value " +$scope.valueSelected[i] + "filer "+$scope.filtersSelected + "date "+$scope.datarange + "kpi" + $scope.kpiSelected + "sub "+$scope.categorySelected );
      var timelinestring = ""
    if($scope.matterOpenTimeLine) {
      timelinestring = "timelinematteropen";
        }
      else {
        timelinestring = "timeline";
      }
        (function(k,seriesname){
          var serviceUrlFormatted = getServiceParams($scope.categorySelected,$scope.valueSelected[i],$scope.filtersSelected, $scope.categorySelected);
          $.ajax({
              url      : serviceUrlFormatted,
              type     : "POST",
              //data     : {category: $scope.categorySelected, categoryvalue: $scope.valueSelected[i], filters: $scope.filtersSelected, datefilter: $scope.datarange, selectedkpi: $scope.kpiSelected, subcategory: $scope.categorySelected,charttype:timelinestring},
              success  : function(data) {
              $scope.loadTimelineGraph = false;
              seriesnametmp =  seriesname;
              if($scope.categorySelected == "matter_number") {
                seriesnametmp = getMatterNameValue(seriesname);
              }
              seriesOptions[k] = {
                name: seriesnametmp,
                data: JSON.parse(data),
                threshold: null,
                turboThreshold: 20000,
                regression: true,
                regressionSettings: {
                  color: "rgba(223, 83, 83, .9)",
                  name: seriesnametmp + " - Trend"
                }
            };
                matterOpenSeriesOptions[k] = {
                name: seriesnametmp,
                data: JSON.parse(data)
            };
                success++;
                if((success == $scope.valueSelected.length) ) {
                  if($scope.matterOpenTimeLine) {
                    $scope.loadTimelineGraph = false;
                    createChartMatterOpen(matterOpenSeriesOptions);
                  }
                  else {
                    $scope.loadTimelineGraph = false;
                    createChart(seriesOptions);
                  }

                  }
              }
          });
        })(j,$scope.valueSelected[i]);
        j++;
    }

		var chart;
	};
  function createChartMatterOpen(seriesOptions) {
        var kpi = getNameToBeDisplayed($scope.kpiSelected);
				var cat = getNameToBeDisplayed($scope.categorySelected);
				var sub = getNameToBeDisplayed($scope.subcategorySelected);
				var title = cat + ' : ' +kpi;
        window.chart = new Highcharts.chart({
            chart: {
              renderTo: 'timelinechart',
              type: 'spline',
              zoomType: 'x'
            },
          title: {
            text: 'Matter - ' + kpi + ' Chart'
          },

          xAxis: {
         title: "Matter Open Days"
          },
          yAxis: {
            title: {
              text: kpi
            },
            min: 0
          },
          tooltip: {
            headerFormat: '<b>{series.name}</b><br>',
            pointFormat: '{point.y:.2f}'
          },

          plotOptions: {
            spline: {
              marker: {
                enabled: true
              }
            }
          },
          credits: {
        			enabled: false
        		},
          series: seriesOptions,
          legend : {
            enabled: true,
                    itemWidth: 800,
                    x: 90,
                    useHTML: true,
                    labelFormatter: function() {
                        var total = 0;
                        for(var i=this.yData.length; i--;) { total += this.yData[i]; };
                         var regex = /spending/gi;
                         var labelVal;
                         if(regex.test(kpi)){
                          labelVal = $filter('currency')(total.toFixed(2), '$');
                         }else{
                          labelVal = total.toFixed(2);
                         }
                        return "<div style='display: inline-table; width: 480px;'>"+this.name+"</div><div style='text-align:right;display: inline-table; width:50px; font-size:14px; margin-left:-5%;'>"+ labelVal +"</div>";
                    }
                }

        }, function(chart) {

        });


  }

	  $scope.populateSubCategorySelection = function() {
		$scope.subcategoryvalues = [];
		$scope.showSubCategory = true;
  	if($scope.categorySelected == 'state') {
			$scope.subcategoryvalues.push('County');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
				$scope.subcategoryvalues.push('Anomaly');
		}
		else if($scope.categorySelected == 'county') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
				$scope.subcategoryvalues.push('Anomaly');
			}
		else if($scope.categorySelected == 'firm_name') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');
	  }
		else if($scope.categorySelected == 'matter_number') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');
		}
		else if($scope.categorySelected == 'phase') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');
		}
		else if($scope.categorySelected == 'expense') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');
		}
		else if($scope.categorySelected == 'task_code') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');
		}
		else if($scope.categorySelected == 'full_name') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Task');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');
		}
		else if($scope.categorySelected == 'staff_level') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');
		}
	};
	$scope.getDateFilter = function() {
    $scope.timeselected = [];
    $scope.WEX_TimeFrameStart = "";
    $scope.WEX_TimeFrameEnd = "";
    $scope.WEX_FirstTimeRangeStart = "";
    $scope.WEX_FirstTimeRangeEnd = "";
    $scope.WEX_SecondTimeRangeStart = "";
    $scope.WEX_SecondTimeRangeEnd = "";
    var timeCompSelectedValue = "";
    $scope.datarange = document.getElementById("daterange").value;
    timeStartByValue = $scope.datarange.split("-");
    $scope.WEX_TimeFrameStart = timeStartByValue[0];
    $scope.WEX_TimeFrameEnd = timeStartByValue[1];
    timeCompSelectedValue = document.getElementById("timecomprange").value;
    $scope.timeselected.push($scope.datarange);
    if(timeCompSelectedValue != "") {
      timeCompByValue = timeCompSelectedValue.split("-");
      $scope.WEX_FirstTimeRangeStart = timeStartByValue[0];
      $scope.WEX_FirstTimeRangeEnd = timeStartByValue[1];
      $scope.WEX_SecondTimeRangeStart = timeCompByValue[0];
      $scope.WEX_SecondTimeRangeEnd = timeCompByValue[1];
      $scope.datarange = $scope.datarange + '||' + timeCompSelectedValue;
      $scope.timeselected.push(timeCompSelectedValue);
    }
};

 function getDateFilterForTimeFilters(elementName) {
  var timeSelectedValue = "";
  var daterangetmp = document.getElementById(elementName).value + '||';
  return daterangetmp;
};

	function createMattertable(data) {
		var jsonData = eval(data);
		$scope.matterTableData = jsonData;
		$scope.dataForMatterTableLoaded = true;
		$scope.$apply();
	};

	$scope.convertTime = function(datetoconvert) {
		var d = new Date(datetoconvert);
		var t= d.getTime();

		return Math.round(t /1000);
	};

  function getServiceParams(catSelectedTmp,catValueSelectedTmp,filterSelectedTmp,subCatSelectedTmp) {
      var retFormattedUrl = "";
      var tempFieldStr = "";
       if($scope.WEX_TimeFrameStart != "") {
       	 tempFieldStr = tempFieldStr + "WEX_TimeFrameStart=" + $scope.WEX_TimeFrameStart;
      }
      if($scope.WEX_TimeFrameEnd != "") {
        tempFieldStr = tempFieldStr + "&WEX_TimeFrameEnd=" + $scope.WEX_TimeFrameEnd;
      }
      if($scope.WEX_FirstTimeRangeStart != "") {
        tempFieldStr = tempFieldStr + "&WEX_FirstTimeRangeStart=" + $scope.WEX_FirstTimeRangeStart;
      }
      if($scope.WEX_FirstTimeRangeEnd != "") {
        tempFieldStr = tempFieldStr + "&WEX_FirstTimeRangeEnd=" + $scope.WEX_FirstTimeRangeEnd;
      }
      if($scope.WEX_SecondTimeRangeStart != "") {
        tempFieldStr = tempFieldStr + "&WEX_SecondTimeRangeStart=" + $scope.WEX_SecondTimeRangeStart;
      }
      if($scope.WEX_SecondTimeRangeEnd != "") {
        tempFieldStr = tempFieldStr + "&WEX_SecondTimeRangeEnd=" + $scope.WEX_SecondTimeRangeEnd;
      }

      if(catSelectedTmp != "" && catValueSelectedTmp != "") {
        if(catSelectedTmp == "firm_name"){
          catSelectedTmp = $scope.firmIDfieldname;
        }
        if(catSelectedTmp == "phase"){
          catSelectedTmp = $scope.phasecodefieldname;
        }
        if(catSelectedTmp == "supervising_attorney"){
          catSelectedTmp = $scope.attorneySPfieldname;
        }
        // These are not categories but filters
        // if(catSelectedTmp == "dispute_type"){
        //   catSelectedTmp = $scope.suittypefieldname;
        // }
        tempFieldStr = tempFieldStr + "&WEX_category=" + catSelectedTmp + "&WEX_" + catSelectedTmp + "=" + catValueSelectedTmp ;
      }
      if(subCatSelectedTmp != "") {
        tempFieldStr = tempFieldStr+"&WEX_subcategory=" + subCatSelectedTmp;
      }
      if(filterSelectedTmp != ""){
        tempFieldStr =  tempFieldStr+ "&" + filterSelectedTmp;
      }
      retFormattedUrl = $scope.serviceDataUrl + "?"+tempFieldStr;
    //  console.log(retFormattedUrl);
      return retFormattedUrl;
    }

	$scope.executeReport = function() {
    $scope.loadGraph = true;
    $scope.loadTimelineGraph = true;
    $scope.getCategorySelected();
		$scope.getValueSelected();
    $scope.getMatterValueSelected();
		//$scope.getFilters(true);
    $scope.getFiltersSP(true);
		$scope.getSelectedKPI();
    if($scope.categorySelected == "expense" && $scope.subcategoryselect == "Time Keeper"){
      $scope.subcategoryselect = "Matter";
    }
	  if($scope.categorySelected == "matter_number") {
		  $scope.matternumberselected = true;
	  }
    else {
		  $scope.matternumberselected = false;
	  }
    $scope.getDefaultSubcategory($scope.subcategoryselect);
    $('div.legendTable > table').empty();
    $('ul#legendTabs').empty();
    document.getElementById('chart_wrapper').scrollIntoView(true);
		$scope.populateSubCategorySelection();
  	$scope.getDateFilter();
//		console.log("category is"+ $scope.categorySelected + ", category value is: "+$scope.valueSelected[0] + ", selected kpi:" + $scope.kpiSelected +", sub category is:" + $scope.subcategorySelected);
    if($scope.valueSelected.length == 1) {
      $scope.showPieChart = true;
    }
    if($scope.valueSelected.length == 1 && $scope.categorySelected == "matter_number") {
      $scope.dataForMatterTableLoaded = true;
    } else {
      $scope.dataForMatterTableLoaded = false;
    }
		var categoryString = "";
			for(var i in $scope.valueSelected ) {
				categoryString = categoryString + $scope.valueSelected[i] + ",";
			}

    if(!$scope.rate){
          		if($scope.showcompTimeCategory) {
                // change to categoryString when endpoint is changed.
                //analysisService.getAnalysisCharts($scope.categorySelected,$scope.valueSelected[0],$scope.filtersSelected,$scope.datarange, $scope.kpiSelected,$scope.subcategorySelected,"timecomparison")
                //analysisService.getAnalysisCharts($scope.categorySelected,categoryString,$scope.filtersSelected,$scope.datarange, $scope.kpiSelected,$scope.subcategorySelected,"timecomparison")
                var serviceUrlFormatted = getServiceParams($scope.categorySelected,$scope.valueSelected[0],$scope.filtersSelected, $scope.subcategorySelected);
                analysisService.getAnalysisCharts(serviceUrlFormatted)
                .then(
                    function( mydata ) {
                      createBarChart(mydata);
                });
                $scope.showPieChart = false;
          		}
          		else if($scope.valueSelected.length == 1) {
                //create the params, category and subcategory and pass it to service.

                //analysisService.getAnalysisCharts($scope.categorySelected,$scope.valueSelected[0],$scope.filtersSelected, $scope.datarange, $scope.kpiSelected,$scope.subcategorySelected,"pie")
                var serviceUrlFormatted = getServiceParams($scope.categorySelected,$scope.valueSelected[0],$scope.filtersSelected, $scope.subcategorySelected);
                analysisService.getAnalysisCharts(serviceUrlFormatted)
                .then(
                    function( mydata ) {
                      createPieHighChart(mydata);
                });
          			$scope.showPieChart = true;
          		}
          		else {
              $scope.showPieChart = false;
              //analysisService.getAnalysisCharts($scope.categorySelected, categoryString, $scope.filtersSelected, $scope.datarange,$scope.kpiSelected, $scope.subcategorySelected,"bar")
              var serviceUrlFormatted = getServiceParams($scope.categorySelected,categoryString,$scope.filtersSelected, $scope.subcategorySelected);
              analysisService.getAnalysisCharts(serviceUrlFormatted)
              .then(
                  function( mydata ) {
                      createBarChart(mydata);
              });
          		}
          		if(!$scope.showcompTimeCategory) {
                createTimeLineChart();
          		}
          		if($scope.valueSelected.length == 1 && $scope.categorySelected == "matter_number") {
                analysisService.getMatterChart($scope.valueSelected[0])
                .then(
                    function( mydata ) {
                        createMattertable(mydata);
                });
          		}
      } else {
        var seriesOptions = [];
        var j = 0;
        var success = 0;
        $scope.openRateTab = 0;
        $scope.setOpenTab = function(val){
        $scope.openRateTab = val;
      }
      for(var i in $scope.valueSelected ) {
          (function(k,seriesname){
            var serviceUrlFormatted = getServiceParams($scope.categorySelected,$scope.valueSelected[i],$scope.filtersSelected, $scope.subcategorySelected);
            $.ajax({
                url      : serviceUrlFormatted,
                type     : "POST",
              //  data     : {category: $scope.categorySelected, categoryvalue: $scope.valueSelected[i], filters: $scope.filtersSelected, datefilter: $scope.datarange, selectedkpi: $scope.kpiSelected, subcategory: $scope.subcategorySelected,charttype:"pie"},
                success  : function(data) {
                seriesOptions[k] = {
                  id: seriesname.replace(/\s/g, ''),
                  name: seriesname,
                  data: JSON.parse(data),
              };
                  success++;
                  if((success == $scope.valueSelected.length) ) {
                    $scope.rateData = seriesOptions;
                    $scope.$apply();
                  }
                }
            });
          })(j,$scope.valueSelected[i]);
          j++;
      }
    }
    var selectedStateString = getSelectedValues($scope.searchSelectStateModel);
    var subcat = getSubCategoryForAverages($scope.subcategorySelected);
    var kpivalue = "";
    if($scope.hours) {
			kpivalue = 'hours';
		}
		else if($scope.spending) {
			kpivalue = 'net_amt';
		}
		else if($scope.anomalies) {
			kpivalue = 'anomaly_description';
		}
    else if($scope.rate){
      kpivalue = 'rate';
    }
    getAveragesList(kpivalue, selectedStateString, subcat);
	};
  init();
}]);

var AnalysisDataService = angular.module('AnalysisDataService', [])
    .service('analysisService', function ($http,$q) {
    return({
          getAnalysisData: getAnalysisData,
          getMatterList: getMatterList,
          getFullNameList: getFullNameList,
          getAveragesData:getAveragesData,
          getExpenseOrTaskCodeList:getExpenseOrTaskCodeList,
          getPlantiffCounsilData:getPlantiffCounsilData,
          getAnalysisCharts:getAnalysisCharts,
          getMatterChart:getMatterChart

    });

    function getAnalysisCharts(serviceUrlWithParams) {
    var request = $http({
              method: "post",
              url: serviceUrlWithParams
              // params: {
              //           params: paramsA,
              //           category: categoryA,
              //           subcategory: subcategoryA,
              //   }
            });
          return(request.then( handleSuccess, handleError ) );
      }

      // function getAnalysisCharts(categoryA,categoryvalueA,filtersA,datefilterA,selectedkpiA,subcategoryA,charttypeA) {
      // var request = $http({
      //           method: "post",
      //           url: "/AppBuilder/endpoint/getChartsJSON",
      //           params: {
      //                     category: categoryA,
      //                     categoryvalue: categoryvalueA,
      //                     filters: filtersA,
      //                     datefilter: datefilterA,
      //                     selectedkpi: selectedkpiA,
      //                     subcategory: subcategoryA,
      //                     charttype:charttypeA
      //           }
      //         });
      //       return(request.then( handleSuccess, handleError ) );
      //   }
      //
      function getMatterChart(matternameA) {
      var request = $http({
                method: "post",
                url: "/AppBuilder/endpoint/getMatterChart",
                params: {
                          mattername: matternameA
                }
              });
            return(request.then( handleSuccess, handleError ) );
        }
      function getFullNameList(filtervalue,findfieldname) {
      var request = $http({
                method: "post",
                url: "/AppBuilder/endpoint/getAnalysisTimekeeperDropdownValues",
                params: {
                          FilterValue: filtervalue
                }
              });
            return(request.then( handleSuccess, handleError ) );
        }

    function getAnalysisData(filtervalue,findfieldname,datefilter) {
      var request = $http({
                method: "post",
                url: "/AppBuilder/endpoint/getAnalysisDropdownValues",
                params: {
                          FilterValue: filtervalue,
                          FindFieldName: findfieldname,
                          datefilter: datefilter
                      }
              });
            return(request.then( handleSuccess, handleError ) );
        }

        function getMatterList(selecteditem,datefilter) {
          var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/getAnalysisMatterDropdownValues",
                    params: {
                              FilterValue: selecteditem,
                              datefilter: datefilter

                          }
                  });
                return(request.then( handleSuccess, handleError ) );
            }
            function getPlantiffCounsilData(selecteditem,datefilter) {
              var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/getAnalysisPlaintiffDropdownValues",
                        params: {
                                  FilterValue: selecteditem,
                                  datefilter: datefilter

                              }
                      });
                    return(request.then( handleSuccess, handleError ) );
                }
            function getExpenseOrTaskCodeList(selecteditem,datefilter,findfieldname) {
              var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/getAnalysisExpenseTaskDropdownValues",
                        params: {
                                  FilterValue: selecteditem,
                                  datefilter: datefilter,
                                  FindFieldName: findfieldname
                              }
                      });
                    return(request.then( handleSuccess, handleError ) );
                }
            function getAveragesData(filterkpi,filterstate,filtersubcategory) {
               var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/getAverages",
                        params: {
                                  kpi: filterkpi,
                                  state: filterstate,
                                  subcategory: filtersubcategory
                              }
                      });
                    return(request.then( handleSuccess, handleError ) );
                }
            function handleError( response ) {
                if (
                    ! angular.isObject( response.data ) ||
                    ! response.data.message
                    ) {
                    return( $q.reject( "An unknown error occurred." ) );
                }
                return( $q.reject( response.data.message ) );
            }
            function handleSuccess( response ) {
              return( response.data);
            }
  });

// PRINT AREA FUNCTION
function printTab(tabName) {

    var pdf = new jsPDF("l","pt","legal");
        combinedElement = document.body;
  		  if(tabName)
        {
          combinedElement = document.getElementById("printPlaceHolder");
          combinedElement.innerHTML =  document.getElementById("header").innerHTML +  document.getElementById(tabName).outerHTML; //+ document.getElementById("kpiPieColumnChart").outerHTML;
          //console.log(combinedElement.innerHTML);
          combinedElement.style.display = "";
          combinedElement.parentElement.style.marginTop="2000px"
         	//convertHtmlElement = document.getElementById(tabName);
        }

        html2pdf(combinedElement, pdf, function(pdf) {
            combinedElement.style.display = "none";
            combinedElement.parentElement.style.marginTop="0px";
            combinedElement.innerHTML = "";
              //pdf.addPage();
              //html2pdf(document.getElementById("kpiPieColumnChart"), pdf, function(pdf) {
               // pdf.addPage();
               // html2pdf(document.getElementById("kpiLineChart"), pdf, function(pdf) {
                       pdf.save("Analysis-" + (new Date().getTime())+ ".pdf");
                //});
              //});
         }, {"width":1600}
        );
}

</script>
