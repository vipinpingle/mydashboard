(function() {
    console.clear();
'use strict';
angular.module('wexdashboard', ['ui.tree', 'ui.bootstrap','wexdashboard.directives','wexdashboard.services'])

.controller('firmdrilldowncontroller', function($scope,$timeout,HierarchyNodeService) {

    //console.log(HierarchyNodeService);
    var dList = [];

    currentYear = moment().format("YYYY");
    for( i = 0 ; i < 3; i++)
    {
            var item = new Object();
            item.id = (currentYear - i)+"-01-01" + "::" + moment((currentYear - i)+"-01-01").endOf("year").format("YYYY-MM-DD");
            item.title = (currentYear - i);
            item.items = [];
            for(j = 1 ; j < 12; j+=3)
            {
                    qDateStr = (currentYear - i)+"-0"+j +"-01";
                    if(moment().fquarter(1).start > moment(qDateStr).fquarter(1).start)
                    {
                            var qItem = new Object();
                            qItem.id = moment(qDateStr).fquarter(1).start +"::"+ moment(qDateStr).fquarter(1).end;
                            qItem.title = moment(qDateStr).fquarter(1).toString();
                            qItem.items = [];
                            for(k = j ; k < j+3; k++)
                            {
                                    var mItem = new Object();
                                    startDateStr = "";
                                    if(k < 10)
                                    {
                                            startDateStr = (currentYear - i)+"-0"+k +"-01";
                                        }
                                        else
                                        {
                                                startDateStr = (currentYear - i)+ "-" + k +"-01";
                                        }
                                        console.log(startDateStr);
                                        mItem.id = moment(startDateStr).format("YYYY-MM-DD") +"::"+ moment(startDateStr).endOf("month").format("YYYY-MM-DD");
                                        mItem.title = moment(startDateStr).format("MMM");
                                    qItem.items.push(mItem)
                            }
                            item.items.push(qItem)
                    }
            }
            dList.push(item);
    }
    console.log(JSON.stringify(dList));
    $scope.baseList = dList;
    $scope.list = $scope.baseList;

})
.directive('indeterminateCheckbox',function(HierarchyNodeService) {
    return {
        restrict:'A',
        scope: {
          node:'='
        },
        link: function(scope, element, attr) {

            scope.$watch('node',function(nv) {

                var flattenedTree = HierarchyNodeService.getAllChildren(scope.node,[]);
                flattenedTree = flattenedTree.map(function(n){ return n.isSelected });
                var initalLength = flattenedTree.length;
                var compactedTree = _.compact(flattenedTree);

                var r = compactedTree.length > 0 && compactedTree.length < flattenedTree.length;
                element.prop('indeterminate', r);

            },true);

        }
    }
})

})();
