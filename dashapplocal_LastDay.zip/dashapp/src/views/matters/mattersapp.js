
<script src="/AppBuilder/dashapp/src/lib/html2pdf.js"></script>
<script type="text/javascript" src="/AppBuilder/dashapp/src/lib/angular-sanitize.min.js"></script>
<script type="text/javascript" src="/AppBuilder/dashapp/dist/scripts/ng-csv.min.js"></script>
<script type="text/javascript">

// SAVE AREA to PDF
var doc = new jsPDF("l","mm","a4");
var specialElementHandlers = {
    '#editor': function (element, renderer) {
        return true;
    }
};
function saveArea(areaName) {

    var saveContents = "";
    var l = 0;
    if(document.getElementById("printStyles"))
    {
      saveContents = document.getElementById("printStyles").innerHTML;
    }
    styleTags = document.getElementsByTagName("style");
    for(l=0; l < styleTags.length; l++)
    {

      saveContents = saveContents + styleTags[l].outerHTML;
    }
    saveContents = saveContents + document.getElementById(areaName).innerHTML
    console.log('save button was clicked');
    doc.fromHTML(saveContents, 23, 15, {
            'elementHandlers': specialElementHandlers
    });
    doc.save('matters-overview.pdf');
}
  var app = angular.module('wexdashboard', ['angularUtils.directives.dirPagination','MatterDataService','ui.bootstrap','ui.tree','wexdashboard.directives','wexdashboard.services','angularjs-dropdown-multiselect','ngCsv']);
  app.controller('MatterController',['$scope','$q','$window','$http','matterService','sharedParameterService', function($scope,$q,$window,$http,matterService, sharedParameterService) {
  $scope.exportDataUrl = $window.exportWebServiceUrl + "/GetAnalysisData";
  $scope.timekeeperkey = "timekeepername:descending";
  $scope.anomalykey = "anomaly_description:descending";
  $scope.sharedParameterService = sharedParameterService;
  $scope.currentPage = 1;
  $scope.numberOfResults = "10";
  $scope.pageNumber = "1";
  $scope.pageNumI = "1";
  $scope.searchItem = "";
  $scope.sortByField = "matter_open_date" //"matterdate";
  $scope.sortByFieldInvoice_Date = "invoice_date";
  $scope.sortByFieldLabel = "Date";
  $scope.totalPageCount = "";
  $scope.totalPageLineItemCount = "";
  $scope.matterList = "";
//  $scope.show_matterDetailView = false;
  $scope.matterLineItems = [];
  $scope.recentInvoiceList = [];
  $scope.staffLevelList = [];
  $scope.sortType = 'id';
  $scope.sortReverse = false;
  $scope.searchItem = '';
  $scope.selectedMatterIdLineItem = "";
  $scope.sortLineItemByType = "itemnumber";
  $scope.filterByMatterNumber = "";
  $scope.highlighted="";
  $scope.searchAnomalies = "";
  $scope.matterAnomalies = [];
  $scope.rowOpen = [];
  $scope.invoiceLineItemsAnomalies = [];
  $scope.mattersortList = [
      {name : "Date", value : "matter_open_date:descending"},
      {name : "Matter Name", value : "matter_name"},
      {name : "Matter Number", value : "matter_number"},
      {name : "Billing", value : "sum:descending"}
  ];
  $scope.invoicesViewList = [{id:"invoice_date", title:"Date",selected:true}, {id:"invoice_total", title:"Spend"}]

  $scope.matterPhasesViewList = [{id:"matter_total_hours", title:"Hours"}, {id:"spend", title:"Spend", selected:true}]

  $scope.searchSelectAllSettings = { enableSearch: true, showCheckAll: false, showUncheckAll:false,keyboardControls: true,
    styleActive: true,scrollable: true,scrollableHeight: '150px',selectionLimit:1,smartButtonMaxItems: 1,closeOnSelect:true,};
  $scope.searchSelectStaffModel = [];
  $scope.staffChangeEventListeners = {
      onSelectionChanged: onStaffSelectionChanged
  };
  $scope.showSidebar = true;

  // Data for matter phases
  $scope.matterPhaseCategories =  ['L100 Case Assess., Dev, Admin', 'L200 Pre-trial Pleadings & Motions', 'L300 Discovery', 'L400 Trial Prep & Trial', 'L500 Appeal',  'L600 e-Discovery', 'A100 Activities','E100 Expenses'];
  $scope.matterPhaseCatCodes =  ['', 'E100','A100', 'L600', 'L500', 'L400','L300', 'L200','L100'];
  $scope.monthCategories =  ['January', 'February','March', 'April', 'May','June','July','August','September', 'October','November', 'December'];

  $scope.matterPhases = [{
        name: 'Actual Spending',
        data: [{y:0, color:'#029fdb'}, {y:0, color:'#be00f3'}, {y:0, color:'#92cd0d'}, {y:0, color:'#e9b918'}, {y:0, color:'#c31820'},{y:0, color:'#6f5df7'}, {y:0, color:'#f25214'}, {y:0, color:'#fff800'}],
        stack: 'actual_spending'
    },
    {
        name: 'Budget',
        data: [0, 0, 0, 0, 0, 0, 0,0],
        stack: 'budget',
        color: '#adadad'
    }];

    $scope.matterProgressByPhase = [{
        name: 'L100',
        color: '#029fdb',
        data: [] },{
        name: 'L200',
        color: '#be00f3',
        data: [] },{
        name: 'L300',
        color: '#92cd0d',
        data: [] },{
        name: 'L400',
        color : '#e9b918',
        data: [] },{
        name: 'L500',
        color : '#c31820',
        data: [] },{
        name: 'L600',
        color : '#6f5df7',
        data: [] },{
        name: 'A100',
        color : '#f25214',
        data: [] },{
        name: 'E100',
        color : '#fff800',
        data: [] }];

    $scope.matterSpending = [{
        name: 'Actual',
        color: '#c31820',
        data: [3934, 2503, 3177, 1658, null, null, null, null]
    }, {
        name: 'Projected',
        color: '#15a9ff',
        data: [null, null, null, 1658, 4031, 4931, 6133, 7175]
    }, {
        name: 'Maximum Projected',
        color: '#adadad',
        data: [null, null, null, 1658, 3031, 4031, 5031, 6031],
        dashStyle: 'dot'
    }, {
        name: 'Minimum Projected',
        color: '#adadad',
        data: [null, null, null, 1658, 5031, 6031, 7031, 8031],
        dashStyle: 'dot'
    }];

//  $scope.mattersExportAnomaliesFields = ["anomaly_group_id","invoice_anomaly_id","item_date","matter_number","matter_name","invoice_id","invoice_line_item_id","firm_name","full_name",
//  "line_item_anomaly_id","anomaly_type","anomaly_description","staff_level","state","county","court_type","task_id",
//  "rate","cat_code","judge","phase","hours","matter_id","task_code","matter_open_date","expense","supervising_attorney","net_amt","dispute_type",
//  "matter_type","matter_status","matter_close_date","team_lead","invoice_date","trial_date"];

$scope.mattersExportAnomaliesFields = ["invoice_anomaly_id","anomaly_group_id","item_date","anomaly_type","anomaly_description","invoice_id","invoice_date","firm_name","full_name","rate","cat_code","net_amt","matter_number","matter_name",
"staff_level","state","county","court_type","judge","phase","hours","task_code","matter_open_date","expense","expense_net_amount","supervising_attorney","dispute_type","matter_type","matter_sub_type","matter_status","matter_close_date","team_lead","trial_date","disposition","disposition_date"];
  function getUrlRequestParameters()
  {
     decodedUrl = decodeURI(location.href);
     url = decodedUrl.split("?");
     retMap = {};
     if(url.length > 1)
     {
         prevParamName = "";
         reqParamArray = url[1].split("&");
         for (i in reqParamArray)
         {
           reqParam = reqParamArray[i].split("=");
           if(reqParam.length == 2)
           {
             retMap[reqParam[0]] = reqParam[1];
             prevParamName = reqParam[0];
           }
           else
           {
              retMap[prevParamName] = retMap[prevParamName] + "&" + reqParam[0];
           }
         }
     }
    return retMap;
  }

  $('#daterange').daterangepicker({
         ranges: {
           '2017': ['1/1/2017', '12/31/2017'],
		       '2016': ['1/1/2016', '12/31/2016'],
           '2015': ['1/1/2015', '12/31/2015'],
		       '2014': ['1/1/2014', '12/31/2014'],
           '2013': ['1/1/2013', '12/31/2013'],
           '2012': ['1/1/2012', '12/31/2012']
        }
   });

   $('#daterange').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
  //    console.log($(this).val());
  //    console.log($scope.sharedParameterService);
      $scope.sharedParameterService.setSharedParameter('datefilter', $(this).val());
      $scope.expand_date_filter = false;
       $scope.mldatefilter = picker.startDate.format('MM/DD/YYYY') + ' ' +  picker.endDate.format('MM/DD/YYYY');
      getMattersListData($scope.numberOfResults,$scope.pageNumber, $scope.searchItem,$scope.sortByField, $(this).val());

      $scope.$apply( function() {
//	console.log($scope);
	    });
    });

  function init() {

    var dList = getPeriodHierarchy();
    //console.log(JSON.stringify(dList));
    if(dList.length > 0)
    {
      $scope.selectedPageDateFilter = dList[0].title;
      $scope.expand_page_date_filter = false;
      $scope.sharedParameterService.setSharedParameter("datefilter",dList[0].id);
      $scope.datefilter = dList[0].id;
    }
    $scope.mldatefilter = "01/02/2012 12/31/2017"
    $scope.sharedParameterService.setSharedParameter("invoiceview","invoice_date:descending");
    $scope.selectedInvoiceView = "Date"
    $scope.matterPhaseView = "spend";
    $scope.selectedMatterPhasesView = "Spend"
    $scope.list = dList;
    urlparams = getUrlRequestParameters();
    if(urlparams["matter"])
    {
        $scope.searchItem  = urlparams["matter"];
        $scope.getSearchedData($scope.searchItem);
    }
    else
    {
       getMattersListData($scope.numberOfResults,$scope.pageNumber, $scope.searchItem,$scope.sortByField, $scope.sharedParameterService.getSharedParameter('datefilter'));
    }
  //  $scope.expand_staff_level_selection = false;
  }

  $scope.exportAnomaliesData = function(selectedTabName) {
    ///console.log("calling anomalies export");
     $scope.exportForMattersAnomaliesList = [];
     $scope.mattersLineItemAnomaliesDataArr = [];
     $scope.mattersAnomalyArr = [];
     $scope.exportFileName = "export-matter-anomalies-" + $scope.selectedMatternumber + ".csv";
     return $q.all([matterService.getMattersAnomaliesDataExport($scope.exportDataUrl,"V_ANALYSIS_ANOMALIES_METRICS_VIEW",$scope.selectedMatternumber,"","","item_date:ascending","anomalies"), matterService.getMattersAnomaliesDataExport($scope.exportDataUrl,"V_ANALYSIS_INVOICE_ANOMALIES_METRICS_VIEW",$scope.selectedMatternumber,"","","invoice_date:ascending","anomalies")])
       .then(
         function (data) {
           $scope.mattersLineItemAnomaliesDataArr = buildMattersLineItemAnomaliesDataFormatForExcel(data[0]);
           $scope.mattersAnomalyArr = buildMattersAnomaliesDataFormatForExcel(data[1]);
           if($scope.mattersLineItemAnomaliesDataArr !== undefined && $scope.mattersAnomalyArr !== undefined){
               $scope.exportForMattersAnomaliesList = $scope.mattersLineItemAnomaliesDataArr.concat($scope.mattersAnomalyArr);
             } else if($scope.mattersLineItemAnomaliesDataArr === undefined && $scope.mattersAnomalyArr !== undefined){
                $scope.exportForMattersAnomaliesList = $scope.mattersAnomalyArr;
             } else if($scope.mattersLineItemAnomaliesDataArr !== undefined && $scope.mattersAnomalyArr === undefined){
                $scope.exportForMattersAnomaliesList = $scope.mattersLineItemAnomaliesDataArr;
             } else {
               console.log("Both anomalies array are empty");
             }
           //  console.log( $scope.exportForMattersAnomaliesList);
           return $scope.exportForMattersAnomaliesList;
         },
         function (error) {
             console.log("Error while calling export for anomalies" + error);
         }
       );
   }

  // Format the data for excel.
  function buildMattersLineItemAnomaliesDataFormatForExcel(origData) {
    $scope.mattersLineItemAnomaliesDataArr = [];
    var anomaliesDataList = [];
    var dataArr = [];
    var tmp = "";
    if(origData.length > 0)
    {
      origData = origData.slice(0,-1);
    }
    for (var item in origData) {
     tmp = getFormattedDataAnomaliesRow(origData[item],"lineitem");
     dataArr.push(tmp);
    }
     var retVal = dataArr.map(function(each){
          return JSON.parse(each)
     });
     $scope.mattersLineItemAnomaliesDataArr = retVal.sort();
     return $scope.mattersLineItemAnomaliesDataArr;
  }

  function buildMattersAnomaliesDataFormatForExcel(origData) {
   $scope.mattersAnomalyArr = [];
   var anomaliesDataList = [];
   var dataArr = [];
   var tmp = "";
   if(origData.length > 0)
   {
     origData = origData.slice(0,-1);
   }
   for (var item in origData) {
    tmp = getFormattedDataAnomaliesRow(origData[item],"invoiceitem");
    dataArr.push(tmp);
   }
    var retVal = dataArr.map(function(each){
         return JSON.parse(each)
    });
   $scope.mattersAnomalyArr = retVal.sort();
   return $scope.mattersAnomalyArr;
  }

  function getFormattedDataAnomaliesRow(data,type) {
      var fmtDataArr = [];
      var tmp = "";
      var tmpFormat = "";
      angular.forEach(data, function(element, index) {
        tmp = "";
        if(index =="size" || index=="date_id" || index=="location_id" || index=="firm_id" || index=="matter_id" || index=="task_id" || index=="person_id" || index=="case_length_bucket" || index =="invoice_line_item_id" || index=="line_item_anomaly_id" || index=="disb_id"){
        }  else if(index == 'invoice_date' ||  index=="item_date" ||  index=="matter_open_date" ||  index=="matter_close_date" || index=="trial_date" || index == 'disposition_date'){
            element = element.slice(0, -11);
            tmp = '{"' + index + '":"' + element + '"}';
            fmtDataArr.push(tmp);
        } else {
          var cleanupChar = element.replace(/,/g, ' ');
              cleanupChar = element.replace(/["\"]/g, "'");
              tmp = '{"' + index + '":"' + cleanupChar + '"}';
              fmtDataArr.push(tmp);
         }
        });
       fmtDataArr.sort();
       var newTmp = "";
       var newTmpFormat = "";
       var mydatatmp = "";
       angular.forEach(fmtDataArr,function(value,key){
           mydatatmp = fmtDataArr.map(function(each){
           return JSON.parse(each)
         });
       });

      for (var item in mydatatmp) {
        for(var subitem in mydatatmp[item]){
          newTmp += '"' + subitem + '":"' + mydatatmp[item][subitem] + '",';
         }
        }
        if(type == "lineitem"){
        //  newTmp += '"invoice_date":"NA",';
          newTmp += '"invoice_anomaly_id":"NA",';
          newTmp += '"anomaly_type":"lineitem"';
      //    newTmp += '"trial_date":"NA"';
        }
        if(type == "invoiceitem"){
          newTmp += '"anomaly_group_id":"NA",';
          newTmp += '"item_date":"NA",';
          //newTmp += '"invoice_line_item_id":"NA",';
          newTmp += '"staff_level":"NA",';
          newTmp += '"phase":"NA",';
          newTmp += '"hours":"NA",';
          newTmp += '"task_code":"NA",';
          newTmp += '"expense":"NA",';
          newTmp += '"net_amt":"0",';
          newTmp += '"full_name":"NA",';
        //  newTmp += '"line_item_anomaly_id":"NA",';
          newTmp += '"rate":"0",';
          newTmp += '"anomaly_type":"invoice"';
        }
        newTmpFormat = "{" + newTmp + "}";
         return newTmpFormat;
    }

  function fillStaffList() {
   $scope.staffLevelList = [{id:'',label:"All"}];
   matterService.getFirmStaffServiceData($scope.selectedMatternumber)
        .then(
              function( mydata ) {
              for(var i in mydata) {
            //    console.log("fillStaffList i = " + i);
                $scope.staffLevelList.push(
                  {
                    id:i,
                    label: i
                  });
              };
		    });
    };

  function fillFirmList() {
   $scope.firmList = [{id:'',title:"All Firms"}];
   $scope.selectedFirmFilter = "All Firms";
   matterService.getMatterFirms($scope.selectedMatternumber)
        .then(
              function( mydata ) {
              for(var i in mydata) {
                $scope.firmList.push(
                  {
                    id:mydata[i].properties.firm_id[0],
                    title: mydata[i].properties.firm_name[0]
                  });
              };
		    });
    };

  function getMattersListData(numResults,pageNum,searchStr,sortByType, datefilter){
          if(!datefilter)
          {
            datefilter = "";
          }
    		  matterService.getMatterListServiceData(numResults,pageNum,searchStr,sortByType,datefilter)
                .then(
                  function( mydata ) {
    			             $scope.matterList = mydata;
                      if($scope.matterList.length > 0)
                       {
                          $scope.getMatterDetails($scope.matterList[0]);
                       }
                       $scope.totalPageCount = mydata[$scope.matterList.length-1].total;
  		    });
  };

  function onStaffSelectionChanged() {
    if($scope.searchSelectStaffModel.length >= 0) {
      //$scope.displaySelectedStaffValues = $scope.searchSelectStaffModel.map(function(el){return el.label}).join("||");
      tmpSelectedStaff = "";
      if($scope.searchSelectStaffModel[0] != undefined){
        tmpSelectedStaff = $scope.searchSelectStaffModel[0].id;
      }
      if (tmpSelectedStaff != '' )
      {
 $scope.sharedParameterService.setSharedParameter("staffLevelFilter","timekeeper_level>>"+tmpSelectedStaff);
      }else
      {
           $scope.sharedParameterService.setSharedParameter("staffLevelFilter","");
      }
    //    console.log("$scope.searchSelectStaffModel " + $scope.searchSelectStaffModel[0].label);
      }
  };

 $scope.updateGraphs = function(){

   $scope.matterBudget = "";
   $scope.matterTotalSpend = "";
   $scope.matterPeriodSpend = "";
   $scope.matterBlendedRate = "";
   $scope.matterCaseLength = "";
   $scope.matterSpending = "";

   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget1" , $scope.selectedFirmId)
        .then(
              function( mydata ) {
              $scope.matterBudget = mydata.budget;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget2" , $scope.selectedFirmId)
        .then(
              function( mydata ) {
              $scope.matterTotalSpend = mydata.totalmatterspent;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget3",  $scope.selectedFirmId)
        .then(
              function( mydata ) {
              $scope.matterPeriodSpend = mydata.matterperiodspend;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget4",  $scope.selectedFirmId)
        .then(
              function( mydata ) {
              $scope.matterBlendedRate = mydata.matterblendedrate;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget5",  $scope.selectedFirmId)
        .then(
              function( mydata ) {
              $scope.matterCaseLength = mydata.caselength;
    });
    matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget9", $scope.selectedFirmId)
        .then(
              function( mydata ) {
              $scope.percentOfBudget = mydata.percentspent;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget11", $scope.selectedFirmId)
        .then(
              function( mydata ) {
              $scope.yearlyBudget = mydata.yearlybudget;
              $scope.yearlyBudgetPercentSpent = mydata.yearlybudgetpercentspent;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter, $scope.matterPhaseView, "widget6", $scope.selectedFirmId)
        .then(
              function( mydata ) {
              phaseSpending = {"L100":0,"L200":0,"L300":0, "L400":0, "L500":0, "L600":0, "A100":0, "E100":0};
              phaseBudget = {"L100":0,"L200":0,"L300":0, "L400":0, "L500":0, "L600":0, "A100":0, "E100":0};
              keys = Object.keys(mydata);
              for(i in keys)
              {
                phaseSpending[keys[i]] = mydata[keys[i]].spend;
                phaseBudget[keys[i]] = mydata[keys[i]].budget;
              }

           matterPhaseLabel = 'Actual Spending'
           yAxisTitle = "Amount"
           if($scope.matterPhaseView === 'matter_total_hours')
           {
             matterPhaseLabel= 'Actual Hours';
             yAxisTitle = "Hours"
           }

              $scope.matterPhases = [{
        name: matterPhaseLabel,
        data: [{y:phaseSpending["L100"], color:'#029fdb'}, {y:phaseSpending["L200"], color:'#be00f3'}, {y:phaseSpending["L300"], color:'#92cd0d'}, {y:phaseSpending["L400"], color:'#e9b918'}, {y:phaseSpending["L500"], color:'#c31820'},{y:phaseSpending["L600"], color:'#6f5df7'}, {y:phaseSpending["A100"], color:'#f25214'}, {y:phaseSpending["E100"], color:'#fff800'}],
        stack: 'actual_hours',
        yAxisTitle : yAxisTitle
    },
    {
        name: 'Budget',
        data: [phaseBudget["L100"], phaseBudget["L200"], phaseBudget["L300"], phaseBudget["L400"], phaseBudget["L500"], phaseBudget["L600"], phaseBudget["A100"], phaseBudget["E100"]],
        stack: 'budget',
        color: '#adadad'
    }];

		    });

    matterService.getMatterProgress($scope.selectedMatternumber, $scope.datefilter, $scope.sharedParameterService.getSharedParameter('firmFilter'))
        .then(
              function( mydata ) {
              $scope.matterProgressByPhase = [{
                  name: 'L100',
                  color:'#029fdb',
                  data: mydata['L100']},{
                  name: 'L200',
                  color:'#be00f3',
                  data: mydata['L200']},{
                  name: 'L300',
                  color: '#92cd0d',
                  data: mydata['L300']},{
                  name: 'L400',
                 color : '#e9b918',
                  data: mydata['L400']},{
                  name: 'L500',
                  color : '#c31820',
                  data: mydata['L500']},{
                  name: 'L600',
                  color : '#6f5df7',
                  data: mydata['L600']},{
                  name: 'A100',
                  color : '#f25214',
                  data: mydata['A100']},{
                  name: 'E100',
                  color : '#fff800',
                  data: mydata['E100']}];

    });

   function formatOptionsForTimeline(data){
        var seriesOptions = options.slice();
      var newOptions = [];
       for(var i = 0; i < seriesOptions.length; i++){
         var linkId = seriesOptions[i]["name"].replace(/\s/g, "");
         var newSeries = jQuery.extend(true, {}, seriesOptions[i]);
         newSeries["type"] = "line";
         newSeries["id"] = linkId;
         newOptions.push(newSeries);
         newOptions.push({
            name: seriesOptions[i]["name"] + " - Trend",
            linkedTo: linkId,
            showInLegend: true,
            enableMouseTracking: false,
            type: 'trendline',
            algorithm: 'linear'
         });
       }
      return newOptions;
    }

   matterService.getMatterSpending($scope.selectedMatternumber, $scope.datefilter, $scope.sharedParameterService.getSharedParameter('firmFilter'))
        .then(
              function( mydata ) {
              $scope.matterSpending = mydata;
//                console.log('the matter spending data ', mydata);
    });
   }

     //calling the next page data for matter list items
     $scope.getNextPageMatterData = function(pageNumber) {
        $scope.pageNumberLineitem = pageNumber;
        getMattersListData($scope.numberOfResults,pageNumber,$scope.searchItem,$scope.sortByField, $scope.sharedParameterService.getSharedParameter('datefilter'));
     }

    $scope.selectPeriod = function(selectedVal)
{
  if(selectedVal != '')
  {
    $scope.selectedPageDateFilter = selectedVal.split(":")[1];
    $scope.expand_page_date_filter = false;
    $scope.sharedParameterService.setSharedParameter("datefilter",selectedVal.split(":")[0]);
    $scope.datefilter = selectedVal.split(":")[0];
    $scope.show_DropDown = false;
    $scope.updateGraphs();
  }
}
    $scope.selectFirm = function(selectedVal)
    {
       if(selectedVal != '')
       {
         $scope.expand_firm_filter = false;
         $scope.selectedFirmFilter = selectedVal.split(":")[1];
         $scope.selectedFirmId = selectedVal.split(":")[0];
         if($scope.selectedFirmId != '')
         {
            $scope.sharedParameterService.setSharedParameter("firmFilter", "firm_id>>"+$scope.selectedFirmId);
            $scope.sharedParameterService.setSharedParameter("firmNameFilter", "firm_name>>"+$scope.selectedFirmFilter);
         }
         else
         {
            $scope.sharedParameterService.setSharedParameter("firmFilter","");
            $scope.sharedParameterService.setSharedParameter("firmNameFilter","");
         }
         $scope.updateGraphs();
         getMatterAnomaliesSummary($scope.selectedMatternumber,"",$scope.searchAnomalies,"widget1");
        getMatterTimekeeperAnomalies($scope.selectedMatternumber,"",$scope.searchAnomalies,"widget2", "Default");
        getMatterTimekeeperInvoiceAnomalies($scope.selectedMatternumber,"",$scope.searchAnomalies,"widget4","Default");
       }
    }

    $scope.selectInvoiceView = function(selectedVal)
    {
      if(selectedVal != '')
      {
        console.log(selectedVal);
        $scope.selectedInvoiceView = selectedVal.split(":")[1];
        $scope.expand_invoice_view_list = false;
        $scope.sharedParameterService.setSharedParameter("invoiceview",selectedVal.split(":")[0]+":descending");
      }

    }

    $scope.selectMatterPhaseView = function(selectedVal)
    {
      if(selectedVal != '')
      {
        console.log(selectedVal);
        $scope.selectedMatterPhasesView = selectedVal.split(":")[1];
        $scope.expand_phase_view_list = false;
        $scope.matterPhaseView = selectedVal.split(":")[0];

        matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter, $scope.matterPhaseView, "widget6", $scope.selectedFirmId)
        .then(
              function( mydata ) {
               phaseSpending = {"L100":0,"L200":0,"L300":0, "L400":0, "L500":0, "L600":0, "A100":0, "E100":0};
              phaseBudget = {"L100":0,"L200":0,"L300":0, "L400":0, "L500":0, "L600":0, "A100":0, "E100":0};
              keys = Object.keys(mydata);
              for(i in keys)
              {
                phaseSpending[keys[i]] = mydata[keys[i]].spend;
                phaseBudget[keys[i]] = mydata[keys[i]].budget;
              }

           matterPhaseLabel = 'Actual Spending'
           yAxisTitle = "Amount";
           if($scope.matterPhaseView === 'matter_total_hours')
           {
             matterPhaseLabel= 'Actual Hours';
             yAxisTitle = "Hours";
           }
              $scope.matterPhases = [{
        name: matterPhaseLabel,
        data: [{y:phaseSpending["L100"], color:'#029fdb'}, {y:phaseSpending["L200"], color:'#be00f3'}, {y:phaseSpending["L300"], color:'#92cd0d'}, {y:phaseSpending["L400"], color:'#e9b918'}, {y:phaseSpending["L500"], color:'#c31820'},{y:phaseSpending["L600"], color:'#6f5df7'}, {y:phaseSpending["A100"], color:'#f25214'}, {y:phaseSpending["E100"], color:'#fff800'} ],
        stack: 'actual_spending',
        yAxisTitle: yAxisTitle
    },
    {
        name: 'Budget',
        data: [phaseBudget["L100"], phaseBudget["L200"], phaseBudget["L300"], phaseBudget["L400"], phaseBudget["L500"], phaseBudget["L600"], phaseBudget["A100"], phaseBudget["E100"]],
        stack: 'budget',
        color: '#adadad'
    }];

		    });

      }

    }


    $scope.expandTimekeeper = function(event, params )
   {
    //   console.log("Fired on expand timekeeper : " + params[1].value + " :: " + params[0].value.name);
    //   console.log(params[0].value);
       if(!$scope.sharedParameterService.getSharedParameter("topTKMattersKpi")){
           $scope.sharedParameterService.setSharedParameter("topTKMattersSort","hours");
           $scope.selectedTKMFilter = "Hours"
       }
       $scope.sharedParameterService.setSharedParameter("selectedTKIndex", params[1].value);
       $scope.sharedParameterService.setSharedParameter("timekeeperName"+params[1].value, params[0].value.name);
       updateTimekeeperSummary(params[0].value.name, params[1].value)

   }

  function updateTimekeeperSummary(timekeeper, selectedIndex)
  {
    dateFilter = $scope.datefilter;
    matterNumber = $scope.selectedMatternumber;
    if(!$scope.timekeeperDetails)
    {
        $scope.timekeeperDetails = {};
    }
    if(!$scope.timekeeperDetails[selectedIndex])
    {
        $scope.timekeeperDetails[selectedIndex] = new Object();
    }
    matterService.getTimekeperData(matterNumber, timekeeper,  dateFilter, "widget1")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('AverageBillrate' + mydata.avgbillrate);
                       $scope.timekeeperDetails[selectedIndex].avgBillRate =  mydata.avgbillrate;
                     $scope.timekeeperDetails[selectedIndex].billing =  mydata.billing;
                     $scope.timekeeperDetails[selectedIndex].matterCount =  mydata.mattercount;
                      $scope.timekeeperDetails[selectedIndex].costPerMatter =  mydata.costpermatter;
                     $scope.timekeeperDetails[selectedIndex].avgAnomalies =  mydata.avganomalies;
                $scope.timekeeperDetails[selectedIndex].avgStateLevelRate = mydata.avgstatelevelrate;
           });

    matterService.getBillingActivity(matterNumber,timekeeper, dateFilter)
                 .then(
                    function( mydata ) {
                        $scope.billingHours = mydata;
          });

  }
     //calling the search for matter list
     $scope.getSearchedData = function(searchedString) {
        getMattersListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField,  $scope.sharedParameterService.getSharedParameter('datefilter'));
     }

     $scope.getTimekeeperSearchedData = function(searchTimekeeper){
         $scope.sharedParameterService.setSharedParameter("searchTimekeeper", searchTimekeeper);
     }
     //calling the search for matters list
     $scope.getMatterListSorted = function(sortByField, sortByFieldLabel) {
          $scope.sortByFieldLabel = sortByFieldLabel;
          sortByValue = sortByField.split(":");
          sortByFieldArr = $scope.sortByField.split(':');
          if(sortByFieldArr[0] == sortByValue[0])
          {
              if(sortByFieldArr[1] == 'descending')
              {
                 sortByValue[1] = 'ascending';
              }
              else
              {
                 sortByValue[1] = 'descending';
              }
          }
          else if (sortByValue.length == 1)
          {
            sortByValue.push("ascending");
          }

          $scope.sortByField = sortByValue[0]+":"+sortByValue[1];
          getMattersListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField, $scope.sharedParameterService.getSharedParameter('datefilter'));
        }

    $scope.getMatterDetails = function(item) {
        $scope.selectedState =  item.properties.state;
      //  commenting till we fix the firm_name in matter_lost
    //    $scope.selectedFirmname = item.properties.firm_name[0];
        $scope.selectedMattername = item.properties.matter_name[0];
        $scope.selectedMatternumber = item.properties.matter_number[0];
        $scope.highlighted="highlighted";
        $scope.searchTimekeeper = "";
        $scope.toShow='Summary';
        getMatterDetailsData($scope.selectedMatternumber);
        fillFirmList();
        $scope.selectedFirmId = "";
        $scope.sharedParameterService.setSharedParameter("selectedMatterNumberFilter","matter_number>>" +$scope.selectedMatternumber);
        $scope.sharedParameterService.setSharedParameter("searchTimekeeper", "");
        $scope.sharedParameterService.setSharedParameter("matterId", item.properties.matter_number[0]);
        $scope.sharedParameterService.setSharedParameter("staffLevelFilter","");
        $scope.sharedParameterService.setSharedParameter("firmFilter","");
        $scope.sharedParameterService.setSharedParameter("firmNameFilter","");
        fillStaffList();
        $scope.show_matterDetailView = true;
       $scope.primaryFirm  = "";
        matterService.getMatterServiceData($scope.selectedMatternumber, "","", "widget7", $scope.selectedFirmId)
        .then(
              function( mydata ) {
               // console.log("mydata=" + mydata.primary_firm);
                if(!mydata.primary_firm == "") {
                  $scope.primaryFirm = mydata.primary_firm;
                } else {
                //  console.log("itme.propertiesfirm_name " + item.firms);
                  $scope.primaryFirm = item.firms;

                }
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget8", $scope.selectedFirmId)
        .then(
              function( mydata ) {
              $scope.opposingFirm = mydata.opposing_firm;
    });


   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget10", $scope.selectedFirmId)
        .then(
              function( mydata ) {
              $scope.dormancyDays = mydata.dormancydays;
    });

        $scope.updateGraphs();
        getMatterAnomaliesSummary($scope.selectedMatternumber,"",$scope.searchAnomalies,"widget1");
        getMatterTimekeeperAnomalies($scope.selectedMatternumber,"",$scope.searchAnomalies,"widget2", "Default");
        getMatterTimekeeperInvoiceAnomalies($scope.selectedMatternumber,"",$scope.searchAnomalies,"widget4","Default");
    }

      function getRecentInvoices(selectedMatterNumber) {

        matterService.getRecentInvoicesServiceData($scope.numberOfResults,$scope.pageNumber,selectedMatterNumber,$scope.sortByFieldInvoice_Date)
               .then(
                 function( mydata ) {
                     $scope.recentInvoiceList = mydata;
              });
        };

    // Callback function to retrieve data for matterlineitem details.
     function getMatterDetailsData(matterNumber){
          matterService.getMatterDetailsServiceData(matterNumber)
                 .then(
                   function( mydata ) {
                       $scope.matterLineItems = mydata;
                       $scope.matterDetail = mydata[0];
                });
        };

        // Matter anomalies invoice lineitems for timekeeper
        $scope.getMatterAnomaliesInvoiceLineItems = function(matternumber,timekeepergroupid) {
          var filters = "";
          var widgetName = "widget3";
          filters = "matter_number>>" + matternumber + "&&anomaly_group_id>>" + timekeepergroupid;
          if($scope.selectedFirmId != '')
          {
            filters = filters +"&&firm_id>>"+$scope.selectedFirmId;
          }
          $scope.invoiceLineItemsAnomalies[timekeepergroupid] = [];
          $("#timekeeperrowdetail_spinner").removeClass("hide");
          matterService.getMatterAnomaliesSummaryData(filters,"",$scope.searchAnomalies,widgetName)
                .then(
                  function( mydata ) {
                    $scope.currentGroupId = timekeepergroupid;
                      $scope.invoiceLineItemsAnomalies[timekeepergroupid] = mydata;
                    $("#timekeeperrowdetail_spinner").addClass("hide");
                    });

            }

        $scope.getAnomalySearchedData = function(matternumber,searchAnomalies){
                $scope.sharedParameterService.setSharedParameter("searchAnomalies", searchAnomalies);
                getMatterAnomaliesSummary(matternumber,"",$scope.searchAnomalies,"widget1");
                getMatterTimekeeperAnomalies(matternumber,"",$scope.searchAnomalies,"widget2", "Default");
                getMatterTimekeeperInvoiceAnomalies(matternumber,"",$scope.searchAnomalies,"widget4","Default");
        }

        $scope.sort = function(keyname){
            //    console.log("$scope.sortOrder " + $scope.sortOrder);
                $scope.sortOrder = !$scope.sortOrder;
                $scope.timekeeperanomalieslist = sortByKeyOrder($scope.timekeeperanomalieslist,keyname,$scope.sortOrder);
                $scope.sortKey = keyname;
        }

        $scope.sortString = function(keyname){
          //console.log(JSON.stringify($scope.timekeeperanomalieslist ));
          var tmpArray = [];
          sortByValueA = keyname.split(":");
          //console.log("keyname = " + keyname);
          if(sortByValueA[0] === "timekeepername") {
              if(sortByValueA[1] === "descending") {
                  sortByValueA[1]  = 'ascending';
              } else {
                  sortByValueA[1]  = 'descending';
                }
                $scope.timekeeperkey = 'timekeepername:'+sortByValueA[1];
              //  console.log("$scope.timekeeperkey = " + $scope.timekeeperkey);
              } else if(sortByValueA[0] === "anomaly_description") {
                  if(sortByValueA[1] === "descending") {
                      sortByValueA[1]  = 'ascending';
                  } else {
                      sortByValueA[1]  = 'descending';
                    }
                    $scope.anomalykey = 'anomaly_description:'+sortByValueA[1];
                    //console.log("$scope.anomalykey = " + $scope.anomalykey);
                  }
                $scope.sortOrderStr = !$scope.sortOrderStr;
                tmpArray = sortArrOfObjectsByParam($scope.timekeeperanomalieslist,sortByValueA[0],sortByValueA[1]);
                $scope.timekeeperanomalieslist = [];
                $scope.timekeeperanomalieslist = tmpArray;
                $scope.sortKey = sortByValueA[0];
        }

        $scope.sortByDetail = function(keyname, groupId){
                $scope.sortKeyDetail = keyname;
                $scope.reverseInvDetail = !$scope.reverseInvDetail;
                sortByKey($scope.invoiceLineItemsAnomalies[groupId],keyname);
        }
        $scope.sortInv = function(keyname){
                $scope.sortKeyInv = keyname;
                $scope.reverseInv = !$scope.reverseInv;
                sortByKey($scope.timekeeperinvoiceanomalieslist,keyname);
        }

        function sortArrOfObjectsByParam(arrToSort, strObjParamToSortBy, sortAscending) {
        //  console.log("params to sort" + strObjParamToSortBy + " order = " + sortAscending);
          if(sortAscending == undefined) sortAscending = 'ascending';  // default to true
        //  console.log(sortAscending);
          if(sortAscending === 'ascending') {
            arrToSort.sort(function (a, b) {
              if(a[strObjParamToSortBy] && isNaN(a[strObjParamToSortBy])) {
                return a[strObjParamToSortBy].localeCompare(b[strObjParamToSortBy]);
              }else if(!isNaN(a[strObjParamToSortBy])) {
                return a[strObjParamToSortBy] - b[strObjParamToSortBy];
              } else {
                return 1;
              }
            });
        }
        else {
        //  console.log("in else loop" + sortAscending);
            arrToSort.sort(function (a, b) {
              if(b[strObjParamToSortBy] && isNaN(b[strObjParamToSortBy])) {
                return b[strObjParamToSortBy].localeCompare(a[strObjParamToSortBy]);
              } else if(!isNaN(b[strObjParamToSortBy])){
                return b[strObjParamToSortBy] - a[strObjParamToSortBy];
              }else {
                return 1;
              }
            });
      }
    //  console.log(arrToSort);
      return arrToSort;
    }


        function sortByKeyOrder(array,key,type) {
                //console.log("sortByKeyOrder key = " + key + " type = " + type);
                return array.sort(function(a, b) {
                      var x = a[key]; var y = b[key];
                      if (!type) {
                          return (x-y);
                      } else {
                          return (y-x);
                      }
                  });

        }
        function sortByKey(array, key) {
                return array.sort(function(a, b) {
                var x = a[key]; var y = b[key];
                return ((x < y) ? -1 : ((x > y) ? 1 : 0));
              });
        }

      $scope.setCurrentRow = function(index){
            for (i = 0; i < $scope.rowOpen.length; i++) {
           }
        $scope.rowOpen[index] = true
      }
      function getMatterAnomaliesSummary(matterId,datefilter,searchString,widgetName){
        var filters = "";
        if(!matterId){
        } else {
          filters = "matter_number>>" + matterId;
        }
        if($scope.selectedFirmId != '')
        {
          filters = filters +"&&firm_id>>"+$scope.selectedFirmId;
        }
        matterService.getMatterAnomaliesSummaryData(filters,datefilter,searchString,widgetName)
              .then(
                function( mydata ) {
                    $scope.matterAnomalies = mydata;
                  });
        }

        function getMatterTimekeeperAnomalies(matterId,datefilter,searchString,widgetName,sortType){
          var filters = "";
          filters = "matter_number>>" + matterId;
          var index = 0;
          if($scope.selectedFirmId != '')
          {
            filters = filters +"&&firm_id>>"+$scope.selectedFirmId;
          }
          $("#timekeeperrow_spinner").removeClass("hide");
          $scope.timekeeperanomalieslist = [];
          matterService.getMatterAnomaliesSummaryData(filters,datefilter,searchString,widgetName)
                .then(
                  function( mydata ) {
                       $scope.timekeeperanomalieslist = formatTimeekeeperList(mydata);//mydata.slice(0,-1);
                       $scope.currentPage = 1;
                       //$scope.sortKey = "counter";
                        //$scope.sortOrder = true;
                      $("#timekeeperrow_spinner").addClass("hide");
                     });
            }

          // format timekeeper list to add the counter
          function formatTimeekeeperList(mydata) {
                var newTimekeeperArr = [];
                var i = 1;
                for (var item in mydata) {
                	 var newTmpFormat = "";
                    tmp = getFormattedTimekeeperRow(mydata[item]);
                		tmp += '"counter"' + ':"' + i +	 '"';
                    newTmpFormat = "{" + tmp + "}";
                    newTimekeeperArr.push(newTmpFormat);
                    i = i + 1;
                   }
                		var retTimekeeperList = newTimekeeperArr.map(function(each){
                         return JSON.parse(each)
                    });
                // console.log(retTimekeeperList);
                	return retTimekeeperList;
                }

                function getFormattedTimekeeperRow(datarecord) {
                	 var newTmp = "";
                   for (var item in datarecord) {
                      newTmp += '"' + item + '":"' + datarecord[item]	+	 '",';
                   }
                	 return newTmp;
                }

          // function to retrieve timekeeper anomalies as invoice level and link it to invoice page.
          function getMatterTimekeeperInvoiceAnomalies(matterId,datefilter,searchString,widgetName,sortType){
            var filters = "";
            var sortType = "";
            filters = "matter_number>>" + matterId;
            if($scope.selectedFirmId != '')
            {
              filters = filters +"&&firm_id>>"+$scope.selectedFirmId;
            }
            $scope.timekeeperinvoiceanomalieslist = [];
            $("#timekeeperrowlistinvoice_spinner").removeClass("hide");
            matterService.getMatterAnomaliesSummaryData(filters,datefilter,searchString,widgetName)
                  .then(
                    function( mydata ) {
                        $scope.timekeeperinvoiceanomalieslist = mydata;
                        $("#timekeeperrowlistinvoice_spinner").addClass("hide");
                      });
            }

    init();
}]);

//DataService containing all the data calls from backend.

	var MatterDataService = angular.module('MatterDataService', [])
      .service('matterService', function ($http,$q) {
      return({
            getMatterListServiceData: getMatterListServiceData,
            //getMatterLineItemsServiceData: getMatterLineItemsServiceData
            getMatterDetailsServiceData:getMatterDetailsServiceData,
            getRecentInvoicesServiceData:getRecentInvoicesServiceData,
            getFirmStaffServiceData : getFirmStaffServiceData,
            getMatterSpendingByPhase : getMatterSpendingByPhase,
            getMatterServiceData  : getMatterServiceData,
            getMatterSpending : getMatterSpending,
            getTimekeperData : getTimekeperData,
            getBillingActivity : getBillingActivity,
            getMatterAnomaliesSummaryData:getMatterAnomaliesSummaryData,
            getMatterProgress : getMatterProgress,
            getMatterFirms : getMatterFirms,
            getMattersAnomaliesDataExport:getMattersAnomaliesDataExport
      });

      // start call to get matter list service data
      function  getMatterListServiceData(numResultsS,pageNumS,searchStrS,sortByTypeS, datefilterS) {
       var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/getMatterList",
      			        params: {
                              noofresults: numResultsS,
                              pagenumber: pageNumS,
                              searchstring: searchStrS,
                              sortbyfield: sortByTypeS,
                              datefilter : datefilterS
      				        }
              });
            return(request.then( handleSuccess, handleError ) );
      		}

        // start call to get matter details service data
        function  getMatterDetailsServiceData(matternumberL) {

        var request = $http({
                      method: "post",
                      url: "/AppBuilder/endpoint/getMatterDetailSummary",
                      params: {
                                matternumber: matternumberL
                        }
                });
              return(request.then( handleSuccess, handleError ) );
            }

            // start call to get recent invoices list for the matter data
            function  getRecentInvoicesServiceData(numResultsS,pageNumS,searchStrS,sortByTypeS) {
             var request = $http({
                          method: "post",
                          url: "/AppBuilder/endpoint/getInvoiceList",
            			        params: {
                                    noofresults: numResultsS,
                                    pagenumber: pageNumS,
                                    searchstring: searchStrS,
                                    sortbyfield: sortByTypeS
            				        }
                    });
                  return(request.then( handleSuccess, handleError ) );
            		}

                function getFirmStaffServiceData(matternumber) {
                 var request = $http({
                              method: "post",
                              url: "/AppBuilder/endpoint/getAnalysisDropdownValues",
                			        params: {
                                        FindFieldName: "staff_level",
                                        FilterValue: "matter_number>>"+matternumber,
                                        datefilter: ""
                				        }
                        });
                      return(request.then( handleSuccess, handleError ) );
                		}
              // Get the matter's spending by phase
              function getMatterSpendingByPhase(matternumber, datafilterL, firmFileterL) {
                 var request = $http({
                              method: "post",
                              url: "/AppBuilder/endpoint/analysisjsonendpoint",
                			        params: {
                                        excludeothers: "Y",
                                        filters: "",
                                        noofresults : 10,
                                        selectedkpi : "net_amt",
                                        subcategory : "phase",
                                        charttype : "pie",
                                        category : "matter_number",
                                        categoryvalue : matternumber,
                                        datefilter : datafilterL
                				        }
                        });
                      return(request.then( handleSuccess, handleError ) );
                		}
             // start call to get firm list service data
          function  getMatterServiceData(matterNumberL, dateFileterL, kpiL, widgetNameL, firmIdL) {

            console.log("Passing parameters in getMatterServiceData " + "matterNumberL = " + matterNumberL + " dateFileterL = " + dateFileterL + " widgetNameL = "
            + widgetNameL);
           var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/getMatterDetails",
          			        params: {
                                  matter_number: matterNumberL,
                                  datefilter: dateFileterL,
                                  widgetname: widgetNameL,
                                  kpi : kpiL,
                                  firm_id: firmIdL
          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
          		}
            // Get the data for the matter spending graph
            function getMatterSpending(matterNumberL, dateFileterL, firmFilterL){
              var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/apoorvanalysischarts",
          			        params: {
                                  category : 'matter_number',
                                  categoryvalue: matterNumberL,
                                  datefilter: dateFileterL,
                                  charttype : 'timeline',
                                  filters : firmFilterL,
                                  selectedkpi : 'net_amt',
                                  subcategory : 'matter_number'

          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
            }

             // start call to get firm time keeper summary data
          function  getTimekeperData(matterIdL, timekeeperL , dateFileterL, widgetNameL) {

            console.log("Passing parameters in getTimekeperData " + "matterIdL = " + matterIdL + " timekeeperL = " + timekeeperL + " dateFileterL = " + dateFileterL + " widgetNameL = "
            + widgetNameL);
           var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/getMatterTimekeeperDetails",
          			        params: {
                                  matternumber: matterIdL,
                                  datefilter: dateFileterL,
                                  widgetname: widgetNameL,
                                  timekeeper : timekeeperL
          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
          		}

        // start call to get billing activity data
            function  getBillingActivity(matterIdL, timekeeperL, dateFilterL) {
             var request = $http({
                          method: "post",
                          url: "/AppBuilder/endpoint/apoorvanalysischarts",
                          params: {
                                    category: "full_name",
                                    categoryvalue : timekeeperL+"||",
                                    charttype:"timeline",
                                    datefilter : dateFilterL,
                                    filters : "matter_number>>"+matterIdL,
                                    selectedkpi : "hours",
                                    subcategory : "full_name"
                            }
                    });
                  return(request.then( handleSuccess, handleError ) );
                }

                // start call to get firm sumamry for total invoices, lineitem and total anomalies service data
                function  getMatterAnomaliesSummaryData(filtersL,datefilterS,searchStringL,widgetNameL) {
                 var request = $http({
                              method: "post",
                              url: "/AppBuilder/endpoint/FirmsAnomaliesSummary",
                              params: {
                                        datefilter: datefilterS,
                                        entity:"matter",
                                        filters:filtersL,
                                        searchfilter:searchStringL,
                                        widget: widgetNameL
                                }
                        });
                      return(request.then( handleSuccess, handleError ) );
                    }

              // Get the data for the matter progress graph
            function getMatterProgress(matterNumberL, dateFileterL, firmFilterL){
              var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/getMatterProgress",
          			        params: {
                                   matternumber: matterNumberL,
                                  datefilter: dateFileterL,
                                  filters : firmFilterL
          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
            }

            function getMatterFirms(matterNumberL, dateFileterL){
              var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/getMatterFirms",
          			        params: {
                                  matternumber: matterNumberL,
                                  datefilter: dateFileterL
          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
            }

            function getMattersAnomaliesDataExport(dataUrlL,entityL,matternumberIdL,searchStrL,dateFilterL,sortByTypeL,selectedtab) {
               var request = $http({
                            method: "GET",
                            url: dataUrlL,
                            params: {
                                    viewname:entityL,
                                    matternumber:matternumberIdL,
                                    searchstring: searchStrL,
                                    datefilter: dateFilterL,
                                    sortby: sortByTypeL,
                                    tabname:selectedtab
                              }
                      });
                    return(request.then( handleSuccess, handleError ) );
                  }

      // Common method to handle the request from the server
      function handleError( response ) {
          if (
              ! angular.isObject( response.data ) ||
              ! response.data.message
              ) {
              return( $q.reject( "An unknown error occurred." ) );
          }
          return( $q.reject( response.data.message ) );
      }
      function handleSuccess( response ) {
		  return( response.data);
      }
	   // end call to get data from service.
	  });

(function() {
    console.clear();
'use strict';
angular.module('wexdashboard')

.controller('firmdrilldowncontroller', function($scope,$timeout,HierarchyNodeService) {

    //console.log(HierarchyNodeService);
    var dList = [];

    currentYear = moment().format("YYYY");
    for( i = 0 ; i < 3; i++)
    {
            var item = new Object();
            item.id = (currentYear - i)+"-01-01" + "::" + moment((currentYear - i)+"-01-01").endOf("year").format("YYYY-MM-DD");
            item.title = (currentYear - i);
            item.items = [];
            for(j = 1 ; j < 12; j+=3)
            {
                    qDateStr = (currentYear - i)+"-0"+j +"-01";
                    if(moment().fquarter(1).start > moment(qDateStr).fquarter(1).start)
                    {
                            var qItem = new Object();
                            qItem.id = moment(qDateStr).fquarter(1).start +"::"+ moment(qDateStr).fquarter(1).end;
                            qItem.title = moment(qDateStr).fquarter(1).toString();
                            qItem.items = [];
                            for(k = j ; k < j+3; k++)
                            {
                                    var mItem = new Object();
                                    startDateStr = "";
                                    if(k < 10)
                                    {
                                            startDateStr = (currentYear - i)+"-0"+k +"-01";
                                        }
                                        else
                                        {
                                                startDateStr = (currentYear - i)+ "-" + k +"-01";
                                        }
                                        //console.log(startDateStr);
                                        mItem.id = moment(startDateStr).format("YYYY-MM-DD") +"::"+ moment(startDateStr).endOf("month").format("YYYY-MM-DD");
                                        mItem.title = moment(startDateStr).format("MMM");
                                    qItem.items.push(mItem)
                            }
                            item.items.push(qItem)
                    }
            }
            dList.push(item);
    }
    //console.log(JSON.stringify(dList));
    $scope.baseList = dList;
    $scope.list = $scope.baseList;
    $scope.setPeriod = function(selected)
    {
       //alert('selected'+selected);
    }



})
.directive('indeterminateCheckbox',function(HierarchyNodeService) {
    return {
        restrict:'A',
        scope: {
          node:'='
        },
        link: function(scope, element, attr) {

            scope.$watch('node',function(nv) {

                var flattenedTree = HierarchyNodeService.getAllChildren(scope.node,[]);
                flattenedTree = flattenedTree.map(function(n){ return n.isSelected });
                var initalLength = flattenedTree.length;
                var compactedTree = _.compact(flattenedTree);

                var r = compactedTree.length > 0 && compactedTree.length < flattenedTree.length;
                element.prop('indeterminate', r);

            },true);

        }
    }
})

})();

var DEFAULT_ID = '__default';
function getPeriodHierarchy()
{
     var dList = [{id:'', title:'All Time'}];

    currentYear = moment().format("YYYY");
    i = 0;
    while( currentYear - i >= 2012)
    {

            var item = new Object();
            item.id = "01/01/" + (currentYear - i) + "-" + moment((currentYear - i)+"-01-01").endOf("year").format("MM/DD/YYYY");
            item.title = (currentYear - i);
            item.items = [];
            for(j = 1 ; j < 12; j+=3)
            {
                    qDateStr = "0"+j +"/01/" + (currentYear - i);
                    if(moment().fquarter(1).start > moment(qDateStr).fquarter(1).start)
                    {
                            var qItem = new Object();
                            qItem.id = moment(moment(qDateStr).fquarter(1).start).format("MM/DD/YYYY") +"-"+ moment(moment(qDateStr).fquarter(1).end).format("MM/DD/YYYY");
                            qItem.title = moment(qDateStr).fquarter(1).toString();
                            qItem.displayTitle = qItem.title + " " + (currentYear - i);
                            qItem.items = [];
                            for(k = j ; k < j+3; k++)
                            {
                                    var mItem = new Object();
                                    startDateStr = "";
                                    if(k < 10)
                                    {
                                            startDateStr = "0"+k +"/01" +"/"  + (currentYear - i);
                                        }
                                        else
                                        {
                                                startDateStr =  k +"/01"+ "/" +(currentYear - i);
                                        }
                                        //console.log(startDateStr);
                                        mItem.id = moment(startDateStr).format("MM/DD/YYYY") +"-"+ moment(startDateStr).endOf("month").format("MM/DD/YYYY");
                                        mItem.title = moment(startDateStr).format("MMM");
                                        mItem.displayTitle = mItem.title + " " + (currentYear - i);
                                    qItem.items.push(mItem)
                            }
                            item.items.push(qItem)
                    }
            }
            dList.push(item);
            i++;
    }
    return dList;
}

// PRINT AREA FUNCTION
function printArea(areaName) {
    /*var printContents = document.getElementById(areaName).innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;*/
    var pdf = new jsPDF("l","pt","letter");
        /*var canvas = pdf.canvas;
        canvas.height = 792;
        canvas.width= 612;
        /*pdf.fromHTML(document.getElementById(areaName), 2, 2, {
          'elementHandlers': specialElementHandlers
          }, function(){
            var blob = pdf.output('blob');
            window.open(URL.createObjectURL(blob));
           }
        ); */
        convertHtmlElement = document.body;
  		  if(areaName)
        {
         	convertHtmlElement = document.getElementById(areaName);
        }
        html2pdf(convertHtmlElement, pdf, function(pdf) {
            //var blob = pdf.output('blob');
            //window.open(URL.createObjectURL(blob));
            pdf.save("Matters" + (new Date().getTime())+ ".pdf");
         }
        );
}

// PRINT AREA FUNCTION
function printTab(tabName) {

    var pdf = new jsPDF("l","pt","A3",true);

        combinedElement = document.body;
  		  if(tabName)
        {
          combinedElement = document.getElementById("printPlaceHolder");
          combinedElement.innerHTML =  document.getElementById("header").innerHTML +  document.getElementById(tabName).outerHTML;
          combinedElement.style.display = "";
          combinedElement.parentElement.style.marginTop="1000px";
          //combinedElement.parentElement.style.width="1150px";
         	//convertHtmlElement = document.getElementById(tabName);
      //    console.log("if(tabName)");
        }

        html2pdf(combinedElement, pdf, function(pdf) {
            combinedElement.style.display = "none";
            combinedElement.parentElement.style.marginTop="0px";
            combinedElement.innerHTML = "";
            if(tabName == "Summary")
            {
              pdf.addPage();
              var mattertablescustom = document.getElementById("matterTables");
              var matterspendinggraph = document.getElementById("matterSpedningGraph");
          //    matterspendinggraph.style.width = '75%';
              html2pdf(matterspendinggraph, pdf, function(pdf) {
                pdf.addPage();
                //html2pdf(document.getElementById("matterPhasesGraph"), pdf, function(pdf) {
                 // pdf.addPage();
                  html2pdf(document.getElementById("matterProgressGraph"), pdf, function(pdf) {
                     pdf.addPage();

                     mattertablescustom.style.width = '75%';
                     html2pdf(mattertablescustom, pdf, function(pdf) {
                       pdf.save("Matters-" + (new Date().getTime())+ ".pdf");
                       mattertablescustom.style.width = '100%';
                    },{width:1600});
                  },{width:1600});
              //    matterspendinggraph.style.width = '100%';
               // });
             },{width:1600});
            // });

            }
            else{
              pdf.save("Matters-"+ tabName+"-" + (new Date().getTime())+ ".pdf");
            }
         },{width:1600}
        );
}

var doc = new jsPDF("l","mm","a4");
var specialElementHandlers = {
    '#container': function (element, renderer) {
        return true;
    }
};

/*$('#matters-pdf').click(function () {
    doc.fromHTML($('.mattersSummary').html(), 15, 15, {
        'width': 170,
            'elementHandlers': specialElementHandlers
    });
    doc.save('matters-overview.pdf');
});*/

</script>
