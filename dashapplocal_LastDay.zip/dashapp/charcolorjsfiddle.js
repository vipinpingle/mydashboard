Highcharts.setOptions({
			colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D']
		});
var rawdata = [
			{"name":"Cantrell, Dennis","firm_name":"Cantrell, Strenski &amp; Mehringer, LLP","staff_level":"Partner","data": [11212.5, 0]},
			{"name":"Mundrick, Keith D.","firm_name":"Cantrell, Strenski &amp; Mehringer, LLP","staff_level":"Associate","data": [13538.0, 0]},
			{"name":"Alexovich, Joanne","firm_name":"Cantrell, Strenski &amp; Mehringer, LLP","staff_level":"Paralegal","data": [20000.0, 0]},
			{"name":"Drummy, John","firm_name":"Kightlinger &amp; Gray","staff_level":"Partner","data": [0, 30695.0]},
			{"name":"Spurgeon, J. Todd","firm_name":"Kightlinger &amp; Gray","staff_level":"Partner","data": [0, 15020.0]},
			{"name":"Spur, J. Todd","firm_name":"Kightlinger &amp; Gray","staff_level":"Partner","data": [0, 35020.0]}];
// select this unique values based on category selected.
var myFinalDataSeries = [];
var uniqueNames = [];
for(i = 0; i< rawdata.length; i++){
    if(uniqueNames.indexOf(rawdata[i].firm_name) === -1){
        uniqueNames.push(rawdata[i].firm_name);
    }
}

function filterMyData(firm_name) {
var filterData = [];
var colorIndex = 0;
for(i = 0; i< rawdata.length; i++){
    if(rawdata[i].firm_name === firm_name){
		   var newItem = rawdata[i].data;
       var temp = [];
      	newItem.forEach(function(item,index) {
        if(item === 0){
        } else {
          temp.push({"x":parseInt(index), "y":item});
        }
          rawdata[i].data = temp;
					colorIndex = colorIndex + 1;
          rawdata[i].color = Highcharts.getOptions().colors[colorIndex];
        });
    		filterData.push(rawdata[i]);
    }
	}
		var sortedFilterData = filterData.sort(function(a,b) {
		 		return b.data[0].y-a.data[0].y;
		 });
		return sortedFilterData;
	}
	for(j = 0; j<uniqueNames.length; j++){
	    var tempSeries;
				tempSeries = filterMyData(uniqueNames[j]);
				myFinalDataSeries.push(tempSeries)
	};
		var retVal = [];
		angular.forEach(myFinalDataSeries, function(element, index) {
		                  angular.forEach(element, function(el, index) {
		                  retVal.push(el);
		                 });
		             });


//console.log(JSON.stringify(retVal));
var customdata =[{"name":"Cantrell, Dennis","firm_name":"Cantrell, Strenski &amp; Mehringer, LLP","staff_level":"Partner","data":[11212.5],"color":"#be00f3","stack":"Cantrell, Strenski &amp; Mehringer, LLP"},
{"name":"Mundrick, Keith D.","firm_name":"Cantrell, Strenski &amp; Mehringer, LLP","staff_level":"Associate","data":[2538],"color":"#be00f3","stack":"Cantrell, Strenski &amp; Mehringer, LLP"},
{"name":"Alexovich, Joanne","firm_name":"Cantrell, Strenski &amp; Mehringer, LLP","staff_level":"Paralegal","data":[600],"color":"#be00f3","stack":"Cantrell, Strenski &amp; Mehringer, LLP"},

{"name":"Drummy, John","firm_name":"Kightlinger &amp; Gray","staff_level":"Partner","data":[30695],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"Spurgeon, J. Todd","firm_name":"Kightlinger &amp; Gray","staff_level":"Partner","data":[2520],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"Sanders, R. Eric","firm_name":"Kightlinger &amp; Gray","staff_level":"Associate","data":[2445],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"Gerth, Mark","firm_name":"Kightlinger &amp; Gray","staff_level":"Partner","data":[1820],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"Hurdle, Sarah","firm_name":"Kightlinger &amp; Gray","staff_level":"Associate","data":[1605],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"Sims, Laura","firm_name":"Kightlinger &amp; Gray","staff_level":"Associate","data":[1245],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"Bradley, Galen","firm_name":"Kightlinger &amp; Gray","staff_level":"Partner","data":[857.5],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"Davis, Debra L","firm_name":"Kightlinger &amp; Gray","staff_level":"Paralegal","data":[656],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"Wong, Kyle B","firm_name":"Kightlinger &amp; Gray","staff_level":"Associate","data":[600],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"Stafford, Casey","firm_name":"Kightlinger &amp; Gray","staff_level":"Partner","data":[122.5],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"McClanahan, Cindra","firm_name":"Kightlinger &amp; Gray","staff_level":"Paralegal","data":[120],"color":"#be00f3","stack":"Kightlinger &amp; Gray"},{"name":"Walker, April","firm_name":"Kightlinger &amp; Gray","staff_level":"Paralegal","data":[16],"color":"#be00f3","stack":"Kightlinger &amp; Gray"}]

Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Stacked column chart'
    },
    xAxis: {
        categories: ['Cantrell, Strenski &amp; Mehringer, LLP', 'Kightlinger &amp; Gray']
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Total fruit consumption'
        },
        stackLabels: {
            enabled: true,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
            }
        }
    },
    legend: {
        align: 'right',
        x: -30,
        verticalAlign: 'top',
        y: 25,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
        borderColor: '#CCC',
        borderWidth: 1,
        shadow: false
    },
    tooltip: {
        headerFormat: '<b>{point.x}</b><br/>',
        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
    },
    plotOptions: {
        column: {
            stacking: 'normal',
            dataLabels: {
                enabled: true,
                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
            }
        }
    },
    series: retVal
});
