$(function() {
  /* original code from jsfiddle.net/gh/get/jquery/1.9.1/highslide-software/highcharts.com/tree/master/samples/maps/demo/map-drilldown/ */

  /* KNOWN ISSUES
    - you can only change the variable when at the US map (not the county one)
    - legal clearance: http://shop.highsoft.com/highmaps.html
    - does not include territories
  */


  var cmsDataBaseUrl = "https://opendata.demo.socrata.com/resource/6gbd-tgny.json?$limit=50000"
  var cmsDataColorBy_selector = jQuery("#cmsDataColorBy_selector")
  var cmsDataColorBy = cmsDataColorBy_selector.val()
  var colorByText = $(cmsDataColorBy_selector).find("option:selected").text()

  var columnsToFormatAsNumbersWithCommas = [
    "Fee-for-Service Beneficiaries", "Providers", "Users Per Provider", "Average # of Providers in Bene's County"
  ]

  var columnsToFormatAsPercent = [
    "Users as a % of FFS Benes",
    "Percentage of FFS Beneficiaries By Number of Providers Delivering Services in Beneficiary's County - 0 to 2 Providers",
    "Percentage of FFS Beneficiaries By Number of Providers Delivering Services in Beneficiary's County - 3 to 4 Providers",
    "Percentage of FFS Beneficiaries By Number of Providers Delivering Services in Beneficiary's County - 5 to 9 Providers",
    "Percentage of FFS Beneficiaries By Number of Providers Delivering Services in Beneficiary's County - 10 to 19 Providers",
    "Percentage of FFS Beneficiaries By Number of Providers Delivering Services in Beneficiary's County - 20 or More Providers"
  ]

  var slashPatternUrl = 'https://mark.demo.socrata.com/api/assets/BA536634-DA84-452D-93BE-7F7C1C09069E';

  var mapData = Highcharts.geojson(Highcharts.maps['countries/us/custom/us-small'])
  var small = $('#container').width() < 400; // Some responsiveness

  var cmsData;
  $.getJSON(cmsDataBaseUrl, function(returnedData) {
    cmsData = returnedData
  }).then(do_map)

  /* watch for dropdown change */
  cmsDataColorBy_selector.change(function() {
    cmsDataColorBy = cmsDataColorBy_selector.val()
    colorByText = $(cmsDataColorBy_selector).find("option:selected").text()

    do_map()
  })

  function do_map() {

    // Set drilldown pointers
    $.each(mapData, function(i) {
      this.drilldown = this.properties['hc-key'];
      var this_state = _.findWhere(cmsData, {
        "aggregation_level": "STATE",
        "state_territory": this.properties["postal-code"]
      })

      // set value
      if (this_state) {
        this.value = parseFloat(this_state[cmsDataColorBy]);
      } else {
        this.value = undefined
      }

      //to denote states in moratoria group, we can add a "*" to the label
      //this.name += "*" // tooltip label
      //this.properties["postal-code"] += "*" // map label

      // deal with boxes to the right (from https://www.highcharts.com/maps/demo/us-data-labels)
      var path = this.path,
        copy = {
          path: path
        };
      if (path[1] === 9727) {
        Highcharts.seriesTypes.map.prototype.getBox.call(0, [copy]);
        this.middleX = ((path[1] + path[4]) / 2 - copy._minX) / (copy._maxX - copy._minX); // eslint-disable-line no-underscore-dangle
        this.middleY = ((path[2] + path[7]) / 2 - copy._minY) / (copy._maxY - copy._minY); // eslint-disable-line no-underscore-dangle
      }

    });

    // Instantiate the map
    $('#container').highcharts('Map', {
      chart: {
        events: {
          drilldown: function(e) {
            cmsDataColorBy_selector.attr("disabled", true) // disable changing variabl from drill down
            if (!e.seriesOptions) {
              var chart = this,
                mapKey = 'countries/us/' + e.point.drilldown + '-all',
                // Handle error, the timeout is cleared on success
                fail = setTimeout(function() {
                  if (!Highcharts.maps[mapKey]) {
                    chart.showLoading('<i class="icon-frown"></i> Failed loading ' + e.point.name);
                    fail = setTimeout(function() {
                      chart.hideLoading();
                    }, 1000);
                  }
                }, 3000);

              // Show the spinner
              chart.showLoading('<i class="icon-spinner icon-spin icon-3x"></i>');

              // Load the drilldown map
              $.getScript('https://code.highcharts.com/mapdata/' + mapKey + '.js', function() {
                mapData = Highcharts.geojson(Highcharts.maps[mapKey]);

                // Set a non-random bogus value
                $.each(mapData, function(i) {
                  console.log(e.point.drilldown)
                  var this_county = _.findWhere(cmsData, {
                    "aggregation_level": "COUNTY",
                    "county": this.name,
                    "state_territory": (e.point.drilldown[3]+e.point.drilldown[4]).toUpperCase()
                  })
                  if (this_county) {
                    this.value = parseFloat(this_county[cmsDataColorBy]); // VALUE FOR STATE
                  } else {
                    this.value = undefined
                  }
                });

                // Hide loading and add series
                chart.hideLoading();
                clearTimeout(fail);
                chart.addSeriesAsDrilldown(e.point, {
                  name: e.point.name,
                  data: mapData,
                  dataLabels: {
                    enabled: true,
                    format: '{point.name}'
                  }
                });
              });
            }

            this.setTitle(null, {
              text: e.point.name
            });
          },
          drillup: function() {
            cmsDataColorBy_selector.attr("disabled", false) // re-enable changing variable from drill up
            mapData = Highcharts.geojson(Highcharts.maps['countries/us/custom/us-small']) // set mapData back to country level
            this.setTitle(null, {
              text: 'USA'
            });
          }
        }
      },

      title: {
        text: 'Market Saturation Drilldown Map: '+colorByText
      },

      subtitle: {
        text: 'USA',
        floating: true,
        align: 'right',
        y: 50,
        style: {
          fontSize: '16px'
        }
      },

      legend: small ? {} : {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'middle'
      },

      colorAxis: {
        min: 0,
        minColor: '#E6E7E8',
        maxColor: '#005645'
      },

      mapNavigation: {
        enabled: true,
        buttonOptions: {
          verticalAlign: 'bottom'
        }
      },

      plotOptions: {
        map: {
          states: {
            hover: {
              color: '#EEDD66'
            }
          }
        }
      },

      tooltip: {
        style: {
          "max-width": "200px;"
        },
        useHTML: true,
        formatter: function() {
          var tooltipStr = "<table>"
          if (this.series.name == "USA") {
            tooltipStr += "<tr><td class='key'>State: </td><td class='value'>" + this.point.name + "</td></tr>"
          } else {
            tooltipStr += "<tr><td class='key'>" + this.series.name + " County: </td><td class='value'>" + this.point.name + "</td></tr>"
          }

          var valueToShow = this.point.value
          if (columnsToFormatAsNumbersWithCommas.indexOf(colorByText) != -1) {
            valueToShow = valueToShow.toLocaleString('en')
          } else if (columnsToFormatAsPercent.indexOf(colorByText) != -1) {
            valueToShow = valueToShow + "%"
          }

          tooltipStr += "<tr><td class='key'>" + colorByText + ":</td><td class='value'>" + valueToShow + "</td>"

          tooltipStr += "</table>"
          return tooltipStr;
        }
      },

      series: [{
        data: mapData,
        name: 'USA',
        dataLabels: {
          enabled: true,
          format: '{point.properties.postal-code}'
        }
      }],

      drilldown: {
        activeDataLabelStyle: {
          color: '#FFFFFF',
          textDecoration: 'none',
          textShadow: '0 0 3px #000000'
        },
        drillUpButton: {
          relativeTo: 'spacingBox',
          position: {
            x: 0,
            y: 60
          }
        }
      }
    });

  }

});
