filtername = params[:FilterValue].split(">>")[0]
filtervalue = params[:FilterValue].split(">>")[1].split("||")
findfieldname = params[:FindFieldName]
returnarray = {}

filterstring =nil
    if filtervalue.any?
      filtervalue.each do |filterwhole|
        if filterstring.nil?
          filterstring = field(filtername).contains(filterwhole)
        else
        filterstring = filterstring.or(field(filtername).contains(filterwhole))
        end
      end
    else
      filterstring = ""
    end
#print filterstring
returnarray = {}
returnarray1 = {}
returnarray2 = {}
i = 0
entity_type("Analysis_Entity").where(filterstring).faceted_by(field('matter_name').with_facet_id('findfieldid').with_maximum_facet_values_of(-1).without_pruning.then(field('matter_number').with_facet_id('matter_number'))).faceting.get_facet('findfieldid').facet_values.each do |result|

  #record = entity_type("Analysis").where(field("mattername").contains(result.value)).requesting(1).to_json
  #recordhash = JSON.parse(record)
 # print result.value
  returnarray1[i] = result.value
  i = i + 1
end
i = 0
entity_type("Analysis_Entity").where(filterstring).faceted_by(field('matter_number').with_facet_id('matter_number').with_maximum_facet_values_of(-1).without_pruning).faceting.get_facet('matter_number').facet_values.each do |result|

  #record = entity_type("Analysis").where(field("mattername").contains(result.value)).requesting(1).to_json
  #recordhash = JSON.parse(record)
  returnarray2[i] = result.value
  i = i + 1
end

j = 0
begin
  returnarray[returnarray1[j]] = returnarray2[j]
  j = j + 1;
end until j >= i
returnarray.to_json
#
