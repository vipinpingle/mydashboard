
category = params[:category]
subcategory = params[:subcategory]
categoryvalue = params[:categoryvalue]
selectedkpi = params[:selectedkpi]
filters = params[:filters].split("&&")
datefilter = params[:datefilter].split("||")
filterstring =nil
tempfilterstring = nil
facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
facet_by_hours = sum(xpath('$'+selectedkpi)).with_facet_id('kpi_id')



dataall = {}

    data = {}
    if datefilter.any?

		datefilter.each do |daterange|
		data = {}
			categoryfilterstring = field(category).contains(categoryvalue)
			if filters.any?
      filters.each do |filterwhole|

        filtername = filterwhole.split(">>")[0]
        filtervalue = filterwhole.split(">>")[1].split("||")

		internalfilterstring = nil

        if filtervalue.any?
          filtervalue.each do |filtereach|
			if internalfilterstring.nil?
				internalfilterstring = field(filtername).contains(filtereach)
			else
				internalfilterstring = internalfilterstring.or(field(filtername).contains(filtereach))
			end
		  end
		else
			internalfilterstring = ""
		end



        if filterstring.nil?
           filterstring = categoryfilterstring.and(internalfilterstring)
        else
          filterstring = filterstring.and(internalfilterstring)
        end
      end
    else
      filterstring = categoryfilterstring
    end

			dates = daterange.split("-")
			dateStart = dates[0].split("/")
			actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

			dateEnd = dates[1].split("/")
			actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)

      			filterstring = filterstring.and(field("itemdate").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("itemdate").isGreaterThan(actualStartDate.to_time.to_i.to_java))

      if selectedkpi == "AnomalyCount"
        facets = entity_type('LineItemAnomaly').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting

      facets.get_facet('subcategory_id').facet_values.each do |firm|
			  data[firm.value] = firm.getChildren.first.value
			end

     #facets = entity_type('LineItemAnomaly').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_invdate.then(facet_by_hours))).faceting

   # facets.get_facet('subcategory_id').facet_values.each do |firm|
   #   arr = []
   #   firm.get_facet('invdate_id').facet_values.each_with_index do |invdate,index|
   #     invdate.getChildren.each do |total|

   #                   test = 0
   #                   data[firm.value].each do |hash1|
   #                     if hash1.key?(invdate.value)
   #                       test = 1
   #                       hash1[invdate.value] = total.value + hash1[invdate.value]
   #                       break
   #                      end
   #                   end
   #                   if test == 0
   #                     data[firm.value] << {invdate.value => total.value}
   #                   end
   #     end
   #   end
   # end
  else

      facets = entity_type('Analysis').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting

      facets.get_facet('subcategory_id').facet_values.each do |firm|
			  data[firm.value] = firm.getChildren.first.value
			end
    end
     data = data.sort_by {|k,v| v}.reverse

			datanew = {}
			i = 1
			totalrest = 0
			data.each do |key,value|
			  if(i < 10)
				datanew.store(key,value)
			  else
				totalrest = totalrest + value
				datanew.store("others",totalrest)
			  end
			  i = i + 1
			end

			dataall[daterange] = datanew
filterstring = nil
		end
    end


series = ""
seriesmap = {}
dataall.each_with_index do |(key,val),i|
  val.each_with_index do |(key1,val1),j|
    if seriesmap.key?(key1)
      seriesmap[key1] = seriesmap[key1].push(val1)
    else
      seriesmap[key1] = Array.new(i,0)
      seriesmap[key1] = seriesmap[key1].push(val1)
    end
 #   series << "\{name:'#{key1}', data: [#{i}, #{val1}]\}"
  end
end

def makeproperarray(arraytofix,dataall)
  if arraytofix.length < dataall.length
    arraytofix.push(0)
    makeproperarray(arraytofix,dataall)
  end
else
  return arraytofix
end

seriesmap.each_with_index do |(key,val),i|
  seriesmap[key] = makeproperarray(val,dataall)
  series << "\{name:'#{key}',data: #{val}\}"
  unless i == seriesmap.size - 1
      series << ","
    end
end



series.gsub!('nil','null')

series.html_safe
#series.to_json
