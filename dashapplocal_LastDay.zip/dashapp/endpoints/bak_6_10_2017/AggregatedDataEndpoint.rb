# Using parameters
# Accesses the values that are passed to the endpoint with the <params> array
state2 = params[:State2]
state1 = params[:State1]
widget = params[:WidgetName]

# Query API
# You can use the query API as you can in other parts of Application Builder
# You can use the query API to do additional calls, or to call external web services

#entity_type("AggregatedData").where(field('state').within(state)).to_json.html_safe


entity_type("AggregatedData").where(field('state').contains(state1).or(contains(state2))).where(field('Widget').contains(widget)).requesting(entity_type("AggregatedData").where(field('state').contains(state1).or(contains(state2))).where(field('Widget').contains(widget)).total_results).to_json
