datefilter = params[:datefilter].split("-")
filters = params[:filters].split("&&")
searchstring = params[:searchfilter]
widget = params[:widget]
entity = params[:entity]

filterstring =nil
actualStartDate = ""
actualEndDate = ""
searchOnField = ""

if entity != "matter"
    dateStart = datefilter[0].split("/")
    actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)
    dateEnd = datefilter[1].split("/")
    actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)
    searchOnField = "invoice_id"
else
    searchOnField = "matter_number"
end


if filters.any?
    filters.each do |filterwhole|
    filtername = filterwhole.split(">>")[0]
    filtervalue = filterwhole.split(">>")[1]
    internalfilterstring = nil
    internalfilterstring = field(filtername).contains(filtervalue)

      if filterstring.nil?
          filterstring = internalfilterstring
      else
          filterstring = filterstring.and(internalfilterstring)
        end
    end
end

if filterstring.nil?
  if entity != "matter"
  filterstring =(field("date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("date").isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
  end
else
  if entity != "matter"
  filterstring = filterstring.and(field("date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("date").isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
  end
end
series = ""
anomalyfilterstring = nil
linitemfilterstring = nil
 if searchstring.eql? ("")
   linitemfilterstring = filterstring
   anomalyfilterstring = filterstring
  else
  linitemfilterstring = filterstring.and(field("timekeeper_name").contains(searchstring).or(field("anomaly_desc").contains(searchstring)))
  anomalyfilterstring = filterstring.and((field("anomaly_desc").contains(searchstring)).or(field(searchOnField).is(searchstring)))
  end

if widget.eql?("widget1")

#calculate number of invoices that have anomalies
  print "\n--searchOnField--\n"
print searchOnField
  print "\n-facets---\n"

facets = entity_type("anomaly_invoice").where(anomalyfilterstring).faceted_by(field(searchOnField).with_facet_id(searchOnField).with_maximum_facet_values_of(-1).without_pruning).faceting
  print linitemfilterstring
numberofinvoices  = facets.get_facet(searchOnField).facet_values.count
series << "{\"numberofinvoices\":#{numberofinvoices}"
#calculate number of lineitems that have anomalies
facets = entity_type("anomaly_lineitem").where(linitemfilterstring).faceted_by(field("invoice_line_item_id").with_facet_id('invoice_line_item_id').with_maximum_facet_values_of(-1).without_pruning).faceting

numberoflineitems  = facets.get_facet('invoice_line_item_id').facet_values.count
series << ",\"numberoflineitems\":#{numberoflineitems}"
#calculate total number of anomalies
facets = entity_type("anomaly_invoice").where(anomalyfilterstring).faceted_by(field("invoice_anomaly_id").with_facet_id('invoice_anomaly_id').with_maximum_facet_values_of(-1).without_pruning).faceting

numberofinvoiceanomalies  = facets.get_facet('invoice_anomaly_id').facet_values.count

facets = entity_type("anomaly_lineitem").where(linitemfilterstring).faceted_by(field("anomaly_group_id").with_facet_id('anomaly_group_id').with_maximum_facet_values_of(-1).without_pruning).faceting

numberoflineitemanomalies  = facets.get_facet('anomaly_group_id').facet_values.count

totalanomalies = numberoflineitemanomalies + numberofinvoiceanomalies

series << ",\"totalanomalies\":#{totalanomalies}\}"
  # widget2 returns the timekeeper lineitem anomalies table
elsif widget.eql?("widget2")

  series << "["
  #facets = entity_type("anomaly_lineitem").where(linitemfilterstring).faceted_by(field("timekeeper_name").with_facet_id('timekeeper_name').with_maximum_facet_values_of(-1).without_pruning.then(field("anomaly_desc").with_facet_id('anomaly_desc').with_maximum_facet_values_of(-1).without_pruning)).faceting



  facets = entity_type("anomaly_lineitem").where(linitemfilterstring).faceted_by(field("anomaly_group_id").with_facet_id('anomaly_group_id').with_maximum_facet_values_of(-1).without_pruning.then(field("invoice_line_item_id").with_facet_id('invoice_line_item_id').with_maximum_facet_values_of(-1).without_pruning).then(field(searchOnField).with_facet_id(searchOnField).with_maximum_facet_values_of(-1).without_pruning)).faceting
  total = 0

  facets.get_facet('anomaly_group_id').facet_values.each do |anomaly_group_id|
    total = total + 1
    lineitems = 0
    invoices = 0
    timekeeper = ""
    anomaly_desc = ""
    groupid = anomaly_group_id.value
    invoiceid = ""
    lineitemid = ""
    lineitems = anomaly_group_id.get_facet('invoice_line_item_id').facet_values.count
    anomaly_group_id.get_facet('invoice_line_item_id').facet_values.each do |invoice_line_item_id|
       invoices = invoice_line_item_id.get_facet(searchOnField).facet_values.count
    end
     filterstring1 = linitemfilterstring.and(field('anomaly_group_id').contains(anomaly_group_id.value))
    totalresults = entity_type("anomaly_lineitem").where(filterstring1).total_results

    rb_hash = JSON.parse(entity_type("anomaly_lineitem").where(filterstring1).requesting(totalresults).to_json)

    rb_hash.each do |anomaly|
      timekeeper = anomaly["properties"]["timekeeper_name"].first
      anomaly_desc = anomaly["properties"]["anomaly_desc"].first
      invoiceid = anomaly["properties"]["invoice_id"].first
      lineitemid = anomaly["properties"]["invoice_line_item_id"].first

    end
    series << "{\"id\":#{total},\"invoiceid\":\"#{invoiceid}\",\"lineitemid\":\"#{lineitemid}\",\"groupid\":\"#{groupid}\",\"invoicecount\":#{invoices},\"lineitemcount\":#{lineitems},\"timekeepername\":\"#{timekeeper}\",\"anomaly_description\":\"#{anomaly_desc}\"}"
    unless total == facets.get_facet('anomaly_group_id').facet_values.count
      series << ","
    end
  end
  series << "]"
  ary = JSON[series].sort_by{ |e| e['id'].to_i }
  series = ""
  series << ary.to_json

  #series << "{\"total\":#{total}}]"


  #widget 3 returns the invoice anomalies
elsif widget.eql?("widget3")
  totalresults = entity_type("anomaly_lineitem").where(linitemfilterstring).total_results
  rb_hash = JSON.parse(entity_type("anomaly_lineitem").where(linitemfilterstring).requesting(totalresults).to_json)
  i = 0
  series << "["
  rb_hash.each do |lineitem|
    i = i +1
    date = lineitem["properties"]["date"].first
    firm_name = lineitem["properties"]["firm_name"].first
    timekeeper_name = lineitem["properties"]["timekeeper_name"].first
    description = lineitem["properties"]["description"].first
    code = lineitem["properties"]["code"].first
    rate = lineitem["properties"]["rate"].first
    hours = lineitem["properties"]["hours"].first
    notes = lineitem["properties"]["notes"].first
    matter_number = lineitem["properties"]["matter_number"].first
    matter_name = lineitem["properties"]["matter_name"].first

    invoice_id   = lineitem["properties"]["invoice_id"].first
    anomaly_desc   = lineitem["properties"]["anomaly_desc"].first
    anomaly_group_id   = lineitem["properties"]["anomaly_group_id"].first
    series << "{\"id\":#{i},\"invoice_id\":\"#{invoice_id}\", \"date\":\"#{date}\", \"anomaly_desc\":\"#{anomaly_desc}\", \"hours\":#{hours},\"firm_name\":\"#{firm_name}\",\"timekeeper_name\":\"#{timekeeper_name}\",\"description\":\"#{description}\",\"code\":\"#{code}\",\"rate\":#{rate},\"notes\":\"#{notes}\",\"matter_number\":\"#{matter_number}\",\"matter_name\":\"#{matter_name}\",\"anomaly_group_id\":\"#{anomaly_group_id}\"}"
    unless i == rb_hash.size
      series << ","
    end
  end
     series << "]"
elsif widget.eql?("widget4")
  totalresults = entity_type("anomaly_invoice").where(anomalyfilterstring).total_results
  if totalresults > 0
  rb_hash = JSON.parse(entity_type("anomaly_invoice").where(anomalyfilterstring).requesting(totalresults).to_json)

  i = 0
  series << "["
  rb_hash.each do |invoice|
    i = i +1
    if !invoice["properties"]["invoice_id"].nil?

    invoiceid = invoice["properties"]["invoice_id"].first
    end
        if !invoice["properties"]["date"].nil?

    invdate = invoice["properties"]["date"].first
          end
              if !invoice["properties"]["anomaly_desc"].nil?

    anomaly_desc = invoice["properties"]["anomaly_desc"].first
                end
                    if !invoice["properties"]["total_hours"].nil?

    total_hours = invoice["properties"]["total_hours"].first
                    else
                      total_hours = 0
                      end
                          if !invoice["properties"]["invoice_amt"].nil?

    invoice_amt = invoice["properties"]["invoice_amt"].first
    end
    series << "{\"invoiceid\":\"#{invoiceid}\", \"invdate\":\"#{invdate}\", \"anomaly_desc\":\"#{anomaly_desc}\", \"total_hours\":#{total_hours}, \"invoice_amt\":#{invoice_amt}}"
    unless i == rb_hash.size
      series << ","
    end
  end
     series << "]"

  ary = JSON[series].sort_by{ |e| e['invoice_amt'] }.reverse
  series = ""
  series << ary.to_json
end
end
series
