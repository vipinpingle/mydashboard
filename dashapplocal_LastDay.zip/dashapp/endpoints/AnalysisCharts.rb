#Combined scripts for all charttypes
#Based on the charttype apply the logic

$charttype = params[:charttype]
category = params[:category]
subcategory = params[:subcategory]
selectedkpi = params[:selectedkpi]
$filters = params[:filters].split("&&")
$datefilter = params[:datefilter].split("-")
$categoryfilterstring = nil
$etc = nil
filterstring =nil
datanew = {}
dataall = {}
datanewvalue = []
series = ""
seriesmap = {}

if $charttype == "timecomparison"
  categoryvalue = params[:categoryvalue]
  $datefilter = params[:datefilter].split("||")
else
  $datefilter = params[:datefilter].split("-")
  categoryvalue = params[:categoryvalue].split("||")
  #print "\n********** \n"
  #print categoryvalue
end



if subcategory.eql?("full_name")
  facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning.then(field('firm_name').with_facet_id('firm_name').with_maximum_facet_values_of(-1).without_pruning)
else
  facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
end

facet_by_hours = sum(xpath('$'+selectedkpi)).with_facet_id('kpi_id')
facet_by_invdate = xpath("viv:format-date($item_date,'%m/%d/%Y')").with_facet_id('invdate_id').with_maximum_facet_values_of(-1).without_pruning

def getStartAndEndDateForTimeComparison(actualStartDate,actualEndDate,daterange)
  dates = daterange.split("-")
  dateStart = dates[0].split("/")
  actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)
  dateEnd = dates[1].split("/")
  actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)
end

def getStartAndEndDate(datefilter)
  actualStartDate = ""
  actualEndDate = ""

  dateStart = datefilter[0].split("/")
  actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)
  dateEnd = datefilter[1].split("/")
  actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)
end

def getFilterString(filterstring,filters,datefieldname,categoryfilterstring,datefilter,daterange)
  if filters.any?
    filters.each do |filterwhole|
		filtername = filterwhole.split(">>")[0]
		filtervalue = filterwhole.split(">>")[1].split("||")
		internalfilterstring = nil
		tmpFilterDateString = nil
		if filtervalue.any?
			  filtervalue.each do |filtereach|
				if(filtername.include?("_date"))
				  tmpDate = filtereach.split("-")
				  tmpdateStart = tmpDate[0].split("/")
				  tmpactualStartDate = Date.new(tmpdateStart[2].to_i,tmpdateStart[0].to_i,tmpdateStart[1].to_i)
				  tmpdateEnd = tmpDate[1].split("/")
				  tmpactualEndDate = Date.new(tmpdateEnd[2].to_i,tmpdateEnd[0].to_i,tmpdateEnd[1].to_i)
				  tmpFilterDateString = "true"
				end

          if(filtername.include?("opposing_firm_id"))
            # find all matter numbers

            entity_type("matter_firms").where(field("firm_id").contains(filtereach).and(field('firm_type').is("Opposing"))).faceted_by(field("matter_number").with_facet_id("matter_number")).faceting.get_facet('matter_number').facet_values.each do |matter_number|

             #print matter_number.value.to_s
             if internalfilterstring.nil?
               internalfilterstring = field("matter_number").contains(matter_number.value)
              else
                internalfilterstring = internalfilterstring.or(field("matter_number").contains(matter_number.value))
              end
            #internalfilterstring = field("firm_id").contains(filtereach)

end
          else

				if internalfilterstring.nil?
					if tmpFilterDateString.nil?
							internalfilterstring = field(filtername).contains(filtereach)
					else
							  internalfilterstring = field(filtername).isLessThanOrEqual(tmpactualEndDate.to_time.to_i.to_java).and(field(filtername).isGreaterThanOrEqual(tmpactualStartDate.to_time.to_i.to_java))
					end
				else
					if tmpFilterDateString.nil?
					  internalfilterstring = internalfilterstring.or(field(filtername).contains(filtereach))
					else
					  internalfilterstring = internalfilterstring.and(field(filtername).isLessThanOrEqual(tmpactualEndDate.to_time.to_i.to_java)).and(field(filtername).isGreaterThanOrEqual(tmpactualStartDate.to_time.to_i.to_java))
					end
				end
          end
			  end
		else
			internalfilterstring = ""
		end
		if filterstring.nil?
			  filterstring = $categoryfilterstring.and(internalfilterstring)
		else
			  filterstring = filterstring.and(internalfilterstring)
		end
	end
  else
    # for loop ends here
    filterstring = $categoryfilterstring
  end
    # for invoicelevel anomaly
    #searchstringwithoutdate = filterstring
  if !daterange.nil?
	dates = daterange.split("-")
	dateStart = dates[0].split("/")
	actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)
	dateEnd = dates[1].split("/")
	actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)

    # datefieldname  can be item_date or invoice date in case of anomalies
    filterstring = filterstring.and(field(datefieldname).isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field(datefieldname).isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
  else
    if datefilter.any?
        dateStart = datefilter[0].split("/")
        actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)
        dateEnd = datefilter[1].split("/")
        actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)
        if filterstring.nil?
          filterstring =(field(datefieldname).isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field(datefieldname).isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
		else
          filterstring =  filterstring.and(field(datefieldname).isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field(datefieldname).isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
		end
    end
  end
  print filterstring
  return filterstring
end

# For pie and bar. If the category is phase, task and fullname, then apply select only line item anomalies, else do both invoice as well as line item. Need to change the filter string also
def getDataFromFacetsPBC(data,entitytype,filterstring,facet_by_subcategory,facet_by_hours)
    cattmp = params[:category]
    subcattmp = params[:subcategory]

	if (params[:selectedkpi] == "anomaly_description")

		facets = entity_type("AnalysisAnomaly_Matrix").where(filterstring).faceted_by(facet_by_subcategory.then(field('anomaly_group_id').with_facet_id('anomaly_group_id').with_maximum_facet_values_of(-1).without_pruning)).faceting

		arr = []
    #print "\n-- filterstraing for lineitem anomaly --\n"
    #print filterstring
		facets.get_facet('subcategory_id').facet_values.each do |firm|
      if params[:subcategory].eql?('full_name')
        firm.get_facet('firm_name').facet_values.each do |readlfirm|
          data[firm.value + "||" + readlfirm.value] = readlfirm.get_facet('anomaly_group_id').facet_values.count
        end

      else

      data[firm.value] = firm.get_facet('anomaly_group_id').facet_values.count
      end

		end

		if (cattmp != "phase") && (cattmp != "task_code") && (cattmp != "full_name") && (cattmp != "rate") && (cattmp != "expense") && (subcattmp != "phase") && (subcattmp != "task_code") && (subcattmp != "full_name") && (subcattmp != "rate") && (subcattmp != "expense")

      filterstring = getFilterString(nil,$filters,"invoice_date",$categoryfilterstring,$datefilter,nil)
      print "\n-- filterstraing for invoice anomaly --\n"
    print filterstring

			facets = entity_type("AnalysisInvoiceAnomalies").where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting

			facets.get_facet('subcategory_id').facet_values.each do |firm|

			  if data.key?(firm.value)
				data[firm.value] = data[firm.value]+firm.ndocs
			   # print "\n if data.key loop \n"
			  else
				#print "\n else loop \n"
				data[firm.value] = firm.ndocs
			  end
			end
		end
	else
		facets = entity_type(entitytype).where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting

		arr = []
    if params[:subcategory].eql?('full_name')
      facets.get_facet('subcategory_id').facet_values.each do |firm|
        #data[firm.value + "->" + firm.get_facet('firm_name').facet_values.first.value] = firm.get_facet('firm_name').facet_values.first.getChildren.first.value
        firm.get_facet('firm_name').facet_values.each do |readlfirm|
         # data1[firm.value] = readlfirm.value
          data[firm.value + "||" + readlfirm.value] = readlfirm.getChildren.first.value
        end
		end
    else
		facets.get_facet('subcategory_id').facet_values.each do |firm|
		  data[firm.value] = firm.getChildren.first.value
		end
  end
	end

  return data
end

# For timeline
def getDataFromFacetsTC(data,entitytype,filterstring,facet_by_subcategory,facet_by_hours,facet_by_invdate)
	cattmp = params[:category]
    subcattmp = params[:subcategory]
	if (params[:selectedkpi] == "anomaly_description")

	# do lineitem anomalies first
	arr = []
	facets = entity_type("AnalysisAnomaly_Matrix").where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_invdate).then(field('anomaly_group_id').with_facet_id('anomaly_group_id').with_maximum_facet_values_of(-1).without_pruning)).faceting
		facets.get_facet('subcategory_id').facet_values.each do |firm|
		  firm.get_facet('invdate_id').facet_values.each_with_index do |invdate,index|
         datenew = invdate.value.split("/")
        actualdatenew = Date.new(datenew[2].to_i,datenew[0].to_i,datenew[1].to_i)
        arr << {(actualdatenew.to_time.to_i*1000) => invdate.get_facet('anomaly_group_id').facet_values.count}
        #arr << {invdate.value => invdate.ndocs}

		  end
		end
	#see if invoice level anomalies need to be added.

		if (cattmp != "phase") && (cattmp != "task_code") && (cattmp != "full_name") && (cattmp != "rate") && (cattmp != "expense") && (subcattmp != "phase") && (subcattmp != "task_code") && (subcattmp != "full_name") && (subcattmp != "rate") && (subcattmp != "expense")
      filterstring = getFilterString(nil,$filters,"invoice_date",$categoryfilterstring,$datefilter,nil)
      facet_by_invdate = xpath("viv:format-date($invoice_date,'%m/%d/%Y')").with_facet_id('invdate_id').with_maximum_facet_values_of(-1).without_pruning
			facets = entity_type("AnalysisInvoiceAnomalies").where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_invdate)).faceting
			facets.get_facet('subcategory_id').facet_values.each do |firm|
				firm.get_facet('invdate_id').facet_values.each_with_index do |invdate,index|
          datenew = invdate.value.split("/")
        actualdatenew = Date.new(datenew[2].to_i,datenew[0].to_i,datenew[1].to_i)
        arr << {(actualdatenew.to_time.to_i*1000) => invdate.ndocs}
					#arr << {invdate.value => invdate.ndocs}
                  print " \n inserted into arr \n"

				end
			end
		end

    data = arr
	else
		facets = entity_type(entitytype).where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_invdate.then(facet_by_hours))).faceting
		facets.get_facet('subcategory_id').facet_values.each do |firm|
		  arr = []
		  firm.get_facet('invdate_id').facet_values.each_with_index do |invdate,index|
			invdate.getChildren.each do |total|
        datenew = invdate.value.split("/")
        actualdatenew = Date.new(datenew[2].to_i,datenew[0].to_i,datenew[1].to_i)
			  arr << {(actualdatenew.to_time.to_i*1000) => total.value}

			end
			data = arr
		  end
		end
	end

#print "\n data is "
#print data
  return data
end

def getDataStore(datanew,data)
 data = data.sort_by {|k,v| v}.reverse
 datanew = {}
 i = 1
  othercount = 0
 totalrest = 0
 data.each do |key,value|
   if(i < 20)
     datanew.store(key,value)
   else
     totalrest = totalrest + value
     othercount = othercount +1
   end
   i = i + 1
 end
  if(totalrest > 0)

      if $charttype == "pie"
        datanew.store("others",totalrest.round(2))
    datanew.store("average",(totalrest/othercount).round(2))
    datanew.store("totalitems",othercount)

      else
        $etc = "{average: #{totalrest/othercount} ,totalitems: #{othercount} "
        #datanew.store("others",totalrest.to_s + ',' + (totalrest/i).to_s + ',' + i.to_s)
        datanew.store("others","{y: #{totalrest.round(2)}, average: #{(totalrest/othercount).round(2)} ,totalitems: #{othercount} }" )

      end
  end
  return datanew
end


# return the json formated data to return
def getJsonFormat(series,datavalue)
datavalue.each_with_index do |(key, val), i|
  series << "\{name:'#{key}',data: #{val}\}"
  unless i == datavalue.size - 1
    series << ","
  end
end
  return series
end

# return the json formated data for pie. Need to make it more generic.
def getJsonPieFormat(series,datavalue)
  if $charttype == "pie"
datavalue.each_with_index do |(key, val), i|
    if key.eql? ("totalitems")
      next
    end

    if key.eql? ("average")
      next
    end
        if key.eql? ("others")
          series << "\{name:\"#{key}\",y: #{val}\,average: #{datavalue["average"]}\,totalitems: #{datavalue["totalitems"]}\}"
        else
          if params[:subcategory].eql?("full_name")
            firm_name= key.split("||")[1]
            full_name = key.split("||")[0]
            if $charttype == "pie"
              series << "\{name:\"#{full_name}\",firm_name:\"#{firm_name}\",y: #{val}\}"
            else
              series << "\{name:\"#{full_name}\",firm_name:\"#{firm_name}\",data: #{val}\}"
          end
          else
            series << "\{name:\"#{key}\",y: #{val}\}"

          end
           unless i == datavalue.size - 1
            series << ","
           end
        end


end
  return series
else
  datavalue.each_with_index do |(key, val), i|
  series << "\{name:'#{key}',y: #{val}\}"
  unless i == datavalue.size - 1
    series << ","
  end
end
  return series
end
end


def executeQuery(data,datanew,selectedkpi,filterstring,facet_by_subcategory,facet_by_hours,facet_by_invdate,charttype)
  #datanew = {}

  #anomaly_description was anomalycount before
  if selectedkpi == "anomaly_description"
    if charttype == "timeline"
      data  = getDataFromFacetsTC(data,'AnalysisAnomaly_Matrix',filterstring,facet_by_subcategory,facet_by_hours,facet_by_invdate)
    else
      data  = getDataFromFacetsPBC(data,'AnalysisAnomaly_Matrix',filterstring,facet_by_subcategory,facet_by_hours)
    #print "\n data in executeQuery \n"
    #print data
    end
  else
   if charttype == "timeline"
      data  = getDataFromFacetsTC(data,'Analysis_Matrix',filterstring,facet_by_subcategory,facet_by_hours,facet_by_invdate)
    else
     data  = getDataFromFacetsPBC(data,'Analysis_Matrix',filterstring,facet_by_subcategory,facet_by_hours)
    end
  end
  if charttype == "timeline"
    datanew = data
    else
     datanew = getDataStore(datanew,data)
  end
  return datanew
end


#main code to execute all functions

if $charttype == "timecomparison"
  if $datefilter.any?
    $datefilter.each do |daterange|
    data = {}

    datanew = {}
    $categoryfilterstring = field(category).contains(categoryvalue)
      filterstring = getFilterString(filterstring,$filters,"item_date",$categoryfilterstring,$datefilter,daterange)
      dataall[daterange] = executeQuery(data,datanew,selectedkpi,filterstring,facet_by_subcategory,facet_by_hours,facet_by_invdate,$charttype)
    filterstring = nil

     # print "\n**********\n"
     # print daterange
     # print "\n data returned \n"
     # print dataall[daterange]
     # print "\n==========\n"

  end
 end
else
    #print "\n-----in else loop ---\n"
    if(categoryvalue.any?)
      datanewvalue ={}
      categoryvalue.each do |catval|
      data = {}
      datanew = {}

      $categoryfilterstring = field(category).contains(catval)
      filterstring =nil
      daterange = nil
        filterstring = getFilterString(filterstring,$filters,"item_date",$categoryfilterstring,$datefilter,daterange)
      #print filterstring
      if $charttype=="timeline"
        datanewvalue[catval] = executeQuery(data,datanew,selectedkpi,filterstring,facet_by_subcategory,facet_by_hours,facet_by_invdate,$charttype)
      else
        if $charttype == "pie"
          datanew = executeQuery(data,datanew,selectedkpi,filterstring,facet_by_subcategory,facet_by_hours,facet_by_invdate,$charttype)
        else
          dataall[catval] = executeQuery(data,datanew,selectedkpi,filterstring,facet_by_subcategory,facet_by_hours,facet_by_invdate,$charttype)
        end
      end
      end
    end
end

def makeproperarray(arraytofix,dataall)
  if arraytofix.length < dataall.length
    arraytofix.push(0)
    makeproperarray(arraytofix,dataall)
  end
else
  return arraytofix
end

def getJsonFormattedPieData(datavalue)
  series = ""
  series = getJsonPieFormat(series,datavalue)
  return series
end

def getJsonFormattedBarData(dataall)
series = ""
seriesmap = {}
names = Array.new
dataall.each_with_index do |(key,val),i|
  val.each_with_index do |(key1,val1),j|
    if names.include?(key1)
    else
      names.push(key1)
    end
  end
end
dataall.each_with_index do |(key,val),i|
  names.each do |name|
    if seriesmap.key?(name)
    else
       seriesmap[name] = Array.new
    end
    if val.key?(name)
      seriesmap[name] = seriesmap[name].push(val[name])
    else
      seriesmap[name] = seriesmap[name].push(0)
    end

    end
  end
others = []
  seriesmap.each_with_index do |(key,val),i|

    seriesmap[key] = makeproperarray(val,dataall)
    if key.eql? ("others")
      others = val
      others = others.to_s.gsub('"', '')
      #others = others.map{|n|eval n}
    else
     # series << "\{name:\"#{key}\",data: #{val}\}"
      if params[:subcategory].eql?("full_name")
            firm_name= key.split("||")[1]
            full_name = key.split("||")[0]
        series << "\{name:\"#{full_name}\",firm_name:\"#{firm_name}\",data: #{val}\}"
          else

        series << "\{name:\"#{key}\",data: #{val}\}"

          end
      unless i == (seriesmap.size-1)
        series << ","
        end
      end
    end

if others.empty?
else



  series << "\,{name:\"others\",data:#{others}\}"
end
    return series
end

def getJsonFormattedTimeComparisonData(dataall)
series = ""
seriesmap = {}
dataall.each_with_index do |(key,val),i|
  val.each_with_index do |(key1,val1),j|
    if seriesmap.key?(key1)
      seriesmap[key1] = seriesmap[key1].push(val1)
    else
      seriesmap[key1] = Array.new(i,0)
      seriesmap[key1] = seriesmap[key1].push(val1)
    end
  end
end

seriesmap.each_with_index do |(key,val),i|
  seriesmap[key] = makeproperarray(val,dataall)
  series << "\{name:'#{key}',data: #{val}\}"
  unless i == seriesmap.size - 1
      series << ","
    end
end
return series
end

if $charttype.eql?"bar"
  series = getJsonFormattedBarData(dataall)
end
if $charttype.eql?"pie"
  #print datanew
  series = getJsonFormattedPieData(datanew)
end
if $charttype.eql?"timeline"
  series = "["
  datanewvalue.each do |name,month_array|
    i = 0

 month_array = month_array.sort_by {|k| k.first}
    month_array.each do |timeint|
      timeint.each_with_index do |(key,val),j|
        series << "[#{key},#{val}]"
        unless i == (month_array.size - 1)
          series << ","
        end
      end
      i = i +1
    end

  end
  series << "]"

end

if $charttype.eql?"timecomparison"
  series = getJsonFormattedTimeComparisonData(dataall)
  #

end

series.gsub!('nil','null')
series.html_safe
