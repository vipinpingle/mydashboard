widget = params[:widgetname]
matter_number = params[:matter_number]
firm_id = params[:firm_id]

$datefilter = params[:datefilter].split("-")
filterstring = nil
filterstring1 = nil
data = {}
firmspend = 0
series = ""
datefieldname = ""
kpi = params[:kpi]
$spend = 0
if widget.eql? ("widget5")
  datefieldname = "open_date"
elsif widget.eql? ("widget3")
  datefieldname = "item_date"
  elsif widget.eql? ("widget4")
  datefieldname = "item_date"

  elsif widget.eql? ("widget11")
  datefieldname = "year"
else
  datefieldname = "date"
end


if $datefilter.any?
 dateStart = $datefilter[0].split("/")
 actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)
 dateEnd = $datefilter[1].split("/")
 actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)
  if filterstring.nil?
    filterstring =(field(datefieldname).isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field(datefieldname).isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
  else
    filterstring =  filterstring.and(field(datefieldname).isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field(datefieldname).isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
  end
end

if $datefilter.any?
 dateStart = $datefilter[0].split("/")
 actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)
 dateEnd = $datefilter[1].split("/")
 actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)
  if filterstring1.nil?
    filterstring1 =(field("item_date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("item_date").isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
  else
    filterstring1 =  filterstring1.and(field("item_date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("item_date").isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
  end
end

state = nil
entity_type("Analysis_Matrix").where(field("matter_number").contains(matter_number)).faceted_by(field("state").with_facet_id("state")).faceting.get_facet('state').facet_values.each do |firm|
  state = firm.value
		end

widget2string = nil
if firm_id.eql?("")
   widget2string = field("matter_number").contains(matter_number)
else
  widget2string = field("matter_number").contains(matter_number).and(field('firm_id').is(firm_id))
end
widget3string = nil
if filterstring.nil?
  if firm_id.eql?("")
   widget3string = field("matter_number").contains(matter_number)
  else
    widget3string = field("matter_number").contains(matter_number).and(field('firm_id').is(firm_id))
  end
else
   if firm_id.eql?("")
     widget3string = filterstring.and(field("matter_number").contains(matter_number))
  else
    widget3string =  filterstring.and(field("matter_number").contains(matter_number).and(field('firm_id').is(firm_id)))
  end
end

if widget.eql? ("widget1")
  budget = 0

   entity_type("Matter_Firm_Budget").where(widget2string).faceted_by(field("matter_number").with_facet_id("cat").then(sum(xpath('$total_budget')).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|

  budget = firm.getChildren.first.value
end

series << "\{\"budget\":#{budget}\}"


elsif widget.eql? ("widget2")

totalmatterspent = 0


entity_type("Analysis_Matrix").where(widget2string).faceted_by(field("matter_number").with_facet_id("cat").then(sum(xpath('$net_amt')).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|

  totalmatterspent = firm.getChildren.first.value
end
series << "\{\"totalmatterspent\":#{totalmatterspent}\}"


elsif widget.eql? ("widget3")
matterperiodspend = 0



entity_type("Analysis_Matrix").where(widget3string).faceted_by(field("matter_number").with_facet_id("cat").then(sum(xpath('$net_amt')).with_facet_id('kpi_id')
)).faceting.get_facet('cat').facet_values.each do |firm|

  matterperiodspend = firm.getChildren.first.value
end

series << "\{\"matterperiodspend\":#{matterperiodspend}\}"

elsif widget.eql? ("widget4")

#matterexpensespend = 0

#widget4string = widget3string.and(field("expense").is("NA").negated)
#entity_type("Analysis_Matrix").where(widget4string).faceted_by(field("matter_number").with_facet_id("cat").then(sum(xpath('$net_amt')).with_facet_id('kpi_id')
#)).faceting.get_facet('cat').facet_values.each do |firm|
 # matterexpensespend = firm.getChildren.first.value
#end

#print "\n**matterexpensespend*\n"
#print matterexpensespend

matterperiodspend = 0
#print widget3string

entity_type("Analysis_Matrix").where(widget3string.and(field("expense").is("NA"))).faceted_by(field("matter_number").with_facet_id("cat").then(sum(xpath('$net_amt')).with_facet_id('kpi_id')
)).faceting.get_facet('cat').facet_values.each do |firm|
  matterperiodspend = firm.getChildren.first.value
end

#print "\n**matterperiodspend*\n"
#print matterperiodspend

matterhours = 0
entity_type("Analysis_Matrix").where(widget3string).faceted_by(field("matter_number").with_facet_id("cat").then(sum(xpath('$hours')).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|

  matterhours = firm.getChildren.first.value
end
#print "\n*matterhours*\n"
#print matterhours
if matterhours == 0
  series << "\{\"matterblendedrate\":0\}"

else
 # matterperiodtotal = matterperiodspend - matterexpensespend
#print "\n*matterperiodtotal*\n"
#print matterperiodtotal
series << "\{\"matterblendedrate\":#{(matterperiodspend/matterhours).round(2)}\}"
end
elsif widget.eql?("widget5")
caselength = 0
entity_type("Matter_Details").where(field("matter_number").contains(matter_number)).faceted_by(field("matter_number").with_facet_id("cat").then(avg(xpath('$case_length')).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|

  caselength = firm.getChildren.first.value
end

series << "\{\"caselength\":#{caselength}\}"
elsif widget.eql?("widget6")
data = {}
data1 = {}
if filterstring.nil?
  filterstring = field("matter_number").contains(matter_number)
else
  filterstring = filterstring.and(field("matter_number").contains(matter_number))
end
if !firm_id.nil?
  filterstring = filterstring.and(field("firm_id").contains(firm_id))
end
entity_type("matter_phase").where(filterstring.and(field("matter_number").contains(matter_number))).faceted_by(field("phase_code").with_facet_id("cat").then(sum(xpath('$'+kpi)).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|

  data[firm.value] = firm.getChildren.first.value.round(0)
end
if kpi.eql?("spend")
entity_type("matter_phase").where(filterstring.and(field("matter_number").contains(matter_number))).faceted_by(field("phase_code").with_facet_id("cat").then(sum(xpath('$expense')).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|

  data[firm.value] = data[firm.value] + firm.getChildren.first.value.round(0)
end

entity_type("matter_budget_phase").where((field("matter_number").contains(matter_number))).faceted_by(field("phase_code").with_facet_id("cat").then(sum(xpath('$total_phase_budget')).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|
  temp = 0
  if firm.getChildren.first.value.nan?
    temp = 0
  else
    temp = firm.getChildren.first.value.round(0)
  end
  data1[firm.value] = temp
end
end

series = "{"
data.each_with_index do |(key,val),i|
  temp1= 0
  if data1.key?(key)
   temp1 = data1[key]



  end
  series << "\"#{key}\":{\"spend\":#{val},\"budget\":#{temp1}\}"

  if i == (data.size-1)

  else
    series << ","
  end

end

series << "}"
elsif widget.eql?("widget7")
primaryfirm = ""
entity_type("matter_firms").where(field("matter_number").contains(matter_number).and(field("firm_type").is("Primary"))).faceted_by(field("firm_name").with_facet_id("cat")).faceting.get_facet('cat').facet_values.each do |firm|

  primaryfirm = firm.value
  primaryfirm.gsub!("&amp;", "&")
end

series << "\{\"primary_firm\":\"#{primaryfirm}\"\}"
elsif widget.eql?("widget8")
opposingfirm = ""
entity_type("matter_firms").where(field("matter_number").contains(matter_number).and(field("firm_type").is("Opposing Primary"))).faceted_by(field("firm_name").with_facet_id("cat")).faceting.get_facet('cat').facet_values.each do |firm|

  opposingfirm = firm.value
  opposingfirm.gsub!("&amp;", "&")
end

series << "\{\"opposing_firm\":\"#{opposingfirm}\"\}"
elsif widget.eql?("widget9")
budget = 0
entity_type("Matter_Firm_Budget").where(widget2string).faceted_by(field("matter_number").with_facet_id("cat").then(sum(xpath('$total_budget')).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|

  budget = firm.getChildren.first.value
end
totalmatterspent = 0




entity_type("Analysis_Matrix").where(widget2string).faceted_by(field("matter_number").with_facet_id("cat").then(sum(xpath('$net_amt')).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|

  totalmatterspent = firm.getChildren.first.value
end

if budget == 0
  series << "\{\"percentspent\":0\}"

else
  series << "\{\"percentspent\":#{((totalmatterspent/budget)*100).round(2)}\}"

end

elsif widget.eql?("widget10")
dormancy_days = 0
dateflag = false
entity_type("Matter_Details").where(field("matter_number").contains(matter_number).and(field("matter_close_date").exists)).faceted_by(field("matter_number").with_facet_id("cat")).faceting.get_facet('cat').facet_values.each do |firm|

  dateflag = true
end

entity_type("Matter_Details").where(field("matter_number").contains(matter_number)).faceted_by(field("matter_number").with_facet_id("cat").then(avg(xpath('$dormancy_days')).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|

  if firm.getChildren.first.value == 0
    dormancy_days = 0
  else
    dormancy_days = firm.getChildren.first.value + 120
  end
end

if dormancy_days < 0
  dormancy_days = 0
end

if dateflag
   dormancy_days = 0
end

series << "\{\"dormancydays\":#{dormancy_days}\}"
elsif widget.eql?("widget11")
yearlybudget = 0.0
filterstring111 = nil
if filterstring.nil?
  filterstring111 = field("matter_number").contains(matter_number)
else
  filterstring111 = filterstring.and(field("matter_number").contains(matter_number))

end
entity_type("Matter_Budget").where(filterstring111).faceted_by(field("matter_number").with_facet_id("cat").then(sum(xpath('$matter_yearly_budget')).with_facet_id('kpi_id'))).faceting.get_facet('cat').facet_values.each do |firm|

  yearlybudget = firm.getChildren.first.value
end

series << "\{\"yearlybudget\":#{yearlybudget.round(2)}"
filterstring112 = nil
if filterstring1.nil?
  filterstring112 = field("matter_number").contains(matter_number)
else
  filterstring112 = filterstring1.and(field("matter_number").contains(matter_number))

end
matterperiodspend = 0
entity_type("Analysis_Matrix").where(filterstring112).faceted_by(field("matter_number").with_facet_id("cat").then(sum(xpath('$net_amt')).with_facet_id('kpi_id')
)).faceting.get_facet('cat').facet_values.each do |firm|

  matterperiodspend = firm.getChildren.first.value
end
if yearlybudget == 0
  series << "\,\"yearlybudgetpercentspent\":0\}"
else

series << "\,\"yearlybudgetpercentspent\":#{((matterperiodspend/yearlybudget)*100).round(2)}\}"

end
else
  avgcaselength = 0
entity_type("Matter_Details").where(filterstring.and(field("matter_number").contains(matter_number))).faceted_by(field("matter_number").with_facet_id("cat").then(avg(xpath('$case_length')).with_facet_id('kpi_id')
)).faceting.get_facet('cat').facet_values.each do |firm|

  avgcaselength = firm.getChildren.first.value
end

series << "\{\"avgcaselength\":#{avgcaselength.round(2)}\}"
end

series.gsub!('NaN','0')


series
