stringtest = {}
#facet1 = field('itemnumber').with_facet_id('randomid').without_pruning
#facet2 = field("anom_desc").with_facet_id('anomdesc').without_pruning
entity_type("Invoice_Line_Item_Anomalies").where(field('invoice_id').contains(params[:invoiceid]).and(field('invoice_lineitem_number').contains(params[:linenumber]))).to_json
