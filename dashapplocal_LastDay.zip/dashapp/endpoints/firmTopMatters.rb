data = {}
data1 = {}
data2 = {}
category = params[:category]
subcategory = params[:subcategory]
categoryvalue = params[:categoryvalue]
selectedkpi = params[:selectedkpi].split(",")
filters = params[:filters].split(",")
sortbyfield = params[:sortbyfield].split(':')
sortbystring = field(sortbyfield[0])
filterstring1 = nil
filterstring =nil
datefilter = params[:datefilter].split("-")
noofresults = params[:noofresults]
pagesize = 10

def getFilterString( filters)
  filterstring = nil
  if !filters.nil?
    if filters.any?
		  filters.each do |filterwhole|
		    filtername = filterwhole.split(">>")[0]
		    filtervalue = filterwhole.split(">>")[1].split("||")
		    internalfilterstring = nil
        if filtervalue.any?
          filtervalue.each do |filtereach|
			      if internalfilterstring.nil?
          		internalfilterstring = field(filtername).contains(filtereach)
          	else
          		internalfilterstring = internalfilterstring.or(field(filtername).contains(filtereach))
          	end
	        end
        end
        filterstring = internalfilterstring
      end
    end
  end
  return filterstring
end

if noofresults != nil
 pagesize = noofresults.to_i
end

if subcategory.include? "item_date"
  facet_by_subcategory =  xpath("viv:format-date($item_date,'%m/%d/%Y')").with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
else
  facet_by_subcategory =  field(subcategory).with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning.then(field("matter_name").with_facet_id('matter_name').with_maximum_facet_values_of(-1).without_pruning)
end



facet_by_kpi1 = sum(xpath('$'+selectedkpi[0])).with_facet_id('kpi_id1')

if category == "full_name"
 facet_by_kpi2 = sum(xpath('$'+selectedkpi[1])).with_facet_id('kpi_id2')
end

facet_by_phase = field('phase').with_facet_id('phase').with_maximum_facet_values_of(-1).without_pruning

facet_by_case_length = field('case_length').with_facet_id('case_length').with_maximum_facet_values_of(-1).without_pruning

filterstring = field(category).contains(categoryvalue)
filterstring1 = field(category).contains(categoryvalue)
filterforphase = nil
paramfilterstring = getFilterString(filters)
filterforphase = paramfilterstring
if !paramfilterstring.nil?
  filterstring = filterstring.and(paramfilterstring)
end

#categoryfilterstring+filterstring

  if datefilter.any?
      dateStart = datefilter[0].split("/")
      actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

      dateEnd = datefilter[1].split("/")
      actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)

    filterstring1 = filterstring1.and(field("date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("date").isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
  filterstring = filterstring.and(field("item_date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("item_date").isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))

    if filterforphase.nil?
      filterforphase = field("invoice_date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java).and(field("invoice_date").isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
    else
      filterforphase = filterforphase.and(field("invoice_date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("invoice_date").isGreaterThanOrEqual(actualStartDate.to_time.to_i.to_java))
    end

   end

facets = entity_type('Analysis_Matrix').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_case_length)).faceting


facets.get_facet('subcategory_id').facet_values.each do |matter_id|
  matter_id.get_facet('matter_name').facet_values.each do |matter_name|
    matter_name.get_facet('case_length').facet_values.each do |case_length|
      data[matter_id.value + "||" + matter_name.value] =  case_length.value
    end
  end
end


facets = entity_type('Analysis_Matrix').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_kpi1)).faceting

facets.get_facet('subcategory_id').facet_values.each do |matter_id|
  matter_id.get_facet('matter_name').facet_values.each do |matter_name|
    data2[matter_id.value + "||" + matter_name.value] = matter_name.getChildren[0].value.to_s
  end
end
datatimekeeper = {}
if category == "full_name"
 facets = entity_type('Analysis_Matrix').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_kpi2)).faceting

facets.get_facet('subcategory_id').facet_values.each do |matter_id|
  matter_id.get_facet('matter_name').facet_values.each do |matter_name|
    datatimekeeper[matter_id.value + "||" + matter_name.value] = firm.getChildren[0].value.to_s
  end
end
end

dormancydays = {}
facets = entity_type('Matter_Dormancy_Time').where(filterstring1).faceted_by(facet_by_subcategory.then(avg(xpath('$dormancy_days')).with_facet_id('dormancy_days'))).faceting
facets.get_facet('subcategory_id').facet_values.each do |matter_id|
  matter_id.get_facet('matter_name').facet_values.each do |matter_name|
  days = matter_name.getChildren.first.value.to_i
  if days < 0
  dormancydays[matter_id.value + "||" + matter_name.value] = 0
  else
    dormancydays[matter_id.value + "||" + matter_name.value] = days
  end
  end
end



datatoshow = {}
if category.eql?("firm_id")
if sortbyfield[0].eql? ("net_amt")
  datatoshow = data2
elsif sortbyfield[0].eql? ("dormancy_days")
  datatoshow = dormancydays
else
  datatoshow = data
end
else
  datatoshow = data2
end

datatoshow = datatoshow.sort_by {|k,v| v.to_f}.reverse

series = "["
datatoshow.each_with_index do |(key, val), i|
  key = key.gsub /"/, ''
  if i < pagesize
    if category == "full_name"
      series << "\{\"name\":\"#{key.split("||")[0]}\",\"hours\": \"#{data2[key]}\",\"net_amt\": \"#{datatimekeeper[key]}\"\},"
    else
      if subcategory == "matter_number"
     if filterforphase.nil?
       matterInvoicesJson = entity_type('Invoice_List').where(field("matter_number").is(key.split("||")[0])).sorted_by(field("invoice_date").in_descending_order).requesting(1).to_json
     else
       matterInvoicesJson = entity_type('Invoice_List').where(filterforphase.and(field("matter_number").is(key.split("||")[0]))).sorted_by(field("invoice_date").in_descending_order).requesting(1).to_json
     end
    # series << matterInvoicesJson.to_s
     matterInvoices = JSON.parse(matterInvoicesJson)

     latestInvoiceId =  matterInvoices[0]["properties"]["invoice_id"][0]

     #series << latestInvoiceId
     if filterforphase.nil?
     lineItemCount =   entity_type('Analysis_Matrix').where(field("invoice_id").is(latestInvoiceId).and(field("phase").contains("E100").negated.and(field("phase").contains("E200").negated))).total_results
     else
        lineItemCount =   entity_type('Analysis_Matrix').where(filterforphase.and(field("invoice_id").is(latestInvoiceId).and(field("phase").contains("E100").negated.and(field("phase").contains("E200").negated)))).total_results
     end
     if(lineItemCount > 0)
            if filterforphase.nil?
       phaseFacets = entity_type('Analysis_Matrix').where(field("invoice_id").is(latestInvoiceId).and(field("phase").contains("E100").negated.and(field("phase").contains("E200").negated))).faceted_by(facet_by_phase.then((sum(xpath('$hours'))).with_facet_id("phase_hours"))).faceting

            else
               phaseFacets = entity_type('Analysis_Matrix').where(filterforphase.and(field("invoice_id").is(latestInvoiceId).and(field("phase").contains("E100").negated.and(field("phase").contains("E200").negated)))).faceted_by(facet_by_phase.then((sum(xpath('$hours'))).with_facet_id("phase_hours"))).faceting
            end

       #series << phaseFacets.to_s
       phase = ''
       phaseHours = 0
       phaseFacets.get_facet("phase").facet_values.each do | phaseHour |
         totalPhaseHours = phaseHour.getChildren.first.value
         #series << phaseHour.value + '::'+ totalPhaseHours.to_s
         if(totalPhaseHours > phaseHours)
           phase = phaseHour.value
           phaseHours = totalPhaseHours
         end
       end

       #invoiceLineItems = JSON.parse(invoiceLineItemPhaseJson)

       #phase = invoiceLineItems[invoiceLineItems.length-1]["properties"]["phase"][0]
       #if phase.slice(0) != 'L'
       #  phase = invoiceLineItems[invoiceLineItems.length-2]["properties"]["phase"][0]
       #end
     end
     #series << "\{\"name\":\"#{key}\",\"phase\": \"#{data1[key]}\","
        series << "\{\"name\":\"#{key.split("||")[0]}\",\"phase\": \"#{phase}\",\"matter_name\": \"#{key.split("||")[1]}\","
   else
   series << "\{\"name\":\"#{key}\", "
   end
     series << "\"caselength\":"
    series << "\""+data[key] + "\","
      series << "\"dormancy_days\":"
    series << "\""+dormancydays[key].to_s + "\","
      series << "\"spending\": \""
    series << data2[key]
    series <<  "\"\},"
   end
  end
  end

series << "{\"total\": \"#{pagesize}\"}"
series << "]"
#series.gsub!(\\"Skip\\", "Skip")
series.html_safe
