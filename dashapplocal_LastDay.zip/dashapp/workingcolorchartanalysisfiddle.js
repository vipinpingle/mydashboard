Highcharts.setOptions({
			colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D']
		});
var rawdata = [{"name":"L160","data":[5485.5,2710]},{"name":"L120","data":[2467,9650]},{"name":"NA","data":[2300.56,2896.9]},{"name":"L310","data":[2178,1182.5]},{"name":"L210","data":[1909,4425]},{"name":"L240","data":[716,15775]},{"name":"L320","data":[600,2321]},{"name":"L230","data":[500,542.5]},{"name":"L330","data":[215,1032.5]},{"name":"L250","data":[180,0]},{"name":"L150","data":[100,0]},{"name":"L440","data":[0,2905]},{"name":"L110","data":[0,776]},{"name":"L410","data":[0,507.5]},{"name":"L130","data":[0,472.5]},{"name":"L340","data":[0,245]},{"name":"L430","data":[0,87.5]},{"name":"L420","data":[0]}]


// select this unique values based on category selected.
var filterData = [];
var colorIndex = 0;
var retVal = {};
var myd = [];
var colorIndex = 0;
angular.forEach(rawdata, function(element, index) {
	//	console.log(element);
 	var tmp1 = "";
   angular.forEach(element, function(el, index) {
                 // console.log(index);
                  if(index === "data") {
                  //  console.log(el.length);
                    for(j=0;j<el.length;j++){
                    	tmp1 = getData(element,j,colorIndex);
                      console.log(tmp1);
                      myd.push(tmp1);
                    }
                  }
     });
     colorIndex = colorIndex + 1;
     if(colorIndex > 19){
     colorIndex = 0;
     }
 });
// console.log(JSON.stringify(myd));
 var retVal = myd.map(function(each){
    return JSON.parse(each)
  });

  var sortedFilterData = retVal.sort(function(a,b) {
 		return b.data[0].y-a.data[0].y;
});
//console.log(JSON.stringify(sortedFilterData));
function getData(mydat,k){
//console.log("k=" + k);
	var retMyTmp = [];
  var newTmpFormat = "";
  var newFinal = "";
  angular.forEach(mydat, function(el1, index1) {
   var temp = [];
   if(index1 === "data"){
   temp = [];
   temp.push('[{"x":'+ parseInt(k) + ',"y":' + el1[k] + '}]');
   	retMyTmp += '"' + index1 + '":' + temp + '';

   } else {
    retMyTmp += '"' + index1 + '":"' + el1 + '",';
   }

});
	retMyTmp += ',"color":"' + Highcharts.getOptions().colors[colorIndex] + '"';
	 newFinal = "{" + retMyTmp + "}";
   return newFinal;

}

Highcharts.chart('container', {
    chart: {
        type: 'column'
    },
    title: {
        text: 'Stacked column chart'
    },
    xAxis: {
        categories: ['Cantrell, Strenski &amp; Mehringer, LLP', 'Kightlinger &amp; Gray']
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Total fruit consumption'
        },
        stackLabels: {
            enabled: true,
            style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
            }
        }
    },
    legend: {
        align: 'right',
        x: -30,
        verticalAlign: 'top',
        y: 25,
        floating: true,
        backgroundColor: (Highcharts.theme && Highcharts.theme.background2) || 'white',
        borderColor: '#CCC',
        borderWidth: 1,
        shadow: false
    },
    tooltip: {
        headerFormat: '<b>{point.x}</b><br/>',
        pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
    },
    plotOptions: {
        column: {
            stacking: 'normal',
            dataLabels: {
                enabled: true,
                color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
            }
        }
    },
    series: sortedFilterData
});
