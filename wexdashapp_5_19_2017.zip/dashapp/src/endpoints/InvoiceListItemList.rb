noofresults = params[:noofresults].to_i
pagenumber= params[:pagenumber].to_i
searchstring= params[:searchstring]
sortbyfield = params[:sortbyfield]
whereclause = nil
sortbystring = field(sortbyfield)
returntype = params[:returntype]
returnstring = nil
test = {}
matternumber = params[:matternumber]
if matternumber != ""
  if searchstring != ""
    whereclause = field("matternumber").contains(matternumber).and(field("mattername").contains(searchstring).or(field("invoiceid").contains(searchstring)).or(field("firmname").contains(searchstring)).or(field("matternumber").contains(searchstring)))

  else
    whereclause = field("matternumber").contains(matternumber)
  end
else
  if searchstring != ""
  whereclause = field("invoiceid").contains(params[:invoiceid]).and(field("mattername").contains(searchstring).or(field("invoiceid").contains(searchstring)).or(field("firmname").contains(searchstring)).or(field("matternumber").contains(searchstring)))

  else
  whereclause = field("invoiceid").contains(params[:invoiceid])
  end
end


totalresults = entity_type('Analysis').where(whereclause).total_results

startingwith = (pagenumber-1)*noofresults
if pagenumber==1
  startingwith = 0
end

returnstring = entity_type('Analysis').where(whereclause).starting_at(startingwith).sorted_by(sortbystring).requesting(noofresults).to_json


rb_hash = JSON.parse(returnstring)

rb_hash.each do |lineitem|
  invoiceid = params[:invoiceid].to_s
  linenumber = lineitem["properties"]["itemnumber"]

  lineitemanomaly = endpoint("getLineItemAnomaly", invoiceid: invoiceid, linenumber: linenumber[0])
  lineitemhash = JSON.parse(lineitemanomaly)
  anomalyrray = []
  lineitemhash.each do |anomalylinetime|
    if anomalylinetime["properties"]["AnomalyCount"] != nil
      if anomalylinetime["properties"]["AnomalyCount"][0] == "NA"

      else

        anomalyrray << {anomalycount: anomalylinetime["properties"]["AnomalyCount"][0], anomalydesc: anomalylinetime["properties"]["anom_desc"][0]}

      end
    else
      #anomalyrray <<
    end

  lineitem["anomaly"] = anomalyrray
  end
end

rb_hash << {total: totalresults}


rb_hash.to_json
