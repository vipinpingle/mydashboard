
<script type="text/javascript">

  var app = angular.module('wexdashboard', ['angularUtils.directives.dirPagination','InvoiceDataService','ui.bootstrap','ui.tree','wexdashboard.directives','wexdashboard.services']);
  app.controller('InvoiceController',['$scope','$http','invoiceService',function($scope, $http,invoiceService) {

  // variable for pagination calls
  $scope.numberOfResults = "10";
  $scope.pageNumber = "1";
  $scope.pageNumI = "1";
  $scope.searchItem = "";
  $scope.sortByField = "invdate";
  $scope.sortByFieldLabel = "Date";
  $scope.totalPageCount = "";
  $scope.totalPageLineItemCount = "";
  $scope.invList = "";
  $scope.showinvdetails = false;
  $scope.invoiceLineItems = [];
  $scope.sortType = 'id';
  $scope.sortReverse = false;
  $scope.searchItem = '';
  $scope.selectedInvoiceIdLineItem = "";
  $scope.sortLineItemByType = "itemnumber";
  $scope.filterByMatterNumber = "";
  $scope.highlighted="";
  $scope.invsortList = [
      {name : "Date", value : "invdate"},
      {name : "Matter Name", value : "mattername"},
      {name : "Matter Number", value : "matternumber"},
      {name : "Firm Name", value : "firmname"}
  ];


$scope.ytdList = [
    {name : "2016", value : "01/01/2016-12/31/2016"},
    {name : "2015", value : "01/01/2015-12/31/2015"}
];
$scope.topspendingyearselected = $scope.ytdList[0].name;
$scope.tophoursbilledyearselected = $scope.ytdList[0].name;
$scope.topviolationsyearselected = $scope.ytdList[0].name;

  $scope.topspendingyearFilter = function() {
    if($scope.topspendingyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.topspendingyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadSpendingBudgetData($scope.selectedstateCode,selectedValue);
  }

  $scope.tophoursbilledyearsFilter = function() {
    if($scope.tophoursbilledyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.tophoursbilledyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadTopHoursBilledExpenditureData($scope.selectedstateCode,selectedValue);
  }

  $scope.topviolationssyearsFilter = function() {
    if($scope.topviolationsyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.topviolationsyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadTopFirmViolationsData($scope.selectedstateCode,selectedValue);
  }
  function init() {
    getInvoiceListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);

  }
    function getInvoiceListData(numResults,pageNum,searchStr,sortByType){
    		  invoiceService.getInvoiceListServiceData(numResults,pageNum,searchStr,sortByType)
                .then(
                  function( mydata ) {
    			             $scope.invList = mydata;
                    //   console.log("returned data = " + JSON.stringify(mydata));
                       $scope.totalPageCount = mydata[numResults].total;
                    //   console.log("total page count returned" + $scope.totalPageCount);
    				    });
            };

     //calling the next page data for invoice list items
     $scope.getNextPageInvoiceData = function(pageNumber) {
      //  console.log("Calling next page data with number = " + pageNumber);
        console.log("next page sortby = " + $scope.sortByField);
        $scope.pageNumberLineitem = pageNumber;
        getInvoiceListData($scope.numberOfResults,pageNumber,$scope.searchItem,$scope.sortByField);
      //  console.log("Calling next page data ended ");
     }

     //calling the search for invoice list
     $scope.getSearchedData = function(searchedString) {
      //  $scope.searchItem = searchedString
        getInvoiceListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
     }
     //calling the sort for invoice list
     $scope.getInvListSorted = function(item) {
        console.log("sorting the field = " + item.name);
        $scope.sortByField = item.value;
        getInvoiceListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
        $scope.sortByFieldLabel = item.name;
     }

    //calling the search for line items based on matter
    $scope.getSearchedLineItemsForMatter = function(mtnumber) {
        console.log("Calling the backend with data for mtnumber = " + mtnumber);
      //   var sortLineItemType = "itemnumber"
      //   console.log("calling getInvoiceLineItemsList function on click with invoiceId = " + item.properties.matternumber);
         var searchLineItem = "";
          $scope.filterByMatterNumber = mtnumber;
          getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResults,$scope.pageNumI,searchLineItem,$scope.sortLineItemByType);
    }

    // sorting invoice details table

    $scope.sortInvDetailTable = function(selectedFieldForSorting) {
       var searchLineItem = "";
       $scope.sortLineItemByType = selectedFieldForSorting;
       $scope.reverseSort=($scope.sortLineItemByType == selectedFieldForSorting)?
        ! $scope.reverseSort:false;
       console.log("selectedFieldForSorting = " + selectedFieldForSorting);
       getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResults,$scope.pageNumI,searchLineItem,$scope.sortLineItemByType);

    }

        $scope.getSortClass = function(selectedFieldForSorting) {
     if ($scope.sortLineItemByType == selectedFieldForSorting) {
       return $scope.reverseSort
       ?'arrow-down'
       :'arrow-up';
     }
      return'';
    }

    //calling the next page for invoicelineitems data
    $scope.getNextPageInvoiceLineItems = function(pageNumLineItem) {
       var searchLineItem = "";
    //   var sortLineItemType =  "itemnumber";
       $scope.pageNumI = pageNumLineItem;
       getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResults,$scope.pageNumI,searchLineItem,$scope.sortLineItemByType);
    }

      // Line itmes details call
    $scope.getInvoiceLineItemsList = function(item) {
        console.log("calling getInvoiceLineItemsList function on click with invoiceId = " + item.properties.invoiceid);

        //$scope.selectedInvoiceid = "338518"; // hardcoded for anomalies testing purpose.
        var pageNumI = $scope.pageNumI = "1";
        var searchStrI = "";
        var sortByTypeI = "itemnumber";//$scope.sortLineItemByType;// ;
        $scope.highlighted="highlighted";
        console.log("I am calling invoice list now " + pageNumI + ", " + searchStrI + "," + sortByTypeI);
        getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResults,pageNumI,searchStrI,sortByTypeI)
        $scope.show_firmDetailView = true;
        console.log("showinvdetails " + $scope.showinvdetails);
    }

    // Callback function to retrieve data for invoicelineitem details.
     function getInvoiceLineItemsData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType){
          invoiceService.getInvoiceLineItemsServiceData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType)
                 .then(
                   function( mydata ) {
                       $scope.invoiceLineItems = mydata;
                    //   $scope.sortLineItemByType = "itemnumber";
                       $scope.totalPageLineItemCount = mydata[numResults].total;
                });
        };

    init();
}]);


  //Highcharts Column Template
  // Create the chart

Highcharts.chart('topspendingcontainer', {
    chart: {
        type: 'column'
    },
    xAxis: {
        type: 'category',
        labels: {
      	 enabled: false
   		}
    },
    yAxis: {
     gridLineWidth: 0,
     minorGridLineWidth: 0,
     labels: {
       enabled: false
   		}
    },
    credits: {
        enabled: false
    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            pointPadding: 0,
            groupPadding: 0,
            colors: ['#c31820', '#cbcbcb'],
            dataLabels: {
                        enabled: true,
                        color: '#FFFFFF',
                        style: {
                        	fontWeight: 'bolder',
                          textOutline: false,
                          },
                        inside: true,
      }
        },
                  column: {
                maxPointWidth: 70
            }
    },
    title: {
    text: null
		},
    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
    },
    series: [{
        name: 'Brands',
        colorByPoint: true,
        data: [{
            name: 'Microsoft Internet Explorer',
            y: 56.33
            }, {
            name: 'Chrome',
            y: 24.03
        }]
    }],
});

Highcharts.chart('tophoursbilledcontainer', {
    chart: {
        type: 'column'
    },
    xAxis: {
        type: 'category',
        labels: {
      	 enabled: false
   		}
    },
    yAxis: {
     gridLineWidth: 0,
     minorGridLineWidth: 0,
     labels: {
       enabled: false
   		}
    },
    credits: {
        enabled: false
    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            pointPadding: 0,
            groupPadding: 0,
            colors: ['#c31820', '#cbcbcb'],
            dataLabels: {
                        enabled: true,
                        color: '#FFFFFF',
                        style: {
                        	fontWeight: 'bolder',
                          textOutline: false,
                          },
                        inside: true,
      }
        },
                  column: {
                maxPointWidth: 70
            }
    },
    title: {
    text: null
		},
    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
    },
    series: [{
        name: 'Brands',
        colorByPoint: true,
        data: [{
            name: 'Microsoft Internet Explorer',
            y: 56.33
            }, {
            name: 'Chrome',
            y: 24.03
        }]
    }],
});


  Highcharts.chart('topviolationscontainer', {
    chart: {
        type: 'column'
    },
    xAxis: {
        type: 'category',
        labels: {
      	 enabled: false
   		}
    },
    yAxis: {
     gridLineWidth: 0,
     minorGridLineWidth: 0,
     labels: {
       enabled: false
   		}
    },
    credits: {
        enabled: false
    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            pointPadding: 0,
            groupPadding: 0,
            colors: ['#c31820', '#cbcbcb'],
            dataLabels: {
                        enabled: true,
                        color: '#FFFFFF',
                        style: {
                        	fontWeight: 'bolder',
                          textOutline: false,
                          },
                        inside: true,
      }
        }
    },
    title: {
    text: null
		},
    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
    },
    series: [{
        name: 'Brands',
        colorByPoint: true,
        data: [{
            name: 'Microsoft Internet Explorer',
            y: 56.33
            }, {
            name: 'Chrome',
            y: 24.03
        }]
    }],
});


 //Highcharts Highest Billihng Anomalies Template
  // Create the chart

Highcharts.chart('highestanomaliescontainer', {
    chart: {
        type: 'column'
    },
    xAxis: {
        type: 'category',
        labels: {
      	 enabled: true
   		}
    },
    yAxis: {
     gridLineWidth: 0,
     minorGridLineWidth: 0,
     labels: {
       enabled: true
   		}
    },
    credits: {
        enabled: false
    },
    legend: {
        enabled: false
    },
    plotOptions: {
        series: {
            borderWidth: 0,
            pointPadding: 0,
            groupPadding: 0.2,
            colors: ['#c31820'],
            dataLabels: {
                        enabled: true,
                        color: '#FFFFFF',
                        style: {
                        	fontWeight: 'bolder',
                          textOutline: false,
                          },
                        inside: true,
      }
        },
                  column: {
                maxPointWidth: 70
            }
    },
    title: {
    text: null
		},
    tooltip: {
        headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
        pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
    },
    series: [{
        name: 'Brands',
        colorByPoint: true,
        data: [{
            name: 'Gartner, Leavenworth, Mills and Schmidt',
            y: 56.33
        }, {
            name: 'Shane Smith Atty',
            y: 34.03
        }, {
            name: 'Cantor-Williams',
            y: 30.38
        }, {
            name: 'Lanter, Davis, Shotenstein, Williams and Brandywine',
            y: 24.77
        }, {
            name: 'Mills, Stipe, Buck, and Bailey',
            y: 30.91
        }]
    }],
});

     $( window ).load(function() {
    chart.reflow();
});

//DataService containing all the data calls from backend.

	var InvoiceDataService = angular.module('InvoiceDataService', [])
      .service('invoiceService', function ($http,$q) {

      // Service method to get the invoice listing
      // Return service methodes.
      return({
            getInvoiceListServiceData: getInvoiceListServiceData,
            getInvoiceLineItemsServiceData: getInvoiceLineItemsServiceData
      });

      // start call to get invoice list service data
      function  getInvoiceListServiceData(numResultsS,pageNumS,searchStrS,sortByTypeS) {
       var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/InvoiceList",
      			        params: {
                              noofresults: numResultsS,
                              pagenumber: pageNumS,
                              searchstring: searchStrS,
                              sortbyfield: sortByTypeS
      				        }
              });
            return(request.then( handleSuccess, handleError ) );
      		}

          // start call to get invoice list service data
          function  getInvoiceLineItemsServiceData(invoiceIdL,matterNumberL,numResultsL,pageNumL,searchStrL,sortByTypeL) {

            console.log("Passing parameters in getInvoiceLineItemsServiceData " + "invoiceIdL = " + invoiceIdL + " matterNumberL = " + matterNumberL + " numResultsL = "
            + numResultsL + " pageNumL = " + pageNumL + " searchStrL = " +searchStrL + " sortByTypeL = " + sortByTypeL);
           var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/InvoiceListItemList",
          			        params: {
                                  invoiceid: invoiceIdL,
                                  matternumber: matterNumberL,
                                  noofresults: numResultsL,
                                  pagenumber: pageNumL,
                                  searchstring: searchStrL,
                                  sortbyfield: sortByTypeL,

          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
          		}

      // Common method to handle the request from the server
      function handleError( response ) {
          if (
              ! angular.isObject( response.data ) ||
              ! response.data.message
              ) {
              return( $q.reject( "An unknown error occurred." ) );
          }
          return( $q.reject( response.data.message ) );
      }
      function handleSuccess( response ) {
		  return( response.data);
      }
	   // end call to get data from service.


	  });

(function() {
    console.clear();
'use strict';
angular.module('wexdashboard')

.controller('firmdrilldowncontroller', function($scope,$timeout,HierarchyNodeService) {

    //console.log(HierarchyNodeService);
    var dList = [];

    currentYear = moment().format("YYYY");
    for( i = 0 ; i < 3; i++)
    {
            var item = new Object();
            item.id = (currentYear - i)+"-01-01" + "::" + moment((currentYear - i)+"-01-01").endOf("year").format("YYYY-MM-DD");
            item.title = (currentYear - i);
            item.items = [];
            for(j = 1 ; j < 12; j+=3)
            {
                    qDateStr = (currentYear - i)+"-0"+j +"-01";
                    if(moment().fquarter(1).start > moment(qDateStr).fquarter(1).start)
                    {
                            var qItem = new Object();
                            qItem.id = moment(qDateStr).fquarter(1).start +"::"+ moment(qDateStr).fquarter(1).end;
                            qItem.title = moment(qDateStr).fquarter(1).toString();
                            qItem.items = [];
                            for(k = j ; k < j+3; k++)
                            {
                                    var mItem = new Object();
                                    startDateStr = "";
                                    if(k < 10)
                                    {
                                            startDateStr = (currentYear - i)+"-0"+k +"-01";
                                        }
                                        else
                                        {
                                                startDateStr = (currentYear - i)+ "-" + k +"-01";
                                        }
                                        console.log(startDateStr);
                                        mItem.id = moment(startDateStr).format("YYYY-MM-DD") +"::"+ moment(startDateStr).endOf("month").format("YYYY-MM-DD");
                                        mItem.title = moment(startDateStr).format("MMM");
                                    qItem.items.push(mItem)
                            }
                            item.items.push(qItem)
                    }
            }
            dList.push(item);
    }
    console.log(JSON.stringify(dList));
    $scope.baseList = dList;
    $scope.list = $scope.baseList;

})
.directive('indeterminateCheckbox',function(HierarchyNodeService) {
    return {
        restrict:'A',
        scope: {
          node:'='
        },
        link: function(scope, element, attr) {

            scope.$watch('node',function(nv) {

                var flattenedTree = HierarchyNodeService.getAllChildren(scope.node,[]);
                flattenedTree = flattenedTree.map(function(n){ return n.isSelected });
                var initalLength = flattenedTree.length;
                var compactedTree = _.compact(flattenedTree);

                var r = compactedTree.length > 0 && compactedTree.length < flattenedTree.length;
                element.prop('indeterminate', r);

            },true);

        }
    }
})

})();

</script>
