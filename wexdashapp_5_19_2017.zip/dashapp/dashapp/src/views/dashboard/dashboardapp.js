var app = angular.module('wexdashboard', ['datamaps','DataService','ui.router','ui.bootstrap','ui.tree','wexdashboard.directives','wexdashboard.services']);
  app.config(function($stateProvider, $urlRouterProvider) {
  $urlRouterProvider.otherwise('all');
  $stateProvider
  .state('allstate', {
    url: '/all',
    templateUrl:'/AppBuilder/dashapp/src/views/dashboard/dashboardview.html',
    controller: 'MainController'
  })
});

app.controller('MainController', ['$scope','$state','billingService',function($scope,$state,billingService){

function getStateMapCoordinates(stateM) {
var centerS = "";
var scaleS = "";
// center is always longitude, latitude
var statemapcoordinates = {"TX": {"center": [-95, 31],"scale": 1400},"IN": {"center": [-81, 40],"scale": 3500}};
   angular.forEach(statemapcoordinates, function(value, key) {
       if(key==stateM) {
         centerS = value.center;
         scaleS = value.scale;
       }
    });
    return {
      'projectcenter': centerS,
      'projectscale': scaleS
    };
};
$scope.selectedmapState = "All";
$scope.selectedstateCode = "";
$scope.spendingHours = "";
$scope.billedHours = "";
$scope.violationHours = "";
$scope.topTrackedMatters = "";
$scope.topStateExpenditureData = "";
$scope.topFirmAnomaliesData = "";
$scope.dataSpendingByBudgetLoaded = false;
$scope.dataHoursBilledLoaded = false;
$scope.dataViolationsLoaded = false;
$scope.dataTrackedMattersLoaded = false;
$scope.dataTopExpendituresLoaded = false;
$scope.dataTopAnamoliesLoaded = false;
$scope.filterDefaultDate = "01/01/2016-12/31/2016";
$scope.billingHoursDefaultDate = "01/01/2016-12/31/2016";
$scope.violationHoursDefaultDate = "01/01/2016-12/31/2016";
var spendingHoursCurrencyFormat = d3.format("$,.3s");
$scope.sortDateKey = "";
$scope.selectValueDisplay = "Year";
var dList = getDateList();
$scope.list  = dList;
$scope.categories = [];
$scope.billcategories = [];
$scope.violationcategories = [];

$scope.setPeriod = function(selectedDate)
{
    if(selectedDate != "") {
      $scope.filterDefaultDate = selectedDate;
      $scope.sortDateKey = "";
      $scope.billingHoursDefaultDate = getSelectedFilterDate(selectedDate,$scope.sortDateKey);
      console.log("$scope.filterDefaultDate = " + $scope.filterDefaultDate);
      console.log("*********Loading of new view ends************");
      loadSpendingBudgetData($scope.selectedstateCode,$scope.filterDefaultDate);
      loadBillingHoursData($scope.selectedstateCode,$scope.billingHoursDefaultDate);
      loadVoilationData($scope.selectedstateCode,$scope.billingHoursDefaultDate);
      //loadVoilationData($scope.selectedstateCode,$scope.violationHoursDefaultDate);
      loadTrackedMattersData($scope.selectedstateCode,$scope.filterDefaultDate);
      loadTopFirmExpenditureData($scope.selectedstateCode,$scope.filterDefaultDate);
      loadTopFirmAnamoliesData($scope.selectedstateCode,$scope.filterDefaultDate);
      console.log("*********Loading of new view ends************");
      $scope.show_DropDown = false;
      for(i=0;i<=$scope.list.length;i++) {
        if($scope.list[i].id == selectedDate) {
          console.log("************* list = " + JSON.stringify($scope.list[i].id));
          console.log("************* list = " + JSON.stringify($scope.list[i].title));
          $scope.selectValueDisplay = $scope.list[i].title;
        }
      }
    } else {
      console.log("====view by event is not fired====");
    }
}

function getSelectedFilterDate(selectedDateRange,sortDateKey) {
  var dataForFilter = [];
  var tmpDate = selectedDateRange.split('-'),
  fromDate = "",toDate="",duration="",newFilteredRange="",finalDateRange="",tmpfromdate="";
  fromDate = moment(tmpDate[0], 'MM/DD/YYYY');
  toDate =  moment(tmpDate[1], 'MM/DD/YYYY');
  duration = toDate.diff(fromDate, 'days')
  if(duration <=31) {
    tmpfromdate = moment(fromDate).subtract('month',1).format('MM/DD/YYYY')
    if(sortDateKey == "") {
      console.log("sortDateKey = " + sortDateKey);
      newFilteredRange = tmpfromdate + "-" + moment(toDate, 'MM/DD/YYYY').format('MM/DD/YYYY');
    } else {
      dataForFilter.push(tmpfromdate);
      dataForFilter.push(moment(tmpfromdate).endOf('month').format('MM/DD/YYYY'));
      dataForFilter.push(moment(fromDate, 'MM/DD/YYYY').format('MM/DD/YYYY'));
      dataForFilter.push(moment(toDate, 'MM/DD/YYYY').format('MM/DD/YYYY'));
    }
  }
  else if(duration > 31  && duration <=90) {
    tmpfromdate = moment(fromDate).subtract('month',3).format('MM/DD/YYYY')
    if(sortDateKey == "") {
      newFilteredRange = tmpfromdate + "-" + moment(toDate, 'MM/DD/YYYY').format('MM/DD/YYYY');
    } else {
      dataForFilter.push(tmpfromdate);
      dataForFilter.push(moment(tmpfromdate).endOf('quarter').format('MM/DD/YYYY'));
      dataForFilter.push(moment(fromDate, 'MM/DD/YYYY').format('MM/DD/YYYY'));
      dataForFilter.push(moment(toDate, 'MM/DD/YYYY').format('MM/DD/YYYY'));
    }
  } else {
      tmpfromdate = moment(fromDate).subtract('year',1).format('MM/DD/YYYY')
      if(sortDateKey == "") {
      console.log("sortDateKey = " + sortDateKey);
      newFilteredRange = tmpfromdate + "-" + moment(toDate, 'MM/DD/YYYY').format('MM/DD/YYYY'); //selectedDateRange;
    } else {
      dataForFilter.push(tmpfromdate);
      dataForFilter.push(moment(tmpfromdate).endOf('year').format('MM/DD/YYYY'));
      dataForFilter.push(moment(fromDate, 'MM/DD/YYYY').format('MM/DD/YYYY'));
      dataForFilter.push(moment(toDate, 'MM/DD/YYYY').format('MM/DD/YYYY'));
    }
  }
  console.log("getSelectedFilterDate = " + newFilteredRange);
  console.log("dataForFilter = " + dataForFilter);
  if(sortDateKey == "") {
    return newFilteredRange;
  }
  else {
    return dataForFilter;
  }

}

function getDateLabels(startDate,endDate) {
  var fromDate = "",toDate="",diff="",labelChart = [];
  fromDate = moment(startDate, 'MM/DD/YYYY');
  toDate =  moment(endDate, 'MM/DD/YYYY');
  diff = toDate.diff(fromDate, 'days')
  console.log("diff = " + diff);
  if(diff >=364){
    console.log("Generate year labels" + moment(toDate).format("[FY] YYYY"));
  //  console.log("Generate year labels" + moment(fromDate).format("[FY] YYYY"));
    labelChart.push(moment(toDate).format("[FY] YYYY"));
    //labelChart.push(moment(fromDate).format("[FY] YYYY"));
  }
  if(diff <=31) {
    console.log("Generate month labels" + moment(toDate).format("MMM YYYY"));
  //  console.log("Generate month labels" + moment(fromDate).format("MMMM YYYY"));
    labelChart.push(moment(toDate).format("MMM YYYY"));
   // labelChart.push(moment(fromDate).format("MMMM YYYY"));
  }
  else if(diff > 31) {
    console.log("Generate quarter labels" + moment(toDate).format("[Q]Q YYYY"));
  //  console.log("Generate quarter labels" + moment(fromDate).format("[Q]Q YYYY"));
    labelChart.push(moment(toDate).format("[Q]Q YYYY"));
    //labelChart.push(moment(fromDate).format("[Q]Q YYYY"));
  }
  return labelChart;
}

// get the view by date calculation
function getDateList()
{
var dList = [];
currentYear = moment().format("YYYY")-1;
console.log("getDateList currentYear = " + currentYear);
for( i = 0 ; i <2; i++)
{
	var item = new Object();
	item.id = "01/01/" +(currentYear - i) + "-" + moment("01/01/"+(currentYear - i)).endOf("year").format("MM/DD/YYYY");
	item.title = (currentYear - i);
	item.items = [];
	for(j = 1 ; j < 12; j+=3)
	{
		qDateStr = "0"+j +"/01/"+(currentYear - i);
		if(moment().fquarter(1).start > moment(qDateStr).fquarter(1).start)
		{
			var qItem = new Object();
			qItem.id = moment(moment(qDateStr).fquarter(1).start).format("MM/DD/YYYY") +"-"+ moment(moment(qDateStr).fquarter(1).end).format("MM/DD/YYYY");
			qItem.title = moment(qDateStr).fquarter(1).toString();
			qItem.items = [];
			for(k = j ; k < j+3; k++)
			{
				var mItem = new Object();
				startDateStr = "";
				if(k < 10)
				{
					startDateStr = "0"+k +"/01/"+(currentYear - i);
					}
					else
					{
									startDateStr = k +"/01/" + (currentYear - i);
					}
					console.log(startDateStr);
					mItem.id = moment(startDateStr).format("MM/DD/YYYY") +"-"+ moment(startDateStr).endOf("month").format("MM/DD/YYYY");
					mItem.title = moment(startDateStr).format("MMM");
					qItem.items.push(mItem)
			}
			item.items.push(qItem)
		}
	}
	dList.push(item);
	}
	return dList;
}

$scope.resetToAllStates = function(allstatekey) {
  console.log("inside resetToAllStates = " + allstatekey);
  $scope.selectedstateCode = "";
  $scope.sortDateKey = "";
  loadMap(allstatekey,$scope.selectedstateCode);
  loadSpendingBudgetData($scope.selectedstateCode,$scope.filterDefaultDate);
  loadBillingHoursData($scope.selectedstateCode,$scope.billingHoursDefaultDate);
  loadVoilationData($scope.selectedstateCode,$scope.billingHoursDefaultDate);
  loadTrackedMattersData($scope.selectedstateCode,$scope.filterDefaultDate);
  loadTopFirmExpenditureData($scope.selectedstateCode,$scope.filterDefaultDate);
  loadTopFirmAnamoliesData($scope.selectedstateCode,$scope.filterDefaultDate);
}

function init() {
     $scope.sortDateKey = "";
     $scope.billingHoursDefaultDate = getSelectedFilterDate($scope.billingHoursDefaultDate,$scope.sortDateKey);
     console.log("init " + $scope.billingHoursDefaultDate);
     loadMap($scope.selectedmapState,$scope.selectedstateCode);
     loadSpendingBudgetData($scope.selectedstateCode,$scope.filterDefaultDate);
     loadBillingHoursData($scope.selectedstateCode,$scope.billingHoursDefaultDate);
     loadVoilationData($scope.selectedstateCode,$scope.billingHoursDefaultDate);
     loadTrackedMattersData($scope.selectedstateCode,$scope.filterDefaultDate);
     loadTopFirmExpenditureData($scope.selectedstateCode,$scope.filterDefaultDate);
     loadTopFirmAnamoliesData($scope.selectedstateCode,$scope.filterDefaultDate);
  };

function loadSpendingBudgetData(selectedStateS,filterdate){

    var categoryS = "state";
    var categorySvalue = selectedStateS;
    var filtersS = "";
    var selectedkpiS = "netamount";
    var subcategoryS = "firmname";
    var datefilterS = filterdate;
    billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
          .then(
            function( mydata ) {
                var spendingByBudget = d3.nest()
               .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
               .entries(mydata);
               $scope.spendingHours = spendingHoursCurrencyFormat(spendingByBudget);
               $scope.dataSpendingByBudgetLoaded = true;
             });
      };


  function loadBillingHoursData(selectedStateS,filterdate){
    var categoryS = "state";
    var categorySvalue = selectedStateS;
    var filtersS = "";
    var selectedkpiS = "hours";
    var subcategoryS = "itemdate";
    var datefilterS = filterdate;

    billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
          .then(
            function( mydata ) {
              // var billedByHours = d3.nest()
              //  .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.descending)
              //  .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
              //  .entries(mydata);
               console.log("loadBillingHoursData date1 = " + filterdate);
               console.log("loadBillingHoursData date = " + $scope.billingHoursDefaultDate);
                $scope.billedHours =  getFormattedJson(mydata,$scope.filterDefaultDate);
                $scope.billcategories = setCategoriesLabel($scope.billedHours);
                console.log("billedHours = " + $scope.billedHours);
                $scope.dataHoursBilledLoaded = true;
            }
          );
      };

  function getFormattedJson(myServerData,sortDate) {
    fData = [];
    console.log("getFormattedJson sortDate = " + sortDate);
    console.log("getFormattedJson sortDateKey = " + $scope.sortDateKey);
    dSorter = getSelectedFilterDate(sortDate,"true");
    // add logic here to set the correct formatted json array for graph
    totalA = 0;
    totalB = 0;
    var condA = dSorter[0];
    var condB = dSorter[1];
    var condC = dSorter[2];
    var condD = dSorter[3];
    var labelC = [];
    var labelD = [];
    // Get the date and sort the correct json array.
    console.log("getFormattedJson conditions values, condA= " + condA + " condB= " + condB + " condC= " + condC + " condD= " + condD);
    for (var key in myServerData) {
           if (myServerData.hasOwnProperty(key)) {
        //        console.log("**** name " + myServerData[key].name);
        //      console.log("**** condA " + condA);
              if(moment(myServerData[key].name).isBetween(condC,condD)) {
              totalA = totalA + parseInt(myServerData[key].value);
          }else if(moment(myServerData[key].name).isBetween(condA,condB)) {
              totalB = totalB + parseInt(myServerData[key].value);
           }
          }
        }

        labelC = getDateLabels(condA,condB);
        labelD = getDateLabels(condC,condD);
        fData.push({key:labelC[0],y: totalB, color:"#c31820"},
                 {key:labelD[0],y: totalA, color:"#cbcbcb"});
      console.log("dSorter array = " + JSON.stringify(fData));
      return fData;
  }

  function setCategoriesLabel(myFData) {
    var tmpArr = [];
    for (var key in myFData) {
       if (myFData.hasOwnProperty(key)) {
         tmpArr.push(myFData[key].key);
      }
    }
    console.log("setCategoriesLabel = " + JSON.stringify(tmpArr));
    return tmpArr;
  }


  function loadVoilationData(selectedStateS,filterdate){
    var categoryS = "state";
    var categorySvalue = selectedStateS;
    var filtersS = "";
    var selectedkpiS = "AnomalyDollars";
    var subcategoryS = "itemdate";
    var datefilterS = filterdate;

    billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
          .then(
            function( mydata ) {
              // var violationByHours = d3.nest()
              //  .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.ascending)
              //  .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
              //  .entries(mydata);
                console.log("loadVoilationData date1 = " + filterdate);
                console.log("loadVoilationData date = " + $scope.billingHoursDefaultDate);
                $scope.violationHours =  getFormattedJson(mydata,$scope.filterDefaultDate);
                $scope.violationcategories = setCategoriesLabel($scope.violationHours);
                $scope.dataViolationsLoaded = true;
            }
          );
      };

 function formatDataForMatterChart(trackedMattersData) {
   var myArr = [];
   var tmpStr = "";
   $scope.categories = [];
   for (var key in trackedMattersData) {
          if (trackedMattersData.hasOwnProperty(key)) {
             var tmpStrKeyValue = '"' + trackedMattersData[key].key + '"';
             var tmpStrCatValue = trackedMattersData[key].key;
             tmpStr = '{name:' + tmpStrKeyValue + ',y:' + trackedMattersData[key].values + '}';
             myArr.push(tmpStr);
             $scope.categories.push(tmpStrCatValue);
          }
       }
   return myArr;
 }
  function loadTrackedMattersData(selectedStateS,filterdate){
    var categoryS = "state";
    var categorySvalue = selectedStateS;
    var filtersS = "";
    var selectedkpiS = "netamount";
    var subcategoryS = "mattername";
    var datefilterS =  filterdate;
    billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
          .then(
            function( mydata ) {
            var trackedMatters = d3.nest()
              .key(function(d){ return d.name; })
              .rollup(function(leaves){
                return leaves.map(function(d){
                  return d.y;
                }).sort(d3.descending).slice(0, 3);
            })
            .entries(mydata);
               $scope.topTrackedMatters = formatDataForMatterChart(trackedMatters.slice(0,3));
               $scope.dataTrackedMattersLoaded = true;
            });
      };

  function loadTopFirmExpenditureData(selectedStateS,filterdate){
    var categoryS = "state";
    var categorySvalue = selectedStateS;
    var filtersS = "";
    var selectedkpiS = "netamount";
    var subcategoryS = "firmname";
    var datefilterS = filterdate;
    billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
          .then(
            function( mydata ) {
              var topFirmByExpenditures = d3.nest()
              .key(function(d) { return d.name})
              .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
              .entries(mydata);
              var top5Firms = topFirmByExpenditures.slice(0,5);
              $scope.topStateExpenditureData = top5Firms;
              $scope.dataTopExpendituresLoaded = true;
            }
          );
      };

  function loadTopFirmAnamoliesData(selectedStateS,filterdate){
    var datefilterS = filterdate;
     billingService.getAnomaliesData(selectedStateS,datefilterS)
          .then(
            function( mydata ) {
              var topFirmByAnamolies = d3.nest()
               .key(function(d) { return d.name})
               .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
               .entries(mydata);
               var top5Anomalies = topFirmByAnamolies.slice(0,5);
                $scope.topFirmAnomaliesData = top5Anomalies;
                $scope.dataTopAnamoliesLoaded = true;
            }
          );
      };

  function loadMap(selectedmapState,selectedstateCode) {
    if(selectedmapState != "All") {
      var fileUrl = "/AppBuilder/dashapp/src/lib/maps/USA/" + selectedstateCode + ".topo.json";
    //  console.log("fileUrl = " + fileUrl);
      var stateObjectName = selectedmapState + '.geo';
    //  console.log("stateObjectName = " + stateObjectName);
      var scaledCenter = getStateMapCoordinates(selectedstateCode);
    //  console.log("loadMap = " + scaledCenter.projectcenter);
      $scope.mapObject = {
      geographyConfig: {
            dataUrl: fileUrl
          },
          scope: stateObjectName,
          options: {
            width: 600,
            height: 350,
            legendHeight: 60 // optionally set the padding for the legend
          },
          projection: '',
          setProjection: function(element) {
            var projection = d3.geo.mercator()
               .center(scaledCenter.projectcenter)
               .rotate([4.4, 0])
               .scale(scaledCenter.projectscale)
              // GA -77.60896022270053,32.361291820877184 , scale 2000
              .translate([element.offsetWidth / 2, element.offsetHeight / 2]);
            var path = d3.geo.path().projection(projection);
            return {path: path, projection: projection};
            },
           fills: {
            defaultFill: '#c31820',
            lt50: 'rgba(0,244,244,0.9)',
            gt50: '#c31820'
          },
          // data: {
          //   '071': {fillKey: 'lt50' },
          //   '001': {fillKey: 'gt50' }
          // },
        };
    } else {

    $scope.mapObject = {
        scope: 'usa',
        options: {
          width: 600,
          legendHeight: 60 // optionally set the padding for the legend
        },
        geographyConfig: {
          highlighBorderColor: '#306596',
          highlighBorderWidth: 2
        },
        fills: {
          'HIGH': '#CC4731',
          'MEDIUM': '#c31820',
          'LOW': '#306596',
          'defaultFill': '#DDDDDD'
        },
        data: {
          "IN": {
            "fillKey": "MEDIUM",
          },
          "TX": {
            "fillKey": "MEDIUM",
          }
        },
      };
    }
  }
     $scope.updateActiveState = function(geography) {
      $scope.stateName = geography.properties.name;
      $scope.stateCode = geography.id;
      console.log("statename = "+$scope.stateName);
      loadMap($scope.stateName,$scope.stateCode);
      loadSpendingBudgetData($scope.stateCode,$scope.filterDefaultDate);
      loadBillingHoursData($scope.stateCode,$scope.billingHoursDefaultDate);
      loadVoilationData($scope.stateCode,$scope.violationHoursDefaultDate);
      loadTrackedMattersData($scope.stateCode,$scope.filterDefaultDate);
      loadTopFirmExpenditureData($scope.stateCode,$scope.filterDefaultDate);
      loadTopFirmAnamoliesData($scope.stateCode,$scope.filterDefaultDate);
      $scope.selectedstateCode = $scope.stateCode;
      $scope.$apply();
    };

    init();
}]);

app.directive('hcBarChart', function($window){
    return {
        restrict: 'E',
        replace: true,
        template: '<div id="barcontainer" style="margin: 0 auto;height:160px">not working</div>',
        scope: {
            data: '=data',
            cat: '='
        },
        link: function (scope, element) {
          // console.log("categories***** = " + scope.cat);
           var chart = new Highcharts.chart({
                chart: {
                    type: 'column',
                    renderTo: element[0],
                    marginBottom: 1,
                    marginLeft: 0,
                    marginRight: 0,
                    marginTop: 0
                },
                title: {
                  text: ''
                },
                legend: {
                    enabled: false
                },
                credits: {
                    enabled: false
                },
                xAxis: {
                    categories: scope.cat,
                    title: {
                        text: null
                    },
                    lineWidth: 0,
                    tickWidth: 0,
                    labels: {
                            x : -10,
                            y : -150,
                            align: 'center',
                            formatter: function () {
                    		    var text = this.value
                    		    return '<div title="' + text + '">' + text + '</div></div>';
                    },
                    style: {
                    	    width: '100px'
                    },
                    useHTML: true
                  }
                },
                yAxis: {
                    visible:false},
                plotOptions: {
                    column: {
                      dataLabels: {
                          enabled: true,
                          inside: true,
                          align: 'center',
                          verticalAlign:'top',
                          x: -10,
                          shadow: false,
                          color: '#ffffff',
                          style: {
                            "fontWeight": "bold",
                            "font-family": "Roboto",
                            "font-size": "16px",
                        },
                        formatter: function () {
                          var currencyFormat = d3.format(".3s");
                          return currencyFormat(this.y);
                        }
                      },
                      pointWidth: 95,
                      pointPadding: 2,
                      groupPadding: 0.3,
                      borderWidth: 1,
                      }
                },
                series: [{
                    data: scope.data
                }]
            });
            scope.$watch("data", function (newValue) {
                chart.series[0].setData(newValue, true);
          }, true);
        }
    };
});

app.directive('hcHbChart', function($window){
    return {
        restrict: 'EAC',
        replace: true,
        template: '<div id="mattercontainer" style="margin: 0 auto;height:250px">not working</div>',
        scope: {
            data: '=',
            cat: '='
        },
        link: function (scope, element) {
          // console.log("categories***** = " + scope.cat);
           var chart = new Highcharts.chart({
                chart: {
                    type: 'bar',
                    renderTo: 'mattercontainer'
                },
                title: {
                  text: ''
                },
                legend: {
                    enabled: false
                },
                credits: {
                    enabled: false
                },
                xAxis: {
                    categories: scope.cat,
                    title: {
                        text: null
                    },
                    lineWidth: 0,
                    tickWidth: 0,
                    labels: {
                            x : 0,
                            y : -35,
                            align: 'left',
                    		    formatter: function () {
                    		    var text = this.value
                    		    return '<div class="js-ellipse" style="width:250px; overflow:hidden" title="' + text + '">' + text + '</div>';
                    },
                    style: {
                    	    width: '150px'
                    },
                    useHTML: true
                    }

                },
                yAxis: {
                    visible:false},
                plotOptions: {
                    bar: {
                        dataLabels: {
                            enabled: true,
                            x: -80,
                            shadow: false,
                            color: '#ffffff',
                            style: {
                              "fontWeight": "bold",
                              "font-family": "Roboto",
                              "font-size": '13px',
                              "font-weight": 'normal',
                              "font-style": 'normal',
                              "font-stretch": 'normal',
                              "letter-spacing": 'normal',
                              "color": '#ffffff',
                              "word-wrap": 'break-word'
                          },
                          formatter: function () {
                            return '$' + Highcharts.numberFormat(Math.round(this.y));
                        }
                        }
                    }
                },
                series: [{
                    data: scope.data,
                    color: '#c31820'
                }]
            });
            scope.$watch("data", function (newValue) {
              //  console.log("value in chart = " + newValue);
                var json = eval("([" +newValue+ "])");
                chart.series[0].setData(json, true);
          }, true);
        }
    };
});

var DataService = angular.module('DataService', [])
    .service('billingService', function ($http,$q) {
    return({
          getServiceData: getServiceData,
          getAnomaliesData: getAnomaliesData
      });

    function  getServiceData(category,categoryvalue,filters,selectedkpi,subcategory,datefilter) {
    var request = $http({
            method: "post",
            url: "/AppBuilder/endpoint/dashboardendpoint",
            params: {
                    category: category,
                    categoryvalue: "'" + categoryvalue + "'",
                    filters: filters,
                    selectedkpi: selectedkpi,
                    subcategory: subcategory,
                    datefilter: datefilter
                  }
        });
    return(request.then( handleSuccess, handleError ) );
  }

  function  getAnomaliesData(stateS,datefilterS) {
  var request = $http({
            method: "post",
            url: "/AppBuilder/endpoint/getAnomaly",
            params: {
                    state: stateS,
                    datefilter: datefilterS
                }
        });
    return(request.then( handleSuccess, handleError ) );
  }

  function handleError( response ) {
        if (
            ! angular.isObject( response.data ) ||
            ! response.data.message
            ) {
            return( $q.reject( "An unknown error occurred." ) );
        }
        return( $q.reject( response.data.message ) );
    }
    function handleSuccess( response ) {
      return( response.data);
    }
 });
