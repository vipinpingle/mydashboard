
filtername = params[:FilterValue].split(">>")[0]
filtervalue = params[:FilterValue].split(">>")[1].split("||")
findfieldname = params[:FindFieldName]
returnarray = {}

filterstring =nil
    if filtervalue.any?
      filtervalue.each do |filterwhole|
        if filterstring.nil?
          filterstring = field(filtername).contains(filterwhole)
        else
        filterstring = filterstring.or(field(filtername).contains(filterwhole))
        end
      end
    else
      filterstring = ""
    end

if findfieldname == "anomaly"
  entity_type("LineItemAnomaly").where(filterstring).faceted_by(field("anom_desc").with_facet_id('findfieldid').with_maximum_facet_values_of(-1)).faceting.get_facet('findfieldid').facet_values.each do |result|
  returnarray[result.value] = result.ndocs
  end
else

entity_type("Analysis").where(filterstring).faceted_by(field(findfieldname).with_facet_id('findfieldid').with_maximum_facet_values_of(-1)).faceting.get_facet('findfieldid').facet_values.each do |result|
  if findfieldname.include? "date"
  t = Time.at(result.value.to_i)
  returnarray[t.strftime("%m/%d/%Y")] = result.ndocs
  else
    returnarray[result.value] = result.ndocs
  end
#end
end
end
if filtername == "anom_desc"
  entity_type("LineItemAnomaly").where(filterstring).faceted_by(field("anom_desc").with_facet_id('findfieldid').with_maximum_facet_values_of(-1)).faceting.get_facet('findfieldid').facet_values.each do |result|
  returnarray[result.value] = result.ndocs
end
end

returnarray.to_json
#
