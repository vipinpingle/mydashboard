# Query API
# You can use the query API as you can in other parts of Application Builder
# You can use the query API to do additional calls, or to call external web services

entity_type("Analysis").where(field("invoiceid").contains(params[:invoiceid].to_s)).sorted_by(field('itemnumber')).requesting(entity_type("Analysis").where(field("invoiceid").contains(params[:invoiceid].to_s)).total_results).to_json.html_safe
#
