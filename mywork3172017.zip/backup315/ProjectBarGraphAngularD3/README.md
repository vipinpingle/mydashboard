# An introduction into reusable chart components in AngularJS and D3

This example consists of a **<chart>** component that composes a **<bar>** as well as two **<axis>** components.


