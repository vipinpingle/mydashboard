# Query API
# You can use the query API as you can in other parts of Application Builder
# You can use the query API to do additional calls, or to call external web services

entity_type("Analysis").where(field("mattername").contains(params[:mattername])).requesting(1).to_json
