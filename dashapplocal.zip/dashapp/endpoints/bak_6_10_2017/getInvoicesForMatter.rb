# Query API
# You can use the query API as you can in other parts of Application Builder
# You can use the query API to do additional calls, or to call external wdaeb services
data = {}
entity_type("Analysis").where(field("matternumber").contains(params[:matter].to_s)).faceted_by(field('invoiceid').with_facet_id('invoiceid')).faceting.get_facet('invoiceid').facet_values.each do |invoice|
  data[invoice.value] = invoice.ndocs
end
#
data.each do |key,value|
  entity_type("Analysis").where(field("invoiceid").contains(key)).faceted_by( xpath("viv:format-date($itemdate,'%m/%d/%Y')").with_facet_id('invdateid')).faceting.get_facet('invdateid').facet_values.each do |test|
    data[key] = test.value
    break
  end
end
series = "["
data.each_with_index do |(key, val), i|
  series << "\{\"invoiceid\":\"#{key}\",\"invoicedate\": \"#{val}\"\}"
  unless i == data.size - 1
      series << ","
    end
  end
series = series + "]"
series.html_safe
