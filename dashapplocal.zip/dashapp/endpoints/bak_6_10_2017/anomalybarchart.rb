
category = params[:category]
subcategory = params[:subcategory]
categoryvalue = params[:categoryvalue].split("||")
selectedkpi = params[:selectedkpi]
filters = params[:filters].split(",")
datefilter = params[:datefilter].split("-")
filterstring =nil

facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').without_pruning
facet_by_hours = sum(xpath('$'+selectedkpi)).with_facet_id('kpi_id')



dataall = {}
if(categoryvalue.any?)
  categoryvalue.each do |catval|
    data = {}
    categoryfilterstring = field(category).contains(catval)
    filterstring =nil
    if filters.any?
      filters.each do |filterwhole|
        filterwholearray = filterwhole.split("-")
         if filterstring.nil?
           filterstring = categoryfilterstring.and(field(filterwholearray.at(0)).contains(filterwholearray.at(1)))
        else
          filterstring = filterstring.and(field(filterwholearray.at(0)).contains(filterwholearray.at(1)))
        end
      end
    else
      filterstring = categoryfilterstring
    end

    if datefilter.any?
      dateStart = datefilter[0].split("/")
      actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

      dateEnd = datefilter[1].split("/")
      actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)


      filterstring = filterstring.and(field("itemdate").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("itemdate").isGreaterThan(actualStartDate.to_time.to_i.to_java))

        end

    facets = entity_type('InvoiceAnomaly').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|
      data[firm.value] = firm.getChildren.first.value
    end

    facets = entity_type('LineItemAnomaly').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|

      if data.key?(firm.value)
        data[firm.value] = data[firm.value]+firm.getChildren.first.value
      else
        data[firm.value] = firm.getChildren.first.value
      end
    end

    data = data.sort_by {|k,v| v}.reverse

    datanew = {}
    i = 1
    totalrest = 0
    data.each do |key,value|
      if(i < 10)
        datanew.store(key,value)
      else
        totalrest = totalrest + value
        datanew.store("others",totalrest)
      end
      i = i + 1
    end

    dataall[catval] = datanew

  end
end

series = ""
seriesmap = {}
dataall.each_with_index do |(key,val),i|
  val.each_with_index do |(key1,val1),j|
    if seriesmap.key?(key1)
      seriesmap[key1] = seriesmap[key1].push(val1)
    else
      seriesmap[key1] = Array.new(i,0)
      seriesmap[key1] = seriesmap[key1].push(val1)
    end
 #   series << "\{name:'#{key1}', data: [#{i}, #{val1}]\}"
  end
end

def makeproperarray(arraytofix,dataall)
  if arraytofix.length < dataall.length
    arraytofix.push(0)
    makeproperarray(arraytofix,dataall)
  end
else
  return arraytofix
end

seriesmap.each_with_index do |(key,val),i|
  seriesmap[key] = makeproperarray(val,dataall)
  series << "\{name:'#{key}',data: #{val}\}"
  unless i == seriesmap.size - 1
      series << ","
    end
end



series.gsub!('nil','null')

series.html_safe
