data = {}
category = params[:category]
subcategory = params[:subcategory]
categoryvalue = params[:categoryvalue]
selectedkpi = params[:selectedkpi]
filters = params[:filters].split(",")
filterstring =nil

if subcategory.include? "itemdate"
  facet_by_subcategory =  xpath("viv:format-date($invdate,'%m/%d/%Y')").with_facet_id('subcategory_id').without_pruning
else
  facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').without_pruning
end

#facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').without_pruning
facet_by_hours = sum(xpath('$'+selectedkpi)).with_facet_id('kpi_id')

categoryfilterstring = field(category).contains(categoryvalue)

if filters.any?
filters.each do |filterwhole|
  filterwholearray = filterwhole.split("-")
  if filterstring.nil?
       filterstring = categoryfilterstring.and(field(filterwholearray.at(0)).contains(filterwholearray.at(1)))
  else
    filterstring = filterstring.and(field(filterwholearray.at(0)).contains(filterwholearray.at(1)))
  end
end
else
  filterstring = categoryfilterstring
end

#categoryfilterstring+filterstring

facets = entity_type('Analysis').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
arr = []
facets.get_facet('subcategory_id').facet_values.each do |firm|
  data[firm.value] = firm.getChildren.first.value
  end

#data

data = data.sort_by {|k,v| v}.reverse

series = "["
data.each_with_index do |(key, val), i|
  series << "\{\"name\":\"#{key}\",\"value\": [\"#{val}\"]\}"
  unless i == data.size - 1
      series << ","
    end
  end
series = series + "]"
series.html_safe
