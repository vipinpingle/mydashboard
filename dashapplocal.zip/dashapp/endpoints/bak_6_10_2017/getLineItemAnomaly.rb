stringtest = {}
#facet1 = field('itemnumber').with_facet_id('randomid').without_pruning
facet2 = field("anom_desc").with_facet_id('anomdesc').without_pruning
entity_type("LineItemAnomaly").where(field('invoiceid').contains(params[:invoiceid]).and(field('itemnumber').contains(params[:linenumber]))).to_json
