facet_by_subcategory = field("firmname").with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
facet_by_hours = sum(xpath('$AnomalyCount')).with_facet_id('kpi_id')
data = {}
datefilter = params[:datefilter].split("-")
filterstring =nil
#entity_type('LineItemAnomaly').where(field("state").contains(params[:state])).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting.get_facet('subcategory_id').facet_values.each do |firm|
#  data[firm.value] = firm.getChildren.first.value
#end


if datefilter.any?
      dateStart = datefilter[0].split("/")
      actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

      dateEnd = datefilter[1].split("/")
      actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)


  filterstring = field("endgperiod").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java).and(field("endgperiod").isGreaterThan(actualStartDate.to_time.to_i.to_java))

 end

facets = entity_type('InvoiceAnomaly').where(field("state").contains(params[:state]).and(filterstring)).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|
      data[firm.value] = firm.getChildren.first.value
    end

if datefilter.any?
      dateStart = datefilter[0].split("/")
      actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

      dateEnd = datefilter[1].split("/")
      actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)


  filterstring = field("itemdate").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java).and(field("itemdate").isGreaterThan(actualStartDate.to_time.to_i.to_java))

 end
facets = entity_type('LineItemAnomaly').where(field("state").contains(params[:state]).and(filterstring)).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|

      if data.key?(firm.value)
        data[firm.value] = data[firm.value]+firm.getChildren.first.value
      else
        data[firm.value] = firm.getChildren.first.value
      end
    end
data = data.sort_by {|k,v| v}.reverse

series = "["
data.each_with_index do |(key, val), i|
  series << "\{\"name\":\"#{key}\",\"value\": [\"#{val}\"]\}"
  unless i == data.size - 1
      series << ","
    end
  end
series = series + "]"

series.html_safe
