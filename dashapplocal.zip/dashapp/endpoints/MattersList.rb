noofresults = params[:noofresults].to_i
pagenumber= params[:pagenumber].to_i
searchstring= params[:searchstring]
sortbyfield = params[:sortbyfield]
whereclause = nil
sortbystring = field(sortbyfield)
returntype = params[:returntype]
returnstring = nil

if searchstring != ""
  whereclause = field("matter_name").contains(searchstring).or(field("matter_number").contains(searchstring)).or(field("firm_name").contains(searchstring)).or(field("matter_number").contains(searchstring))
end

totalresults = entity_type('Matter_List').where(whereclause).total_results

startingwith = (pagenumber-1)*noofresults
if pagenumber==1
  startingwith = 0
end
if returntype == "total"
  returnstring = totalresults
else
returnstring = entity_type('Matter_List').where(whereclause).starting_at(startingwith).sorted_by(sortbystring).requesting(noofresults).to_json
end

rb_hash = JSON.parse(returnstring)

rb_hash.each do |matteritem|
  matternumber = matteritem["properties"]["matter_number"]
  firmitems = endpoint("getMatterDetails", matternumber: matternumber[0])
  firmitemhash = JSON.parse(firmitems)
  firmvalues = []
  firmlistformat = ""
  firmitemhash.each do |firmitem|
     firmvalues << firmitem["properties"]["firm_name"][0]
  end
  uniqueFirmList = firmvalues.uniq
  firmlistformat = uniqueFirmList.join(",")
  matteritem["firms"] = firmlistformat
end

rb_hash << {total: totalresults}

rb_hash.to_json
