#Endpoint for firm anomalies

#Dashboard getAnomaly table

subcategory = params[:subcategory]
selectedkpi = params[:selectedkpi]
$filters = params[:filters].split("&&")
$filtername = ""
$datefilter = params[:datefilter].split("-")
filterstring =nil
datanew = {}
dataall = {}
datanewvalue = []
lineitemdata = {}
series = ""
seriesmap = {}
$total = 0
$datefilter = params[:datefilter].split("-")

facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
facet_by_hours = sum(xpath('$'+selectedkpi)).with_facet_id('kpi_id')
facet_by_invdate = xpath("viv:format-date($item_date,'%m/%d/%Y')").with_facet_id('invdate_id').with_maximum_facet_values_of(-1).without_pruning

def getFilterString(filterstring,filters,datefieldname,datefilter,daterange)
  if !filters.nil?
    if filters.any?
		filters.each do |filterwhole|
		filtername = filterwhole.split(">>")[0]
		filtervalue = filterwhole.split(">>")[1].split("||")
		internalfilterstring = nil
    if filtervalue.any?
        filtervalue.each do |filtereach|
			if internalfilterstring.nil?
          		internalfilterstring = field(filtername).contains(filtereach)
          	else
          		internalfilterstring = internalfilterstring.or(field(filtername).contains(filtereach))
          	end
	    end
    else
    	internalfilterstring = ""
    end
        filterstring = internalfilterstring
    end
	end
end
    if datefilter.any?
        dateStart = datefilter[0].split("/")
        actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)
        dateEnd = datefilter[1].split("/")
        actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)
    if filterstring.nil?
        filterstring =(field(datefieldname).isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field(datefieldname).isGreaterThan(actualStartDate.to_time.to_i.to_java))
    else
		filterstring =  filterstring.and(field(datefieldname).isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field(datefieldname).isGreaterThan(actualStartDate.to_time.to_i.to_java))
      end
    end
  return filterstring
end


def getDataFromFacetsPBC(data,entitytype,filterstring,filters,facet_by_subcategory,facet_by_hours)
    facets = entity_type(entitytype).where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|
      data[firm.value] = firm.ndocs
    end
#  print "\n***\n"
#  print data
    filterstring = getFilterString(filterstring,filters,"invoice_date",$datefilter,nil)
    facets = entity_type("AnalysisInvoiceAnomalies").where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    facets.get_facet('subcategory_id').facet_values.each do |firm|
    if data.key?(firm.value)
        data[firm.value] = data[firm.value]+firm.ndocs
    else
        data[firm.value] = firm.ndocs
    end
    end
  return data
end

def getDataFromFacetsLineItemAnomalies(data,entitytype,filterstring,filters,facet_by_subcategory,facet_by_hours)
  lineitemdata = {}
  filterstring = getFilterString(filterstring,filters,"item_date",$datefilter,nil)
    facets = entity_type(entitytype).where(filterstring).faceted_by(facet_by_subcategory).faceting
    facets.get_facet('subcategory_id').facet_values.each do |firm|
        lineitemdata[firm.value] = firm.ndocs
    end
  return lineitemdata
end

def getDataStore(datanew,data)
	data = data.sort_by {|k,v| v}.reverse
	datanew = {}
	data.each do |key,value|
		datanew.store(key,value)
	end
	return datanew
end

def executeQuery(data,datanew,selectedkpi,filterstring,filters,facet_by_subcategory,facet_by_hours,facet_by_invdate)
	if selectedkpi == "anomaly_description"
    data  = getDataFromFacetsPBC(data,'AnalysisAnomaly_Matrix',filterstring,filters,facet_by_subcategory,facet_by_hours)
   # print "\n)))(((((((((\n"
   # print data
		datanew = getDataStore(datanew,data)
	end
	return datanew
end

#main code to execute all functions

datanewvalue ={}
data = {}
datanew = {}
#categoryfilterstring = field($category).contains(params[:categoryvalue])
filterstring =nil
daterange = nil
filters = $filters
filterstring = getFilterString(filterstring,filters,"item_date",$datefilter,daterange)
datanew = executeQuery(data,datanew,selectedkpi,filterstring,filters,facet_by_subcategory,facet_by_hours,facet_by_invdate)

# call to get total count of lineitem anomalies
#filters = nil
facet_by_subcategory = field("firm_name").with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
#anomalydescriptiondata = executeQuery(data,datanew,selectedkpi,filterstring,filters,facet_by_subcategory,facet_by_hours,facet_by_invdate)

firmlineitemsdata = getDataFromFacetsLineItemAnomalies(data,'Analysis_Matrix',filterstring,filters,facet_by_subcategory,facet_by_hours)

#print anomalydescriptiondata
facet_by_subcategory = field("firm_name").with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
filterstring = nil
totalinvoicesdata = {}
filterstring = getFilterString(filterstring,nil,"invoice_date",$datefilter,daterange)
#print "\n filterstring \n"
#print filterstring

facets = entity_type("Invoice_List").where(filterstring).faceted_by(facet_by_subcategory).faceting

facets.get_facet('subcategory_id').facet_values.each do |firm|
        totalinvoicesdata[firm.value.to_s.strip] = firm.ndocs
end

$invoicenumbers = {}
totalinvoicesdata.each_with_index do |(key,value),i|
  #print "\n datanew[key] = "
  #print datanew[key]
  #print " === "
  #print value.to_i
  #print " === "
  #print firmlineitemsdata[key]
  #print "\n\n"
  divisor = value.to_f + firmlineitemsdata[key].to_f
  dividend = datanew[key].to_f
  $invoicenumbers[key] = (dividend/divisor)*100.to_f
end

#print "\n new array****\n"
#print $invoicenumbers

#print "\n ***totalinvoicesdata \n"

def getJsonFormattedData(datavalue)
	series = "["
	datavalue.each_with_index do |(key, val), i|
	key = key.gsub /"/, ''
    series << "\{\"name\":\"#{key}\",\"value\": \"#{val}\"\,\"percentage\": \"#{$invoicenumbers[key].round(2)}\"\}"
	unless i == datavalue.size - 1
      series << ","
    end
	end
	series = series + "]"
	return series
end

series = getJsonFormattedData(datanew)
series.html_safe
