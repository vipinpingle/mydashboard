noofresults = params[:noofresults].to_i
pagenumber= params[:pagenumber].to_i
searchstring= params[:searchstring]
sortbyfield = params[:sortbyfield]
whereclause = nil
sortbystring = field(sortbyfield)
returntype = params[:returntype]
returnstring = nil

if searchstring != ""
  whereclause = field("matter_name").contains(searchstring).or(field("invoice_id").contains(searchstring)).or(field("firm_name").contains(searchstring)).or(field("matter_number").contains(searchstring))
end

totalresults = entity_type('Invoice_List').where(whereclause).total_results

startingwith = (pagenumber-1)*noofresults
if pagenumber==1
  startingwith = 0
end
if returntype == "total"
  returnstring = totalresults
else
returnstring = entity_type('Invoice_List').where(whereclause).starting_at(startingwith).sorted_by(sortbystring).requesting(noofresults).to_json
end

rb_hash = JSON.parse(returnstring)
rb_hash << {total: totalresults}
#returnstring

rb_hash.to_json
