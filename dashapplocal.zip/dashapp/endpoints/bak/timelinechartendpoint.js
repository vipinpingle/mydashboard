data = {}
category = params[:category]
subcategory = params[:subcategory]
categoryvalue = params[:categoryvalue].split("||")
selectedkpi = params[:selectedkpi]
filters = params[:filters].split("&&")
datefilter = params[:datefilter].split("-")



filterstring =nil

facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
facet_by_invdate = xpath("viv:format-date($itemdate,'%m/%d/%Y')").with_facet_id('invdate_id').with_maximum_facet_values_of(-1).without_pruning
facet_by_hours = sum(xpath('$'+selectedkpi)).with_facet_id('kpi_id')


dataall = {}
if(categoryvalue.any?)
  categoryvalue.each do |catval|
    categoryfilterstring = field(category).contains(catval)
    filterstring =nil
    if filters.any?
      filters.each do |filterwhole|

        filtername = filterwhole.split(">>")[0]
        filtervalue = filterwhole.split(">>")[1].split("||")

		internalfilterstring = nil

        if filtervalue.any?
          filtervalue.each do |filtereach|
			if internalfilterstring.nil?
				internalfilterstring = field(filtername).contains(filtereach)
			else
				internalfilterstring = internalfilterstring.or(field(filtername).contains(filtereach))
			end
		  end
		else
			internalfilterstring = ""
		end



        if filterstring.nil?
           filterstring = categoryfilterstring.and(internalfilterstring)
        else
          filterstring = filterstring.and(internalfilterstring)
        end
      end
    else
      filterstring = categoryfilterstring
    end
    # for invoicelevel anomaly
    searchstringwithoutdate = filterstring
    if datefilter.any?
      dateStart = datefilter[0].split("/")
      actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

      dateEnd = datefilter[1].split("/")
      actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)
      filterstring = filterstring.and(field("itemdate").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("itemdate").isGreaterThan(actualStartDate.to_time.to_i.to_java))
    end

  if selectedkpi == "AnomalyCount"
    facets = entity_type('LineItemAnomaly').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_invdate.then(facet_by_hours))).faceting
    facets.get_facet('subcategory_id').facet_values.each do |firm|
      arr = []
      firm.get_facet('invdate_id').facet_values.each_with_index do |invdate,index|
        invdate.getChildren.each do |total|
          arr << {invdate.value => total.value}
        end
        data[firm.value] = arr
      end
    end
  else

    facets = entity_type('Analysis').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_invdate.then(facet_by_hours))).faceting

    facets.get_facet('subcategory_id').facet_values.each do |firm|
      arr = []
      firm.get_facet('invdate_id').facet_values.each_with_index do |invdate,index|
        invdate.getChildren.each do |total|
          arr << {invdate.value => total.value}
        end
        data[firm.value] = arr
      end
    end

  end
  end
end


month_values = data.values.collect { |month_array| month_array.collect { |month_hash| month_hash.keys }}.flatten.uniq
  new_normalized_data = {}

  data.each do |firm, month_array|
    this_firm = []
    month_values.each do |month|
      x = month_array.select{ |month_hash|month_hash. include? month}
      if x.empty?
        this_firm << nil
      else
        this_firm << x.first.values.first
      end
    end
    new_normalized_data[firm] = this_firm
  end

  series = ""
series << "\{name:'category',data: #{month_values.to_json.html_safe }\},"
  new_normalized_data.each_with_index do |(key, val), i|
    series << "\{name:'#{key}',data: #{val}\}"
    unless i == new_normalized_data.size - 1
      series << ","
    end
  end
  series.gsub!('nil','0')


series
