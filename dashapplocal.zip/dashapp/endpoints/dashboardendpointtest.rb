data = {}
category = params[:category]
subcategory = params[:subcategory]
categoryvalue = params[:categoryvalue]
selectedkpi = params[:selectedkpi]
filters = params[:filters].split(",")
filterstring =nil
datefilter = params[:datefilter].split("-")

if subcategory.include? "item_date"
  facet_by_subcategory =  xpath("viv:format-date($item_date,'%m/%d/%Y')").with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
else
  facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
end

facet_by_hours = sum(xpath('$'+selectedkpi)).with_facet_id('kpi_id')
filterstring = field(category).contains(categoryvalue)

#categoryfilterstring+filterstring
if selectedkpi == "anomaly_description"
  if datefilter.any?
      dateStart = datefilter[0].split("/")
      actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

      dateEnd = datefilter[1].split("/")
      actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)

    filterstring1 =     filterstring.and(field("item_date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("item_date").isGreaterThan(actualStartDate.to_time.to_i.to_java))
end
  facet_by_subcategory = field("item_date").with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
  facets = entity_type('AnalysisAnomaly_Matrix').where(filterstring1.and(field("anomaly_id").isGreaterThan(0))).faceted_by(facet_by_subcategory).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|
    t = Time.at(firm.value.to_i)
    data[t.strftime("%m/%d/%Y")] = firm.ndocs
    end

if subcategory.include? "item_date"
  facet_by_subcategory =  xpath("viv:format-date($invoice_date,'%m/%d/%Y')").with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
else
  facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
end
  if datefilter.any?
      dateStart = datefilter[0].split("/")
      actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

      dateEnd = datefilter[1].split("/")
      actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)


  filterstring = filterstring.and(field("invoice_date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("invoice_date").isGreaterThan(actualStartDate.to_time.to_i.to_java))

 end
  #AnalysisAnomaly_Matrix is lineitem anomaly
  facets = entity_type('AnalysisInvoiceAnomalies').where(filterstring.and(field("anomaly_id").isGreaterThan(0))).faceted_by(facet_by_subcategory).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|
      if data.key?(firm.value)
        data[firm.value] = data[firm.value]+firm.ndocs
     else
        data[firm.value] = firm.ndocs
     end
    end
  else
  if datefilter.any?
      dateStart = datefilter[0].split("/")
      actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

      dateEnd = datefilter[1].split("/")
      actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)

  filterstring = filterstring.and(field("item_date").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("item_date").isGreaterThan(actualStartDate.to_time.to_i.to_java))

 end
     facets = entity_type('Analysis_Matrix').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|
      if data[firm.value].nil?
        data[firm.value] =  firm.getChildren.first.value
      else
      data[firm.value] = data[firm.value] + firm.getChildren.first.value
      end
    end
  end

data = data.sort_by {|k,v| v}.reverse

series = "["
data.each_with_index do |(key, val), i|
  key = key.gsub /"/, ''
  if subcategory == "matter_name"
    series << "\{\"name\":\"#{key}\",\"y\": #{val}\}"
  else
  series << "\{\"name\":\"#{key}\",\"value\": \"#{val}\"\}"
  end
  unless i == data.size - 1
      series << ","
    end
  end
series = series + "]"
#series.gsub!(\\"Skip\\", "Skip")
series.html_safe
