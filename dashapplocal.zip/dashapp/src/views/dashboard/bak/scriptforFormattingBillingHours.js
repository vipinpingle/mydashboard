var json = [{"name":"03/31/2016","value": ["831339.27"]},{"name":"06/30/2016","value": ["625967.64"]},{"name":"04/30/2016","value": ["585622.96"]},{"name":"11/30/2016","value": ["550113.82"]},{"name":"02/29/2016","value": ["533596.72"]},{"name":"11/30/2015","value": ["503712.61"]},{"name":"09/30/2015","value": ["427673.64"]},{"name":"06/30/2015","value": ["418626.41"]},{"name":"05/31/2016","value": ["366279.49"]},{"name":"07/31/2016","value": ["365651.08"]},{"name":"01/31/2016","value": ["365027.69"]},{"name":"10/31/2015","value": ["331386.76"]},{"name":"12/31/2015","value": ["324394.55"]},{"name":"07/31/2015","value": ["321500.97"]},{"name":"12/31/2016","value": ["314283.68"]},{"name":"08/31/2016","value": ["305745.93"]},{"name":"10/31/2016","value": ["289630.45"]},{"name":"09/30/2016","value": ["263166.26"]},{"name":"08/31/2015","value": ["224843.45"]},{"name":"03/31/2015","value": ["210875.04"]}
];

totalA = 0;
totalB = 0;
for (var key in json) {
       if (json.hasOwnProperty(key)) {
       	 if(json[key].name > "04/30/2016") {
          totalA = totalA + parseInt(json[key].value);
          console.log("my condition satisfied = " + json[key].value);

       }else if(json[key].name < "04/30/2016") {
          totalB = totalB + parseInt(json[key].value);
          console.log("my condition satisfied = " + json[key].value);

       }
    	}
    }
 var newJson = [];
  newJson.push({name:"A",values: totalA},
 						{name:"B",values: totalB});
 console.log("my grand totalA = " + totalA);
 console.log("my grand totalB = " + totalB);
 console.log("my new array = " + JSON.stringify(newJson));



 $(document).ready(function() {

   var compareToA = "01/01/2015";
 	var compareToB = "12/31/2015";
   var compareToC = "01/01/2016";
 	var compareToD = "12/31/2016";
   $('.compare').click(function(e) {

     var date = "10/02/2015";

     /*********************/
     if(moment(date).isAfter(compareToA) && moment(date).isBefore(compareToB)){
     $('.result2').text('Date is After: yes');
     } else  if(moment(date).isBefore(compareToB)){
     $('.result2').text('Date is After: no');
     }

   });

 });
