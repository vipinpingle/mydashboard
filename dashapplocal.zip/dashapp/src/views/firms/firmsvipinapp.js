<script src="/AppBuilder/dashapp/src/lib/angularjs-dropdown-multiselect.min.js"></script>
<script>

/* off-canvas sidebar toggle */
$('[data-toggle=offcanvas]').click(function() {
    $('.row-offcanvas').toggleClass('active');
    $('.collapse').toggleClass('in').toggleClass('hidden-xs').toggleClass('visible-xs');
    $('.collapsemain').toggleClass('col-md-8').toggleClass('col-md-11');
    $('.table_wrapper').toggleClass('wrapper_size');
    $('.expandrightview').toggleClass('firms_overview').toggleClass('firms_overviewexpanded');
});

//Title Append
$('#nav_title').append($('#pagetitle').val());



</script>


<script type="text/javascript">
  var counter = 0;
  var app = angular.module('wexdashboard', ['angularUtils.directives.dirPagination','FirmDataService','ui.bootstrap','ui.tree','wexdashboard.directives','wexdashboard.services']);
  app.filter("percentage", function(){
    return function(input, max){
      if(isNaN(input)){
        return input;
      }
      return input + '%';
    }
  });
  app.controller('FirmController',['$scope','$http','$filter',  'firmService','sharedParameterService', function($scope,  $http,$filter, firmService, sharedParameterService) {
 //alert(firmService + ' ' + sharedParameterService );
  // variable for pagination calls
  $scope.sharedParameterService = sharedParameterService;
  $scope.numberOfResults = "10";
  $scope.pageNumber = "1";
  $scope.pageNumI = "1";
  $scope.searchItem = "";
  $scope.sortByField = "firm_name";
  $scope.sortByFieldLabel = "Firm Name";
  $scope.totalPageCount = "";
  $scope.totalPageLineItemCount = "";
  $scope.firmList = "";
  $scope.showfirmdetails = false;
  $scope.firmLineItems = [];
  $scope.sortType = 'id';
  $scope.sortReverse = false;
  $scope.searchItem = '';
  $scope.selectedFirmIdLineItem = "";
  $scope.sortLineItemByType = "itemnumber";
  $scope.filterByMatterNumber = "";
  $scope.highlighted="";
  $scope.highlighted="";
  $scope.staffLevelList = [];
  $scope.showSidebar = true;

  $scope.searchSelectAllSettings = { enableSearch: true, showCheckAll: false, showUncheckAll:false,keyboardControls: true, styleActive: true,scrollable: true,scrollableHeight: '200px'};

  // PUSH Mock data for bar charts
  iData = [];
  iData.push({key:"Spend",y: 0, color:"#c31820"},
                 {key:"Budget",y: 0, color:"#cbcbcb"})
  $scope.invoiceSummary=iData;
  tmpArr = [];
  tmpArr.push("Spend","Annual Budget")
  $scope.billcategories=tmpArr;

  fData = [];
  fData.push({key:"Firm",y: 0, color:"#92cd0d"},
                 {key:"State Average",y: 0, color:"#cbcbcb"})
  $scope.billingRate=fData;
  tmpArr = [];
  tmpArr.push("Firm","State Average")
  $scope.ratecategories=tmpArr;

  fData = [];
  fData.push({key:"Opened",y: 0, color:"#029fdb"},
                 {key:"Closed",y: 0, color:"#cbcbcb"})
  $scope.matterActivity=fData;
  tmpArr = [];
  tmpArr.push("Opened","Closed")
  $scope.anomolycategories=tmpArr;

  $scope.matterActivityBarLabel = "Matter Activity";
  $scope.invoiceBarLabel = "Total Invoice";
  $scope.billingRateBarLabel = "Blended Billing Rate";

  $scope.firmsortList = [
      {name : "Invoices", value : "total_invoices:descending"},
      {name : "Amount", value : "sum:descending"},
      {name : "Firm Name", value : "firm_name"}
  ];
  monthEmptyArray  = [null,null,null,null,null,null,null,null,null,null,null,null];
  $scope.mattercounts = [{name:"Dormant" , data:monthEmptyArray},{name: "Open", data:monthEmptyArray},{name: "Closed", data:monthEmptyArray}];
  $scope.monthcategories = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  $scope.billingHours = "";

  var dList = getPeriodHierarchy();
    //console.log(JSON.stringify(dList));
    if(dList.length > 0)
    {
      $scope.selectedPageDateFilter = dList[0].title;
      $scope.expand_page_date_filter = false;
      $scope.sharedParameterService.setSharedParameter("datefilter",dList[0].id);
      $scope.datefilter = dList[0].id;
    }

    $scope.list = dList;

    $scope.mattersFilterList =  [{"id":"hours","title":"Hours"},{"id":"net_amt","title":"Spend"}];
    $scope.billingPeriodList = [{"id":"30", "title":"30 Days"},{"id":"90", "title":"90 Days"}, {"id":"180", "title":"180 Days"}]

$scope.ytdList = [
    {name : "2016", value : "01/01/2016-12/31/2016"},
    {name : "2015", value : "01/01/2015-12/31/2015"}
];

//$scope.firmAnomalies = {"totalNumberOfInvoices":"12","totalNumberOfLineItems":"76", "totalNumberOfAnomalies":"112"}
  $scope.firmAnomalies = [];

$scope.selectPeriod = function(selectedVal)
{
  if(selectedVal != '')
  {
    console.log(selectedVal);
    $scope.selectedPageDateFilter = selectedVal.split(":")[1];
    $scope.expand_page_date_filter = false;
    $scope.sharedParameterService.setSharedParameter("datefilter",selectedVal.split(":")[0]);
    $scope.datefilter = selectedVal.split(":")[0];
    //alert("selectPeriod");
    getFirmLineItemsData($scope.selectedFirmid,$scope.datefilter);
    $scope.show_DropDown = false;
    updateMatterActivityGraph();
  }
}

$scope.selectStaffLevel = function(selectedVal)
{
  if(selectedVal != '')
  {

    $scope.expand_staff_level_selection = false;
    $scope.selectedStaffLevel = selectedVal.split(":")[1];
    $scope.sharedParameterService.setSharedParameter("staffLevel",selectedVal.split(":")[0]);
  }
}

$scope.selectTopMatterView = function(selectedVal)
{
  if(selectedVal != '')
  {
    $scope.expand_top10matters_view_selection = false;
    $scope.selectedTop10MattersView = selectedVal.split(":")[1];
    $scope.sharedParameterService.setSharedParameter("top10mattersview",selectedVal.split(":")[0]);
  }
}

$scope.staffChangeEventListeners = {
      onSelectionChanged: onStaffSelectionChanged
  };

  function onStaffSelectionChanged() {
    console.log($scope.selectStaffModel);
  }

 // Accordion
  $scope.oneAtATime = true;


 $scope.status = {
   isCustomHeaderOpen: false,
   isFirstOpen: true,
   isFirstDisabled: false,
   open: true
 };

   $scope.timekeepers=[
       {"id" : "1", "name": "Derek S Jamison", "title": "Partner ", "billingRate": "225", "billingToDate": "234,436", "openMattersCount": "5", "ytdOpenMatters": "9", "ytdClosedMatters": "5", "avgCostPerMatter": "13.5", "avgAnomalies": "3", "open": true },
       {"id" : "2","name": "Sharon S Johansen", "title": "Associate ", "billingRate": "170", "billingToDate": "334,436", "openMattersCount": "7", "ytdOpenMatters": "8", "ytdClosedMatters": "3", "avgCostPerMatter": "30", "avgAnomalies": "9", "open": false},
       {"id" : "3","name": "Kelly J Sherman", "title": "Managing Partner ", "billingRate": "876", "billingToDate": "134,092", "openMattersCount": "1", "ytdOpenMatters": "3", "ytdClosedMatters": "2", "avgCostPerMatter": "91.9", "avgAnomalies": "1", "open": false},
       {"id" : "4","name": "Rodrigo P Condozo", "title": "Partner ", "billingRate": "248", "billingToDate": "210,201", "openMattersCount": "8", "ytdOpenMatters": "10", "ytdClosedMatters": "2", "avgCostPerMatter": "42.1", "avgAnomalies": "14", "open": false}

   ];

   $scope.expandTimekeeper = function(event, params )
   {
       console.log("Fired on expand timekeeper : " + params[1].value + " :: " + params[0].value.name);
       console.log(params[0].value);
       if(!$scope.sharedParameterService.getSharedParameter("topTKMattersKpi")){
           $scope.sharedParameterService.setSharedParameter("topTKMattersKpi","hours");
           $scope.sharedParameterService.setSharedParameter("topTKMattersSort","hours");
           $scope.selectedTKMFilter = "Hours"
       }
       $scope.sharedParameterService.setSharedParameter("selectedTKIndex", params[1].value);
       $scope.sharedParameterService.setSharedParameter("timekeeperName"+params[1].value, params[0].value.name);
       updateTimekeeperSummary(params[0].value.name, params[1].value)

   }

  function updateTimekeeperSummary(timekeeper, selectedIndex)
  {
    dateFilter = $scope.datefilter;
    firmId = $scope.selectedFirmid;
    if(!$scope.timekeeperDetails)
    {
        $scope.timekeeperDetails = {};
    }
    if(!$scope.timekeeperDetails[selectedIndex])
    {
        $scope.timekeeperDetails[selectedIndex] = new Object();
    }
    firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget1")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('AverageBillrate' + mydata.avgbillrate);
                       $scope.timekeeperDetails[selectedIndex].avgBillRate =  mydata.avgbillrate;
           });
    firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget2")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('Billing to Date' + mydata.billing);
                       $scope.timekeeperDetails[selectedIndex].billing =  mydata.billing;
           });
    firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget3")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('Matter Count' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].matterCount =  mydata.mattercount;
           });
     firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget4")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('Cost Per Matter Matter ' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].costPerMatter =  mydata.costpermatter;
           });
    firmService.getTimekeperData(firmId, timekeeper,  dateFilter, "widget6")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('Cost Per Matter Matter ' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].avgAnomalies =  mydata.avganomalies;
           });

    firmService.getBillingActivity(firmId,timekeeper, dateFilter)
                 .then(
                   function( mydata ) {
                       $scope.billingHours = mydata;
                    //   console.log("$scope.billingHours = "+$scope.billingHours);
           });
  }


   $scope.expandAnomaly = function(event, params )
   {
    console.log("Fired on expand");
    $scope.sharedParameterService.setSharedParameter(params[0].name, params[0].value);
    console.log(event);
   }

   $scope.selectMatterFilter = function(selectedVal)
   {
      console.log(selectedVal);
    //alert("selectPeriod");
      selectedIndex = $scope.sharedParameterService.getSharedParameter("selectedTKIndex");
      $scope.sharedParameterService.setSharedParameter("topTKMattersKpi", selectedVal.split(":")[0]);
     $scope.sharedParameterService.setSharedParameter("topTKMattersSort", selectedVal.split(":")[0]);
      $scope.selectedTKMFilter = selectedVal.split(":")[1];
      $scope.show_MFLDropDown = false;
   }

    $scope.selectBillingPeriod = function(selectedVal)
    {
      console.log(selectedVal);
    //alert("selectPeriod");

      $scope.show_BillingDropDown = false;
    }

    // Accordion


$scope.topspendingyearselected = $scope.ytdList[0].name;
$scope.tophoursbilledyearselected = $scope.ytdList[0].name;
$scope.topviolationsyearselected = $scope.ytdList[0].name;

  $scope.topspendingyearFilter = function() {
    if($scope.topspendingyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.topspendingyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadSpendingBudgetData($scope.selectedstateCode,selectedValue);
  }

  $scope.tophoursbilledyearsFilter = function() {
    if($scope.tophoursbilledyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.tophoursbilledyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadTopHoursBilledExpenditureData($scope.selectedstateCode,selectedValue);
  }

  $scope.topviolationssyearsFilter = function() {
    if($scope.topviolationsyearselected == '2016'){
      selectedValue = $scope.ytdList[0].value;
    } else if($scope.topviolationsyearselected == '2015'){
      selectedValue = $scope.ytdList[1].value;
    }
    loadTopFirmViolationsData($scope.selectedstateCode,selectedValue);
  }
  function init() {
    currentYear = moment().format("YYYY");
    defaultDateFilter =  "01/01/" + (currentYear ) + "-" + moment((currentYear)+"-01-01").endOf("year").format("MM/DD/YYYY");
    $scope.sharedParameterService.setSharedParameter("datefilter",defaultDateFilter);
    $scope.sharedParameterService.setSharedParameter("searchTimekeeper", "");
    $scope.datefilter = defaultDateFilter;
    $scope.expand_staff_level_selection = false;
    $scope.expand_top10matters_view_selection = false;
    getFirmListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);

  }

  function updateMatterActivityGraph()
  {
      monthEmptyArray  = [null,null,null,null,null,null,null,null,null,null,null,null];
      $scope.dormantCases = monthEmptyArray;
      $scope.closedCases = monthEmptyArray;
      $scope.openCases = monthEmptyArray;
      firmService.getMatterActivity($scope.selectedFirmid, $scope.datefilter, "closed_count")
        .then(
        function(mydata){
            $scope.closedCases = extractToMonthArray(mydata);
          console.log ("Closed Cases : "+ $scope.closedCases)
          firmService.getMatterActivity($scope.selectedFirmid, $scope.datefilter, "open_count")
            .then(
              function(mydata){
                $scope.openCases = extractToMonthArray(mydata);
                console.log ("Open Cases : "+ $scope.openCases);

                $scope.mattercounts = [{name:"Dormant" , data:$scope.dormantCases},{name: "Open", data:$scope.openCases},{name: "Closed", data:$scope.closedCases}];
                console.log($scope.mattercounts);
          });
      });
  }

  function extractToMonthArray(monthlyData)
  {
       returnArray = [null,null,null,null,null,null,null,null,null,null,null,null]
       for(i = 0; i < monthlyData.length ; i++)
       {
         month = parseInt(monthlyData[i].name);
         returnArray[month - 1] = monthlyData[i].y;
       }
       console.log (returnArray);
       return returnArray;
  }
  function getFirmListData(numResults,pageNum,searchStr,sortByType){
    		  firmService.getFirmListServiceData(numResults,pageNum,searchStr,sortByType)
                .then(
                  function( mydata ) {
    			             $scope.firmList = mydata;
                       if($scope.firmList.length > 0)
                       {
                          $scope.getFirmLineItemsList($scope.firmList[0]);
                      }
                    //   console.log("returned data = " + JSON.stringify(mydata));
                       $scope.totalPageCount = mydata[numResults].total;
                    //   console.log("total page count returned" + $scope.totalPageCount);
    				    });
            };

     //calling the next page data for firm list items
     $scope.getNextPageFirmData = function(pageNumber) {
      //  console.log("Calling next page data with number = " + pageNumber);
        console.log("next page sortby = " + $scope.sortByField);
        $scope.pageNumberLineitem = pageNumber;
        getFirmListData($scope.numberOfResults,pageNumber,$scope.searchItem,$scope.sortByField);
      //  console.log("Calling next page data ended ");
     }

     //calling the search for firm list
     $scope.getSearchedData = function(searchedString) {
      //  $scope.searchItem = searchedString
        getFirmListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
     }

     $scope.getTimekeeperSearchedData = function(searchTimekeeper){
         $scope.sharedParameterService.setSharedParameter("searchTimekeeper", searchTimekeeper);
     }

     //calling the search for firm list
     $scope.getSortedData = function(sortByField, sortByFieldLabel) {
          //$scope.sortByField = sortByField;
          $scope.sortByFieldLabel = sortByFieldLabel;

          sortByValue = sortByField.split(":");
          sortByFieldArr = $scope.sortByField.split(':');
          if(sortByFieldArr[0] == sortByValue[0])
          {
              if(sortByFieldArr[1] == 'descending')
              {
                 sortByValue[1] = 'ascending';
              }
              else
              {
                 sortByValue[1] = 'descending';
              }
          }
          else if (sortByValue.length == 1)
          {
            sortByValue.push("ascending");
          }

        $scope.sortByField = sortByValue[0]+":"+sortByValue[1];

          getFirmListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
     }
     //calling the sort for firm list
     $scope.getFirmListSorted = function(item) {
        console.log("sorting the field = " + item.name);
        sortByValue = item.value.split(":");
        sortByField = $scope.sortByField.split(':');
        if(sortByField.split(':')[0] == item.value.split(":")[0])
        {
              if(sortByField[1] == 'descending')
              {
                 sortByValue[1] = 'ascending';
              }
              else
              {
                 sortByValue[1] = 'descending';
              }
        }
        else if (sortByValue.length == 1)
        {
           sortByValue.push("ascending");
        }

        $scope.sortByField = sortByValue[0]+":"+sortByValue[1];
        getFirmListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
        $scope.sortByFieldLabel = item.name;
     }



   $scope.getSortClass = function(selectedFieldForSorting) {
     if ($scope.sortLineItemByType == selectedFieldForSorting) {
       return $scope.reverseSort
       ?'arrow-down'
       :'arrow-up';
     }
      return'';
    }

     // Line itmes details call
    $scope.getFirmLineItemsList = function(item) {
        console.log("calling getFirmLineItemsList function on click with firmId = " + item.properties.firm_id[0]);

        //$scope.selectedFirmid = "338518"; // hardcoded for anomalies testing purpose.
        $scope.selectedFirmid = item.properties.firm_id[0];
        $scope.selectedFirm = item;
        $scope.toShow='Summary';
        var pageNumI = $scope.pageNumI = "1";
        var searchStrI = "";
        var sortByTypeI = "itemnumber";//$scope.sortLineItemByType;// ;
        $scope.highlighted="highlighted";
        console.log("I am calling firm list now " + pageNumI + ", " + searchStrI + "," + sortByTypeI);
        getFirmLineItemsData($scope.selectedFirmid,$scope.datefilter)
        $scope.sharedParameterService.setSharedParameter("searchTimekeeper", "");
        $scope.searchTimekeeper = "";
        $scope.show_firmDetailView = true;
        console.log("showfirmdetails " + $scope.showfirmdetails);
        $scope.sharedParameterService.setSharedParameter("staffLevel",undefined);
        $scope.sharedParameterService.setSharedParameter("firmId",item.properties.firm_id[0]);
        updateDropdowns($scope.selectedFirmid);
        updateMatterActivityGraph();

    }

    // Function to update the view by dropdowns based on selected firmid
    function updateDropdowns(firmId)
    {
       updateStaffLevelDropdown(firmId);
       updateTop10MattersDropdown(firmId)
    }

    function updateStaffLevelDropdown(firmId)
    {
       console.log("Staff level firm Id " + firmId + "::" +$scope.selectedFirmid );

       firmService.getFirmStaffLevels(firmId)
                 .then(
                   function( mydata ) {
                     sList = [{id:"", title:"All"}];
                     firstItem = "";
                     for(key in mydata)
                     {
                         var item = new Object();
                         item.id = key;
                         item.title = key;
                         sList.push(item);
                     }
                     $scope.staffLevelList = sList;
                     if(sList.length > 0)
                     {
                       $scope.selectedStaffLevel = sList[0].id;
                       sList[0].isSelected = true;
                       $scope.sharedParameterService.setSharedParameter("staffLevel",sList[0].id);
                     }
                });
    }

    function updateTop10MattersDropdown(firmId)
    {
       console.log("Staff level firm Id " + firmId + "::" +$scope.selectedFirmid );


       sList = [{"id":"net_amt","title":"Spend"}, {"id":"age","title":"Age"}, {"id":"dormant","title":"Dormant"}];

       $scope.top10MatterViewList = sList;

       $scope.selectedTop10MattersView = sList[0].title;
       sList[0].isSelected = true;
       $scope.sharedParameterService.setSharedParameter("top10mattersview",sList[0].id);
    }

    // Callback function to retrieve data for firmlineitem details.
     function getFirmLineItemsData(firmId,dateFilter){
          firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget1")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                        iData = [];
                     var test = $filter('currency')(mydata.spending, '$');
                        iData.push({key:"YTD Spend",y: mydata.spending, color:"#c31820"},
                                     {key:"Budget",y: mydata.budget, color:"#cbcbcb"})
                        $scope.invoiceSummary=iData;
           });
           firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget2")
                 .then(
                   function( mydata ) {
                      fData = [];
                      fData.push({key:"Firm",y: mydata.firmblendedrate, color:"#92cd0d"},
                                 {key:"State Average",y: mydata.stateblendedrate, color:"#cbcbcb"})
                      $scope.billingRate=fData;
           });
           firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget3")
                 .then(
                   function( mydata ) {
                       fData = [];
                       fData.push({key:"Opened",y: mydata.opencount, color:"#029fdb"},
                                  {key:"Closed",y: mydata.closedcount, color:"#cbcbcb"})
                       $scope.matterActivity=fData;
           });
           firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget4")
                 .then(
                   function( mydata ) {
                       $scope.costPerMatter = mydata.costpermatter;
           });
           firmService.getFirmLineItemsServiceData(firmId, dateFilter, "widget5")
                 .then(
                   function( mydata ) {
                       $scope.averageCaseLength = mydata.avgcaselength;
           });

           firmService.getFirmsAnomaliesSummary(firmId, dateFilter)
                 .then(
                   function( mydata ) {
                       $scope.firmAnomalies = mydata[0];
                       console.log("$scope.firmAnomalies = "+$scope.firmAnomalies);
           });

        };
    init();
}]);

//DataService containing all the data calls from backend.

	angular.module('FirmDataService', [])
      .service('firmService', function ($http,$q) {

      // Service method to get the firm listing
      // Return service methodes.
      return({
            getFirmListServiceData: getFirmListServiceData,
            getFirmLineItemsServiceData: getFirmLineItemsServiceData,
            getFirmStaffLevels : getFirmStaffLevels,
            getMatterActivity  :  getMatterActivity,
            getFirmsAnomaliesSummary:getFirmsAnomaliesSummary,
            getTimekeperData : getTimekeperData,
            getBillingActivity: getBillingActivity,

      });

      // start call to get firm list service data
      function  getFirmListServiceData(numResultsS,pageNumS,searchStrS,sortByTypeS) {
       var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/FirmsList",
      			        params: {
                              noofresults: numResultsS,
                              pagenumber: pageNumS,
                              searchstring: searchStrS,
                              sortbyfield: sortByTypeS
      				        }
              });
            return(request.then( handleSuccess, handleError ) );
      		}

          // start call to get firm list service data
          function  getFirmLineItemsServiceData(firmIdL, dateFileterL, widgetNameL) {

            console.log("Passing parameters in getFirmLineItemsServiceData " + "firmeIdL = " + firmIdL + " dateFileterL = " + dateFileterL + " widgetNameL = "
            + widgetNameL);
           var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/firms_details",
          			        params: {
                                  firmid: firmIdL,
                                  datefilter: dateFileterL,
                                  widgetname: widgetNameL
          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
          		}

            // start call to get firm time keeper summary data
          function  getTimekeperData(firmIdL, timekeeperL , dateFileterL, widgetNameL) {

            console.log("Passing parameters in getTimekeperData " + "firmeIdL = " + firmIdL + " timekeeperL = " + timekeeperL + " dateFileterL = " + dateFileterL + " widgetNameL = "
            + widgetNameL);
           var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/firm_timekeeper_details",
          			        params: {
                                  firmid: firmIdL,
                                  datefilter: dateFileterL,
                                  widgetname: widgetNameL,
                                  timekeeper : timekeeperL
          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
          		}

              // start call to get firm sumamry for total invoices, lineitem and total anomalies service data
              function  getFirmsAnomaliesSummary(firmId,datefilterS) {
               var request = $http({
                            method: "post",
                            url: "/AppBuilder/endpoint/FirmsAnomaliesSummary",
                            params: {
                                      datefilter: datefilterS,
                                      filters: "firm_id>>"+firmId,
                                      selectedkpi: "anomaly_description",
                                      subcategory: "firm_name"
                              }
                      });
                    return(request.then( handleSuccess, handleError ) );
                  }

    // start call to get firm stafflevelsdata
      function  getFirmStaffLevels(firmId) {
       var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/AnalysisDataEndpoint",
      			        params: {
                              FindFieldName: "staff_level",
                              FilterValue: "firm_id>>"+firmId
      				        }
              });
            return(request.then( handleSuccess, handleError ) );
      		}
    // start call to get firm monthly activity data
      function  getMatterActivity(firmId, dateFilter, caseStatus) {
       var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/matteractivity",
      			        params: {
                              category: "firm_id",
                              categoryvalue : firmId,
                              datefilter : dateFilter,
                              excludetotal : 'Y',
                              filters : '',
                              noofresults : 12,
                              selectedkpi : caseStatus,
                              subcategory : 'date:%m'
      				        }
              });
            return(request.then( handleSuccess, handleError ) );
      		}
//endpoint("apoorvanalysischarts", category: "full_name", categoryvalue: "Vittitoe, Craig||", charttype: "timeline", datefilter: "01/01/2016-12/31/2016", filters: "firm_id>>50",
// selectedkpi: "hours", subcategory: "full_name")
          // start call to get billing activity data
            function  getBillingActivity(firmId, timekeeper, dateFilter) {
             var request = $http({
                          method: "post",
                          url: "/AppBuilder/endpoint/apoorvanalysischarts",
                          params: {
                                    category: "full_name",
                                    categoryvalue : timekeeper+"||",
                                    charttype:"timeline",
                                    datefilter : dateFilter,
                                    filters : "firm_id>>"+firmId,
                                    selectedkpi : "hours",
                                    subcategory : "full_name"
                            }
                    });
                  return(request.then( handleSuccess, handleError ) );
                }


      // Common method to handle the request from the server
      function handleError( response ) {
          if (
              ! angular.isObject( response.data ) ||
              ! response.data.message
              ) {
              return( $q.reject( "An unknown error occurred." ) );
          }
          return( $q.reject( response.data.message ) );
      }
      function handleSuccess( response ) {
		      return( response.data);
      }
	   // end call to get data from service.


	  });

var DEFAULT_ID = '__default';

function getPeriodHierarchy()
{
     var dList = [];

    currentYear = moment().format("YYYY");
    i = 0;
    while( currentYear - i >= 2012)
    {

            var item = new Object();
            item.id = "01/01/" + (currentYear - i) + "-" + moment((currentYear - i)+"-01-01").endOf("year").format("MM/DD/YYYY");
            item.title = (currentYear - i);
            item.items = [];
            for(j = 1 ; j < 12; j+=3)
            {
                    qDateStr = "0"+j +"/01/" + (currentYear - i);
                    if(moment().fquarter(1).start > moment(qDateStr).fquarter(1).start)
                    {
                            var qItem = new Object();
                            qItem.id = moment(moment(qDateStr).fquarter(1).start).format("MM/DD/YYYY") +"-"+ moment(moment(qDateStr).fquarter(1).end).format("MM/DD/YYYY");
                            qItem.title = moment(qDateStr).fquarter(1).toString();
                            qItem.displayTitle = qItem.title + " " + (currentYear - i);
                            qItem.items = [];
                            for(k = j ; k < j+3; k++)
                            {
                                    var mItem = new Object();
                                    startDateStr = "";
                                    if(k < 10)
                                    {
                                            startDateStr = "0"+k +"/01" +"/"  + (currentYear - i);
                                        }
                                        else
                                        {
                                                startDateStr =  k +"/01"+ "/" +(currentYear - i);
                                        }
                                        //console.log(startDateStr);
                                        mItem.id = moment(startDateStr).format("MM/DD/YYYY") +"-"+ moment(startDateStr).endOf("month").format("MM/DD/YYYY");
                                        mItem.title = moment(startDateStr).format("MMM");
                                        mItem.displayTitle = mItem.title + " " + (currentYear - i);
                                    qItem.items.push(mItem)
                            }
                            item.items.push(qItem)
                    }
            }
            dList.push(item);
            i++;
    }
    return dList;
}
</script>
