
<script type="text/javascript">
 $(function() {
     var start = moment().subtract(29, 'days');
     var end = moment();
     var currYear = '';
     var pervYear = '';
     var prevToPrevYear = '';

    $('input[name="daterange"]').daterangepicker({
        //startDate: start,
        //endDate: end,
        ranges: {
           '2017': ['1/1/2017', '12/31/2017'],
		       '2016': ['1/1/2016', '12/31/2016'],
           '2015': ['1/1/2015', '12/31/2015'],
		       '2014': ['1/1/2014', '12/31/2014'],
           '2013': ['1/1/2013', '12/31/2013'],
           '2012': ['1/1/2012', '12/31/2012']
        }
	});

  $('input[name="timecomprange"]').daterangepicker({
      startDate: '1/1/2016',
			endDate: '12/31/2016',
      autoUpdateInput: false,
      locale: {
          cancelLabel: 'Clear'
      },
			ranges: {
			     '2017': ['1/1/2017', '12/31/2017'],
		       '2016': ['1/1/2016', '12/31/2016'],
           '2015': ['1/1/2015', '12/31/2015'],
		       '2014': ['1/1/2014', '12/31/2014'],
           '2013': ['1/1/2013', '12/31/2013'],
           '2012': ['1/1/2012', '12/31/2012']
			}
		});

  });
  var app = angular.module('wexdashboard',['AnalysisDataService','ui.bootstrap','angularjs-dropdown-multiselect']);

      //KPI Buttons color changes

app.controller("navbarCtrl", function($scope) {

  $scope.kpibutton1 = "kpi_inactive";
  $scope.kpibutton2 = "kpi_inactive";
  $scope.kpibutton3 = "kpi_inactive";

  $scope.switchButtons = function(item) {
    $scope.kpibutton1 = "kpi_inactive";
    $scope.$parent.spending = false;
    $scope.kpibutton2 = "kpi_inactive";
    $scope.$parent.hours = false;
    $scope.kpibutton3 = "kpi_inactive";
    $scope.$parent.anomalies = false;
    //console.log($scope.$parent);
    switch (item) {
      case 1:
        $scope.kpibutton1 = "kpi_active";
        $scope.$parent.spending = true;
        break; // it encounters this break so will not continue into 'default:'
      case 2:
        $scope.kpibutton2 = "kpi_active";
        $scope.$parent.hours = true;
        break;
      case 3:
        $scope.kpibutton3 = "kpi_active";
        $scope.$parent.anomalies = true;
        break;
      default:
        console.log('default')
          // fall-through

    }

  }


});

  app.controller('analysisController',['$scope','$http','$filter','analysisService',function($scope, $http,$filter,analysisService) {


  function init() {

  //console.log("initializing the fillStateList ");
  $scope.stateselect = "";
  $scope.kpiSelected= "";
	$scope.categorySelected = "";
	$scope.subcategorySelected= "";
	$scope.valueSelected = [];
	$scope.filtersSelected = "";
	$scope.timeselected = [];
	$scope.subcategoryvalues = [];
	//$scope.subcategoryselect = 'Time Keeper'; // set default value to timekeeper. changing it with matter + firm drop down.
  $scope.subcategoryselect = 'Time Keeper';
	$scope.datarange = "";
  $scope.timecompselected = "";
  $scope.firmOrMatterParentSelected = "";
  $scope.initialtimecomp = true;
  // flags to disable the drop down
	$scope.showcompTimeCategory = false;
	$scope.showSubCategory = false;
  $scope.showStateCategory = false;
	/*$scope.spending = false;
	$scope.hours = false;*/
	$scope.rate = false;
	$scope.blended = false;
	$scope.spendbudget = false;
	$scope.cpm = false;
	$scope.comparisions = false;
	$scope.anomalies = false;
// flags to disable drop downs or button ends here.

  $scope.statefieldname = "state";
  $scope.countyfieldname = "county";
  $scope.expensefieldname = "expense";
  $scope.firmfieldname = "firm_name";
  $scope.matternamefieldname = "matter_name";
  $scope.timekeeperfieldname = "full_name";
  $scope.taskcodefieldname = "task_code";
  $scope.phasefieldname = "phase";
  $scope.stafffieldname = "staff_level";
  $scope.ratebucketfieldname = "rate";
  $scope.trialdatefieldname = "trial_date";
  $scope.lengthbucketfieldname = "case_length_bucket";
  $scope.mattertypefieldname = "matter_type";
  $scope.disputetypefieldname = "dispute_type";
  $scope.courttypefieldname = "court_type";
  $scope.teamleadfieldname = "team_lead";
  $scope.attorneyfieldname = "supervising_attorney";
  $scope.opposingcounselfieldname = "plaintiff_counsel";
  $scope.assignedcounselfieldname = "assigned_counsel";
  $scope.judgefieldname = "judge";
  $scope.opendatefieldname = "matter_open_date";
  $scope.closedatefieldname = "matter_close_date"; //"closedate";
  $scope.anomalyfieldname = "anomaly";
  $scope.anomalydescriptionfieldname = "anomaly_description" ;//"anom_desc";
  $scope.statusfieldname = "matter_status";
  $scope.legendheader = "";
	$scope.legendmiddle = "";
	$scope.legendright = "";
	$scope.stateList = [];
	$scope.countyList = [];
	$scope.firmList = [];
	$scope.timekeeperList = [];
	$scope.matternameList = [];
	$scope.taskList = [];
	$scope.phaseList = [];
	$scope.staffList = [];
	$scope.expenseList = [];
	$scope.rateList = [];
	$scope.traildateList = [];
	$scope.caselengthList = [];
	$scope.mattertypeList = [];
	$scope.disputetypeList = [];
	$scope.courttypeList = [];
	$scope.teamleadList = [];
	$scope.supervisingattorneyList = [];
	$scope.plaintiffcounselList = [];
	$scope.assignedcounselList = [];
	$scope.judgeList = [];
	$scope.anomalytypeList = [];
	$scope.matterstatusList = [];
	$scope.matteropenList = [];
	$scope.mattercloseList = [];
	$scope.selectionList = [];
  $scope.selectionListOrder = ["state","county","firm","timekeeper","mattername","task","expense"];
  $scope.selectionListOrdercolumnname = ["state","county","firm","judge","mattername","task","itemtype"];
	$scope.matterTableData = "";
	$scope.dataForMatterTableLoaded = false;


// variables to display the values of the select drop down for the user notification
  $scope.displaySelectedStateValues = "";
  $scope.displaySelectedCountyValues = "";
  $scope.displaySelectedFirmValues = "";
  $scope.displaySelectedExpenseValues = "";
  $scope.displaySelectedTimekeeperValues = "";
  $scope.displaySelectedMatternameValues = "";
  $scope.displaySelectedTaskValues = "";
  $scope.displaySelectedPhaseValues = "";
  $scope.displaySelectedStaffValues = "";

  $scope.displaySelectedRateValues = "";
  $scope.displaySelectedTraildateValues = "";
  $scope.displaySelectedCaseLengthValues = "";
  $scope.displaySelectedMatterTypeValues = "";
  $scope.displaySelectedDisputeTypeValues = "";
  $scope.displaySelectedCourtTypeValues = "";
  $scope.displaySelectedTeamLeadValues = "";
  $scope.displaySelectedSupervisingAttorneyValues = "";
  $scope.displaySelectedPlaintiffCounselValues = "";
  $scope.displaySelectedAssignedCounselValues = "";
  $scope.displaySelectedJudgeValues = "";
  $scope.displaySelectedMatteropenValues = "";
  $scope.displaySelectedMattercloseValues = "";
  $scope.displaySelectedAnomalyTypeValues = "";
  $scope.displaySelectedMatterstatusValues = "";
  $scope.displaySelectedTimeCompValues = "";
  $scope.showPieChart = false;
  $scope.searchSelectAllSettings = { enableSearch: true, showCheckAll: false, showUncheckAll:false,keyboardControls: true, styleActive: true,scrollable: true,scrollableHeight: '200px'};
  $scope.searchSelectMatterSettings = { enableSearch: true, showCheckAll: false, showUncheckAll:false,keyboardControls: true, styleActive: true,scrollable: true,scrollableHeight: '300px'};
  $scope.searchSelectStateModel = [];
  $scope.stateChangeEventListeners = {
      onSelectionChanged: onStateSelectionChanged
      // onItemDeselect: onItemDeselect,
      // onSelectAll: onSelectAll,
      // onDeselectAll: onDeselectAll
  };
  $scope.searchSelectCountyModel = [];
  $scope.countyChangeEventListeners = {
  	  onSelectionChanged: onCountySelectionChanged
  };
  $scope.searchSelectFirmModel = [];
  $scope.firmChangeEventListeners = {
  	  onSelectionChanged: onFirmSelectionChanged
  };
  $scope.searchSelectTimekeeperModel = [];
  $scope.timekeeperChangeEventListeners = {
      onSelectionChanged: onTimekeeperSelectionChanged
  };
  $scope.searchSelectMatterModel = [];
  $scope.matterChangeEventListeners = {
      onSelectionChanged: onMatterSelectionChanged
  };
  $scope.searchSelectTaskModel = [];
  $scope.taskChangeEventListeners = {
      onSelectionChanged: onTaskSelectionChanged
  };
  $scope.searchSelectStaffModel = [];
  $scope.staffChangeEventListeners = {
      onSelectionChanged: onStaffSelectionChanged
  };
  $scope.searchSelectPhaseModel = [];
  $scope.phaseChangeEventListeners = {
      onSelectionChanged: onPhaseSelectionChanged
  };
  $scope.searchSelectExpenseModel = [];
  $scope.expenseChangeEventListeners = {
      onSelectionChanged: onExpenseSelectionChanged
  };

  // filter drop downs
  $scope.searchSelectRateModel = [];
  $scope.rateChangeEventListeners = {
      onSelectionChanged: onRateSelectionChanged
  };

  $scope.searchSelectTrialDateModel = [];
  $scope.trialDateChangeEventListeners = {
      onSelectionChanged: onTrialDateSelectionChanged
  };
  $scope.searchSelectCaseLengthModel = [];
  $scope.caseLengthChangeEventListeners = {
      onSelectionChanged: onCaseLengthSelectionChanged
  };
  $scope.searchSelectMatterTypeModel = [];
  $scope.matterTypeChangeEventListeners = {
      onSelectionChanged: onMatterTypeSelectionChanged
  };
  $scope.searchSelectMatterStatusModel = [];
  $scope.matterStatusChangeEventListeners = {
      onSelectionChanged: onMatterStatusSelectionChanged
  };
  $scope.searchSelectMatterOpenDateModel = [];
  $scope.matterOpenDateChangeEventListeners = {
      onSelectionChanged: onMatterOpenDateSelectionChanged
  };
  $scope.searchSelectMatterCloseDateModel = [];
  $scope.matterCloseDateChangeEventListeners = {
      onSelectionChanged: onMatterCloseDateSelectionChanged
  };
  $scope.searchSelectDisputeTypeModel = [];
  $scope.disputeTypeChangeEventListeners = {
      onSelectionChanged: onDisputeTypeSelectionChanged
  };
  $scope.searchSelectCourtTypeModel = [];
  $scope.courtTypeChangeEventListeners = {
      onSelectionChanged: onCourtTypeSelectionChanged
  };
  $scope.searchSelectTeamLeadModel = [];
  $scope.teamLeadChangeEventListeners = {
      onSelectionChanged: onTeamLeadSelectionChanged
  };
  $scope.searchSelectSupervisingAttorneyModel = [];
  $scope.supervisingAttorneyChangeEventListeners = {
      onSelectionChanged: onSupervisingAttorneySelectionChanged
  };
  $scope.searchSelectPlaintiffModel = [];
  $scope.plaintiffChangeEventListeners = {
      onSelectionChanged: onPlaintiffSelectionChanged
  };
  $scope.searchSelectAssignedCounselModel = [];
  $scope.assignedCounselChangeEventListeners = {
      onSelectionChanged: onAssignedCounselSelectionChanged
  };
  $scope.searchSelectJudgeModel = [];
  $scope.judgeChangeEventListeners = {
      onSelectionChanged: onJudgeSelectionChanged
  };
  $scope.searchSelectAnomalyTypeModel = [];
  $scope.anomalyTypeChangeEventListeners = {
      onSelectionChanged: onAnomalyTypeSelectionChanged
  };
  fillStateList();
}

 function updateChartHeader(cat, kpi){
   $('.chartHeaderLeft').empty().html(function(){
      return '<p>' + cat + ': ' + kpi + '</p>';
    });
 }

 $('input[name="timecomprange"]').on('cancel.daterangepicker', function(ev, picker) {
      $(this).val('');
      $scope.$apply( function() {
          $scope.initialtimecomp = "true";
          $scope.showcompTimeCategory = false;
          $scope.timecompselected = "";
          $scope.displaySelectedTimeCompValues = "";
      });
  });

  $('input[name="timecomprange"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
      $scope.$apply( function() {
          $scope.initialtimecomp = "false";
          $scope.showcompTimeCategory = true;
          $scope.displaySelectedTimeCompValues = $scope.timecompselected;
        //  console.log("comp selected = " + $scope.timecompselected);
      });
  });

	function fillStateList() {
	//console.log("Get the states list ");
   $scope.stateList = [];
   analysisService.getAnalysisData("","state")
        .then(
              function( mydata ) {
              for(var i in mydata) {
                $scope.stateList.push(
                  {
                    id:i,
                    label: i
                  });
              };
		    });
    };






    // Method to return selectd values from dropdown and concate different values using pipe. Use Id of the dropdown when it is available
    function getSelectedValues(sourceParams){
      var sourceValue = "";
    //  console.log("getSelectedValues sourceParams length = " + sourceParams.length);
      for (i = 0; i < sourceParams.length; i++) {
        sourceValue = sourceValue + sourceParams[i].label + "||"; //need to add this after we update endpoint to handle multiple values separated by ||
    //    console.log("Returned value from getSelectedValues = " + sourceValue);
      }
      return sourceValue;
    }

    // Method to return selectd values from dropdown and concate different values using pipe. Use Id of the dropdown when it is available
    function getSelectedMatterValues(sourceParams){
      var sourceValue = "";
      for (i = 0; i < sourceParams.length; i++) {
        sourceValue = sourceValue + getMatterId(sourceParams[i].label)  + "||"; //need to add this after we update endpoint to handle multiple values  separated by ||
    //    console.log("Returned value from getSelectedParams = " + sourceValue);
      }
      return sourceValue;
    }



    function getMatterId(matternamelabel) {
      var matterId = "";
      if(matternamelabel != "") {
          matterId = matternamelabel.split('->')[1];
      }
      return matterId;
    }


    // Method to return selectd values from dropdown and concate different values using pipe
    function getSelectedValuesForReport(sourceParams){
      $scope.valueSelected = [];
      var labelValue = "";
      for (i = 0; i < sourceParams.length; i++) {
        if($scope.categorySelected == $scope.matternamefieldname){
           labelValue = getMatterId(sourceParams[i].label)
        }

        else {
          labelValue = sourceParams[i].label
        }
      //  console.log("label value in getSelectedValuesForReport = " + labelValue);
        $scope.valueSelected.push(labelValue);
      }
    //  console.log("Returned value from getSelectedValuesForReport = " + $scope.valueSelected.length);
    }

    function contains(arrayItems, item) {
        return arrayItems.indexOf(item) > -1;
    }
    // This method will returns the formatted filtervalue required for the endpoints.
    function getSelectedParams(sourceParams,category){
      var selectedValue = "";
      if(sourceParams.length > 0) {
      if(category == $scope.matternamefieldname) {
        selectedValue = getSelectedMatterValues(sourceParams);

                  console.log("selected value is"+selectedValue);

        return $scope.matternamefieldname + ">>" + selectedValue;
      }

      else {
        selectedValue = getSelectedValues(sourceParams);
      //  console.log("rrerwerwerwer" + selectedValue);
      }
    } else {
    //  console.log("Returning empty selectedValue from getSelectedParams = " + selectedValue);
      return selectedValue = "";

    }

      // for (i = 0; i < sourceParams.length; i++) {
      //   selectedValue = selectedValue + sourceParams[i].label + "||";
      //   console.log("Returned value from getSelectedParams = " + selectedValue);
      // }
      // if(category == $scope.matternamefieldname){
      //   return $scope.matternamefieldname + ">>" + selectedValue;
      // }
      if(category == $scope.statefieldname){
        return $scope.statefieldname + ">>" + selectedValue;
      }
      if(category == $scope.countyfieldname){
        return $scope.countyfieldname + ">>" + selectedValue;
      }
      if(category == $scope.firmfieldname){
        return $scope.firmfieldname + ">>" + selectedValue;
      }
      if(category == $scope.timekeeperfieldname){
        return $scope.timekeeperfieldname + ">>" + selectedValue;
      }
      if(category == $scope.taskcodefieldname){
        return $scope.taskcodefieldname + ">>" + selectedValue;
      }
      if(category == $scope.stafffieldname){
        return $scope.stafffieldname + ">>" + selectedValue;
      }
      if(category == $scope.phasefieldname){
        return $scope.phasefieldname + ">>" + selectedValue;
      }
      if(category == $scope.expensefieldname){
        return $scope.expensefieldname + ">>" + selectedValue;
      }
      if(category == $scope.ratebucketfieldname) {
        return $scope.ratebucketfieldname + ">>" + selectedValue;
      }
      if(category == $scope.trialdatefieldname) {
        return $scope.trialdatefieldname + ">>" + selectedValue;
      }
      if(category == $scope.lengthbucketfieldname) {
        return $scope.lengthbucketfieldname + ">>" + selectedValue;
      }
      if(category == $scope.mattertypefieldname) {
        return $scope.mattertypefieldname + ">>" + selectedValue;
      }
      if(category == $scope.disputetypefieldname) {
        return $scope.disputetypefieldname + ">>" + selectedValue;
      }
      if(category == $scope.courttypefieldname) {
        return $scope.courttypefieldname + ">>" + selectedValue;
      }
      if(category == $scope.teamleadfieldname) {
        return $scope.teamleadfieldname + ">>" + selectedValue;
      }
      if(category == $scope.attorneyfieldname) {
        return $scope.attorneyfieldname + ">>" + selectedValue;
      }
      if(category == $scope.opposingcounselfieldname) {
        return $scope.opposingcounselfieldname + ">>" + selectedValue;
      }
      if(category == $scope.assignedcounselfieldname) {
        return $scope.assignedcounselfieldname + ">>" + selectedValue;
      }
      if(category == $scope.judgefieldname) {
        return $scope.judgefieldname + ">>" + selectedValue;
      }
      if(category == $scope.statusfieldname) {
        return $scope.statusfieldname + ">>" + selectedValue;
      }
      if(category == $scope.opendatefieldname) {
        return $scope.opendatefieldname + ">>" + selectedValue;
      }
      if(category == $scope.closedatefieldname) {
        return $scope.closedatefieldname + ">>" + selectedValue;
      }
      if(category == $scope.anomalydescriptionfieldname) {
        return $scope.anomalydescriptionfieldname + ">>" + selectedValue;
      }
    };

    // function called when state drop down changed
    function onStateSelectionChanged() {
      var selectedState = getSelectedParams($scope.searchSelectStateModel,$scope.statefieldname);
      if(selectedState != "") {
        if($scope.searchSelectStateModel.length >= 0) {
          updateCountyList(selectedState);
          updateFirmList(selectedState);
          updateMatterNameList(selectedState);
          updateTimeKeeperList(selectedState);
          updateTaskList(selectedState);
          updatePhaseList(selectedState);
          updateStaffList(selectedState);
          updateExpenseList(selectedState);
          updateAllFilters(selectedState);
          $scope.displaySelectedStateValues = $scope.searchSelectStateModel.map(function(el){return el.label}).join("||");
          if(contains($scope.selectionList,$scope.statefieldname)){
          //  console.log("selection list already contains state");
          } else {
                $scope.selectionList.push($scope.statefieldname);
          }
          if($scope.displaySelectedStateValues>=0){
              //console.log("removing the state values as nothing is selected");
              index = $scope.selectionList.indexOf($scope.statefieldname);
              //console.log("state index from selection list = " + index);
            if(index > -1) {
              $scope.selectionList.splice(index,1);
            //  console.log("Removed the state from selection list");
            }
          }
      }
    } else {
        $scope.displaySelectedStateValues = "";
        $scope.countyList = [];
        $scope.searchSelectCountyModel = [];
        $scope.displaySelectedCountyValues = "";
        $scope.firmList = [];
        $scope.searchSelectFirmModel = [];
        $scope.displaySelectedFirmValues = "";
        $scope.timekeeperList = [];
        $scope.searchSelectStaffModel = [];
        $scope.displaySelectedTimekeeperValues = "";
        $scope.matternameList = [];
        $scope.searchSelectMatterModel = [];
        $scope.displaySelectedMatternameValues = "";
        $scope.taskList = [];
        $scope.searchSelectTaskModel = [];
        $scope.displaySelectedTaskValues = "";
        $scope.expenseList = [];
        $scope.searchSelectExpenseModel = [];
        $scope.displaySelectedExpenseValues = "";
        $scope.phaseList = [];
        $scope.searchSelectPhaseModel = [];
        $scope.displaySelectedPhaseValues = "";
        $scope.staffList = [];
        $scope.searchSelectStaffModel = [];
        $scope.displaySelectedStaffValues = "";
      //  console.log("=====***no updates fired from onStateSelectionChanged because no value is selected and set the display values and model to none***====== ");
      }
    };

    // function called when county drop down changed. Call only dropdowns which are affected by county selection
    function onCountySelectionChanged() {
      //console.log("selecteditem in countyDropDownSelect");
      var selectedCounty = getSelectedParams($scope.searchSelectCountyModel,$scope.countyfieldname);
      if(selectedCounty != "") {
      if($scope.searchSelectCountyModel.length >= 0) {
        updateFirmList(selectedCounty);
        updateTimeKeeperList(selectedCounty);
        updateMatterNameList(selectedCounty);
        updateTaskList(selectedCounty);
        updatePhaseList(selectedCounty);
        updateStaffList(selectedCounty);
        updateExpenseList(selectedCounty);
        updateAllFilters(selectedCounty);
        $scope.displaySelectedCountyValues = $scope.searchSelectCountyModel.map(function(el){return el.label}).join("||");
        if(contains($scope.selectionList,$scope.countyfieldname)){
        //  console.log("selection list already contains county");
        } else {
              $scope.selectionList.push($scope.countyfieldname);
        }
        if($scope.displaySelectedCountyValues>=0){
            //console.log("removing the county values as nothing is selected");
            index = $scope.selectionList.indexOf($scope.countyfieldname);
            //console.log("county index from selection list = " + index);
					if(index > -1) {
					  $scope.selectionList.splice(index,1);
          //  console.log("Removed the county from selection list");
          }
        }
      }
    } else {
        $scope.displaySelectedCountyValues = "";
      }
    };


    // function called when timekeeper drop down changed. Call only dropdowns which are affected by timekeeper selection
    function onTimekeeperSelectionChanged() {
    //  console.log("selecteditem in timekeeperDropDownSelect");
      var selectedTimekeeper = getSelectedParams($scope.searchSelectTimekeeperModel,$scope.timekeeperfieldname);
      if(selectedTimekeeper != "") {
      if($scope.searchSelectTimekeeperModel.length >= 0) {
        updateMatterNameList(selectedTimekeeper);
        updateTaskList(selectedTimekeeper);
        updatePhaseList(selectedTimekeeper);
        updateExpenseList(selectedTimekeeper);
        updateAllFilters(selectedTimekeeper);
        $scope.displaySelectedTimekeeperValues = $scope.searchSelectTimekeeperModel.map(function(el){return el.label}).join("||");
        console.log("selection list is"+$scope.selectionList + "," + $scope.timekeeperfieldname);
        if(contains($scope.selectionList,$scope.timekeeperfieldname)){
        //  console.log("selection list already contains timekeeper");
        } else {
              $scope.selectionList.push($scope.timekeeperfieldname);
            }
            if($scope.displaySelectedTimekeeperValues>=0){
                //console.log("removing the timekeeper values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.timekeeperfieldname);
                //console.log("timekeeper index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
              //  console.log("Removed the firm from selection list");
              }
            }
          }
        } else {
          $scope.displaySelectedTimekeeperValues = "";
        }
    };


    // function called when firm drop down changed. Call dropdowns which are affected by firm selection
    function onFirmSelectionChanged() {
      console.log("$scope.searchSelectFirmModel.length =" + $scope.searchSelectFirmModel.length);
      console.log("$scope.searchSelectMatterModel.length =" + $scope.searchSelectMatterModel.length);
      if($scope.searchSelectMatterModel ==0 && $scope.searchSelectFirmModel ==0) {
         $scope.firmOrMatterParentSelected = "";
         $scope.displaySelectedFirmValues = "";
      } else {
         if($scope.searchSelectMatterModel<1) {
         $scope.firmOrMatterParentSelected = "firmsdd";
         console.log("first condition satisfied");
       }
      }
      console.log("onFirmSelectionChanged $scope.firmOrMatterParentSelected = " + $scope.firmOrMatterParentSelected);
      if($scope.firmOrMatterParentSelected != "firmsdd") {
        $scope.displaySelectedMatternameValues = "";
        updateMatterNameList(selectedFirm);
      }
        var selectedFirm = getSelectedParams($scope.searchSelectFirmModel,$scope.firmfieldname);
        if(selectedFirm != "") {
        $scope.displaySelectedFirmValues = $scope.searchSelectFirmModel.map(function(el){return el.label}).join("||");
          if(contains($scope.selectionList,$scope.firmfieldname)){
          //  console.log("selection list already contains firm");
          } else {
                $scope.selectionList.push($scope.firmfieldname);
          }
          if($scope.displaySelectedFirmValues>=0){
              //console.log("removing the firm values as nothing is selected");
              index = $scope.selectionList.indexOf($scope.firmfieldname);
              //console.log("firm index from selection list = " + index);
            if(index > -1) {
              $scope.selectionList.splice(index,1);
            //  console.log("Removed the firm from selection list");
            }
          }

          updateTimeKeeperList(selectedFirm);
          updateTaskList(selectedFirm);
          updatePhaseList(selectedFirm);
          updateStaffList(selectedFirm);
          updateExpenseList(selectedFirm);
          updateAllFilters(selectedFirm);
          }  else {
            $scope.displaySelectedFirmValues = "";
          }
    };

    function getFilteredDisplayArray(itemA, itemB) {
      for (var i=0; i<itemB.length; i++) {
          var index = undefined;
          while ((index = itemA.indexOf(itemB[i])) !== -1) {
              itemA.splice(index, 1);
          }
      }
      return itemA;
      }

    function onMatterSelectionChanged() {
      console.log("$scope.searchSelectFirmModel.length =" + $scope.searchSelectFirmModel.length);
      console.log("$scope.searchSelectMatterModel.length =" + $scope.searchSelectMatterModel.length);
      if($scope.searchSelectMatterModel ==0 && $scope.searchSelectFirmModel ==0) {
         $scope.firmOrMatterParentSelected = "";
         $scope.displaySelectedMatternameValues = "";
      } else {
         if($scope.searchSelectFirmModel.length<1) {
          $scope.firmOrMatterParentSelected = "mattersdd";
          console.log("second condition satisfied");
        }
      }
      console.log("onMatterSelectionChanged $scope.firmOrMatterParentSelected = " + $scope.firmOrMatterParentSelected);
        if($scope.firmOrMatterParentSelected == "mattersdd") {
            updateFirmList(selectedMattername);
            $scope.displaySelectedFirmValues = "";
        }
          var selectedMattername = getSelectedParams($scope.searchSelectMatterModel,$scope.matternamefieldname);
          if(selectedMattername != "") {
            $scope.displaySelectedMatternameValues = $scope.searchSelectMatterModel.map(function(el){return el.label}).join("||");
            if(contains($scope.selectionList,$scope.matternamefieldname)){
            //  console.log("selection list already contains mattername");
            } else {
                  $scope.selectionList.push($scope.matternamefieldname);
                }
                if($scope.displaySelectedMatternameValues>=0){
                //    console.log("removing the matter name values as nothing is selected");
                    index = $scope.selectionList.indexOf($scope.matternamefieldname);
                //    console.log("mattername index from selection list = " + index);
                  if(index > -1) {
                    $scope.selectionList.splice(index,1);
              //      console.log("Removed the mattername from selection list");
                  }
                }
            updateTimeKeeperList(selectedMattername);
            updateTaskList(selectedMattername);
            updatePhaseList(selectedMattername);
            updateStaffList(selectedMattername);
            updateExpenseList(selectedMattername);
            updateAllFilters(selectedMattername);
            }else {
              $scope.displaySelectedMatternameValues = "";
            }
    };
    // function called when task drop down changed. Call only dropdowns which are affected by task selection
    function onTaskSelectionChanged() {
    //  console.log("selecteditem in taskDropDownSelect");
      var selectedTask = getSelectedParams($scope.searchSelectTaskModel,$scope.taskcodefieldname);
      if(selectedTask != "") {
      if($scope.searchSelectTaskModel.length >= 0) {
        updateFirmList(selectedTask);
				updateTimeKeeperList(selectedTask);
				updateMatterNameList(selectedTask);
				updateStaffList(selectedTask);
        updateAllFilters(selectedTask);
        $scope.displaySelectedTaskValues = $scope.searchSelectTaskModel.map(function(el){return el.label.trim()}).join("||");
        console.log('the values ', $scope.displaySelectedTaskValues, 'the model ',  $scope.searchSelectTaskModel);
        if(contains($scope.selectionList,$scope.taskcodefieldname)){
      //    console.log("selection list already contains taskcode");
        } else {
              $scope.selectionList.push($scope.taskcodefieldname);
            }
            if($scope.displaySelectedTaskValues>=0){
                //console.log("removing the task values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.taskcodefieldname);
                //console.log("taskcode index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
          //      console.log("Removed the taskcode from selection list");
              }
            }
      }
      } else {
        $scope.displaySelectedTaskValues = "";
      }
    };

    // function called when staff drop down changed. Call only dropdowns which are affected by staff selection
    function onStaffSelectionChanged() {
    //  console.log("selecteditem in staffDropDownSelect");
      var selectedStaff = getSelectedParams($scope.searchSelectStaffModel,$scope.stafffieldname);
      if(selectedStaff != "") {
      if($scope.searchSelectStaffModel.length >= 0) {
        updateTimeKeeperList(selectedStaff);
        updateMatterNameList(selectedStaff);
        updateTaskList(selectedStaff);
        updatePhaseList(selectedStaff);
        updateExpenseList(selectedStaff);
        updateAllFilters(selectedStaff);
        $scope.displaySelectedStaffValues = $scope.searchSelectStaffModel.map(function(el){return el.label}).join("||");
        if(contains($scope.selectionList,$scope.stafffieldname)){
    //      console.log("selection list already contains staff");
        } else {
              $scope.selectionList.push($scope.stafffieldname);
            }
            if($scope.displaySelectedStaffValues>=0){
                //console.log("removing the staff values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.stafffieldname);
                //console.log("staff index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
            //    console.log("Removed the staff from selection list");
              }
            }
      }
      } else {
        $scope.displaySelectedStaffValues = "";
      }
    };

    // function called when phase drop down changed. Call only dropdowns which are affected by phase selection
    function onPhaseSelectionChanged() {
    //  console.log("selecteditem in phaseDropDownSelect");
      var selectedPhase = getSelectedParams($scope.searchSelectPhaseModel,$scope.phasefieldname);
      if(selectedPhase != "") {
      if($scope.searchSelectPhaseModel.length >= 0) {
        updateFirmList(selectedPhase);
        updateTimeKeeperList(selectedPhase);
        updateMatterNameList(selectedPhase);
        updateTaskList(selectedPhase);
        updateStaffList(selectedPhase);
        updateExpenseList(selectedPhase);
        updateAllFilters(selectedPhase);
        $scope.displaySelectedPhaseValues = $scope.searchSelectPhaseModel.map(function(el){return el.label}).join("||");
        if(contains($scope.selectionList,$scope.phasefieldname)){
        //  console.log("selection list already contains phase");
        } else {
              $scope.selectionList.push($scope.phasefieldname);
            }
            if($scope.displaySelectedPhaseValues>=0){
                //console.log("removing the phase values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.stafffieldname);
                //console.log("phase index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
            //    console.log("Removed the phase from selection list");
              }
            }
      }
      } else {
        $scope.displaySelectedPhaseValues = "";
      }
    };

    // function called when expense drop down changed. Call only dropdowns which are affected by expense selection
    function onExpenseSelectionChanged() {
    //  console.log("selecteditem in expenseDropDownSelect");
      var selectedExpense = getSelectedParams($scope.searchSelectExpenseModel,$scope.expensefieldname);
      if(selectedExpense != "") {
      if($scope.searchSelectExpenseModel.length >= 0) {
        updateFirmList(selectedExpense);
				updateTimeKeeperList(selectedExpense);
				updateMatterNameList(selectedExpense);
				updateTaskList(selectedExpense);
				updateStaffList(selectedExpense);
				updatePhaseList(selectedExpense);
        updateAllFilters(selectedExpense);
        $scope.displaySelectedExpenseValues = $scope.searchSelectExpenseModel.map(function(el){return el.label}).join("||");
        if(contains($scope.selectionList,$scope.expensefieldname)){
      //    console.log("selection list already contains expense");
        } else {
              $scope.selectionList.push($scope.expensefieldname);
            }
            if($scope.displaySelectedExpenseValues>=0){
                //console.log("removing the expense values as nothing is selected");
                index = $scope.selectionList.indexOf($scope.expensefieldname);
                //console.log("expense index from selection list = " + index);
              if(index > -1) {
                $scope.selectionList.splice(index,1);
        //        console.log("Removed the expense from selection list");
              }
            }
        }
      } else {
        $scope.displaySelectedExpenseValues = "";
    }
    };

    function onRateSelectionChanged() {
      if($scope.searchSelectRateModel.length >= 0) {
         $scope.displaySelectedRateValues = $scope.searchSelectRateModel.map(function(el){return el.label}).join("||");
      }
    };

    function onTrialDateSelectionChanged() {
      if($scope.searchSelectTrialDateModel.length >= 0) {
         $scope.displaySelectedTraildateValues = $scope.searchSelectTrialDateModel.map(function(el){return el.label}).join("||");
      }
    };

    function onCaseLengthSelectionChanged() {
      if($scope.searchSelectCaseLengthModel.length >= 0) {
         $scope.displaySelectedCaseLengthValues = $scope.searchSelectCaseLengthModel.map(function(el){return el.label}).join("||");
      }
    };

    function onMatterTypeSelectionChanged() {
      if($scope.searchSelectMatterTypeModel.length >= 0) {
         $scope.displaySelectedMatterTypeValues = $scope.searchSelectMatterTypeModel.map(function(el){return el.label}).join("||");
      }
    };

    function onMatterStatusSelectionChanged() {
      if($scope.searchSelectMatterStatusModel.length >= 0) {
         $scope.displaySelectedMatterstatusValues = $scope.searchSelectMatterStatusModel.map(function(el){return el.label}).join("||");
      }
    };

    function onMatterOpenDateSelectionChanged() {
      if($scope.searchSelectMatterOpenDateModel.length >= 0) {
         $scope.displaySelectedMatteropenValues = $scope.searchSelectMatterOpenDateModel.map(function(el){return el.label}).join("||");
      }
    };

    function onMatterCloseDateSelectionChanged() {
      if($scope.searchSelectMatterCloseDateModel.length >= 0) {
         $scope.displaySelectedMattercloseValues = $scope.searchSelectMatterCloseDateModel.map(function(el){return el.label}).join("||");
      }
    };

    function onDisputeTypeSelectionChanged() {
      if($scope.searchSelectDisputeTypeModel.length >= 0) {
         $scope.displaySelectedDisputeTypeValues = $scope.searchSelectDisputeTypeModel.map(function(el){return el.label}).join("||");
      }
    };

    function onCourtTypeSelectionChanged() {
      if($scope.searchSelectCourtTypeModel.length >= 0) {
         $scope.displaySelectedCourtTypeValues = $scope.searchSelectCourtTypeModel.map(function(el){return el.label}).join("||");
      }
    };

    function onTeamLeadSelectionChanged() {
      if($scope.searchSelectTeamLeadModel.length >= 0) {
         $scope.displaySelectedTeamLeadValues = $scope.searchSelectTeamLeadModel.map(function(el){return el.label}).join("||");
      }
    };

    function onSupervisingAttorneySelectionChanged() {
      if($scope.searchSelectSupervisingAttorneyModel.length >= 0) {
         $scope.displaySelectedSupervisingAttorneyValues = $scope.searchSelectSupervisingAttorneyModel.map(function(el){return el.label}).join("||");
      }
    };

    function onPlaintiffSelectionChanged() {
      if($scope.searchSelectPlaintiffModel.length >= 0) {
         $scope.displaySelectedPlaintiffCounselValues = $scope.searchSelectPlaintiffModel.map(function(el){return el.label}).join("||");
      }
    };

    function onAssignedCounselSelectionChanged() {
      if($scope.searchSelectAssignedCounselModel.length >= 0) {
         $scope.displaySelectedAssignedCounselValues = $scope.searchSelectAssignedCounselModel.map(function(el){return el.label}).join("||");
      }
    };

    function onJudgeSelectionChanged() {
      if($scope.searchSelectJudgeModel.length >= 0) {
         $scope.displaySelectedJudgeValues = $scope.searchSelectJudgeModel.map(function(el){return el.label}).join("||");
      }
    };

    function onAnomalyTypeSelectionChanged() {
      if($scope.searchSelectAnomalyTypeModel.length >= 0) {
         $scope.displaySelectedAnomalyTypeValues = $scope.searchSelectAnomalyTypeModel.map(function(el){return el.label}).join("||");
      }
    };

    function updateCountyList(selecteditem) {
         $scope.countyList = [];
         $scope.countyList = getFiltersList(selecteditem,$scope.countyfieldname);
    };

    function updateExpenseList(selecteditem) {
        $scope.expenseList = [];
        $scope.expenseList = getFiltersList(selecteditem,$scope.expensefieldname);
    };

    function updateFirmList(selecteditem) {
       $scope.firmList = [];
       $scope.firmList = getFiltersList(selecteditem,$scope.firmfieldname);

    };

    function updateTimeKeeperList(selecteditem) {
       $scope.timekeeperList = [];
       $scope.timekeeperList = getFiltersList(selecteditem,$scope.timekeeperfieldname);

    };

    function updateMatterNameList(selecteditem) {
       analysisService.getMatterList(selecteditem)
           .then(
             function( mydata ) {
               $scope.matternameList = [];
               for(var i in mydata) {
                 $scope.matternameList.push(
                   {
                     id: i,
                     label:mydata[i] + "->" + i
                   });
                }
            });
    };

    function updateTaskList(selecteditem) {
      $scope.taskList = [];
      $scope.taskList = getFiltersList(selecteditem,$scope.taskcodefieldname);
    };

    function updatePhaseList(selecteditem) {
      $scope.phaseList = [];
      $scope.phaseList = getFiltersList(selecteditem,$scope.phasefieldname);
    };

    function updateStaffList(selecteditem) {
      $scope.staffList = [];
      $scope.staffList = getFiltersList(selecteditem,$scope.stafffieldname);
    };

  // common function to get different lists from the backend service based on the params passed.
  function getFiltersList(selecteditem,findfieldname){
       var dataList = [];
       //console.log("updating filterlist" + selecteditem + "," + findfieldname);
       analysisService.getAnalysisData(selecteditem,findfieldname)
         .then(
           function( mydata ) {
             for(var i in mydata) {
                 dataList.push(
                   { id:i,
                     label: i.replace('&amp;', '&')
                   });
               }
             });
        return dataList;
    };

	function updateAllFilters(selecteditem) {
		//if($scope.selectionList.length > 0) {
		//	console.log('updateAllFilters now: selecteditem value: '+selecteditem);

			$scope.rates = [];
			$scope.traildates = [];
			$scope.caselengths = [];
			$scope.mattertypes = [];
			$scope.disputetypes = [];
			$scope.courttypes = [];
			$scope.teamleads = [];
			$scope.supervisingattorneys = [];
			$scope.plaintiffcounsels = [];
			$scope.assignedcounsels = [];
			$scope.judges = [];
			$scope.matterstatuses = [];
			$scope.matteropens = [];
			$scope.mattercloses = [];
			$scope.anomalytypes = [];

      $scope.rateList= [];
      $scope.rateList = getFiltersList(selecteditem,$scope.ratebucketfieldname);
      $scope.displaySelectedRateValues = "";
      $scope.searchSelectRateModel = [];

      $scope.traildateList= [];
      $scope.traildateList = getFiltersList(selecteditem,$scope.trialdatefieldname);
      $scope.displaySelectedTraildateValues = "";
      $scope.searchSelectTrialDateModel = [];

      $scope.caselengthList= [];
      $scope.caselengthList = getFiltersList(selecteditem,$scope.lengthbucketfieldname);
      $scope.displaySelectedCaseLengthValues = "";
      $scope.searchSelectCaseLengthModel = [];

      $scope.mattertypeList= [];
      $scope.mattertypeList = getFiltersList(selecteditem,$scope.mattertypefieldname);
      $scope.displaySelectedMatterTypeValues = "";
      $scope.searchSelectMatterTypeModel = [];

      $scope.disputetypeList= [];
      $scope.disputetypeList = getFiltersList(selecteditem,$scope.disputetypefieldname);
      $scope.displaySelectedDisputeTypeValues = "";
      $scope.searchSelectDisputeTypeModel = [];

      $scope.courttypeList= [];
      $scope.courttypeList = getFiltersList(selecteditem,$scope.courttypefieldname);
      $scope.displaySelectedCourtTypeValues = "";
      $scope.searchSelectCourtTypeModel = [];

      $scope.teamleadList= [];
      $scope.teamleadList = getFiltersList(selecteditem,$scope.teamleadfieldname);
      $scope.displaySelectedTeamLeadValues = "";
      $scope.searchSelectTeamLeadModel = [];

      $scope.supervisingattorneyList= [];
      $scope.supervisingattorneyList = getFiltersList(selecteditem,$scope.attorneyfieldname);
      $scope.displaySelectedSupervisingAttorneyValues = "";
      $scope.searchSelectSupervisingAttorneyModel = [];

      $scope.plaintiffcounselList= [];
      $scope.plaintiffcounselList = getFiltersList(selecteditem,$scope.opposingcounselfieldname);
      $scope.displaySelectedPlaintiffCounselValues = "";
      $scope.searchSelectPlaintiffModel = [];

      $scope.assignedcounselList= [];
      $scope.assignedcounselList = getFiltersList(selecteditem,$scope.assignedcounselfieldname);
      $scope.displaySelectedAssignedCounselValues = "";
      $scope.searchSelectAssignedCounselModel = [];

      $scope.judgeList= [];
      $scope.judgeList = getFiltersList(selecteditem,$scope.judgefieldname);
      $scope.displaySelectedJudgeValues = "";
      $scope.searchSelectJudgeModel = [];

      $scope.matteropenList= [];
      $scope.matteropenList = getFiltersList(selecteditem,$scope.opendatefieldname);
      $scope.displaySelectedMatteropenValues = "";
      $scope.searchSelectMatterOpenDateModel = [];

      $scope.mattercloseList= [];
      $scope.mattercloseList = getFiltersList(selecteditem,$scope.closedatefieldname);
      $scope.displaySelectedMattercloseValues = "";
      $scope.searchSelectMatterCloseDateModel = [];

      $scope.anomalytypeList= [];
      $scope.anomalytypeList = getFiltersList(selecteditem,$scope.anomalydescriptionfieldname);
      $scope.displaySelectedAnomalyTypeValues = "";
      $scope.searchSelectAnomalyTypeModel = [];

      $scope.matterstatusList= [];
      $scope.matterstatusList = getFiltersList(selecteditem,$scope.statusfieldname);
      $scope.displaySelectedMatterstatusValues = "";
      $scope.searchSelectMatterStatusModel = [];

	};

	$scope.getCategorySelected = function() {
		$scope.categorySelected = $scope.selectionList[$scope.selectionList.length-1];
    console.log("getCategorySelected function ***** = " + $scope.categorySelected);
    if($scope.categorySelected == 'timekeeper')
			$scope.categorySelected = 'full_name';
		else if($scope.categorySelected == 'staff')
			$scope.categorySelected = 'staff_level';
		else if($scope.categorySelected == 'firm')
			$scope.categorySelected = 'firm_name';
		else if($scope.categorySelected == 'expense')
			$scope.categorySelected = 'expense';
		else if($scope.categorySelected == 'task')
			$scope.categorySelected = 'task_code';
      else if($scope.categorySelected == 'matter_name') // added matter_name for firm + matter combination
  			$scope.categorySelected = 'matter_name';
	};

	$scope.getSelectedKPI = function() {

		if($scope.hours) {
			$scope.kpiSelected = 'hours';
		}
		else if($scope.spending) {
			$scope.kpiSelected = 'net_amt';
		}
		else if($scope.anomalies) {
			$scope.kpiSelected = 'anomaly_description';
		}

	};

	$scope.getFilters = function() {
		$scope.filtersSelected = "";
		if($scope.searchSelectRateModel.length >= 1) {
      //console.log("$scope.searchSelectRateModel.length =" + $scope.searchSelectRateModel.length  + " value " + $scope.searchSelectRateModel[0]);
      var selectedRate = getSelectedParams($scope.searchSelectRateModel,$scope.ratebucketfieldname);
    	$scope.filtersSelected = $scope.filtersSelected + selectedRate + "&&";
		}
    if($scope.searchSelectTrialDateModel.length >= 1) {
      var selectedTrailDate = getSelectedParams($scope.searchSelectTrialDateModel,$scope.trialdatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedTrailDate + "&&";
    }
    if($scope.searchSelectCaseLengthModel.length >= 1) {
      var selectedCaseLength = getSelectedParams($scope.searchSelectCaseLengthModel,$scope.lengthbucketfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedCaseLength + "&&";
    }
    if($scope.searchSelectMatterTypeModel.length >= 1) {
      var selectedMatterType = getSelectedParams($scope.searchSelectMatterTypeModel,$scope.mattertypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterType + "&&";
    }
    if($scope.searchSelectDisputeTypeModel.length >= 1) {
      var selectedDisputeType = getSelectedParams($scope.searchSelectDisputeTypeModel,$scope.disputetypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedDisputeType + "&&";
    }
    if($scope.searchSelectCourtTypeModel.length >= 1) {
      var selectedCourtType = getSelectedParams($scope.searchSelectCourtTypeModel,$scope.courttypefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedCourtType + "&&";
    }
    if($scope.searchSelectTeamLeadModel.length >= 1) {
      var selectedTeamLead = getSelectedParams($scope.searchSelectTeamLeadModel,$scope.teamleadfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedTeamLead + "&&";
    }
    if($scope.searchSelectSupervisingAttorneyModel.length >= 1) {
      var selectedSupervisingAttorney = getSelectedParams($scope.searchSelectSupervisingAttorneyModel,$scope.attorneyfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedSupervisingAttorney + "&&";
    }
    if($scope.searchSelectPlaintiffModel.length >= 1) {
      var selectedPlaintiff = getSelectedParams($scope.searchSelectPlaintiffModel,$scope.opposingcounselfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedPlaintiff + "&&";
    }
    if($scope.searchSelectAssignedCounselModel.length >= 1) {
      var selectedAssignedCounsel = getSelectedParams($scope.searchSelectAssignedCounselModel,$scope.assignedcounselfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedAssignedCounsel + "&&";
    }
    if($scope.searchSelectJudgeModel.length >= 1) {
      var selectedJudge = getSelectedParams($scope.searchSelectJudgeModel,$scope.judgefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedJudge + "&&";
    }
    if($scope.searchSelectMatterStatusModel.length >= 1) {
      var selectedMatterStatus = getSelectedParams($scope.searchSelectMatterStatusModel,$scope.statusfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterStatus + "&&";
    }
    if($scope.searchSelectMatterOpenDateModel.length >= 1) {
      var selectedMatterOpenDate = getSelectedParams($scope.searchSelectMatterOpenDateModel,$scope.opendatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterOpenDate + "&&";
    }
    if($scope.searchSelectMatterCloseDateModel.length >= 1) {
      var selectedMatterCloseDate = getSelectedParams($scope.searchSelectMatterCloseDateModel,$scope.closedatefieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedMatterCloseDate + "&&";
    }
    if($scope.searchSelectAnomalyTypeModel.length >= 1) {
      var selectedAnomalyType = getSelectedParams($scope.searchSelectAnomalyTypeModel,$scope.anomalydescriptionfieldname);
      $scope.filtersSelected = $scope.filtersSelected + selectedAnomalyType + "&&";
    }
    //console.log("$scope.selectionList.length  =" + $scope.selectionList.length);
    if($scope.selectionList.length > 1) {
      if($scope.searchSelectStateModel.length >=1) {
        var selectedState = getSelectedParams($scope.searchSelectStateModel,$scope.statefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedState + "&&";
      }
      if($scope.searchSelectCountyModel.length >= 1) {
        var selectedCounty = getSelectedParams($scope.searchSelectCountyModel,$scope.countyfieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedCounty + "&&";
      }
      if($scope.searchSelectFirmModel.length >= 1) {
        var selectedFirm = getSelectedParams($scope.searchSelectFirmModel,$scope.firmfieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedFirm + "&&";
      }
      if($scope.searchSelectMatterModel.length >= 1) {
        var selectedMatterName = getSelectedParams($scope.searchSelectMatterModel,$scope.matternamefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedMatterName + "&&";
      }
      if($scope.searchSelectPhaseModel.length >= 1) {
        var selectedPhase = getSelectedParams($scope.searchSelectPhaseModel,$scope.phasefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedPhase + "&&";
      }
      if($scope.searchSelectExpenseModel.length >= 1) {
        var selectedExpense = getSelectedParams($scope.searchSelectExpenseModel,$scope.expensefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedExpense + "&&";
      }
      if($scope.searchSelectTaskModel.length >= 1) {
        var selectedTask = getSelectedParams($scope.searchSelectTaskModel,$scope.taskcodefieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedTask + "&&";
      }
      if($scope.searchSelectTimekeeperModel >= 1) {
        var selectedTimekeeper = getSelectedParams($scope.searchSelectTimekeeperModel,$scope.timekeeperfieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedTimekeeper + "&&";
      }
      if($scope.searchSelectStaffModel.length >= 1) {
        var selectedStaff = getSelectedParams($scope.searchSelectStaffModel,$scope.stafffieldname);
        $scope.filtersSelected = $scope.filtersSelected + selectedStaff + "&&";
      }
  }
		//console.log("FILTER SELECTION IS::::"+$scope.filtersSelected);
	};

	$scope.getValueSelected = function() {
//		$scope.valueSelected = [];
    //console.log("categorySelected = ******* " + $scope.categorySelected);
		if($scope.categorySelected == 'state') {
			getSelectedValuesForReport($scope.searchSelectStateModel);
		}
		else if($scope.categorySelected == 'county') {
			getSelectedValuesForReport($scope.searchSelectCountyModel);
		}
		else if($scope.categorySelected == 'firm_name') {
      //console.log("category selected in firm_name loop **************")
			getSelectedValuesForReport($scope.searchSelectFirmModel);
		}
		else if($scope.categorySelected == 'matter_name') {
			getSelectedValuesForReport($scope.searchSelectMatterModel);
		}
		else if($scope.categorySelected == 'phase') {
			getSelectedValuesForReport($scope.searchSelectPhaseModel);
		}
		else if($scope.categorySelected == 'expense') {
			getSelectedValuesForReport($scope.searchSelectExpenseModel);
		}
		else if($scope.categorySelected == 'task_code') {
			getSelectedValuesForReport($scope.searchSelectTaskModel);
		}
		else if($scope.categorySelected == 'full_name') {
			getSelectedValuesForReport($scope.searchSelectTimekeeperModel);
		}
		else if($scope.categorySelected == 'staff_level') {
			getSelectedValuesForReport($scope.searchSelectStaffModel);
		}
//		console.log("getValueSelected ******* = " + $scope.valueSelected);
	};

	$scope.getDefaultSubcategory = function(subcategory) {
		console.log('get default subcategory:'+subcategory);
		if(subcategory != "") {
			if(subcategory == 'State') {
				$scope.subcategorySelected = 'state';
			}
			else if(subcategory == 'County') {
				$scope.subcategorySelected = 'county';
			}
			else if(subcategory == 'Firm') {
				$scope.subcategorySelected = 'firm_name';
			}
			else if(subcategory == 'Matter') {
				$scope.subcategorySelected = 'matter_name';
			}
			else if(subcategory == 'Phase') {
				$scope.subcategorySelected = 'phase';
			}
			else if(subcategory == 'Expense') {
				$scope.subcategorySelected = 'expense';
			}
			else if(subcategory == 'Task') {
				$scope.subcategorySelected = 'task_code';
			}
			else if(subcategory == 'Time Keeper') {
				$scope.subcategorySelected = 'full_name';
			}
			else if(subcategory == 'Staff') {
				$scope.subcategorySelected = 'staff_level';
			}
			else if(subcategory == 'Anomaly') {
				$scope.subcategorySelected = 'anomaly_description';
			}
		}
		else {
			if($scope.categorySelected == 'state') {
				$scope.subcategorySelected = 'matter_name';
			}
			else if($scope.categorySelected == 'county') {
				$scope.subcategorySelected = 'matter_name';
			}
			else if($scope.categorySelected == 'firm_name') {
				$scope.subcategorySelected = 'full_name';
			}
			else if($scope.categorySelected == 'matter_name') {
				$scope.subcategorySelected = 'firm_name'; // try firm_name for matter + firm dropdown
			}
			else if($scope.categorySelected == 'phase') {
				$scope.subcategorySelected = 'task_code';
			}
			else if($scope.categorySelected == 'expense') {
				$scope.subcategorySelected = 'matter_name';
			}
			else if($scope.categorySelected == 'task_code') {
				$scope.subcategorySelected = 'full_name';
			}
			else if($scope.categorySelected == 'full_name') {
				$scope.subcategorySelected = 'phase';
			}
			else if($scope.categorySelected == 'staff_level') {
				$scope.subcategorySelected = 'matter_name';
			}
		}
	//	console.log('Sub category selected is'+$scope.subcategorySelected);
	};

	function getNameToBeDisplayed(name) {
  //  console.log("name getNameToBeDisplayed = " + name);
		if(name == 'state') {
				return 'State';
			}
			else if(name == 'county') {
				return 'County';
			}
			else if(name == 'firm_name') {
				return 'Firm Name';
			}
			else if(name == 'matter_name') {
				return 'Matter';
			}
			else if(name == 'phase') {
				return 'Phase';
			}
			else if(name == 'expense') {
				return 'Expense';
			}
			else if(name == 'task_code') {
				return 'Task';
			}
			else if(name == 'full_name') {
				return 'Time Keeper';
			}
			else if(name == 'staff_level') {
				return 'Staff Level';
			}
			else if(name == 'net_amt') {
				return 'Spending ($)';
			}
			else if(name == 'hours') {
				return 'Hours';
			}
			else if(name == 'anomaly_description') {
				return 'Anomaly Count';
			}
			else if(name == 'anomaly_description') {
				return 'Anomaly Description';
			}
			return 'no mapping found';
	};

	function createPieHighChart(returneddata) {
		var json = eval("([" +returneddata+ "])");
    //console.log(json);
		var kpi = getNameToBeDisplayed($scope.kpiSelected);
		var cat = getNameToBeDisplayed($scope.categorySelected);
		var sub = getNameToBeDisplayed($scope.subcategorySelected);
		var title = cat + ' : ' +kpi + ' - Viewing By: '+sub;
			/* TODO: remove
      $(".legendArea2").html("<div></div>");
			$("#legendHeaderLeft2").html("<div>"+sub+"</div>");
			$("#legendHeaderMiddle2").html("<div>Percentage</div>");
			$("#legendHeaderRight2").html("<div>"+ kpi+"</div>"); */

    updateChartHeader(cat, kpi);

    // build legend table
    var table = $('div.legendTable > table');
    table.empty();
    var thead = $('<thead></thead>');
    var tbody = $('<tbody></tbody>');
    var theadRow = $('<tr></tr>');
    theadRow.append('<th>'+sub+'</th>');
    theadRow.append('<th class="text-center">Percentage</th>');
    theadRow.append('<th class="text-center">'+kpi+'</th>');
    thead.append(theadRow);
    Highcharts.setOptions({
			colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D']
		});
    var tot=0;
			for (var j = 0; j < json.length; j++) {
				tot=tot+json[j].y;
			}
			var x=0;
			for(var i=1;i<json.length+1;i++) {
				//if(i%20 == 1)x=0;

        console.log('the kpi ', kpi);
        var thirdColumnValue;
        var patt = /spending/gi;
        if(patt.test(kpi)){
          thirdColumnValue = $filter('currency')(JSON.stringify(json[i-1].y), '$');
        }else{
          thirdColumnValue = JSON.stringify(json[i-1].y);
        }
        console.log('i is'+i);
        var rowHtml = '<td class="percLegendField text-left">' +
            '<div class="circle displayBlock" id="colorLegend" style="background: '+Highcharts.getOptions().colors[i-1] + '"></div>' +
            '<div>' + json[i-1].name + '</div>' +
            '</td>' +
            '<td id="nameLegendField" class="percentageBlock">' +
            (((json[i-1].y)/tot)*100).toFixed(2) + '%' +
            '</td>' +
            '<td id="nameLegendField">' +
            thirdColumnValue +
            '</td>';
        var newRow = $('<tr></tr/>').append(rowHtml);
        tbody.append(newRow);

				x++;
			}


    table.append(thead);
    table.append(tbody);

    tot=0;



		Highcharts.chart('piechart', {
						chart: {
							plotBackgroundColor: null,
							plotBorderWidth: null,
							plotShadow: false,
							type: 'pie',
              width: 275,
              height: 275
						},
          title: { text: '' },
          /* TODO: remove
						title: {
							text: title,
              margin: 7,
              style: {
        		fontFamily: 'Roboto',
            fontSize: 18,
            fontWeight: 600,
            color: '#6e6e6e'
        },
              align: 'left',
                      style: {
                    fontSize: '18px',
                    color: '#6e6e6e'
        }
						}, */
						tooltip: {
              shared: false,
              formatter: function() {
               var text = '';
                if(this.point.name == 'others') {
                  text = this.point.name + ': <b>' + Highcharts.numberFormat(this.point.percentage, 1) +'%</b> <br/>Average: '+ Highcharts.numberFormat(this.point.average,2) +'  <br/>Total Items: '+this.point.totalitems;
                } else {
                  text = this.point.name + ': <b>' + Highcharts.numberFormat(this.point.percentage, 1) + '%';
                }
                return text;
              }
						},
      colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D'],
						plotOptions: {
							pie: {
								allowPointSelect: true,
								cursor: 'pointer',
                size: 250,
                center: ["50%", "50%"],
								dataLabels: {
									enabled: false,
									formatter: function() {
										return Math.round(this.percentage*100)/100 + ' %';
									},
									distance: -30,
									color:'white'
								},
								showInLegend: true
							}
						},
						credits: {
							enabled: false
						},
						legend: {
              enabled: false

						},

						series: [{
							name: kpi,
							colorByPoint: true,
							data: json
						}]
      //,
       //   navigation: {
        //  buttonOptions: {
         //   enabled: true
          //  }
          //}
					});
	};

 // Highcharts.find = function (arr, callback) {
 //   return [].find.call(arr, callback);
 // };

	function createBarChart(returneddata) {
		var json = eval("([" +returneddata+ "])");
		var kpi = getNameToBeDisplayed($scope.kpiSelected);
		var cat = getNameToBeDisplayed($scope.categorySelected);
		var sub = getNameToBeDisplayed($scope.subcategorySelected);
		var title = cat + ' : ' +kpi + ' - Viewing By: '+sub;
  console.log('the kpi for sure ', kpi);
		$scope.legendheader = sub;
		$scope.legendmiddle = "Percentage(%)";
		$scope.legendright = kpi;

    updateChartHeader(cat, kpi);

		var cats = [];
		if($scope.showcompTimeCategory) {
			cats = $scope.timeselected;
		}
		else {
			cats = $scope.valueSelected;
		}
		/*$('.tabLayout').empty();
		for(var i=0;i<cats.length;i++){
			$('.tabLayout').append("<a class='tabButton' id='tabBut"+i+"' tabindex='"+i+"'>"+cats[i]+"        </a>");
		}*/
    $('ul#legendTabs').empty();
    for(var i=0;i<cats.length;i++){
      $('ul#legendTabs').append("<li><a class='tabButton' id='tabBut"+i+"' tabindex='"+i+"'>"+cats[i]+"        </a></li>");
		}
		var tot =0;
    var lastSelectedTab;
		//$(".legendArea").html("<div></div>");
		$(".legendHeaderLeft").html("<div></div>");
			$(".legendHeaderMiddle").html("<div></div>");
			$(".legendHeaderRight").html("<div></div>");
		$(".tabButton").click(function () {
      var table = $('div.legendTable > table');
      table.empty();
      var thead = $('<thead></thead>');
      var tbody = $('<tbody></tbody>');
      // remove / add active class to parent li
      $(this).parents('ul#legendTabs').find('li').removeClass('active');
      $(this).parent().addClass('active');
			$(".legendMid").hide();
			//$(".legendArea").html("<div></div>");
      console.log('the thead ', thead);
      var theadRow = $('<tr></tr>');
      theadRow.append('<th>'+sub+'</th>');
      theadRow.append('<th class="text-center">Percentage</th>');
      theadRow.append('<th class="text-center">'+kpi+'</th>');
      thead.append(theadRow);
      /* TODO: remove
		  $(".legendHeaderLeft").html("<div>"+ sub+"</div>");
			$(".legendHeaderMiddle").html("<div>Percentage</div>");
			$(".legendHeaderRight").html("<div>"+ kpi+"</div>"); */
			Highcharts.setOptions({
			colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D']
		});

      for (var j = 0; j < json.length; j++) {
        if(json[j].name == "others") {
          if(json[j].data[this.tabIndex] == 0) {

          }
          else {
				    tot=tot+json[j].data[this.tabIndex].y;
            console.log("others tot getting added"+tot);
          }
        }
        else
        {
          	tot=tot+json[j].data[this.tabIndex];
      console.log("tot is"+tot);

        }
			}
      console.log("tot final is"+tot);
              console.log('the kpi ', kpi);

			var x=0;
			for(var i=1;i<json.length+1;i++) {
				if(json[i-1].data[this.tabIndex]==0){
					x=x+1;
					continue;
				}
				if(i%20 == 1){
          x=0;
        }else{
         x = x % 20;
        }
        var rowHtml;
        var regex = /spending/gi;
        if(json[i-1].name == "others") {
          var thirdColumnVal;
          if(regex.test(kpi)){
            thirdColumnVal = $filter('currency')(json[i-1].data[this.tabIndex].y);
          }else{
             thirdColumnVal = json[i-1].data[this.tabIndex].y;
          }
                      console.log("others!");

          rowHtml  = '<td class="percLegendField text-left">' +
            '<div class="circle displayBlock" id="colorLegend" style="background: '+Highcharts.getOptions().colors[x] + '"></div>' +
            '<div>' + json[i-1].name + '</div>' +
            '</td>' +
            '<td id="nameLegendField" class="percentageBlock">' +
            (((json[i-1].data[this.tabIndex].y)/tot)*100).toFixed(2) + '%' +
            '</td>' +
            '<td id="nameLegendField">' +
            thirdColumnVal +
            '</td>';

        }
          else{
            var thirdColumnVal;
          if(regex.test(kpi)){
            thirdColumnVal = $filter('currency')(json[i-1].data[this.tabIndex]);
          }else{
             thirdColumnVal = json[i-1].data[this.tabIndex];
          }
            console.log("not others!");
            rowHtml  = '<td class="percLegendField text-left">' +
            '<div class="circle displayBlock" id="colorLegend" style="background: '+Highcharts.getOptions().colors[x] + '"></div>' +
            '<div>' + json[i-1].name + '</div>' +
            '</td>' +
            '<td id="nameLegendField" class="percentageBlock">' +
            (((json[i-1].data[this.tabIndex])/tot)*100).toFixed(2) + '%' +
            '</td>' +
            '<td id="nameLegendField">' +
            thirdColumnVal +
            '</td>';
          }
/*
        if(json[i-1].name == "others") {
                      console.log("others!");

          rowHtml  = '<td class="percLegendField text-left">' +
            '<div class="circle displayBlock" id="colorLegend" style="background: '+Highcharts.getOptions().colors[x] + '"></div>' +
            '<div>' + json[i-1].name + '</div>' +
            '</td>' +
            '<td id="nameLegendField" class="percentageBlock">' +
            (((json[i-1].data[this.tabIndex].y)/tot)*100).toFixed(2) + '%' +
            '</td>' +
            '<td id="nameLegendField">' +
            $filter('currency')(json[i-1].data[this.tabIndex].y) +
            '</td>';

        }
          else{
            console.log("not others!");
            rowHtml  = '<td class="percLegendField text-left">' +
            '<div class="circle displayBlock" id="colorLegend" style="background: '+Highcharts.getOptions().colors[x] + '"></div>' +
            '<div>' + json[i-1].name + '</div>' +
            '</td>' +
            '<td id="nameLegendField" class="percentageBlock">' +
            (((json[i-1].data[this.tabIndex])/tot)*100).toFixed(2) + '%' +
            '</td>' +
            '<td id="nameLegendField">' +
            $filter('currency')(json[i-1].data[this.tabIndex]) +
            '</td>';
          }*/


        var newRow = $('<tr></tr/>').append(rowHtml);
        tbody.append(newRow);
        /* TODO: remove
					$(".legendArea").append("<div class='row'><div id='percLegendField' class='displayBlock col-lg-6'><div class='circle displayBlock' id='colorLegend' style='" + "background:" + Highcharts.getOptions().colors[x] + "'></div>" + json[i-1].name + "</div><div id='nameLegendField' class='percentageBlock col-lg-3'>"+(((json[i-1].data[this.tabIndex])/tot)*100).toFixed(2) + "%</div><div class='col-lg-3' id='nameLegendField'>" + JSON.stringify(json[i-1].data[this.tabIndex]) + "</div><div></br>"); */
				x++;
			}

        table.append(thead);
        table.append(tbody);
			tot=0;
		});



		Highcharts.chart('barchart', {
		chart: {
			type: 'column'
		},
    title: { text: '' },
    /* TODO: remove
		title: {
							text: title,
              margin: 20,
              align: 'left',
                      style: {
                    fontSize: '18px',
                    color: '#6e6e6e'
                      }
        }, */
          colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584', '#2ECC71', '#B3B6B7', '#CB4335', '#2C3E50', '#A3E4D7', '#FDEBD0', '#5499C7', '#CD6155', '#F5B041', '#196F3D'],
		xAxis: {
			categories: cats
		},
		yAxis: {
			min: 0,
			title: {
				text: kpi
			},
			stackLabels: {
				enabled: true,
				style: {
					fontWeight: 'bold',
					color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
				}
			}
		},
		legend : {
			enabled: false,
    },
		tooltip: {
			//headerFormat: '<b>{point.x}</b><br/>',
			//pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
      shared: false,
              formatter: function() {
               var text = '';
                if(this.series.name == 'others') {
                  text = this.series.name + ': <b>' +Highcharts.numberFormat(this.point.y, 1) + '</b> <br/>Average: '+ Highcharts.numberFormat(this.point.average,2) +'  <br/>Total Items: '+this.point.totalitems;
                } else {
                  text = this.series.name + ': <b> ' + Highcharts.numberFormat(this.point.y, 1);
                }
                return text;
              }

		},
		credits: {
			enabled: false
		},

		plotOptions: {
			column: {
				stacking: 'normal',
				dataLabels: {
					enabled: false,
					color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
				}
			}
		},
		series: json

	});
            console.log("json is"+JSON.stringify(json));

	};

	function createTimeLineChart(returneddata) {
		var jsonData = eval("([" +returneddata+ "])");
		//console.log("create timelinechart= "+JSON.stringify(jsonData));
		var chart;

		var nameValues = [];
		for(var m=1;m<jsonData.length;m++) {
			nameValues.push(JSON.stringify(jsonData[m]));
		}
		//console.log('namvalues:'+nameValues);

		var dates = [];
		for(var i=0;i<jsonData[0].data.length;i++) {
			dates.push(jsonData[0].data[i]);
		}
	//	console.log('dates'+dates);
		var categories = [];
		for(var j=0;j<dates.length;j++) {
			categories.push(dates[j]);
		}
	//	console.log('categories1'+categories);

		var obj = {};
		var arr = [];
		for(var z=0;z<categories.length;z++){
			obj[categories[z]] = z;
		}
		categories.sort(function(s1,s2){
			var sdate1 = s1.split('/');
			var sdate2 = s2.split('/');
			var date1 = sdate1[1]+'/'+sdate1[0]+'/'+sdate1[2];
			var date2 = sdate2[1]+'/'+sdate2[0]+'/'+sdate2[2];
			var aa = date1.split('/').reverse().join(),
			bb = date2.split('/').reverse().join();
			return aa < bb ? -1 : (aa > bb ? 1 : 0);

		});
	  // console.log('categories after sort'+categories);
                for(var c=0;c<categories.length;c++){
                    arr.push(JSON.stringify(obj[categories[c]]));
                }
	//	console.log('arr is'+arr);

                var arr1 = [];
                for(var m=0;m<JSON.parse("["+nameValues+"]").length;m++) {
                    for(var b=0;b<JSON.parse("["+nameValues+"]")[0].data.length;b++){
                        arr1.push(JSON.parse("["+nameValues+"]")[m].data[b]);
                    }
                }
                var x = 0;
                for(var r=0;r<nameValues.length;r++) {
                    var arr2 = {};
                    for (var w = x; w < x+arr.length; w++) {
                        arr2[arr[w-x]] = arr1[w];
                    }
                    var jsonArrayData = [];
                    /*console.log(jsonData[r+1].data.length);*/
                    for(var v=0;v<jsonData[r+1].data.length;v++) {
                        /*console.log("arr2 "+arr2[v]);*/
                        jsonArrayData.push(arr2[v]);
                    }
                    jsonData[r+1].data = jsonArrayData;
                    /*console.log(JSON.stringify(jsonData));*/
                    x=x+arr.length;
                }
                var max = arr1.reduce(function(a, b) {
                    return Math.max(a, b);
                });
                var min = arr1.reduce(function (a, b) {
                    return Math.min(a,b);
                });
                var finalJson = [];
                for(var t=1;t<jsonData.length;t++){
                    finalJson.push(JSON.stringify(jsonData[t]));
                }

                var finaldatatodisplay = JSON.parse("["+finalJson+"]");

				var kpi = getNameToBeDisplayed($scope.kpiSelected);
				var cat = getNameToBeDisplayed($scope.categorySelected);
				var sub = getNameToBeDisplayed($scope.subcategorySelected);
				var title = cat + ' : ' +kpi;

				Highcharts.chart('timelinechart', {
                chart: {
zoomType: 'x'
                },
          rangeSelector: {

            buttons: [{
                type: 'day',
                count: 3,
                text: '3d'
            }, {
                type: 'week',
                count: 1,
                text: '1w'
            }, {
                type: 'month',
                count: 1,
                text: '1m'
            }, {
                type: 'month',
                count: 6,
                text: '6m'
            }, {
                type: 'year',
                count: 1,
                text: '1y'
            }, {
                type: 'all',
                text: 'All'
            }],
            selected: 3
        },
          title: { text: '' },
          /* TODO: remove
                title: {
							text: title,
             margin: 20,
              align: 'left',
                      style: {
                    fontSize: '18px',
                    color: '#6e6e6e'
        }
                }, */
                plotOptions: {
                    line: {
                        marker: {
                            enabled: false
                        }
                    }
                },
              colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584'],
                subtitle: {
                    text: ''
                },
                yAxis: {
                    title: {
                        text: kpi
                    },
                    minorGridLineWidth: 0,
                    gridLineWidth: 0,
					max: max,
					min: min
                },
                xAxis: {
                    title: {
                        text: 'Date'
                    },
                    categories: categories
                },
                series: finaldatatodisplay,
                navigation: {
                    menuItemStyle: {
                        fontSize: '10px'
                    }
                },
				credits: {
					enabled: false
				},

                legend : {
                    itemWidth: 800,
                    x: 90,
                    useHTML: true,
                    labelFormatter: function() {
                        var total = 0;
                        for(var i=this.yData.length; i--;) { total += this.yData[i]; };
                         var regex = /spending/gi;
                         var labelVal;
                         if(regex.test(kpi)){
                          labelVal = $filter('currency')(total.toFixed(2), '$');
                         }else{
                          labelVal = total.toFixed(2);
                         }
                        return "<div style='display: inline-table; width: 480px;'>"+this.name+ "</div><div style='text-align:right;display: inline-table; width:50px; font-size:14px; margin-left:-5%;'>"+ labelVal +"</div>";
                    }
                }

            });

	};

	$scope.populateSubCategorySelection = function() {
		$scope.subcategoryvalues = [];
		$scope.showSubCategory = true;
  //  console.log("populateSubCategorySelection = " + $scope.categorySelected);
		if($scope.categorySelected == 'state') {
			$scope.subcategoryvalues.push('County');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
				$scope.subcategoryvalues.push('Anomaly');
		}
		else if($scope.categorySelected == 'county') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
				$scope.subcategoryvalues.push('Anomaly');
			}
		else if($scope.categorySelected == 'firm_name') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'matter_name') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'phase') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'expense') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'task_code') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'full_name') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Task');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'staff_level') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			if($scope.kpiSelected == 'anomaly_description' )
						$scope.subcategoryvalues.push('Anomaly');
		}
//		console.log('Array of values is'+$scope.subcategoryvalues);
	};
	$scope.getDateFilter = function() {
    $scope.timeselected = [];
    var timeCompSelectedValue = "";
    $scope.datarange = document.getElementById("daterange").value;
    timeCompSelectedValue = document.getElementById("timecomprange").value;
    $scope.timeselected.push($scope.datarange);
    if(timeCompSelectedValue != "") {
      $scope.datarange = $scope.datarange + '||' + timeCompSelectedValue;
      $scope.timeselected.push(timeCompSelectedValue);
  //    console.log("time comp selected = " + timeCompSelectedValue);
    }
};

	function createMattertable(data) {
		var jsonData = eval(data);
		$scope.matterTableData = jsonData;
		$scope.dataForMatterTableLoaded = true;
		$scope.$apply();
	};

	$scope.convertTime = function(datetoconvert) {
		var d = new Date(datetoconvert);
		var t= d.getTime();

		return Math.round(t /1000);
	};

	$scope.executeReport = function() {
		// get the last entered filter from selectionList.  TODO - change the name for staff and timekeeper
    console.log("asdfdsf");
		$scope.getCategorySelected();
    console.log("executeReport getCategorySelected = " + $scope.categorySelected);
		$scope.getValueSelected();
  //  console.log("$scope.valueSelected.length = "+ $scope.valueSelected.length);
		$scope.getFilters();
		// returns the KPI that has been selected
		$scope.getSelectedKPI();
		// returns the default SubCategory
    console.log("$scope.submca = " + $scope.subcategoryselect);
    $scope.getDefaultSubcategory($scope.subcategoryselect);

    // clear legend table, tabs
    $('div.legendTable > table').empty();
    $('ul#legendTabs').empty();

    document.getElementById('chart_wrapper').scrollIntoView(true);

		$scope.populateSubCategorySelection();
		// get all the filters put them in this format filtername-filtervalue,filtername-filtervalue
  	$scope.getDateFilter();
  //  console.log('datarange value is:'+$scope.datarange);
	//	console.log('filters is:'+$scope.filtersSelected);
		console.log("category is"+ $scope.categorySelected + ", category value is: "+$scope.valueSelected[0] + ", selected kpi:" + $scope.kpiSelected +", sub category is:" + $scope.subcategorySelected);
    if($scope.valueSelected.length == 1) {
      $scope.showPieChart = true;
    }
    if($scope.valueSelected.length == 1 && $scope.categorySelected == "matter_name") {
      $scope.dataForMatterTableLoaded = true;
    } else {
      $scope.dataForMatterTableLoaded = false;
    }
		var categoryString = "";
			for(var i in $scope.valueSelected ) {
				categoryString = categoryString + $scope.valueSelected[i] + "||";
			}
    //console.log("categoryString before charts loop = " + categoryString);
		// timeComparision
    //console.log("showcompTimeCategory before running the charts report******* " + $scope.showcompTimeCategory);
		if($scope.showcompTimeCategory) {
			$.ajax({
			  url      : "/AppBuilder/endpoint/AnalysisCharts",
			  type     : "POST",
			  data     : {category: $scope.categorySelected, categoryvalue: $scope.valueSelected[0], datefilter: $scope.datarange, filters: $scope.filtersSelected, selectedkpi: $scope.kpiSelected, subcategory: $scope.subcategorySelected,charttype:"timecomparison"},
			  success  : function(data) {
			//	console.log("AnalysisCharts endpoint for timecomparison data = " + data);
          console.log('bar chart data 1 ', data);
				createBarChart(data);
			  }
			});
     $scope.showPieChart = false;
		}
		else if($scope.valueSelected.length == 1) {
      //console.log("inside piechart loop " + $scope.valueSelected.length);
			$.ajax({
				  url      : "/AppBuilder/endpoint/AnalysisCharts",
				  type     : "POST",
				  data     : {category: $scope.categorySelected, categoryvalue: $scope.valueSelected[0], datefilter: $scope.datarange, filters: $scope.filtersSelected,  selectedkpi: $scope.kpiSelected, subcategory: $scope.subcategorySelected,charttype:"pie"},
				  success  : function(data) {
				//		console.log("AnalysisCharts endpoint for pie rOutput:"+ data);
            console.log('pie chart data ', data);
					createPieHighChart(data);
				  }
			});
      $scope.showPieChart = true;
		}
		else {
      // replaced barchartendpoint with analysischarts endpoint
		//console.log('executereport else loop for chart - categoryString:'+categoryString);
    $scope.showPieChart = false;
		$.ajax({
		  url      : "/AppBuilder/endpoint/AnalysisCharts",
		  type     : "POST",
		  data     : {category: $scope.categorySelected, categoryvalue: categoryString, filters: $scope.filtersSelected, datefilter: $scope.datarange, selectedkpi: $scope.kpiSelected, subcategory: $scope.subcategorySelected,charttype:"bar"},
		  success  : function(data) {
					//	console.log("Output for bar chart is:"+ data);
        console.log('bar chart data 2 ', data);
						createBarChart(data);
		  }
		});

		}
		// timelinechart - category and sub category are the same
    ///console.log("timelinechart before ********* =" +$scope.showcompTimeCategory );
		if(!$scope.showcompTimeCategory) {
      $.ajax({
				  url      : "/AppBuilder/endpoint/AnalysisCharts",
				  type     : "POST",
				  data     : {category: $scope.categorySelected, categoryvalue: categoryString, filters: $scope.filtersSelected, datefilter: $scope.datarange, selectedkpi: $scope.kpiSelected, subcategory: $scope.categorySelected,charttype:"timeline"},
				  success  : function(data) {
			//		console.log("Output for timeline chart is:"+ data);
					createTimeLineChart(data);
				  }
			});
		}

		if($scope.valueSelected.length == 1 && $scope.categorySelected == "matter_name") {
			//console.log("data for this matter_name is:"+$scope.valueSelected[0] );
			$.ajax({
			  url      : "/AppBuilder/endpoint/getMatterChart",
			  type     : "POST",
			  data     : {mattername: $scope.valueSelected[0]},
			  success  : function(data) {
				  createMattertable(data);
			  }
			});
		}
	};
  init();
}]);

// Analysis data service

var AnalysisDataService = angular.module('AnalysisDataService', [])
    .service('analysisService', function ($http,$q) {

    // Service method to get the analysis data
    // Return service methodes.
    return({
          getAnalysisData: getAnalysisData,
          getMatterList: getMatterList,
          getFullNameList: getFullNameList
    });

      function getFullNameList(filtervalue,findfieldname) {
      //console.log("getAnalysisData for fields filtervalue = " + filtervalue + " findfieldname = " + findfieldname);
      var request = $http({
                method: "post",
                url: "/AppBuilder/endpoint/TimeKeeperDropDownAnalysis",
                params: {
                          FilterValue: filtervalue
                }
              });
            return(request.then( handleSuccess, handleError ) );
        }

    // start call to get analysis data
    function getAnalysisData(filtervalue,findfieldname) {
      //console.log("getAnalysisData for fields filtervalue = " + filtervalue + " findfieldname = " + findfieldname);
      var request = $http({
                method: "post",
                url: "/AppBuilder/endpoint/AnalysisDataEndpoint",
                params: {
                          FilterValue: filtervalue,
                          FindFieldName: findfieldname
                      }
              });
            return(request.then( handleSuccess, handleError ) );
        }
        // start call to get matter list
        function getMatterList(selecteditem) {
          //console.log("getMatterList for fields selecteditem = " + selecteditem);
          var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/AnalysisMatterDropDown",
                    params: {
                              FilterValue: selecteditem
                          }
                  });
                return(request.then( handleSuccess, handleError ) );
            }
    // Common method to handle the request from the server
    function handleError( response ) {
        if (
            ! angular.isObject( response.data ) ||
            ! response.data.message
            ) {
            //console.log("Returning the error " + response.data);
            return( $q.reject( "An unknown error occurred." ) );
        }
        return( $q.reject( response.data.message ) );
    }
    function handleSuccess( response ) {
      //console.log("Returning the response " + response.data);
      return( response.data);
    }
   // end call to get data from service.
  });


</script>
