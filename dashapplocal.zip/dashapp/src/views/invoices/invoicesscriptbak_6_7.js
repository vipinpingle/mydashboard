<script type="text/javascript">

  var app = angular.module('wexdashboard',['angularUtils.directives.dirPagination','InvoiceDataService','ui.bootstrap']);
  app.controller('InvoiceController',['$scope','$http','invoiceService',function($scope, $http,invoiceService) {

  // variable for pagination calls
  $scope.numberOfResults = "10";
  $scope.pageNumber = "1";
  $scope.pageNumI = "1";
  $scope.searchItem = "";
  $scope.sortByField = "invoice_date";
  $scope.sortByFieldLabel = "Date";
  $scope.totalPageCount = "";
  $scope.totalPageLineItemCount = "";
  $scope.invList = "";
  $scope.showinvdetails = false;
  $scope.invoiceLineItems = [];
  $scope.sortType = 'id';
  $scope.sortReverse = false;
  $scope.searchItem = '';
  $scope.selectedInvoiceIdLineItem = "";
  $scope.sortLineItemByType = "itemnumber";
  $scope.filterByMatterNumber = "";
  $scope.highlighted="";
  $scope.invsortList = [
      {name : "Date", value : "invoice_date"},
      {name : "Matter Name", value : "matter_name"},
      {name : "Matter Number", value : "matter_number"},
      {name : "Firm Name", value : "firm_name"}
  ];
  function init() {
    getInvoiceListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);

  }
    function getInvoiceListData(numResults,pageNum,searchStr,sortByType){
    		  invoiceService.getInvoiceListServiceData(numResults,pageNum,searchStr,sortByType)
                .then(
                  function( mydata ) {
    			             $scope.invList = mydata;
                    //   console.log("returned data = " + JSON.stringify(mydata));
                       $scope.totalPageCount = mydata[numResults].total;
                    //   console.log("total page count returned" + $scope.totalPageCount);
    				    });
            };

     //calling the next page data for invoice list items
     $scope.getNextPageInvoiceData = function(pageNumber) {
      //  console.log("Calling next page data with number = " + pageNumber);
        console.log("next page sortby = " + $scope.sortByField);
        $scope.pageNumberLineitem = pageNumber;
        getInvoiceListData($scope.numberOfResults,pageNumber,$scope.searchItem,$scope.sortByField);
      //  console.log("Calling next page data ended ");
     }

     //calling the search for invoice list
     $scope.getSearchedData = function(searchedString) {
      //  $scope.searchItem = searchedString
        getInvoiceListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
     }
     //calling the sort for invoice list
     $scope.getInvListSorted = function(item) {
        console.log("sorting the field = " + item.name);
        $scope.sortByField = item.value;
        getInvoiceListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
        $scope.sortByFieldLabel = item.name;
     }

    //calling the search for line items based on matter
    $scope.getSearchedLineItemsForMatter = function(mtnumber) {
        console.log("Calling the backend with data for mtnumber = " + mtnumber);
      //   var sortLineItemType = "itemnumber"
      //   console.log("calling getInvoiceLineItemsList function on click with invoiceId = " + item.properties.matternumber);
         var searchLineItem = "";
          $scope.filterByMatterNumber = mtnumber;
          getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResults,$scope.pageNumI,searchLineItem,$scope.sortLineItemByType);
    }

    // sorting invoice details table

    $scope.sortInvDetailTable = function(selectedFieldForSorting) {
       var searchLineItem = "";
       $scope.sortLineItemByType = selectedFieldForSorting;
       $scope.reverseSort=($scope.sortLineItemByType == selectedFieldForSorting)?
        ! $scope.reverseSort:false;
       console.log("selectedFieldForSorting = " + selectedFieldForSorting);
       getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResults,$scope.pageNumI,searchLineItem,$scope.sortLineItemByType);

    }

        $scope.getSortClass = function(selectedFieldForSorting) {
     if ($scope.sortLineItemByType == selectedFieldForSorting) {
       return $scope.reverseSort
       ?'arrow-down'
       :'arrow-up';
     }
      return'';
    }

    //calling the next page for invoicelineitems data
    $scope.getNextPageInvoiceLineItems = function(pageNumLineItem) {
       var searchLineItem = "";
    //   var sortLineItemType =  "itemnumber";
       $scope.pageNumI = pageNumLineItem;
       getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResults,$scope.pageNumI,searchLineItem,$scope.sortLineItemByType);
    }

      // Line itmes details call
    $scope.getInvoiceLineItemsList = function(item) {
        console.log("calling getInvoiceLineItemsList function on click with invoiceId = " + item.properties.invoice_id);
        $scope.selectedState =  item.properties.state;
        $scope.selectedFirmname = item.properties.firm_name;
      	$scope.selectedMattername = item.properties.matter_name;
      	$scope.selectedMatternumber = item.properties.matter_number;
      	$scope.selectedInvoiceid =  item.properties.invoice_id;
        //$scope.selectedInvoiceid = "338518"; // hardcoded for anomalies testing purpose.
        var pageNumI = $scope.pageNumI = "1";
        var searchStrI = "";
        var sortByTypeI = "itemnumber";//$scope.sortLineItemByType;// ;
        $scope.highlighted="highlighted";
        console.log("I am calling invoice list now " + pageNumI + ", " + searchStrI + "," + sortByTypeI);
        getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResults,pageNumI,searchStrI,sortByTypeI)
        $scope.showinvdetails = true;
        console.log("showinvdetails " + $scope.showinvdetails);
    }

    // Callback function to retrieve data for invoicelineitem details.
     function getInvoiceLineItemsData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType){
          invoiceService.getInvoiceLineItemsServiceData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType)
                 .then(
                   function( mydata ) {
                       $scope.invoiceLineItems = mydata;
                    //   $scope.sortLineItemByType = "itemnumber";
                       $scope.totalPageLineItemCount = mydata[numResults].total;
                });
        };

    init();
}]);


//DataService containing all the data calls from backend.

	var InvoiceDataService = angular.module('InvoiceDataService', [])
      .service('invoiceService', function ($http,$q) {

      // Service method to get the invoice listing
      // Return service methodes.
      return({
            getInvoiceListServiceData: getInvoiceListServiceData,
            getInvoiceLineItemsServiceData: getInvoiceLineItemsServiceData
      });

      // start call to get invoice list service data
      function  getInvoiceListServiceData(numResultsS,pageNumS,searchStrS,sortByTypeS) {
       var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/InvoiceList",
      			        params: {
                              noofresults: numResultsS,
                              pagenumber: pageNumS,
                              searchstring: searchStrS,
                              sortbyfield: sortByTypeS
      				        }
              });
            return(request.then( handleSuccess, handleError ) );
      		}

          // start call to get invoice list service data
          function  getInvoiceLineItemsServiceData(invoiceIdL,matterNumberL,numResultsL,pageNumL,searchStrL,sortByTypeL) {

            console.log("Passing parameters in getInvoiceLineItemsServiceData " + "invoiceIdL = " + invoiceIdL + " matterNumberL = " + matterNumberL + " numResultsL = "
            + numResultsL + " pageNumL = " + pageNumL + " searchStrL = " +searchStrL + " sortByTypeL = " + sortByTypeL);
           var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/InvoiceListItemList",
          			        params: {
                                  invoiceid: invoiceIdL,
                                  matternumber: matterNumberL,
                                  noofresults: numResultsL,
                                  pagenumber: pageNumL,
                                  searchstring: searchStrL,
                                  sortbyfield: sortByTypeL,

          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
          		}

      // Common method to handle the request from the server
      function handleError( response ) {
          if (
              ! angular.isObject( response.data ) ||
              ! response.data.message
              ) {
              return( $q.reject( "An unknown error occurred." ) );
          }
          return( $q.reject( response.data.message ) );
      }
      function handleSuccess( response ) {
		  return( response.data);
      }
	   // end call to get data from service.
	  });
</script>
