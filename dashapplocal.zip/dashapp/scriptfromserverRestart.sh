#!/bin/sh

# import IBM environment
if [ -f /opt/ibm/es/nodeinfo/esprofile ]; then
   . /opt/ibm/es/nodeinfo/esprofile
fi

# WEX Server shutdown sequence:
# first check status:
sudo -i -u wexadmn -H bash -c "/opt/ibm/es/bin/esadmin check"
# as root
echo "Executing systemctl stop appbuilder.service"
systemctl stop appbuilder.service
echo "Executing systemctl stop zookeeper.service"
systemctl stop zookeeper.service

# as wexadmn
echo "Executing /opt/ibm/es/bin/stopall.sh"
sudo -i -u wexadmn -H bash -c /opt/ibm/es/bin/stopall.sh

# WEX Server startup sequence:
# as root
echo "Executing /opt/ibm/WEX/Engine/bin/engine-start"
/opt/ibm/WEX/Engine/bin/engine-start

echo "Starting services..."
systemctl start zookeeper.service
systemctl start appbuilder.service

# as wexadmn
echo "Executing /opt/ibm/es/bin/startall.sh"
sudo -i -u wexadmn -H bash -c /opt/ibm/es/bin/startall.sh

# check new status:
echo "Check new status"
sudo -i -u wexadmn -H bash -c "/opt/ibm/es/bin/esadmin check"
