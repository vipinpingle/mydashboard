describe('foo', function() {
  it('should fail', function() {
    expect(true).toEqual(false);
  })
});
