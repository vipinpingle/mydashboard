describe('Syntax error (THIS IS EXPECTED)', function() {
  it('Syntax error (THIS IS EXPECTED)', function() {
     ) // Syntax error here (THIS IS EXPECTED)
  });
});
