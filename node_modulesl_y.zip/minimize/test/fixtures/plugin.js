'use strict';

module.exports = {
  id: 'fromfile',
  element: function noop () {}
};