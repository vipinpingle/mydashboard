var make = require('./make_');
var arrEvery = require('../array/every');
var objEvery = require('../object/every');

    /**
     */
    module.exports = make(arrEvery, objEvery);


