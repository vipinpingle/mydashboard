var make = require('./make_');
var arrMin = require('../array/min');
var objMin = require('../object/min');

    /**
     * Get minimum value inside collection.
     */
    module.exports = make(arrMin, objMin);


