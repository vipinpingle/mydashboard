'use strict';

console.log(require('../').argv);
