# browser-sync-client [![Build Status](https://travis-ci.org/shakyShane/browser-sync-client.png?branch=master)](https://travis-ci.org/shakyShane/browser-sync-client)

Client-side script for BrowserSync

## Contributors

```
    68	Shane Osbourne
     1	Hugo Dias
     1	Sergey Slipchenko
```

## License
Copyright (c) 2014 Shane Osbourne
Licensed under the MIT license.
