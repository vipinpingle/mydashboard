module.exports = [
	'dds',
	'eot',
	'gif',
	'ico',
	'jar',
	'jpeg',
	'jpg',
	'pdf',
	'png',
	'swf',
	'tga',
	'ttf',
	'zip'
]
