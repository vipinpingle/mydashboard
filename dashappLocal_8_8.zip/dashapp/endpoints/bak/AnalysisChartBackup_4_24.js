charttype = params[:charttype]
category = params[:category]
subcategory = params[:subcategory]
categoryvalue = params[:categoryvalue].split("||")
selectedkpi = params[:selectedkpi]
filters = params[:filters].split("&&")
datefilter = params[:datefilter].split("-")
filterstring =nil

facet_by_subcategory = field(subcategory).with_facet_id('subcategory_id').with_maximum_facet_values_of(-1).without_pruning
facet_by_hours = sum(xpath('$'+selectedkpi)).with_facet_id('kpi_id')



dataall = {}
if(categoryvalue.any?)
  categoryvalue.each do |catval|
    data = {}
    categoryfilterstring = field(category).contains(catval)
    searchstringwithoutdate = nil
    filterstring =nil
    if filters.any?
      filters.each do |filterwhole|
        filterwholearray = filterwhole.split(">>")
         if filterstring.nil?
           filterstring = categoryfilterstring.and(field(filterwholearray.at(0)).is(filterwholearray.at(1)))
        else
          filterstring = filterstring.and(field(filterwholearray.at(0)).is(filterwholearray.at(1)))
        end
      end
    else
      filterstring = categoryfilterstring
    end
    # for invoicelevel anomaly
    searchstringwithoutdate = filterstring
    if datefilter.any?
      dateStart = datefilter[0].split("/")
      actualStartDate = Date.new(dateStart[2].to_i,dateStart[0].to_i,dateStart[1].to_i)

      dateEnd = datefilter[1].split("/")
      actualEndDate = Date.new(dateEnd[2].to_i,dateEnd[0].to_i,dateEnd[1].to_i)


      filterstring = filterstring.and(field("itemdate").isLessThanOrEqual(actualEndDate.to_time.to_i.to_java)).and(field("itemdate").isGreaterThan(actualStartDate.to_time.to_i.to_java))

        end
   if selectedkpi == "AnomalyCount"
    facets = entity_type('LineItemAnomaly').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|
      data[firm.value] = firm.getChildren.first.value
    end

    #facets = entity_type('LineItemAnomaly').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    #arr = []
    #facets.get_facet('subcategory_id').facet_values.each do |firm|

    #  if data.key?(firm.value)
    #    data[firm.value] = data[firm.value]+firm.getChildren.first.value
    #  else
    #    data[firm.value] = firm.getChildren.first.value
    #  end
    #end

  else
     facets = entity_type('Analysis').where(filterstring).faceted_by(facet_by_subcategory.then(facet_by_hours)).faceting
    arr = []
    facets.get_facet('subcategory_id').facet_values.each do |firm|
      data[firm.value] = firm.getChildren.first.value
    end
  end

    data = data.sort_by {|k,v| v}.reverse

    datanew = {}
    i = 1
    totalrest = 0
    data.each do |key,value|
      if(i < 10)
        datanew.store(key,value)
      else
        totalrest = totalrest + value

      end
      i = i + 1
    end
    datanew.store("others",totalrest)
    dataall[catval] = datanew

  end
end

series = ""
seriesmap = {}

names = Array.new

dataall.each_with_index do |(key,val),i|
  val.each_with_index do |(key1,val1),j|
    if names.include?(key1)

    else
      names.push(key1)
    end
  end
end


dataall.each_with_index do |(key,val),i|
  names.each do |name|
    if seriesmap.key?(name)

    else
          seriesmap[name] = Array.new
    end
    if val.key?(name)
      seriesmap[name] = seriesmap[name].push(val[name])
    else
      seriesmap[name] = seriesmap[name].push(0)
    end

  end
end


def makeproperarray(arraytofix,dataall)
  if arraytofix.length < dataall.length
    arraytofix.push(0)
    makeproperarray(arraytofix,dataall)
  end
else
  return arraytofix
end

seriesmap.each_with_index do |(key,val),i|
  seriesmap[key] = makeproperarray(val,dataall)
  series << "\{name:'#{key}',data: #{val}\}"
  unless i == seriesmap.size - 1
      series << ","
    end
end
series.gsub!('nil','null')
series.html_safe
