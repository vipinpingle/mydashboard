
filtername = params[:FilterName]
filtervalue = params[:FilterValue]
findfieldname = params[:FindFieldName]
returnarray = {}

if findfieldname == "anomaly"
  entity_type("LineItemAnomaly").where(field(filtername).contains(filtervalue)).faceted_by(field("anom_desc").with_facet_id('findfieldid').with_maximum_facet_values_of(-1)).faceting.get_facet('findfieldid').facet_values.each do |result|
  returnarray[result.value] = result.ndocs
  end
else
  #if findfieldname.include? "date"
  #  entity_type("Analysis").where(field(filtername).contains(filtervalue)).faceted_by(xpath("viv:format-date($"+findfieldname+",'%m/%d/%Y')").with_facet_id('findfieldid').without_pruning).faceting.get_facet('findfieldid').facet_values.each do |result|
  #returnarray[result.value] = result.ndocs
#end
 # else
entity_type("Analysis").where(field(filtername).contains(filtervalue)).faceted_by(field(findfieldname).with_facet_id('findfieldid').with_maximum_facet_values_of(-1)).faceting.get_facet('findfieldid').facet_values.each do |result|
  if findfieldname.include? "date"
  t = Time.at(result.value.to_i)
  returnarray[t.strftime("%m/%d/%Y")] = result.ndocs
  else
    returnarray[result.value] = result.ndocs
  end
#end
end
end
if filtername == "anomaly"
  entity_type("LineItemAnomaly").where(field("anom_desc").contains(filtervalue)).faceted_by(field("anom_desc").with_facet_id('findfieldid').with_maximum_facet_values_of(-1)).faceting.get_facet('findfieldid').facet_values.each do |result|
  returnarray[result.value] = result.ndocs
end
end


returnarray.to_json
#
