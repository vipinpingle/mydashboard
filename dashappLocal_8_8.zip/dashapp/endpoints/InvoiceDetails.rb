noofresults = params[:noofresults].to_i
pagenumber= params[:pagenumber].to_i
searchstring= params[:searchstring]
sortbyfield = params[:sortbyfield]
whereclause = nil
sortbystring = field(sortbyfield)
returntype = params[:returntype]
returnstring = nil
test = {}
matternumber = params[:matternumber]
if matternumber != ""
  if searchstring != ""
    whereclause = field("matter_number").contains(matternumber).and(field("matter_name").contains(searchstring).or(field("invoice_id").contains(searchstring)).or(field("firm_name").contains(searchstring)).or(field("matter_number").contains(searchstring)))

  else
    whereclause = field("matter_number").contains(matternumber)
  end
else
  if searchstring != ""
  whereclause = field("invoice_id").contains(params[:invoiceid]).and(field("matter_name").contains(searchstring).or(field("invoice_id").contains(searchstring)).or(field("firm_name").contains(searchstring)).or(field("matter_number").contains(searchstring)))

  else
  whereclause = field("invoice_id").contains(params[:invoiceid])
  end
end

print whereclause
totalresults = entity_type('Invoice_Detail').where(whereclause).total_results

print "\n totalresults \n"
print totalresults

startingwith = (pagenumber-1)*noofresults
if pagenumber==1
  startingwith = 0
end

returnstring = entity_type('Invoice_Detail').where(whereclause).starting_at(startingwith).sorted_by(sortbystring).requesting(noofresults).to_json

#print "\n returnstring = \n"
#print returnstring

rb_hash = JSON.parse(returnstring)

rb_hash.each do |lineitem|
  invoiceid = params[:invoiceid].to_s
  linenumber = lineitem["properties"]["invoice_line_item_number"]

  lineitemanomaly = endpoint("getInvoiceLineItemAnomaly", invoiceid: invoiceid, linenumber: linenumber[0])
  lineitemhash = JSON.parse(lineitemanomaly)
  #print "\n lineitemhash \n"
  #print lineitemhash
  anomalyrray = []
  lineitemhash.each do |anomalylinetime|
    if anomalylinetime["properties"]["invoice_anomaly_id"] != nil
      if anomalylinetime["properties"]["invoice_anomaly_id"][0] == "NA"

      else

        anomalyrray << {anomalycount: anomalylinetime["properties"]["invoice_anomaly_id"][0], anomalydesc: anomalylinetime["properties"]["invoice_anomaly_description"][0]}

      end
    else
      #anomalyrray <<
    end

  lineitem["anomaly"] = anomalyrray
  end
end

rb_hash << {total: totalresults}


rb_hash.to_json
