	var app = angular.module('wexdashboard', ['datamaps','DataService','ui.router']);

		app.config(function($stateProvider, $urlRouterProvider) {

		$urlRouterProvider.otherwise('all');

		$stateProvider
		.state('allstate', {
			url: '/all',
			templateUrl:'/AppBuilder/dashapp/src/views/dashboard/countrymapview.html',
			controller: 'MainController'
		})
		.state('texas', {
			url: '/texas',
			templateUrl:'/AppBuilder/dashapp/src/views/dashboard/statemapview.html',
			controller: 'TXStateController'
		})
		.state('indiana', {
			url: '/indiana',
			templateUrl:'/AppBuilder/dashapp/src/views/dashboard/indianamapview.html',
			controller: 'INStateController'
		});
	});
    app.controller('MainController', ['$scope','$state','billingService',function($scope,$state,billingService){

	$scope.ytdList = [
        {name : "2016", value : "01/01/2016-12/31/2016"},
		{name : "2015", value : "01/01/2015-12/31/2015"}
    ];
	$scope.topspendingyearselected = $scope.ytdList[0].name;
	$scope.topfirmyearselected = $scope.ytdList[0].name;
	$scope.topanomaliesyearselected = $scope.ytdList[0].name;
	$scope.spendingHours = "";
	$scope.billedHours = "";
	$scope.violationHours = "";
	$scope.topTrackedMatters = "";
	$scope.topStateExpenditureData = "";
	$scope.topFirmAnomaliesData = "";
	$scope.dataSpendingByBudgetLoaded = false;
	$scope.dataHoursBilledLoaded = false;
	$scope.dataViolationsLoaded = false;
	$scope.dataTrackedMattersLoaded = false;
	$scope.dataTopExpendituresLoaded = false;
	$scope.dataTopAnamoliesLoaded = false;
	$scope.filterDefaultDate = "01/01/2016-12/31/2016";
	$scope.billingHoursDefaultDate = "01/01/2015-12/31/2016";
	$scope.violationHoursDefaultDate = "01/01/2015-12/31/2016";


	// both states widget 1d2
	var spendingHoursCurrencyFormat = d3.format("$,.3s");

		function init() {
         // load the initial data for dashboard
			 loadSpendingBudgetData($scope.filterDefaultDate);
			 loadBillingHoursData($scope.billingHoursDefaultDate);
			 loadVoilationData($scope.violationHoursDefaultDate);
			 loadTrackedMattersData($scope.filterDefaultDate);
			 loadTopFirmExpenditureData($scope.filterDefaultDate);
			 loadTopFirmAnamoliesData($scope.filterDefaultDate);
		};

		// function for spending year filter change
		$scope.topspendingyearFilter = function() {
			if($scope.topspendingyearselected == '2016'){
				selectedValue = $scope.ytdList[0].value;
			} else if($scope.topspendingyearselected == '2015'){
				selectedValue = $scope.ytdList[1].value;
			}
			loadSpendingBudgetData(selectedValue);
		}

		// function for firms year filter change
		$scope.topfirmyearsFilter = function() {
			if($scope.topfirmyearselected == '2016'){
				selectedValue = $scope.ytdList[0].value;
			} else if($scope.topfirmyearselected == '2015'){
				selectedValue = $scope.ytdList[1].value;
			}
			loadTopFirmExpenditureData(selectedValue);
		}



		// function for anamolies year filter change
		$scope.topanamoliesyearsFilter = function() {
			if($scope.topanomaliesyearselected == '2016'){
				selectedValue = $scope.ytdList[0].value;
			} else if($scope.topanomaliesyearselected == '2015'){
				selectedValue = $scope.ytdList[1].value;
			}
			loadTopFirmAnamoliesData(selectedValue);
		}

		// Method to be called from controller to get the spending update data from service.

		function loadSpendingBudgetData(filterdate){

		  var categoryS = "state";
		  var categorySvalue = "";
		  var filtersS = "";
		  var selectedkpiS = "netamount";
		 // var subcategoryS = "itemdate";
		  var subcategoryS = "firmname";
		 // var datefilterS = "01/01/2016-12/31/2016";
		  var datefilterS = filterdate;
		 // console.log("loadSpendingBudgetData = " + filterdate);
		  // call the service and filter out the data for scope variable.

		  billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
			    var spendingByBudget = d3.nest()
             //    .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.descending)
				 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
                 .entries(mydata);
				// console.log("spending by budget filter = " +  spendingByBudget);
				  $scope.spendingHours = spendingHoursCurrencyFormat(spendingByBudget);
			      $scope.dataSpendingByBudgetLoaded = true;
				}
			);
        };

		// end of retrieve spending method.

		// load data for billing hours starts here
		function loadBillingHoursData(filterdate){
		  var categoryS = "state";
		  var categorySvalue = "";
		  var filtersS = "";
		  var selectedkpiS = "hours";
		  var subcategoryS = "itemdate";
		  var datefilterS = filterdate;
		  // call the service and filter out the data for scope variable.

		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
                var billedByHours = d3.nest()
                 .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.descending)
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
                 .entries(mydata);
               //   console.log(JSON.stringify(billedByHours));
                  $scope.billedHours = billedByHours;
                  $scope.dataHoursBilledLoaded = true;
              }
            );
        };

		// load data for billing hours ends here

		// load data for violations starts here

		function loadVoilationData(filterdate){
		  var categoryS = "state";
		  var categorySvalue = "";
		  var filtersS = "";
		  var selectedkpiS = "AnomalyDollars";
		  var subcategoryS = "itemdate";
		  var datefilterS = filterdate;

		  // call the service and filter out the data for scope variable.
		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
                var violationByHours = d3.nest()
                 .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.ascending)
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
                 .entries(mydata);
                  $scope.violationHours = violationByHours;
                  $scope.dataViolationsLoaded = true;
              }
            );
        };

		// load data for violations ends here

		// load data for tracked matters starts here

		function loadTrackedMattersData(filterdate){
		  var categoryS = "state";
		  var categorySvalue = "";
		  var filtersS = "";
		  var selectedkpiS = "netamount";
		  var subcategoryS = "mattername";
		  var datefilterS =  filterdate;
		  // call the service and filter out the data for scope variable.
		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
				var trackedMatters = d3.nest()
					.key(function(d){ return d.name; })
					.rollup(function(leaves){
						return leaves.map(function(d){
							return d.value;
						}).sort(d3.descending).slice(0, 3);
				})
				.entries(mydata);
			     $scope.topTrackedMatters = trackedMatters;
                 $scope.dataTrackedMattersLoaded = true;
              }
            );
        };

		// load data for violations ends here

		// load data for expenditure matters starts here

		function loadTopFirmExpenditureData(filterdate){

		  var categoryS = "state";
		  var categorySvalue = "";
		  var filtersS = "";
		  var selectedkpiS = "netamount";
		  var subcategoryS = "firmname";
		  var datefilterS = filterdate;
		  // call the service and filter out the data for scope variable.

		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
              //  console.log("localData for expediture data  = " + JSON.stringify(mydata));
                var topFirmByExpenditures = d3.nest()
                // .key(function(d) { return d.name}).sortKeys(d3.ascending)
				 .key(function(d) { return d.name})
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
				 .entries(mydata);
				 var top5Firms = topFirmByExpenditures.slice(0,5);
                  $scope.topStateExpenditureData = top5Firms;
                  $scope.dataTopExpendituresLoaded = true;
              }
            );
        };

		// load data for top expenditure ends here

		// load data for firm anamolies starts here

		function loadTopFirmAnamoliesData(filterdate){
	//	  var categoryS = "state";
	      // added for new query
		  var stateS = "";
		  var categorySvalue = "";
		  var filtersS = "";
		  var selectedkpiS = "AnomalyCount";
		  var subcategoryS = "firmname";
		  var datefilterS = filterdate;

		  // call the service and filter out the data for scope variable.

		   //billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
		   billingService.getAnomaliesData(stateS,datefilterS)
            .then(
              function( mydata ) {
                //console.log("localData for expediture data  = " + JSON.stringify(mydata));
                var topFirmByAnamolies = d3.nest()
                // .key(function(d) { return d.name}).sortKeys(d3.descending)
                 .key(function(d) { return d.name})
				 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
				 .entries(mydata);
				  var top5Anomalies = topFirmByAnamolies.slice(0,5);
                  $scope.topFirmAnomaliesData = top5Anomalies;
                  $scope.dataTopAnamoliesLoaded = true;
              }
            );
        };

		// load data for top anamolies ends here

	  // setup the mapobject for rendering state map

	  $scope.mapObject = {
        scope: 'usa',
        options: {
          width: 600,
          legendHeight: 60 // optionally set the padding for the legend
        },
        geographyConfig: {
          highlighBorderColor: '#306596',
          highlighBorderWidth: 2
        },
        fills: {
          'HIGH': '#CC4731',
          'MEDIUM': '#c31820',
          'LOW': '#306596',
          'defaultFill': '#DDDDDD'
        },
        data: {
          "IN": {
            "fillKey": "MEDIUM",
          },
          "TX": {
            "fillKey": "MEDIUM",
          }
        },
      };

      // Method to update the charts when map is clicked. Currently working only for one state at a time. Need to fix multiple state selection.

       $scope.updateActiveState = function(geography) {
        // get the selected state values
        $scope.stateName = geography.properties.name;
        $scope.stateCode = geography.id;
         console.log("statename = "+$scope.stateName);
        // based on selected states call the services to get the data
        if($scope.stateCode == 'TX'){
       //   console.log("state code = " + $scope.stateCode);
          $state.go('texas',{});
         }
         if($scope.stateCode == 'IN'){
          $state.go('indiana',{});
  				}
  //          $scope.$apply();
        };

		init();
	}]);

  // state controller for texas map

    app.controller('TXStateController', ['$scope','$state','billingService',function($scope,$state,billingService){

	$scope.spendingHours = "";
	$scope.billedHours = "";
	$scope.violationHours = "";
	$scope.topTrackedMatters = "";
	$scope.topStateExpenditureData = "";
	$scope.topFirmAnomaliesData = "";
	$scope.filterDefaultDate = "01/01/2016-12/31/2016";
	$scope.billingHoursDefaultDate = "01/01/2015-12/31/2016";
	$scope.violationHoursDefaultDate = "01/01/2015-12/31/2016";

	$scope.dataSpendingByBudgetLoaded = false;
	$scope.dataHoursBilledLoaded = false;
	$scope.dataViolationsLoaded = false;
	$scope.dataTrackedMattersLoaded = false;
	$scope.dataTopExpendituresLoaded = false;
	$scope.dataTopAnamoliesLoaded = false;
	$scope.loading = false;
    $scope.ytdList = [
        {name : "2016", value : "01/01/2016-12/31/2016"},
		{name : "2015", value : "01/01/2015-12/31/2015"}
    ];
	$scope.topspendingyearselected = $scope.ytdList[0].name;
	$scope.topfirmyearselected = $scope.ytdList[0].name;
	$scope.topanomaliesyearselected = $scope.ytdList[0].name;
    var spendingHoursCurrencyFormat = d3.format("$,.3s");

	function init() {
         // load the initial data for dashboard
			 loadSpendingBudgetData($scope.filterDefaultDate);
			 loadBillingHoursData($scope.billingHoursDefaultDate);
			 loadVoilationData($scope.violationHoursDefaultDate);
			 loadTrackedMattersData($scope.filterDefaultDate);
			 loadTopFirmExpenditureData($scope.filterDefaultDate);
			 loadTopFirmAnamoliesData($scope.filterDefaultDate);
		};

		// function for spending year filter change
		$scope.topspendingyearFilter = function() {
			if($scope.topspendingyearselected == '2016'){
				selectedValue = $scope.ytdList[0].value;
			} else if($scope.topspendingyearselected == '2015'){
				selectedValue = $scope.ytdList[1].value;
			}
			loadSpendingBudgetData(selectedValue);
		}

		// function for firms year filter change
		$scope.topfirmyearsFilter = function() {
			if($scope.topfirmyearselected == '2016'){
				selectedValue = $scope.ytdList[0].value;
			} else if($scope.topfirmyearselected == '2015'){
				selectedValue = $scope.ytdList[1].value;
			}
			loadTopFirmExpenditureData(selectedValue);
		}



		// function for anamolies year filter change
		$scope.topanamoliesyearsFilter = function() {
			if($scope.topanomaliesyearselected == '2016'){
				selectedValue = $scope.ytdList[0].value;
			} else if($scope.topanomaliesyearselected == '2015'){
				selectedValue = $scope.ytdList[1].value;
			}
			loadTopFirmAnamoliesData(selectedValue);
		}



    // setup the mapobject for rendering state map
    $scope.mapObject1 = {
		geographyConfig: {
          dataUrl: '/AppBuilder/dashapp/src/lib/maps/USA/TX.topo.json'
          //  dataJson: txMapData
        },
        scope: 'Texas.geo',
        options: {
          width: 600,
          height: 350,
          legendHeight: 60 // optionally set the padding for the legend
        },
        projection: '',
        setProjection: function(element) {
          var projection = d3.geo.equirectangular()
            .center([-95, 31])
            .rotate([4.4, 0])
            .scale(1600)
            .translate([element.offsetWidth / 2, element.offsetHeight / 2]);
          var path = d3.geo.path()
            .projection(projection);

          return {path: path, projection: projection};
          },
         fills: {
          defaultFill: '#c31820',
          lt50: 'rgba(0,244,244,0.9)',
          gt50: '#c31820'
        },
        // data: {
        //   '071': {fillKey: 'lt50' },
        //   '001': {fillKey: 'gt50' }
        // },
      };

	    // Method to be called from controller to get the spending update data from service.

		function loadSpendingBudgetData(filterdate){

		  var categoryS = "state";
		  var categorySvalue = "TX";
		  var filtersS = "";
		  var selectedkpiS = "netamount";
		   var subcategoryS = "firmname";
		 // var datefilterS = "01/01/2016-12/31/2016";
		  var datefilterS = filterdate;
		 // console.log("loadSpendingBudgetData = " + filterdate);
		  // call the service and filter out the data for scope variable.

		  billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
			    var spendingByBudget = d3.nest()
             //    .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.descending)
				 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
                 .entries(mydata);
				// console.log("spending by budget filter = " +  spendingByBudget);
				  $scope.spendingHours = spendingHoursCurrencyFormat(spendingByBudget);
			      $scope.dataSpendingByBudgetLoaded = true;
				}
            );
        };
		// end of retrieve spending method.

		// load data for billing hours starts here
		function loadBillingHoursData(filterdate){
		  var categoryS = "state";
		  var categorySvalue = "TX";
		  var filtersS = "";
		  var selectedkpiS = "hours";
		  var subcategoryS = "itemdate";
		  var datefilterS = filterdate;
		  // call the service and filter out the data for scope variable.

		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
                var billedByHours = d3.nest()
                 .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.descending)
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
                 .entries(mydata);
               //   console.log(JSON.stringify(billedByHours));
                  $scope.billedHours = billedByHours;
                  $scope.dataHoursBilledLoaded = true;
              }
            );
        };

		// load data for billing hours ends here

		// load data for violations starts here

		function loadVoilationData(filterdate){
		  var categoryS = "state";
		  var categorySvalue = "TX";
		  var filtersS = "";
		  var selectedkpiS = "AnomalyDollars";
		  var subcategoryS = "itemdate";
		  var datefilterS = filterdate;

		  // call the service and filter out the data for scope variable.
		    billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
                var violationByHours = d3.nest()
                 .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.ascending)
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
                 .entries(mydata);
                  $scope.violationHours = violationByHours;
                  $scope.dataViolationsLoaded = true;
              }
            );
        };

		// load data for violations ends here

		// load data for tracked matters starts here

		function loadTrackedMattersData(filterdate){
		  var categoryS = "state";
		  var categorySvalue = "TX";
		  var filtersS = "";
		  var selectedkpiS = "netamount";
		  var subcategoryS = "mattername";
		  var datefilterS = filterdate;
		  // call the service and filter out the data for scope variable.
		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
				var trackedMatters = d3.nest()
					.key(function(d){ return d.name; })
					.rollup(function(leaves){
						return leaves.map(function(d){
							return d.value;
						}).sort(d3.descending).slice(0, 3);
				})
				.entries(mydata);
			     $scope.topTrackedMatters = trackedMatters;
                 $scope.dataTrackedMattersLoaded = true;
              }
            );
        };

		// load data for violations ends here

		// load data for expenditure matters starts here

		function loadTopFirmExpenditureData(filterdate){

		  var categoryS = "state";
		  var categorySvalue = "TX";
		  var filtersS = "";
		  var selectedkpiS = "netamount";
		  var subcategoryS = "firmname";
		  var datefilterS = filterdate;
		  // call the service and filter out the data for scope variable.

		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
             //   console.log("localData for expediture data texas  = " + JSON.stringify(mydata));
                var topFirmByExpenditures = d3.nest()
                // .key(function(d) { return d.name}).sortKeys(d3.descending)
				 .key(function(d) { return d.name})
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
				 .entries(mydata);
				var top5Firms = topFirmByExpenditures.slice(0,5);
                  $scope.topStateExpenditureData = top5Firms;
			//	   console.log("localData for expediture data for after slicing texas  = " + JSON.stringify(top5Firms));
                  $scope.dataTopExpendituresLoaded = true;
              }

            );
        };

		// load data for top expenditure ends here

		// load data for firm anamolies starts here

		function loadTopFirmAnamoliesData(filterdate){
	//	  var categoryS = "state";
	      // added for new query
		  var stateS = "TX";
		  var categorySvalue = "";
		  var filtersS = "";
		  var selectedkpiS = "AnomalyCount";
		  var subcategoryS = "firmname";
		  var datefilterS = filterdate;

		  // call the service and filter out the data for scope variable.

		   //billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
		   billingService.getAnomaliesData(stateS,datefilterS)
            .then(
              function( mydata ) {
                //console.log("localData for expediture data  = " + JSON.stringify(mydata));
                var topFirmByAnamolies = d3.nest()
               //  .key(function(d) { return d.name}).sortKeys(d3.descending)
			     .key(function(d) { return d.name})
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
				 .entries(mydata);
				  var top5Anomalies = topFirmByAnamolies.slice(0,5);
                  $scope.topFirmAnomaliesData = top5Anomalies;
                  $scope.dataTopAnamoliesLoaded = true;
              }
            );
        };

	init();
  }]);

  // controller for texas state view ends here

  // controller for indiana state view starts here

  app.controller('INStateController', ['$scope','$state','billingService',function($scope,$state,billingService){

	$scope.ytdList = [
        {name : "2016", value : "01/01/2016-12/31/2016"},
		{name : "2015", value : "01/01/2015-12/31/2015"}
    ];
	$scope.topspendingyearselected = $scope.ytdList[0].name;
	$scope.topfirmyearselected = $scope.ytdList[0].name;
	$scope.topanomaliesyearselected = $scope.ytdList[0].name;
	$scope.spendingHours = "";
	$scope.billedHours = "";
	$scope.violationHours = "";
	$scope.topTrackedMatters = "";
	$scope.topStateExpenditureData = "";
	$scope.topFirmAnomaliesData = "";
	$scope.filterDefaultDate = "01/01/2016-12/31/2016";
	$scope.billingHoursDefaultDate = "01/01/2015-12/31/2016";
	$scope.violationHoursDefaultDate = "01/01/2015-12/31/2016";
	$scope.dataSpendingByBudgetLoaded = false;
	$scope.dataHoursBilledLoaded = false;
	$scope.dataViolationsLoaded = false;
	$scope.dataTrackedMattersLoaded = false;
	$scope.dataTopExpendituresLoaded = false;
	$scope.dataTopAnamoliesLoaded = false;


    var spendingHoursCurrencyFormat = d3.format("$,.3s");

	function init() {
         // load the initial data for dashboard
			 loadSpendingBudgetData($scope.filterDefaultDate);
			 loadBillingHoursData($scope.billingHoursDefaultDate);
			 loadVoilationData($scope.violationHoursDefaultDate);
			 loadTrackedMattersData($scope.filterDefaultDate);
			 loadTopFirmExpenditureData($scope.filterDefaultDate);
			 loadTopFirmAnamoliesData($scope.filterDefaultDate);
		};

		// function for spending year filter change
		$scope.topspendingyearFilter = function() {
			if($scope.topspendingyearselected == '2016'){
				selectedValue = $scope.ytdList[0].value;
			} else if($scope.topspendingyearselected == '2015'){
				selectedValue = $scope.ytdList[1].value;
			}
			loadSpendingBudgetData(selectedValue);
		}

		// function for firms year filter change
		$scope.topfirmyearsFilter = function() {
			if($scope.topfirmyearselected == '2016'){
				selectedValue = $scope.ytdList[0].value;
			} else if($scope.topfirmyearselected == '2015'){
				selectedValue = $scope.ytdList[1].value;
			}
			loadTopFirmExpenditureData(selectedValue);
		}



		// function for anamolies year filter change
		$scope.topanamoliesyearsFilter = function() {
			if($scope.topanomaliesyearselected == '2016'){
				selectedValue = $scope.ytdList[0].value;
			} else if($scope.topanomaliesyearselected == '2015'){
				selectedValue = $scope.ytdList[1].value;
			}
			loadTopFirmAnamoliesData(selectedValue);
		}



    // setup the mapobject for rendering state map
    $scope.mapObject2 = {
		geographyConfig: {
          dataUrl: '/AppBuilder/dashapp/src/lib/maps/USA/IN.topo.json'
        },
        scope: 'Indiana.geo',
        options: {
          width: 550,
          height:400,
          legendHeight: 60, // optionally set the padding for the legend
         // highlightFillColor: '#FC8D59'
        },
        projection: '',
        setProjection: function(element) {
          var projection = d3.geo.equirectangular()
            .center([-81, 40])
            .rotate([4.4, 0])
            .scale(4000)
            .translate([element.offsetWidth / 2, element.offsetHeight / 2]);
          var path = d3.geo.path()
            .projection(projection);

          return {path: path, projection: projection};
        },
        fills: {
          defaultFill: '#c31820',
        //  lt50: 'rgba(0,244,244,0.9)',
          gt50: '#c31820'
        },
        // data: {
        //   '090': {fillKey: 'lt50' },
        //   '001': {fillKey: 'gt50' }
        // }
      };

      // Method to be called from controller to get the spending update data from service.

		function loadSpendingBudgetData(filterdate){

		  var categoryS = "state";
		  var categorySvalue = "IN";
		  var filtersS = "";
		  var selectedkpiS = "netamount";
		   var subcategoryS = "firmname";
		 // var datefilterS = "01/01/2016-12/31/2016";
		  var datefilterS = filterdate;
		 // console.log("loadSpendingBudgetData = " + filterdate);
		  // call the service and filter out the data for scope variable.

		  billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
			    var spendingByBudget = d3.nest()
             //    .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.descending)
				 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
                 .entries(mydata);
				// console.log("spending by budget filter = " +  spendingByBudget);
				  $scope.spendingHours = spendingHoursCurrencyFormat(spendingByBudget);
			      $scope.dataSpendingByBudgetLoaded = true;
				}
            );
        };

		// end of retrieve spending method.

		// load data for billing hours starts here
		function loadBillingHoursData(filterdate){
		  var categoryS = "state";
		  var categorySvalue = "IN";
		  var filtersS = "";
		  var selectedkpiS = "hours";
		  var subcategoryS = "itemdate";
		  var datefilterS = filterdate;
		  // call the service and filter out the data for scope variable.

		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
                var billedByHours = d3.nest()
                 .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.descending)
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
                 .entries(mydata);
               //   console.log(JSON.stringify(billedByHours));
                  $scope.billedHours = billedByHours;
                  $scope.dataHoursBilledLoaded = true;
              }
            );
        };

		// load data for billing hours ends here

		// load data for violations starts here

		function loadVoilationData(filterdate){
		  var categoryS = "state";
		  var categorySvalue = "IN";
		  var filtersS = "";
		  var selectedkpiS = "AnomalyDollars";
		  var subcategoryS = "itemdate";
		  var datefilterS = filterdate;

		  // call the service and filter out the data for scope variable.
		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
                var violationByHours = d3.nest()
                 .key(function(d) { return (d.name.split("/")[2])}).sortKeys(d3.ascending)
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
                 .entries(mydata);
                  $scope.violationHours = violationByHours;
                  $scope.dataViolationsLoaded = true;
              }
            );
        };
		// load data for violations ends here

		// load data for tracked matters starts here

		function loadTrackedMattersData(filterdate){
		  var categoryS = "state";
		  var categorySvalue = "IN";
		  var filtersS = "";
		  var selectedkpiS = "netamount";
		  var subcategoryS = "mattername";
		  var datefilterS = filterdate;
		  // call the service and filter out the data for scope variable.
		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
				var trackedMatters = d3.nest()
					.key(function(d){ return d.name; })
					.rollup(function(leaves){
						return leaves.map(function(d){
							return d.value;
						}).sort(d3.descending).slice(0, 3);
				})
				.entries(mydata);
			     $scope.topTrackedMatters = trackedMatters;
                 $scope.dataTrackedMattersLoaded = true;
              }
            );
        };

		// load data for violations ends here

		// load data for expenditure matters starts here

		function loadTopFirmExpenditureData(filterdate){

		  var categoryS = "state";
		  var categorySvalue = "IN";
		  var filtersS = "";
		  var selectedkpiS = "netamount";
		  var subcategoryS = "firmname";
		  var datefilterS = filterdate;
		  // call the service and filter out the data for scope variable.

		   billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
            .then(
              function( mydata ) {
              //  console.log("localData for expediture data  = " + JSON.stringify(mydata));
                var topFirmByExpenditures = d3.nest()
                // .key(function(d) { return d.name}).sortKeys(d3.ascending)
				 .key(function(d) { return d.name})
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
				 .entries(mydata);
				 var top5Firms = topFirmByExpenditures.slice(0,5);
                  $scope.topStateExpenditureData = top5Firms;
                  $scope.dataTopExpendituresLoaded = true;
              }
            );
        };

		// load data for top expenditure ends here

		// load data for firm anamolies starts here

			function loadTopFirmAnamoliesData(filterdate){
	//	  var categoryS = "state";
	      // added for new query
		  var stateS = "IN";
		  var categorySvalue = "";
		  var filtersS = "";
		  var selectedkpiS = "AnomalyCount";
		  var subcategoryS = "firmname";
		  var datefilterS = filterdate;

		  // call the service and filter out the data for scope variable.

		   //billingService.getServiceData(categoryS,categorySvalue,filtersS,selectedkpiS,subcategoryS,datefilterS)
		   billingService.getAnomaliesData(stateS,datefilterS)
            .then(
              function( mydata ) {
                //console.log("localData for expediture data  = " + JSON.stringify(mydata));
                var topFirmByAnamolies = d3.nest()
                // .key(function(d) { return d.name}).sortKeys(d3.descending)
				 .key(function(d) { return d.name})
                 .rollup(function(v) { return d3.sum(v, function(d) { return d.value; }); })
				 .entries(mydata);
				  var top5Anomalies = topFirmByAnamolies.slice(0,5);
                  $scope.topFirmAnomaliesData = top5Anomalies;
                  $scope.dataTopAnamoliesLoaded = true;
              }
            );
        };

	init();
}]);

// controller for indiana state view ends here.


    // Reusable Directive for bar Chart - Use <div bar-chart data="stateBillingData" ></div> where data parameter should be different
    app.directive('barChart', function($window){
    return {
      restrict:'EAC',
      template:"",
      scope:{
             data: '=data'
        },
      link: function (scope,elem,attrs){
        var chartElement = elem[0];
        // variable to hold dc chart
        var chartFactory = dc['barChart'];
        // Create an unconfigured instance of the chart
        var sfBarChart = chartFactory(chartElement,'barchartgroup1');

        var dataToPlot;
		var widgetCurrency = attrs["widgettype"];
	//	console.log("widgetCurrency = " + widgetCurrency);
        var barLabelCurrencyFormat = d3.format(".3s");

		if(widgetCurrency == "violationswidget") {
			barLabelCurrencyFormat = d3.format("$,.3s");
		}

       // set the watch for the data changes. if the values are changed then update the bar chart, else draw the same.

        scope.$watch('data', function (newVal, oldVal) {
            if(newVal!=oldVal){

              dataToPlot = newVal;
              updateBarChart(dataToPlot);

            } else {

              dataToPlot = newVal;
              drawBarChart(dataToPlot);
             }
        });

      function preSetupChartParameters() {

          sfBarChart
            .width(200)
            .height(270)
            .margins({top: 10, right: 10, bottom: 20, left: 10})
            .gap(0)
            .brushOn(false)
            .yAxisLabel("")
            .xUnits(dc.units.ordinal)
        }

      function postSetupChartParameters(data) {

            sfBarChart
            .on('renderlet',function () {
            var barsData = [];
            var dataLabelValues = []; // place holder for adding data labels.
            var bars = sfBarChart.selectAll('.bar').each(function (d) {
				  barsData.push(d);
            });
			for(var i = 0; i < data.length ; i++)
			{
			//	console.log("dataLabelValues Data values = " + data[i].key );
				dataLabelValues.push(data[i].key);
			};
			dataLabelValues.reverse();
			// //Remove old values (if found)
			//console.log("bars value = " + barsData[0].values);
            d3.select(bars[0][0].parentNode).select('#inline-labels').remove();
            // //Create group for labels
            var gLabels = d3.select(bars[0][0].parentNode).append('g').attr('id', 'inline-labels');
            //  console.log("gLabels = " +gLabels);
            for (var i = bars[0].length - 1; i >= 0; i--) {
                var b = bars[0][i];
			//	console.log("b=" + b);
				//Only create label if bar height is tall enough
                if (+b.getAttribute('height') < 18) continue;
				//console.log("barsData[i].values " + barsData[i].data.value);
				var myLabel = barLabelCurrencyFormat(barsData[i].data.value);
				var myLabelYtd = dataLabelValues[i];
			//	console.log("myLabelYtd = " + myLabelYtd);
                  gLabels.append("text")
                  .text(myLabel)
				  .attr("class","barlabelchart")
                  .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
                  .attr('y', +b.getAttribute('y') + 20)
                  .attr('text-anchor', 'middle')
                  .attr('fill', 'white')

				  gLabels.append("text")
                  .text(myLabelYtd)
				  .attr("class","barlabelchartytd")
                  .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
                  .attr('y', +b.getAttribute('y') + 40)
                  .attr('text-anchor', 'middle')
                  .attr('fill', 'white')
                  }
                });
            sfBarChart.yAxis().ticks(0); // hide the yAsix labels
            sfBarChart.xAxis().tickValues([]); // hide the xAxis labels
        }

        // Function to draw default bar chart

        function drawBarChart(data) {

        preSetupChartParameters();
        //console.log("data in drawBarChart = " + JSON.stringify(data));

        var dataToPlotFiltered = crossfilter(data);
        //console.log("data in drawBarChart filtered = " + JSON.stringify(dataToPlotFiltered));

        var yearsDim = dataToPlotFiltered.dimension(function (d) {
			//console.log("years = " + d.key);
            return d.key;
        });
        var hoursGroup = yearsDim.group().reduceSum(function (d) {
          //  console.log("hoursGroup = " + d.values);
            return d.values;
        });

		var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
		var keys = sortByValues.map(function (d) { return d.key; });

        var chartcolortypeL = attrs["chartcolortype"];
         if(chartcolortypeL == 'blue') {

           var barColorRangeA ="#029fdb";
           var barColorRangeB = "#cbcbcb";
         } else {
           var barColorRangeA ="#cbcbcb";
           var barColorRangeB = "#c31820";
         }


		 //var initialScaleData = [600, 2000]; // this is the problem.
		 //var jsondata = JSON.parse(JSON.stringify(data));
		 var initialScaleData = [];
			for(var i = 0; i < data.length ; i++)
				{
					//console.log("initial Scale Data values = " + data[i].values );
					initialScaleData.push(data[i].values);

			};

		//console.log('new array is ' + initialScaleData);
		sfBarChart
          .dimension(yearsDim)
          .group(hoursGroup)
       //   .x(d3.scale.ordinal().domain(1000))
			.x(d3.scale.ordinal().domain(keys))
          .y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))

          .on('pretransition', function (sfBarChart) {
              var colors = d3.scale.ordinal().domain(yearsDim)
                .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820

					sfBarChart.selectAll('rect.bar').each(function(d){
                    d3.select(this).attr("style", "fill: " + colors(d.data.key));
                });

          })
          postSetupChartParameters(data);
            dc.renderAll('barchartgroup1');
          }

        // Function to update the bar chart with changed data. This will be called based on the changed scope data.

        function updateBarChart(data) {

        preSetupChartParameters();
      //  console.log(JSON.stringify(data));
        var dataToPlotFiltered = crossfilter(data);
        // console.log(JSON.stringify(dataToPlotFiltered));
        var yearsDim = dataToPlotFiltered.dimension(function (d) {
        //  console.log("years = " + d.year);
        return d.key;
        });
        var hoursGroup = yearsDim.group().reduceSum(function (d) {
        //    console.log("hoursGroup = " + d.hours);
            return d.values;
        });

		var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
		var keys = sortByValues.map(function (d) { return d.key; });

        var chartcolortypeL = attrs["chartcolortype"];
         if(chartcolortypeL == 'blue') {
           var barColorRangeA ="#029fdb";
           var barColorRangeB = "#cbcbcb";
         } else {
           var barColorRangeA ="#cbcbcb";
           var barColorRangeB = "#c31820";
         }
		// var initialScaleData = [600, 2000];
		//var jsondata = JSON.parse(JSON.stringify(data));
		 var initialScaleData = []; for(var i = 0; i < data.length ; i++) {initialScaleData.push(data[i].values)};
		//console.log('new array is '+initialScaleData);
        sfBarChart
          .dimension(yearsDim)
          .group(hoursGroup)
        //  .x(d3.scale.ordinal().domain(1000))
		  .x(d3.scale.ordinal().domain(keys))
          .y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))
          .on('pretransition', function (sfBarChart) {
              var colors = d3.scale.ordinal().domain(yearsDim)
                .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820
                sfBarChart.selectAll('rect.bar').each(function(d){
                    d3.select(this).attr("style", "fill: " + colors(d.data.key));
                });
          })
          postSetupChartParameters(data);

          dc.redrawAll('barchartgroup1');
          }
        }

      };
  });



   // second Directive for bar Chart - Use <div bar-chart data="stateBillingData" ></div> where data parameter should be different
    app.directive('baraChart', function($window){
    return {
      restrict:'EAC',
      template:"",
      scope:{
             data: '=data'
        },
      link: function (scope,elem,attrs){
        var chartElement = elem[0];
        // variable to hold dc chart
        var chartFactory = dc['barChart'];
        // Create an unconfigured instance of the chart
        var sfBarAChart = chartFactory(chartElement,'barchartgroup2');

        var dataToPlot;
		var widgetCurrency = attrs["widgettype"];
	//	console.log("widgetCurrency = " + widgetCurrency);
        var barLabelCurrencyFormat = d3.format(".3s");

		if(widgetCurrency == "violationswidget") {
			barLabelCurrencyFormat = d3.format("$,.3s");
		}

       // set the watch for the data changes. if the values are changed then update the bar chart, else draw the same.

        scope.$watch('data', function (newVal, oldVal) {
            if(newVal!=oldVal){

              dataToPlot = newVal;
              updateBarAChart(dataToPlot);

            } else {

              dataToPlot = newVal;
              drawBarAChart(dataToPlot);
             }
        });

      function preSetupChartParameters() {

          sfBarAChart
            .width(260)
            .height(270)
            .margins({top: 10, right: 50, bottom: 20, left: 40})
            .gap(0)
            .brushOn(false)
            .yAxisLabel("")
            .xUnits(dc.units.ordinal)
        }

      function postSetupChartParameters(data) {

            sfBarAChart
            .on('renderlet',function () {
            var barsData = [];
            var dataLabelValues = []; // place holder for adding data labels.
            var bars = sfBarAChart.selectAll('.bar').each(function (d) {
                  barsData.push(d);
            });
			for(var i = 0; i < data.length ; i++)
			{
			//	console.log("dataLabelValues Data values = " + data[i].key );
				dataLabelValues.push(data[i].key);
			};
			dataLabelValues.reverse();
            // //Remove old values (if found)
			//console.log("bars value = " + barsData[0].values);
            d3.select(bars[0][0].parentNode).select('#inline-labels').remove();
            // //Create group for labels
            var gLabels = d3.select(bars[0][0].parentNode).append('g').attr('id', 'inline-labels');
            //  console.log("gLabels = " +gLabels);
            for (var i = bars[0].length - 1; i >= 0; i--) {
                var b = bars[0][i];
				//console.log("b=" + b);
            //Only create label if bar height is tall enough
                if (+b.getAttribute('height') < 18) continue;
				//console.log("barsData[i].values " + barsData[i].data.value);
				var myLabel = barLabelCurrencyFormat(barsData[i].data.value);
				var myLabelYtd = dataLabelValues[i];
                  gLabels.append("text")
                  .text(myLabel)
				  .attr("class","barlabelchart")
                  .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
                  .attr('y', +b.getAttribute('y') + 20)
                  .attr('text-anchor', 'middle')
                  .attr('fill', 'white')

				  gLabels.append("text")
                  .text(myLabelYtd)
				  .attr("class","barlabelchartytd")
                  .attr('x', +b.getAttribute('x') + (b.getAttribute('width') / 2))
                  .attr('y', +b.getAttribute('y') + 40)
                  .attr('text-anchor', 'middle')
                  .attr('fill', 'white')
                  }
                });
            sfBarAChart.yAxis().ticks(0); // hide the yAsix labels
            sfBarAChart.xAxis().tickValues([]); // hide the xAxis labels
        }

        // Function to draw default bar chart

        function drawBarAChart(data) {

        preSetupChartParameters();
       // console.log("data in drawBarChart = " + JSON.stringify(data));

        var dataToPlotFiltered = crossfilter(data);
        //console.log("data in drawBarChart filtered = " + JSON.stringify(dataToPlotFiltered));

        var yearsDim = dataToPlotFiltered.dimension(function (d) {
			//console.log("years = " + d.key);
            return d.key;
        });
        var hoursGroup = yearsDim.group().reduceSum(function (d) {
          //  console.log("hoursGroup = " + d.values);
            return d.values;
        });

		var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
		var keys = sortByValues.map(function (d) { return d.key; });

        var chartcolortypeL = attrs["chartcolortype"];
         if(chartcolortypeL == 'blue') {

           var barColorRangeA ="#029fdb";
           var barColorRangeB = "#cbcbcb";
         } else {
           var barColorRangeA ="#cbcbcb";
           var barColorRangeB = "#c31820";
         }


		 //var initialScaleData = [600, 2000]; // this is the problem.
		 //var jsondata = JSON.parse(JSON.stringify(data));
		 var initialScaleData = [];
			for(var i = 0; i < data.length ; i++)
				{
					//console.log("initial Scale Data values = " + data[i].values );
					initialScaleData.push(data[i].values);

			};
		//console.log('new array is ' + initialScaleData);
		sfBarAChart
          .dimension(yearsDim)
          .group(hoursGroup)
          //.x(d3.scale.ordinal().domain(1000))
          .x(d3.scale.ordinal().domain(keys))
		  .y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))

          .on('pretransition', function (sfBarAChart) {
              var colors = d3.scale.ordinal().domain(yearsDim)
                .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820

					sfBarAChart.selectAll('rect.bar').each(function(d){
                    d3.select(this).attr("style", "fill: " + colors(d.data.key));
                });

          })
          postSetupChartParameters(data);
            dc.renderAll('barchartgroup2');
          }

        // Function to update the bar chart with changed data. This will be called based on the changed scope data.

        function updateBarChart(data) {

        preSetupChartParameters();
      //  console.log(JSON.stringify(data));
        var dataToPlotFiltered = crossfilter(data);
        // console.log(JSON.stringify(dataToPlotFiltered));
        var yearsDim = dataToPlotFiltered.dimension(function (d) {
        //  console.log("years = " + d.year);
        return d.key;
        });
        var hoursGroup = yearsDim.group().reduceSum(function (d) {
        //    console.log("hoursGroup = " + d.hours);
            return d.values;
        });

		var sortByValues = data.sort(function (a, b) { return a.values < b.values; });
		var keys = sortByValues.map(function (d) { return d.key; });

        var chartcolortypeL = attrs["chartcolortype"];
         if(chartcolortypeL == 'blue') {
           var barColorRangeA ="#029fdb";
           var barColorRangeB = "#cbcbcb";
         } else {
           var barColorRangeA ="#cbcbcb";
           var barColorRangeB = "#c31820";
         }
		// var initialScaleData = [600, 2000];
		//var jsondata = JSON.parse(JSON.stringify(data));
		 var initialScaleData = []; for(var i = 0; i < data.length ; i++) {initialScaleData.push(data[i].values)};
		//console.log('new array is '+initialScaleData);
        sfBarAChart
          .dimension(yearsDim)
          .group(hoursGroup)
          //.x(d3.scale.ordinal().domain(1000))
          .x(d3.scale.ordinal().domain(keys))
		  .y(d3.scale.linear().domain([0,d3.max(initialScaleData)]).range([0,100]))
          .on('pretransition', function (sfBarAChart) {
              var colors = d3.scale.ordinal().domain(yearsDim)
                .range([barColorRangeA, barColorRangeB]);   // color for other graphs needs to be changed and this will have to be customized parameter set in directive. blue: #029fdb, grey:#cbcbcb, red: #c31820
                sfBarAChart.selectAll('rect.bar').each(function(d){
                    d3.select(this).attr("style", "fill: " + colors(d.data.key));
                });
          })
          postSetupChartParameters(data);

          dc.redrawAll('barchartgroup2');
          }
        }

      };
  });


  // second bar chart

	 // Reusable Directive for row bar Chart - Use <div rowbar-chart data="rowbarchartdata" ></div> where data parameter should be different
    app.directive('rowbarnewChart', function($window){
    return {
     restrict:'EAC',
      template:"",
      scope:{
             data: '=data'
        },
		link: function (scope,elem,attrs){
			// both state widget 1d4
		//set up svg using margin conventions - we'll need plenty of room on the left for labels

		 scope.$watch('data', function (newVal, oldVal) {
            if(newVal!=oldVal){

              barDataToPlot = newVal;
              drawBarChartNew(barDataToPlot);

            } else {

              barDataToPlot = newVal;
              drawBarChartNew(barDataToPlot);
             }
        });


		function drawBarChartNew(data) {

		var margin = {
            top: 15,
            right: 25,
            bottom: 15,
            left: 60
        };

		var barPadding = 3.5;
		var barPaddingOuter = 0.1;
		var topData = data.slice(0,3);
        var width = 580 - margin.left - margin.right,
            height = 280 - margin.top - margin.bottom;
		var rowbarLabelCurrencyFormat = d3.format("$,");
		var x = d3.scale.linear()
            .range([0, width])
            .domain([0, d3.max(topData, function (d) {
                return d.values;
            })]);

        var y = d3.scale.ordinal()
            .rangeRoundBands([height , 0], barPadding, barPaddingOuter)
            .domain(topData.map(function (d) {
                return d.key;
            }));

		// Add the div containing the whole chart
		var chart = d3.select('#matterchart').append('div').attr('class', 'matterchart');

		// Add one div per bar which will group together both labels and bars
		var g = chart.selectAll('div')
			.data(topData)
			.enter()
			.append('div')
			.attr("class", "masterdiv")

		// Add the labels
		g.append("div")
			.attr("class", "barlabel")
			.text(function (d, i) { return d.key });

	// Add the bars
		var bars = g.append("div")
			.attr("class", "rect")
			.style("width", function (d) {
			    return (x(d.values/1.2) + "px");
            })
			.style("padding","10px")
			.text(function (d) { return rowbarLabelCurrencyFormat(Math.ceil(d.values)); })

		}
      }
	  }
  });

  ////////////// horizontal chart


  //DataService containing all the data calls from backend.

	var DataService = angular.module('DataService', [])
      .service('billingService', function ($http,$q) {

      // Service method to get the billing hours
      // Return service methodes.
      return({
            getServiceData: getServiceData,
			getAnomaliesData: getAnomaliesData

      });

      // start call to get service data

      function  getServiceData(category,categoryvalue,filters,selectedkpi,subcategory,datefilter) {
     //   console.log("getServiceData Service Method started");
	//	console.log("Variable in getService Data are category = " + category + " categoryValue = " + categoryvalue + ",filters = " + filters + ",selectedkpi = " + selectedkpi + ",subcategory = " + subcategory + ",datefilter = "+ datefilter);
		var request = $http({
              method: "post",
              url: "/AppBuilder/endpoint/dashboardendpoint",
			  params: {
                      category: category,
                      categoryvalue: "'" + categoryvalue + "'",
                      filters: filters,
					  selectedkpi: selectedkpi,
					  subcategory: subcategory,
					  datefilter: datefilter
				}
          });
        //  console.log("getServiceData Service ended started");
		  return(request.then( handleSuccess, handleError ) );
		}
      // end call to get data from service.

	  // start call to get service data

      //function  getAnomaliesData(category,categoryvalue,filters,selectedkpi,subcategory,datefilter) {
	  function  getAnomaliesData(stateS,datefilterS) {
     //   console.log("getServiceData Service Method started");
	//	console.log("Variable in getService Data are category = " + category + " categoryValue = " + categoryvalue + ",filters = " + filters + ",selectedkpi = " + selectedkpi + ",subcategory = " + subcategory + ",datefilter = "+ datefilter);
		var request = $http({
              method: "post",
              url: "/AppBuilder/endpoint/getAnomaly",
			  params: {
                      state: stateS,
                //      categoryvalue: "'" + categoryvalue + "'",
                //      filters: filters,
				//	  selectedkpi: selectedkpi,
				//	  subcategory: subcategory,
					  datefilter: datefilterS
				}
          });
        //  console.log("getServiceData Service ended started");
		  return(request.then( handleSuccess, handleError ) );
		}
      // end call to get data from service.

      // Common method to handle the request from the server
      function handleError( response ) {
          if (
              ! angular.isObject( response.data ) ||
              ! response.data.message
              ) {
              return( $q.reject( "An unknown error occurred." ) );
          }
          return( $q.reject( response.data.message ) );
      }
      function handleSuccess( response ) {
		//  console.log("handling the success of the call ");
		  return( response.data);
      }

   });
