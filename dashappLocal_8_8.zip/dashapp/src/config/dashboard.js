'use strict';
/**
 * @ngdoc overview
 * @name wexdashboard
 * @description
 * # wexdashboard
 *
 * Main configuration module of the application.
 */

	// angular.module('wexdashboard', ['oc.lazyLoad','datamaps','ui.router'])
	// 	.config(['$stateProvider','$urlRouterProvider','$ocLazyLoadProvider',function ($stateProvider,$urlRouterProvider,$ocLazyLoadProvider) {
  //
	// 	$ocLazyLoadProvider.config({
	// 	 debug:true,
	// 	 events:true,
	//  });

  angular.module('wexdashboard', ['datamaps','ui.router','DashboardController'])
  	.config(['$stateProvider','$urlRouterProvider',function ($stateProvider,$urlRouterProvider) {

	 $urlRouterProvider.otherwise('/dashboard');

	 $stateProvider
 			.state('dashboard', {
	         url:'/dashboard',
           controller: 'DashboardController',
	         templateUrl: '/AppBuilder/dashapp/src/views/dashboard/countrymapview.html'
			    //  resolve: {
	        //      loadMyFiles:function($ocLazyLoad){
	        //          return $ocLazyLoad.load(
	        //          {
	        //              name:'wexdashboard',
	        //              files:[
					// 			'/AppBuilder/dashapp/src/controllers/DashboardController.js',
					// 			'/AppBuilder/dashapp/src/components/services/dashboardservice.js'
					// 		       ]
	        //        })
           //
	        //      }
	        //  }
	     })
}]);
