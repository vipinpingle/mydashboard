<script type="text/javascript">

  var app = angular.module('wexdashboard',['angularUtils.directives.dirPagination','InvoiceDataService','ui.router','ui.bootstrap','wexdashboard.directives','wexdashboard.services']);

app.controller('InvoiceController',['$scope','$state','invoiceService','sharedParameterService','paginationService',function($scope, $state,invoiceService, sharedParameterService, paginationService) {

// variable for pagination calls
$scope.numberOfResults = "10";
$scope.numberOfResultsLineItem = "5";
$scope.pageNumber = "1";
$scope.pageNumI = "1";
$scope.pageNumID = "1";
$scope.searchItem = "";
$scope.sortByField = "invoice_date";
$scope.sortByFieldLabel = "Date";
$scope.totalPageCount = "";
$scope.totalPageLineItemCount = "";
$scope.totalPageLineItemDisbCount = "";
$scope.invList = "";
$scope.showSidebar = true;
//  $scope.showinvdetails = false;
$scope.showAnomalyDescription = false;
$scope.invoiceLineItems = [];
$scope.disbursementsLineItems = [];
$scope.invoiceAnomaliesList = [];
$scope.invoiceTimekeepersList = [];
$scope.invoiceSummaryFeesTotalHours = "";
$scope.invoiceSummaryTotalNetAmount = "";
$scope.invoiceSummaryInvoiceTotal = "";
$scope.invoiceSummaryDisbursementFees = "";
$scope.invoiceSummaryGrandTotalAmount = "";
$scope.invoiceSummaryAverageFeesTotal = "";
$scope.sortType = 'id';
$scope.sortReverse = false;
$scope.searchItem = '';
$scope.selectedInvoiceIdLineItem = "";
$scope.lineItemSummarySelectedKpi = "net_amt,hours";
$scope.lineItemSummarySortByField = "net_amt:ascending";
$scope.lineItemSummarySubcategory = "timekeeper";
$scope.sortLineItemByType = "invoice_line_item_number";
$scope.filterByMatterNumber = '';
$scope.highlighted="";
$scope.invsortList = [
    {name : "Date", value : "invoice_date:descending"},
    {name : "Matter Name", value : "matter_name"},
    {name : "Matter Number", value : "matter_number"},
    {name : "Firm Name", value : "firm_name"},
    {name : "Invoice Amount", value : "invoice_total:descending"}

];
$scope.sharedParameterService = sharedParameterService;
$scope.paginationService = paginationService;
$scope.toggleShowSidebar = function(){
  $scope.showSidebar = !$scope.showSidebar;
//  console.log($scope.showSidebar);
}
$scope.selectInvoice = function(event, params )
   {
  //  	console.log("Fired on selectInvoice : " + event  + " :: " + params[0].value);
   	if( params[0].value != undefined && ($scope.selectedInvoiceid == undefined ||  params[0].value.properties.invoice_id[0] != $scope.selectedInvoiceid[0]))
	{
		$scope.getInvoiceLineItemsList(params[0].value,'default');
        	$scope.getInvoiceLineItemsDisbList(params[0].value,'default');
 	}
	//console.log(event);
   }

   $('#daterange').daterangepicker({
         ranges: {
           '2017': ['1/1/2017', '12/31/2017'],
		       '2016': ['1/1/2016', '12/31/2016'],
           '2015': ['1/1/2015', '12/31/2015'],
		       '2014': ['1/1/2014', '12/31/2014'],
           '2013': ['1/1/2013', '12/31/2013'],
           '2012': ['1/1/2012', '12/31/2012']
        }
   });

   $('#daterange').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
  //    console.log($(this).val());
  //    console.log($scope.sharedParameterService);
      $scope.sharedParameterService.setSharedParameter('datefilter', $(this).val());
      $scope.expand_date_filter = false;
       $scope.datefilter = picker.startDate.format('MM/DD/YYYY') + ' ' +  picker.endDate.format('MM/DD/YYYY')
      $scope.$apply( function() {
//	console.log($scope);
	    });
    });

function init() {
  $scope.toShow='Summary';
  $scope.sharedParameterService.setSharedParameter('invListSort', 'invoice_date:descending');

  $scope.sharedParameterService.setSharedParameter('searchItem', '');
  $scope.sharedParameterService.setSharedParameter('firmname', "");
  $scope.sharedParameterService.setSharedParameter('matternumber', "");
  urlparams = getUrlRequestParameters();
  if(urlparams["firmname"])
  {
    $scope.datefilter = '01/01/2012 12/31/2017';
    $scope.sharedParameterService.setSharedParameter('datefilter', '01/01/2012 - 12/31/2017');
    $scope.sharedParameterService.setSharedParameter('firmname', urlparams["firmname"]);
  }else if(urlparams["matternumber"])
  {
    $scope.datefilter = '01/01/2012 12/31/2017';
    $scope.sharedParameterService.setSharedParameter('datefilter', '01/01/2012 - 12/31/2017');
    $scope.sharedParameterService.setSharedParameter('matternumber', urlparams["matternumber"]);
  }else if(urlparams["invoiceid"])
  {
    $scope.datefilter = '01/01/2012 12/31/2017';
    $scope.sharedParameterService.setSharedParameter('datefilter', '01/01/2012 - 12/31/2017');
    $scope.sharedParameterService.setSharedParameter('searchItem', urlparams["invoiceid"]);
    $scope.searchItem = urlparams["invoiceid"];
//    console.log("urlparams is invoice id " + urlparams["invoiceid"]);
  }
  else{
     $scope.sharedParameterService.setSharedParameter('datefilter', '01/01/2016 - 12/31/2016');
     $scope.datefilter = '01/01/2016 12/31/2016';
  }
 }

  function getUrlRequestParameters()
  {
     url = location.href.split("?");
     retMap = {};
     if(url.length > 1)
     {
         prevParamName = "";
         reqParamArray = url[1].split("&");
         for (i in reqParamArray)
         {
           reqParam = reqParamArray[i].split("=");
           if(reqParam.length == 2)
           {
             retMap[reqParam[0]] = reqParam[1];
             prevParamName = reqParam[0];
           }
           else
           {
              retMap[prevParamName] = retMap[prevParamName] + "&" + reqParam[0];
           }
         }
     }
    return retMap;
  }

   //calling the search for invoice list
   $scope.getSearchedData = function(searchedString) {
      	 $scope.sharedParameterService.setSharedParameter('searchItem', searchedString);
   }


  //calling the search for matters list
  $scope.getInvListSorted = function(sortByField, sortByFieldLabel) {
       $scope.sortByFieldLabel = sortByFieldLabel;
       sortByValue = sortByField.split(":");
       sortByFieldArr = $scope.sortByField.split(':');
       if(sortByFieldArr[0] == sortByValue[0])
       {
           if( (sortByFieldArr.length == 1 && sortByValue.length > 1 && sortByValue[1] == 'descending') ||(sortByFieldArr[1] == 'descending'))
           {
              sortByValue[1] = 'ascending';
           }
           else
           {
              sortByValue[1] = 'descending';
           }
       }
       else if (sortByValue.length == 1)
       {
         sortByValue.push("ascending");
       }

       $scope.sortByField = sortByValue[0]+":"+sortByValue[1];
	     $scope.sharedParameterService.setSharedParameter('invListSort',  $scope.sortByField);
   }

  // sorting invoice details table

  $scope.sortInvDetailTable = function(selectedFieldForSorting) {
     var searchLineItem = "";
      sortParamStr = "";
      matterNumber = "";
     //$scope.sortLineItemByType = selectedFieldForSorting;
      $scope.reverseSort=($scope.sortLineItemByType == selectedFieldForSorting)?
      ! $scope.reverseSort:false;
  //    console.log("selectedFieldForSorting = " + selectedFieldForSorting);
  //    console.log("scope.sortLineItemByType = " + $scope.sortLineItemByType);
  //    console.log("Reversesort = " +  $scope.reverseSort);
      $scope.sortLineItemByType = selectedFieldForSorting;
      sortParamStr = selectedFieldForSorting;
      if( $scope.reverseSort === true)
      {
         sortParamStr = sortParamStr + ":descending";
      }
      $scope.sortLineItemByType = selectedFieldForSorting;
      if($scope.toShow == 'Matters')
      {
        matterNumber = $scope.selectedMatternumber;
      }   //getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResults,$scope.pageNumI,searchLineItem,$scope.sortLineItemByType);
            getInvoiceLineItemsData($scope.selectedInvoiceid, matterNumber ,$scope.numberOfResultsLineItem,$scope.pageNumI,searchLineItem,sortParamStr);
      }

      $scope.sortInvDetailDisbTable = function(selectedFieldForSorting) {
         var searchLineItem = "";
          sortParamStr = "";
          matterNumber = "";
          $scope.reverseSortD=($scope.sortLineItemByDisbType == selectedFieldForSorting)?
          ! $scope.reverseSortD:false;
    //      console.log("selectedFieldForSorting = " + selectedFieldForSorting);
    //      console.log("scope.sortLineItemByType = " + $scope.sortLineItemByDisbType);
    //      console.log("Reversesort = " +  $scope.reverseSortD);
          $scope.sortLineItemByDisbType = selectedFieldForSorting;
          sortParamStr = selectedFieldForSorting;
          if( $scope.reverseSortD === true)
          {
             sortParamStr = sortParamStr + ":descending";
          }
          $scope.sortLineItemByDisbType = selectedFieldForSorting;
          if($scope.toShow == 'Matters')
          {
            matterNumber = $scope.selectedMatternumber;
          }          getInvoiceLineItemsDisbursementData($scope.selectedInvoiceid, matterNumber, $scope.numberOfResultsLineItem,$scope.pageNumI,searchLineItem,sortParamStr);
          }

  $scope.getSortClass = function(selectedFieldForSorting) {
   if ($scope.sortLineItemByType == selectedFieldForSorting) {
     return $scope.reverseSort
     ?'arrow-down'
     :'arrow-up';
   }
    return'';
  }

  $scope.getSortDisbClass = function(selectedFieldForSorting) {
   if ($scope.sortLineItemByDisbType == selectedFieldForSorting) {
     return $scope.reverseSortD
     ?'arrow-down'
     :'arrow-up';
   }
    return'';
  }


  //calling the next page for invoicelineitems data
    $scope.getNextPageInvoiceLineItems = function(pageNumLineItem) {
       var searchLineItem = $scope.searchInvoiceLineItem ;
      matterNumber= '';
    //   var sortLineItemType =  "itemnumber";
       $scope.pageNumI = pageNumLineItem;
       sortParamStr =  $scope.sortLineItemByType;
       if( $scope.reverseSort === true)
       {
             sortParamStr = sortParamStr + ":descending";
       }
      if($scope.toShow == 'Matters')
      {
        matterNumber = $scope.selectedMatternumber;
      }
      getInvoiceLineItemsData($scope.selectedInvoiceid,matterNumber, $scope.numberOfResultsLineItem,$scope.pageNumI,searchLineItem,sortParamStr);
    }



  //calling the next page for invoicelinedisbitems data
 $scope.getNextPageInvoiceDisbLineItems = function(pageNumLineItem) {
    var searchLineItem = $scope.searchInvoiceLineItem;
 //   var sortLineItemType =  "itemnumber";
    $scope.pageNumID = pageNumLineItem;
    matterNumber= '';
    sortParamStrD = $scope.sortLineItemByDisbType;
       if(sortParamStrD === undefined)
 {
   sortParamStrD = "invoice_line_item_number"
 }
 if( $scope.reverseSortD === true)
       {
            sortParamStrD = sortParamStrD + ":descending";
       }
   if($scope.toShow == 'Matters')
      {
        matterNumber = $scope.selectedMatternumber;
      } getInvoiceLineItemsDisbursementData($scope.selectedInvoiceid, matterNumber,$scope.numberOfResultsLineItem,$scope.pageNumID,searchLineItem,sortParamStrD);
 }
    // Line itmes details call
  $scope.getInvoiceLineItemsList = function(item,selectedtab) {
  //    console.log("calling to get line items selectedtab value " + selectedtab);
      $scope.selectedInvoice = item;
      if(selectedtab == "default") {
  //      console.log("calling getInvoiceLineItemsList function on click with invoiceId = " + item.properties.invoice_id);
        $scope.selectedState =  item.properties.state;
        $scope.selectedFirmname = item.properties.firm_name;
        $scope.selectedMattername = item.properties.matter_name;
        $scope.selectedMatternumber = item.properties.matter_number;
        $scope.selectedInvoiceid = item.properties.invoice_id;
      }
      //$scope.selectedInvoiceid = "338518"; // hardcoded for anomalies testing purpose.
      if(selectedtab == 'matters') {
        $scope.selectedMattername = item.properties.matter_name;
        $scope.selectedMatternumber = item.properties.matter_number;
	      $scope.lineItemSummaryCategory = "matter_number";
        $scope.lineItemSummaryCategoryValue = $scope.selectedMatternumber;
    //    console.log("lineItemSummaryCategoryValue***** = " + $scope.lineItemSummaryCategoryValue);
        $scope.toShow = 'Matters';
      } else if(selectedtab == 'anomalies') {
        $scope.filterByMatterNumber = ""; // add logic for anomalies
        $scope.toShow = 'Anomalies';
      } else {
        $scope.lineItemSummaryCategory = "invoice_id";
        $scope.lineItemSummaryCategoryValue = $scope.selectedInvoiceid;
	      $scope.selectedMatternumber = ""
        $scope.toShow = 'Summary';
        }
      $scope.sharedParameterService.setSharedParameter('selectedInvoiceId',$scope.selectedInvoiceid);
      getInvoiceTimekeepersData($scope.lineItemSummaryCategory,$scope.lineItemSummaryCategoryValue);
      getInvoiceLevelAnomaliesData($scope.selectedInvoiceid);
      var pageNumI = $scope.pageNumI = "1";
      if($scope.paginationService.isRegistered("disblineItemList"))
      {
        $scope.paginationService.setCurrentPage("disblineItemList",1);
      }
      if($scope.paginationService.isRegistered("lineItemList"))
      {
        $scope.paginationService.setCurrentPage("lineItemList",1);
      }
      //
      var searchStrI = "";
      var sortByTypeI = "invoice_line_item_number";//$scope.sortLineItemByType;// ;
      $scope.highlighted="highlighted";
      $scope.searchInvoiceLineItem = "";
    //  console.log("I am calling invoice list now " + $scope.selectedInvoiceid + ", " + pageNumI + ", " + searchStrI + "," + sortByTypeI);
      getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.selectedMatternumber,$scope.numberOfResultsLineItem,pageNumI,searchStrI,sortByTypeI)
      getInvoiceLineItemsDisbursementData($scope.selectedInvoiceid,$scope.selectedMatternumber,$scope.numberOfResultsLineItem,$scope.pageNumI,searchStrI,sortByTypeI);

      $scope.showinvdetails = true;
  }

  $scope.getInvoiceLineItemsDisbList = function(item,selectedtab) {
    //  console.log("calling to get line items selectedtab value " + selectedtab);
      if(selectedtab == "default") {
    //    console.log("calling getInvoiceLineItemsDisbList function on click with invoiceId = " + item.properties.invoice_id);
        $scope.selectedState =  item.properties.state;
        $scope.selectedFirmname = item.properties.firm_name;
        $scope.selectedMattername = item.properties.matter_name;
        $scope.selectedMatternumber = item.properties.matter_number;
        $scope.selectedInvoiceid = item.properties.invoice_id;
      }
      if(selectedtab == 'matters') {
	      $scope.selectedMattername = item.properties.matter_name;
        $scope.selectedMatternumber = item.properties.matter_number;
	      $scope.lineItemSummaryCategory = "matter_number";
        $scope.lineItemSummaryCategoryValue = $scope.selectedMatternumber;
    //    console.log("lineItemSummaryCategoryValue***** = " + $scope.lineItemSummaryCategoryValue);
        $scope.toShow = 'Matters';
      } else if(selectedtab == 'anomalies') {
        $scope.filterByMatterNumber = ""; // add logic for anomalies
        $scope.toShow = 'Anomalies';
      } else {
        $scope.lineItemSummaryCategory = "invoice_id";
        $scope.lineItemSummaryCategoryValue = $scope.selectedInvoiceid;
        $scope.toShow = 'Summary';
        }
      var pageNumI = $scope.pageNumI = "1";
      var searchStrI = "";
      var sortByTypeI = "invoice_line_item_number";//$scope.sortLineItemByType;// ;
      $scope.searchInvoiceLineItem = "";
    //  console.log("I am calling invoice list for disbursements now " + $scope.selectedInvoiceid + ", " + pageNumI + ", " + searchStrI + "," + sortByTypeI);
      getInvoiceLineItemsDisbursementData($scope.selectedInvoiceid,$scope.filterByMatterNumber,$scope.numberOfResultsLineItem,pageNumI,searchStrI,sortByTypeI)
      $scope.showinvdetails = true;
  }

     $scope.getInvLineItemSearchedData = function(searchedString, searchType) {
     	$scope.pageNumI = 1;
     	sortParamStr =  $scope.sortLineItemByType;
             if( $scope.reverseSort === true)
             {
                sortParamStr = sortParamStr + ":descending";
             }
               	sortParamStrD = $scope.sortLineItemByDisbType;
                       if(sortParamStrD === undefined)
               	{
               		sortParamStrD = "invoice_line_item_number"
               	}
               	if( $scope.reverseSortD === true)
             {
                  sortParamStrD = sortParamStrD + ":descending";
             }

     	    getInvoiceLineItemsData($scope.selectedInvoiceid,$scope.selectedMatternumber,$scope.numberOfResults,$scope.pageNumI,searchedString,sortParamStr);
        	getInvoiceLineItemsDisbursementData($scope.selectedInvoiceid,$scope.selectedMatternumber,$scope.numberOfResultsLineItem,$scope.pageNumI,searchedString,sortParamStrD);
        }

  // Callback function to retrieve data for invoicelineitem details.
   function getInvoiceTimekeepersData(cat,catvalue){
        formatNumber = d3.format(".2f");
        var totalFeesHours = 0;
        var totalNetAmount = 0;

        invoiceService.getInvoiceLevelTimekeeperServiceData(cat,catvalue,$scope.lineItemSummarySelectedKpi,$scope.lineItemSummarySortByField,$scope.lineItemSummarySubcategory,"lineitem")
               .then(
                 function( mydata ) {
                     $scope.invoiceTimekeepersList = mydata;//formatDataForTimeKeeper(mydata);
                     invoiceService.getInvoiceLevelTimekeeperServiceData(cat,catvalue,$scope.lineItemSummarySelectedKpi,$scope.lineItemSummarySortByField,$scope.lineItemSummarySubcategory,"expense")
                           .then(
                                function( mydata1 ) {
                                 // $scope.invoiceTimekeepersDisbList = mydata1;//formatDataForTimeKeeper(mydata);
                                  $scope.invoiceSummaryDisbursementFees = mydata1;

                                  for(var i =0; i< $scope.invoiceTimekeepersList.length-1; i++){
                                   totalNetAmount = totalNetAmount + parseFloat($scope.invoiceTimekeepersList[i].spending);
                                   totalFeesHours = totalFeesHours + parseFloat($scope.invoiceTimekeepersList[i].hours);
                                   }
              //                    console.log("totalNetAmount" + totalNetAmount);
                                  var grandTotal = parseFloat(mydata1) + parseFloat(totalNetAmount);
                                  $scope.invoiceSummaryFeesTotalHours = formatNumber(totalFeesHours);
                                  $scope.invoiceSummaryTotalNetAmount = formatNumber(totalNetAmount);
                                  $scope.invoiceSummaryInvoiceTotal = formatNumber(totalNetAmount);
                                  $scope.invoiceSummaryGrandTotalAmount = formatNumber(grandTotal);
                                  $scope.invoiceSummaryAverageFeesTotal = formatNumber(parseFloat(totalNetAmount)/parseFloat(totalFeesHours))
                         });
            });

          //formatDataForTimeKeeper($scope.invoiceTimekeepersList,$scope.invoiceTimekeepersDisbList);
      };

    // Callback function to retrieve data for invoicelineitem details.
        function getInvoiceLineItemsData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType){
             invoiceService.getInvoiceLineItemsServiceData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType,"lineitem")
                    .then(
                      function( mydata ) {
                           $scope.invoiceLineItems = mydata.slice(0,-1);
                       //   $scope.sortLineItemByType = "itemnumber";
                          //$scope.totalPageLineItemCount = mydata[numResults].total;
                     $scope.totalPageLineItemCount = mydata[mydata.length - 1].total;
     		        //       console.log("$scope.totalPageLineItemCount = " + $scope.totalPageLineItemCount);
              //         console.log("$scope.totalPageLineItemCount = " + pageNum);
                   });
           };
          // Callback function to retrieve data for invoicelineitem details.
       function getInvoiceLineItemsDisbursementData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType){
            invoiceService.getInvoiceLineItemsServiceData(invoiceId,matterNumber,numResults,pageNum,searchStr,sortByType,"expense")
                   .then(
                     function( mydata ) {
                         $scope.disbursementsLineItems = mydata.slice(0,-1);
                      //   $scope.sortLineItemByType = "itemnumber";
                       //  $scope.totalPageDisburseLineItemCount = mydata[numResults].total;
                	      $scope.totalPageDisburseLineItemCount = mydata[mydata.length - 1].total;
		               });
          };
      // Callback function to retrieve data for invoice anomalies.
       function getInvoiceLevelAnomaliesData(invoiceId){
            invoiceService.getInvoiceLevelAnomaliesServiceData(invoiceId)
                   .then(
                     function( mydata ) {
                         $scope.invoiceAnomaliesList = mydata;
                         if (mydata[0].properties.invoice_anomaly_description){
                             $scope.showAnomalyDescription = true;
                          } else {
                            $scope.showAnomalyDescription = false;
                          }
                        //  console.log("$scope.showAnomalyDescription = " + $scope.showAnomalyDescription);
                  });
          };
  init();
}]);


//DataService containing all the data calls from backend.

var InvoiceDataService = angular.module('InvoiceDataService', [])
    .service('invoiceService', function ($http,$q) {

    // Service method to get the invoice listing
    // Return service methodes.
    return({
          getInvoiceListServiceData: getInvoiceListServiceData,
          getInvoiceLineItemsServiceData: getInvoiceLineItemsServiceData,
          getInvoiceLevelAnomaliesServiceData: getInvoiceLevelAnomaliesServiceData,
          getInvoiceLevelTimekeeperServiceData: getInvoiceLevelTimekeeperServiceData
    });

    // start call to get invoice list service data
    function  getInvoiceListServiceData(numResultsS,pageNumS,searchStrS,sortByTypeS) {
     var request = $http({
                  method: "post",
                  url: "/AppBuilder/endpoint/InvoiceList",
                  params: {
                            pagenumber: pageNumS,
                            searchstring: searchStrS,
                            sortbyfield: sortByTypeS
                    }
            });
          return(request.then( handleSuccess, handleError ) );
        }

        // start call to get invoice list service data
        function  getInvoiceLineItemsServiceData(invoiceIdL,matterNumberL,numResultsL,pageNumL,searchStrL,sortByTypeL,typeL) {

          console.log("Passing parameters in getInvoiceLineItemsServiceData " + "invoiceIdL* = " + invoiceIdL + " matterNumberL = " + matterNumberL + " numResultsL = "
          + numResultsL + " pageNumL = " + pageNumL + " searchStrL = " +searchStrL + " sortByTypeL = " + sortByTypeL + " typeL = " + typeL);
         var request = $http({
                      method: "post",
                      url: "/AppBuilder/endpoint/InvoiceDetails",
                      params: {
                                invoiceid: invoiceIdL,
                                matternumber: matterNumberL,
                                noofresults: numResultsL,
                                pagenumber: pageNumL,
                                searchstring: searchStrL,
                                sortbyfield: sortByTypeL,
                                type:typeL

                        }
                });
              return(request.then( handleSuccess, handleError ) );
            }

            // start call to get invoice level anomalies service data
            function  getInvoiceLevelAnomaliesServiceData(invoiceIdL) {

            console.log("Passing parameters in getInvoiceLevelAnomaliesServiceData " + "invoiceIdL = " + invoiceIdL);
            var request = $http({
                          method: "post",
                          url: "/AppBuilder/endpoint/getInvoiceAnomoly",
                          params: {
                                    invoiceid: invoiceIdL
                            }
                    });
                  return(request.then( handleSuccess, handleError ) );
                }
                // start call to get invoice level anomalies service data
                function  getInvoiceLevelTimekeeperServiceData(categoryT,categoryvalueT,selectedkpiT,sortbyfieldT,subcategoryT,typeT) {

                console.log("Passing parameters in getInvoiceLevelTimekeeperServiceData " + "categoryT = " + categoryT + " categoryvalueT = " + categoryvalueT + " selectedkpiT = " + selectedkpiT +
                " sortbyfieldT = " + sortbyfieldT + " subcategoryT = " + subcategoryT + " typeT = " + typeT);
  //category(invoice_id or matter_number), categoryvalue(actual value based on category), selectedkpi(net_amt,hours), sortbyfield(net_amt:ascending of hours:ascending),
  //subcategory (timekeeper), type (lineitem for lineitems and expense for disbursements)
                var request = $http({
                              method: "post",
                              url: "/AppBuilder/endpoint/getInvoiceTimekeeperDetails",
                              params: {
                                        category: categoryT,
                                        categoryvalue: categoryvalueT,
                                        selectedkpi: selectedkpiT,
                                        sortbyfield:sortbyfieldT,
                                        subcategory:subcategoryT,
                                        type:typeT,
                                        datefilter: "",
                                        filters: "",
                                        noofresults: ""
                                }
                        });
                      return(request.then( handleSuccess, handleError ) );
                    }

    // Common method to handle the request from the server
    function handleError( response ) {
        if (
            ! angular.isObject( response.data ) ||
            ! response.data.message
            ) {
            return( $q.reject( "An unknown error occurred." ) );
        }
        return( $q.reject( response.data.message ) );
    }
    function handleSuccess( response ) {
    return( response.data);
    }
   // end call to get data from service.
  });


</script>
