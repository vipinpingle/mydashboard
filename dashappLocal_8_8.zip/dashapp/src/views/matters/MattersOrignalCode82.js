
<script type="text/javascript">
  var app = angular.module('wexdashboard', ['angularUtils.directives.dirPagination','MatterDataService','ui.bootstrap','ui.tree','wexdashboard.directives','wexdashboard.services','angularjs-dropdown-multiselect']);
  app.controller('MatterController',['$scope','$http','matterService','sharedParameterService', function($scope, $http,matterService, sharedParameterService) {
  $scope.sharedParameterService = sharedParameterService;
  // variable for pagination calls
  $scope.numberOfResults = "10";
  $scope.pageNumber = "1";
  $scope.pageNumI = "1";
  $scope.searchItem = "";
  $scope.sortByField = "matter_open_date" //"matterdate";
  $scope.sortByFieldInvoice_Date = "invoice_date";
  $scope.sortByFieldLabel = "Date";
  $scope.totalPageCount = "";
  $scope.totalPageLineItemCount = "";
  $scope.matterList = "";
//  $scope.show_matterDetailView = false;
  $scope.matterLineItems = [];
  $scope.recentInvoiceList = [];
  $scope.staffLevelList = [];
  $scope.sortType = 'id';
  $scope.sortReverse = false;
  $scope.searchItem = '';
  $scope.selectedMatterIdLineItem = "";
  $scope.sortLineItemByType = "itemnumber";
  $scope.filterByMatterNumber = "";
  $scope.highlighted="";
  $scope.mattersortList = [
      {name : "Date", value : "matter_open_date:descending"},
      {name : "Matter Name", value : "matter_name"},
      {name : "Matter Number", value : "matter_number"},
  //    {name : "Firm Name", value : "firm_name"}
  ];
  $scope.invoicesViewList = [{id:"invoice_date", title:"Date",selected:true}, {id:"invoice_total", title:"Spend"}]

  $scope.matterPhasesViewList = [{id:"matter_total_hours", title:"Hours"}, {id:"spend", title:"Spend", selected:true}]

  $scope.searchSelectAllSettings = { enableSearch: true, showCheckAll: false, showUncheckAll:false,keyboardControls: true,
    styleActive: true,scrollable: true,scrollableHeight: '150px',selectionLimit:1,smartButtonMaxItems: 1,closeOnSelect:true,};
  $scope.searchSelectStaffModel = [];
  $scope.staffChangeEventListeners = {
      onSelectionChanged: onStaffSelectionChanged
  };
  $scope.showSidebar = true;

  // Data for matter phases
  $scope.matterPhaseCategories =  ['L100 Case Assess., Dev, Admin', 'L200 Pre-trial Pleadings & Motions', 'L300 Discovery', 'L400 Trial Prep & Trial', 'L500 Appeal',  'L600 e-Discovery', 'A100 Activities','E100 Expenses'];
  $scope.matterPhaseCatCodes =  ['L100', 'L200', 'L300', 'L400', 'L500','L600', 'A100','E100'];
  $scope.monthCategories =  ['January', 'February','March', 'April', 'May','June','July','August','September', 'October','November', 'December'];

  $scope.matterPhases = [{
        name: 'Actual Spending',
        data: [{y:0, color:'#029fdb'}, {y:0, color:'#be00f3'}, {y:0, color:'#92cd0d'}, {y:0, color:'#e9b918'}, {y:0, color:'#c31820'},{y:0, color:'#6f5df7'}, {y:0, color:'#f25214'}, {y:0, color:'#fff800'}],
        stack: 'actual_spending'
    },
    {
        name: 'Budget',
        data: [0, 0, 0, 0, 0, 0, 0,0],
        stack: 'budget',
        color: '#adadad'
    }];

    $scope.matterProgressByPhase = [{
        name: 'Matter Progress',
        data: [{y:3, color:'#e1261c'}, {y:1, color:'#eb7302'}, {y:5, color: '#ffce17'}, {y:3, color:'#a9e71c'}, {y:7, color:'#01b391'},{y:6, color:'#be00f3'}, {y:8, color:'#00b9ff'}] }];

    $scope.matterSpending = [{
        name: 'Actual',
        color: '#c31820',
        data: [3934, 2503, 3177, 1658, null, null, null, null]
    }, {
        name: 'Projected',
        color: '#15a9ff',
        data: [null, null, null, 1658, 4031, 4931, 6133, 7175]
    }, {
        name: 'Maximum Projected',
        color: '#adadad',
        data: [null, null, null, 1658, 3031, 4031, 5031, 6031],
        dashStyle: 'dot'
    }, {
        name: 'Minimum Projected',
        color: '#adadad',
        data: [null, null, null, 1658, 5031, 6031, 7031, 8031],
        dashStyle: 'dot'
    }];


  function init() {
    getMattersListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
    var dList = getPeriodHierarchy();
    //console.log(JSON.stringify(dList));
    if(dList.length > 0)
    {
      $scope.selectedPageDateFilter = dList[0].title;
      $scope.expand_page_date_filter = false;
      $scope.sharedParameterService.setSharedParameter("datefilter",dList[0].id);
      $scope.datefilter = dList[0].id;
    }
    $scope.sharedParameterService.setSharedParameter("invoiceview","invoice_date:descending");
    $scope.selectedInvoiceView = "Date"
    $scope.matterPhaseView = "spend";
    $scope.selectedMatterPhasesView = "Spend"
    $scope.list = dList;

  //  $scope.expand_staff_level_selection = false;
  }

  function fillStaffList() {
   $scope.staffLevelList = [{id:'',label:"All"}];
   matterService.getFirmStaffServiceData($scope.selectedMatternumber)
        .then(
              function( mydata ) {
              for(var i in mydata) {
            //    console.log("fillStaffList i = " + i);
                $scope.staffLevelList.push(
                  {
                    id:i,
                    label: i
                  });
              };
		    });
    };

  function getMattersListData(numResults,pageNum,searchStr,sortByType){
    		  matterService.getMatterListServiceData(numResults,pageNum,searchStr,sortByType)
                .then(
                  function( mydata ) {
    			             $scope.matterList = mydata;
                      if($scope.matterList.length > 0)
                       {
                          $scope.getMatterDetails($scope.matterList[0]);
                       }
                       $scope.totalPageCount = mydata[numResults].total;
  		    });
  };

  function onStaffSelectionChanged() {
    if($scope.searchSelectStaffModel.length >= 0) {
      //$scope.displaySelectedStaffValues = $scope.searchSelectStaffModel.map(function(el){return el.label}).join("||");
      tmpSelectedStaff = "";
      if($scope.searchSelectStaffModel[0] != undefined){
        tmpSelectedStaff = $scope.searchSelectStaffModel[0].id;
      }
      if (tmpSelectedStaff != '' )
      {
 $scope.sharedParameterService.setSharedParameter("staffLevelFilter","timekeeper_level>>"+tmpSelectedStaff);
      }else
      {
           $scope.sharedParameterService.setSharedParameter("staffLevelFilter","");
      }
    //    console.log("$scope.searchSelectStaffModel " + $scope.searchSelectStaffModel[0].label);
      }
  };

  // $scope.selectStaffLevel = function(selectedVal)
  // {
  //   if(selectedVal != '')
  //   {
  //     $scope.expand_staff_level_selection = false;
  //     $scope.selectedStaffLevel = selectedVal;
  //     $scope.sharedParameterService.setSharedParameter("staffLevel",$scope.selectedStaffLevel);
  //   }
  // }
  //  $scope.staffChangeEventListeners = {
  //     onSelectionChanged: onStaffSelectionChanged
  // };

  // function onStaffSelectionChanged() {
  //     console.log($scope.selectedStaffLevel);
  // }

  // function updateDropdowns(matterId)
  // {
  //    updateStaffLevelDropdown(matterId)
  // }

  // function updateStaffLevelDropdown(matterId)
  // {
  //    console.log("Staff level matter Id " + matterId + "::" +$scope.selectedMatternumber);
  //
  //    matterService.getFirmStaffServiceData(matterId)
  //              .then(
  //                function( mydata ) {
  //                  sList = [];
  //                  firstItem = "";
  //                  for(key in mydata)
  //                  {
  //                      var item = new Object();
  //                      item.id = key;
  //                      item.title = key;
  //                      sList.push(item);
  //                  }
  //                  $scope.staffLevelList = sList;
  //                  if(sList.length > 0)
  //                  {
  //                    $scope.selectedStaffLevel = sList[0].id;
  //                    sList[0].isSelected = true;
  //                    $scope.sharedParameterService.setSharedParameter("staffLevel",sList[0].id);
  //                  }
  //             });
  // }

 $scope.updateGraphs = function(){

         // Data for matter phases

    as = [Math.floor(Math.random()*10000+1), Math.floor(Math.random()*10000+1), Math.floor(Math.random()*10000+1), Math.floor(Math.random()*10000+1), Math.floor(Math.random()*10000+1),Math.floor(Math.random()*10000+1), Math.floor(Math.random()*10000+1)];

    bd = [Math.floor(Math.random()*10000+1), Math.floor(Math.random()*10000+1), Math.floor(Math.random()*10000+1), Math.floor(Math.random()*10000+1), Math.floor(Math.random()*10000+1),Math.floor(Math.random()*10000+1), Math.floor(Math.random()*10000+1)];

   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget1")
        .then(
              function( mydata ) {
              $scope.matterBudget = mydata.budget;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget2")
        .then(
              function( mydata ) {
              $scope.matterTotalSpend = mydata.totalmatterspent;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget3")
        .then(
              function( mydata ) {
              $scope.matterPeriodSpend = mydata.matterperiodspend;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget4")
        .then(
              function( mydata ) {
              $scope.matterBlendedRate = mydata.matterblendedrate;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget5")
        .then(
              function( mydata ) {
              $scope.matterCaseLength = mydata.caselength;
    });

   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter, $scope.matterPhaseView, "widget6")
        .then(
              function( mydata ) {
              phaseSpending = {"L100":0,"L200":0,"L300":0, "L400":0, "L500":0, "L600":0, "A100":0, "E100":0};
              phaseBudget = {"L100":0,"L200":0,"L300":0, "L400":0, "L500":0, "L600":0, "A100":0, "E100":0};
              keys = Object.keys(mydata);
              for(i in keys)
              {
                phaseSpending[keys[i]] = mydata[keys[i]].spend;
                phaseBudget[keys[i]] = mydata[keys[i]].budget;
              }

           matterPhaseLabel = 'Actual Spending'
           yAxisTitle = "Amount"
           if($scope.matterPhaseView === 'matter_total_hours')
           {
             matterPhaseLabel= 'Actual Hours';
             yAxisTitle = "Hours"
           }

              $scope.matterPhases = [{
        name: matterPhaseLabel,
        data: [{y:phaseSpending["L100"], color:'#029fdb'}, {y:phaseSpending["L200"], color:'#be00f3'}, {y:phaseSpending["L300"], color:'#92cd0d'}, {y:phaseSpending["L400"], color:'#e9b918'}, {y:phaseSpending["L500"], color:'#c31820'},{y:phaseSpending["L600"], color:'#6f5df7'}, {y:phaseSpending["A100"], color:'#f25214'}, {y:phaseSpending["E100"], color:'#fff800'}],
        stack: 'actual_hours',
        yAxisTitle : yAxisTitle
    },
    {
        name: 'Budget',
        data: [phaseBudget["L100"], phaseBudget["L200"], phaseBudget["L300"], phaseBudget["L400"], phaseBudget["L500"], phaseBudget["L600"], phaseBudget["A100"], phaseBudget["E100"]],
        stack: 'budget',
        color: '#adadad'
    }];

		    });


  /*$scope.matterPhases = [{
        name: 'Actual Spending',
        data: [{y:as[0], color:'#029fdb'}, {y:as[1], color:'#be00f3'}, {y:as[2], color:'#92cd0d'}, {y:as[3], color:'#e9b918'}, {y:as[4], color:'#c31820'},{y:as[5], color:'#6f5df7'}, {y:as[6], color:'#f25214'}],
        stack: 'actual_spending'
    },
    {
        name: 'Budget',
        data: [bd[0], bd[1], bd[2], bd[3], bd[4], bd[5], bd[6]],
        stack: 'budget',
        color: '#adadad'
    }];*/

    $scope.matterProgressByPhase = [{
        name: 'Matter Progress',
        data: [{y:4, color:'#e1261c'}, {y:2, color:'#eb7302'}, {y:5, color: '#ffce17'}, {y:3, color:'#a9e71c'}, {y:5, color:'#01b391'},{y:6, color:'#be00f3'}, {y:7, color:'#00b9ff'}] }];

   matterService.getMatterSpending($scope.selectedMatternumber, $scope.datefilter)
        .then(
              function( mydata ) {
              $scope.matterSpending = mydata;
    });

   /* $scope.matterSpending = [{
        name: 'Actual',
        color: '#c31820',
        data: [bd[0], bd[1], bd[2], bd[3], null, null, null, null]
    }, {
        name: 'Projected',
        color: '#15a9ff',
        data: [null, null, null, bd[3], bd[4], bd[5], bd[6], bd[7]]
    }, {
        name: 'Maximum Projected',
        color: '#adadad',
        data: [null, null, null, bd[3], (bd[4]+1000), (bd[5]+1000), (bd[6]+1000), (bd[7]+1000)],
        dashStyle: 'dot'
    }, {
        name: 'Minimum Projected',
        color: '#adadad',
        data: [null, null, null, bd[3], (bd[4]-1000), (bd[5]-1000), (bd[6]-1000), (bd[7]-1000)],
        dashStyle: 'dot'
    }];*/

     }

     //calling the next page data for matter list items
     $scope.getNextPageMatterData = function(pageNumber) {
      //  console.log("Calling next page data with number = " + pageNumber);
      //  console.log("next page sortby = " + $scope.sortByField);
        $scope.pageNumberLineitem = pageNumber;
        getMattersListData($scope.numberOfResults,pageNumber,$scope.searchItem,$scope.sortByField);
      //  console.log("Calling next page data ended ");
     }

    $scope.selectPeriod = function(selectedVal)
{
  if(selectedVal != '')
  {
    console.log(selectedVal);
    $scope.selectedPageDateFilter = selectedVal.split(":")[1];
    $scope.expand_page_date_filter = false;
    $scope.sharedParameterService.setSharedParameter("datefilter",selectedVal.split(":")[0]);
    $scope.datefilter = selectedVal.split(":")[0];
    //alert("selectPeriod");
    $scope.show_DropDown = false;
    $scope.updateGraphs();
  }
}

    $scope.selectInvoiceView = function(selectedVal)
    {
      if(selectedVal != '')
      {
        console.log(selectedVal);
        $scope.selectedInvoiceView = selectedVal.split(":")[1];
        $scope.expand_invoice_view_list = false;
        $scope.sharedParameterService.setSharedParameter("invoiceview",selectedVal.split(":")[0]+":descending");
      //alert("selectPeriod");

      }

    }

    $scope.selectMatterPhaseView = function(selectedVal)
    {
      if(selectedVal != '')
      {
        console.log(selectedVal);
        $scope.selectedMatterPhasesView = selectedVal.split(":")[1];
        $scope.expand_phase_view_list = false;
        $scope.matterPhaseView = selectedVal.split(":")[0];


        matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter, $scope.matterPhaseView, "widget6")
        .then(
              function( mydata ) {
               phaseSpending = {"L100":0,"L200":0,"L300":0, "L400":0, "L500":0, "L600":0, "A100":0, "E100":0};
              phaseBudget = {"L100":0,"L200":0,"L300":0, "L400":0, "L500":0, "L600":0, "A100":0, "E100":0};
              keys = Object.keys(mydata);
              for(i in keys)
              {
                phaseSpending[keys[i]] = mydata[keys[i]].spend;
                phaseBudget[keys[i]] = mydata[keys[i]].budget;
              }

           matterPhaseLabel = 'Actual Spending'
           yAxisTitle = "Amount";
           if($scope.matterPhaseView === 'matter_total_hours')
           {
             matterPhaseLabel= 'Actual Hours';
             yAxisTitle = "Hours";
           }
              $scope.matterPhases = [{
        name: matterPhaseLabel,
        data: [{y:phaseSpending["L100"], color:'#029fdb'}, {y:phaseSpending["L200"], color:'#be00f3'}, {y:phaseSpending["L300"], color:'#92cd0d'}, {y:phaseSpending["L400"], color:'#e9b918'}, {y:phaseSpending["L500"], color:'#c31820'},{y:phaseSpending["L600"], color:'#6f5df7'}, {y:phaseSpending["A100"], color:'#f25214'}, {y:phaseSpending["E100"], color:'#fff800'} ],
        stack: 'actual_spending',
        yAxisTitle: yAxisTitle
    },
    {
        name: 'Budget',
        data: [phaseBudget["L100"], phaseBudget["L200"], phaseBudget["L300"], phaseBudget["L400"], phaseBudget["L500"], phaseBudget["L600"], phaseBudget["A100"], phaseBudget["E100"]],
        stack: 'budget',
        color: '#adadad'
    }];

		    });

      }

    }


    $scope.expandTimekeeper = function(event, params )
   {
       console.log("Fired on expand timekeeper : " + params[1].value + " :: " + params[0].value.name);
       console.log(params[0].value);
       if(!$scope.sharedParameterService.getSharedParameter("topTKMattersKpi")){
           $scope.sharedParameterService.setSharedParameter("topTKMattersSort","hours");
           $scope.selectedTKMFilter = "Hours"
       }
       $scope.sharedParameterService.setSharedParameter("selectedTKIndex", params[1].value);
       $scope.sharedParameterService.setSharedParameter("timekeeperName"+params[1].value, params[0].value.name);
       updateTimekeeperSummary(params[0].value.name, params[1].value)

   }

  function updateTimekeeperSummary(timekeeper, selectedIndex)
  {
    dateFilter = $scope.datefilter;
    matterNumber = $scope.selectedMatternumber;
    if(!$scope.timekeeperDetails)
    {
        $scope.timekeeperDetails = {};
    }
    if(!$scope.timekeeperDetails[selectedIndex])
    {
        $scope.timekeeperDetails[selectedIndex] = new Object();
    }
    matterService.getTimekeperData(matterNumber, timekeeper,  dateFilter, "widget1")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('AverageBillrate' + mydata.avgbillrate);
                       $scope.timekeeperDetails[selectedIndex].avgBillRate =  mydata.avgbillrate;
                     $scope.timekeeperDetails[selectedIndex].billing =  mydata.billing;
                     $scope.timekeeperDetails[selectedIndex].matterCount =  mydata.mattercount;
                      $scope.timekeeperDetails[selectedIndex].costPerMatter =  mydata.costpermatter;
                     $scope.timekeeperDetails[selectedIndex].avgAnomalies =  mydata.avganomalies;
           });
   /* matterService.getTimekeperData(matterNumber, timekeeper,  dateFilter, "widget2")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('Billing to Date' + mydata.billing);
                       $scope.timekeeperDetails[selectedIndex].billing =  mydata.billing;
           });
    matterService.getTimekeperData(matterNumber, timekeeper,  dateFilter, "widget3")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('Matter Count' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].matterCount =  mydata.mattercount;
           });
     matterService.getTimekeperData(matterNumber, timekeeper,  dateFilter, "widget4")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('Cost Per Matter Matter ' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].costPerMatter =  mydata.costpermatter;
           });
    matterService.getTimekeperData(matterNumber, timekeeper,  dateFilter, "widget6")
                 .then(
                   function( mydata ) {
                       //$scope.firmLineItems = mydata;
                       console.log('Cost Per Matter Matter ' + mydata.mattercount);
                       $scope.timekeeperDetails[selectedIndex].avgAnomalies =  mydata.avganomalies;
           });*/
    matterService.getBillingActivity(matterNumber,timekeeper, dateFilter)
                 .then(
                    function( mydata ) {
                        $scope.billingHours = mydata;
                  //   console.log("$scope.billingHours = "+$scope.billingHours);
          });

  }



     //calling the search for matter list
     $scope.getSearchedData = function(searchedString) {
      //  $scope.searchItem = searchedString
        getMattersListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
     }

     $scope.getTimekeeperSearchedData = function(searchTimekeeper){
         $scope.sharedParameterService.setSharedParameter("searchTimekeeper", searchTimekeeper);
     }

     //calling the sort for matter list
  //    $scope.getMatterListSorted = function(item) {
  // //      console.log("sorting the field = " + item.name);
  //       $scope.sortByField = item.value;
  //       getMattersListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
  //       $scope.sortByFieldLabel = item.name;
  //    }



     //calling the search for matters list
     $scope.getMatterListSorted = function(sortByField, sortByFieldLabel) {
          $scope.sortByFieldLabel = sortByFieldLabel;
          sortByValue = sortByField.split(":");
          sortByFieldArr = $scope.sortByField.split(':');
          if(sortByFieldArr[0] == sortByValue[0])
          {
              if(sortByFieldArr[1] == 'descending')
              {
                 sortByValue[1] = 'ascending';
              }
              else
              {
                 sortByValue[1] = 'descending';
              }
          }
          else if (sortByValue.length == 1)
          {
            sortByValue.push("ascending");
          }

          $scope.sortByField = sortByValue[0]+":"+sortByValue[1];
          getMattersListData($scope.numberOfResults,$scope.pageNumber,$scope.searchItem,$scope.sortByField);
        }

    $scope.getMatterDetails = function(item) {
        $scope.selectedState =  item.properties.state;
      //  commenting till we fix the firm_name in matter_lost
    //    $scope.selectedFirmname = item.properties.firm_name[0];
        $scope.selectedMattername = item.properties.matter_name[0];
        $scope.selectedMatternumber = item.properties.matter_number[0];
        $scope.highlighted="highlighted";
        $scope.searchTimekeeper = "";
        $scope.toShow='Summary';
        getMatterDetailsData($scope.selectedMatternumber);
        //getRecentInvoices($scope.selectedMatternumber);
        $scope.sharedParameterService.setSharedParameter("selectedMatterNumberFilter","matter_number>>" +$scope.selectedMatternumber);
        $scope.sharedParameterService.setSharedParameter("searchTimekeeper", "");
        $scope.sharedParameterService.setSharedParameter("matterId", item.properties.matter_number[0]);
        $scope.sharedParameterService.setSharedParameter("staffLevelFilter","");
      //  updateDropdowns($scope.selectedMatternumber);
        fillStaffList();
        $scope.show_matterDetailView = true;

        matterService.getMatterServiceData($scope.selectedMatternumber, "","", "widget7")
        .then(
              function( mydata ) {
              $scope.primaryFirm = mydata.primary_firm;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget8")
        .then(
              function( mydata ) {
              $scope.opposingFirm = mydata.opposing_firm;
    });

      matterService.getMatterServiceData($scope.selectedMatternumber, "","", "widget9")
        .then(
              function( mydata ) {
              $scope.percentOfBudget = mydata.percentspent;
    });
   matterService.getMatterServiceData($scope.selectedMatternumber, $scope.datefilter,"", "widget10")
        .then(
              function( mydata ) {
              $scope.dormancyDays = mydata.dormancydays;
    });


        $scope.updateGraphs();
    }

      function getRecentInvoices(selectedMatterNumber) {

        matterService.getRecentInvoicesServiceData($scope.numberOfResults,$scope.pageNumber,selectedMatterNumber,$scope.sortByFieldInvoice_Date)
               .then(
                 function( mydata ) {
                     $scope.recentInvoiceList = mydata;
              });
        };

    // Callback function to retrieve data for matterlineitem details.
     function getMatterDetailsData(matterNumber){
          matterService.getMatterDetailsServiceData(matterNumber)
                 .then(
                   function( mydata ) {
                       $scope.matterLineItems = mydata;
                       $scope.matterDetail = mydata[0];
                });
        };

    init();
}]);

  //HighCharts Top Spending Chart

 /* Highcharts.chart('matterContainerTotSpending', {

    title: {
        text: ''
    },
    credits: {
        enabled: false
    },
    legend: {
        enabled: false
    },

    yAxis: {
        title: {
            text: ''
        }
    },

    plotOptions: {
            line: {
        			marker: {
            		enabled: false
        }
    	}
    },

    series: [{
        name: 'Actual',
        color: '#c31820',
        data: [3934, 2503, 3177, 1658, null, null, null, null]
    }, {
        name: 'Projected',
        color: '#15a9ff',
        data: [null, null, null, 1658, 4031, 4931, 6133, 7175]
    }, {
        name: 'Maximum Projected',
        color: '#adadad',
        data: [null, null, null, 1658, 3031, 4031, 5031, 6031],
        dashStyle: 'dot'
    }, {
        name: 'Minimum Projected',
        color: '#adadad',
        data: [null, null, null, 1658, 5031, 6031, 7031, 8031],
        dashStyle: 'dot'
    }]

});

  //Highcharts Matter Phases Chart



/*Highcharts.chart('matterContainerMatterPhases', {

    chart: {
        type: 'column'
    },
credits: {

enabled: false
},
    title: {
        text: null
    },

    xAxis: {
        categories: ['L100 Case Assess., Dev, Admin', 'L200 Pre-trial Pleadings & Motions', 'L300 Discovery', 'L400 Trial Prep & Trial', 'L500 Appeal', 'A100 Activities','E100 Expenses']
    },

    yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
            text: null
        }
    },

    tooltip: {
        formatter: function () {
            return '<b>' + this.x + '</b><br/>' +
                this.series.name + ': ' + this.y + '<br/>' +
                'Total: ' + this.point.stackTotal;
        }
    },

    plotOptions: {
        column: {
            stacking: 'normal'
        },
        series: {
           pointWidth: 28
            }
    },

    series: [{
        name: 'Actual Spending',
        data: [{y:5000, color:'#029fdb'}, {y:3000, color:'#be00f3'}, {y:4000, color:'#92cd0d'}, {y:7000, color:'#e9b918'}, {y:2000, color:'#c31820'},{y:2900, color:'#6f5df7'}, {y:9832, color:'#f25214'}],
        stack: 'actual_spending'
    },
    {
        name: 'Budget',
        data: [3000, 3500, 4123, 4938, 3213, 6782, 3249],
        stack: 'budget',
        color: '#adadad'
    }]
});

  //Highcharts Matter Progress
  Highcharts.chart('matterContainerMatterProgress', {

    chart: {
        type: 'columnrange',
        inverted: true
    },
    title: {
        text: null
    },
    xAxis: {
        categories: ['L100', 'L200', 'L300', 'L400', 'L500', 'A100', 'E100'],
        title: {
            text: null
        },
    },
    yAxis: {
        categories: ['January', 'February','March', 'April', 'May','June','July','August','September', 'October','November', 'December'],
        title: {
            text: 'Months'
        },
        gridLineColor: 'transparent'
    },


    legend: {
        enabled: false,},
    credits: {
        enabled: false
    },

    series: [{
        name: 'Millions',
        data:
        [
        { low: 0, high: 4, color: '#e1261c'},
        { low:5, high: 8, color: '#eb7302'},
        { low:9, high: 11, color: '#ffce17'},
         { low:2, high: 7, color: '#a9e71c' },
        { low:5, high: 8, color:'#01b391' },
        { low:9, high: 11, color:'#be00f3' },
         { low:2, high: 7, color:'#00b9ff'}
    ]
    }]

});

  */
//DataService containing all the data calls from backend.

	var MatterDataService = angular.module('MatterDataService', [])
      .service('matterService', function ($http,$q) {

      // Service method to get the matter listing
      // Return service methodes.
      return({
            getMatterListServiceData: getMatterListServiceData,
            //getMatterLineItemsServiceData: getMatterLineItemsServiceData
            getMatterDetailsServiceData:getMatterDetailsServiceData,
            getRecentInvoicesServiceData:getRecentInvoicesServiceData,
            getFirmStaffServiceData : getFirmStaffServiceData,
            getMatterSpendingByPhase : getMatterSpendingByPhase,
            getMatterServiceData  : getMatterServiceData,
            getMatterSpending : getMatterSpending,
            getTimekeperData : getTimekeperData,
            getBillingActivity : getBillingActivity
      });

      // start call to get matter list service data
      function  getMatterListServiceData(numResultsS,pageNumS,searchStrS,sortByTypeS) {
       var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/MattersList",
      			        params: {
                              noofresults: numResultsS,
                              pagenumber: pageNumS,
                              searchstring: searchStrS,
                              sortbyfield: sortByTypeS
      				        }
              });
            return(request.then( handleSuccess, handleError ) );
      		}

        // start call to get matter details service data
        function  getMatterDetailsServiceData(matternumberL) {

        var request = $http({
                      method: "post",
                      url: "/AppBuilder/endpoint/getMatterDetails",
                      params: {
                                matternumber: matternumberL
                        }
                });
              return(request.then( handleSuccess, handleError ) );
            }

            // start call to get recent invoices list for the matter data
            function  getRecentInvoicesServiceData(numResultsS,pageNumS,searchStrS,sortByTypeS) {
             var request = $http({
                          method: "post",
                          url: "/AppBuilder/endpoint/InvoiceList",
            			        params: {
                                    noofresults: numResultsS,
                                    pagenumber: pageNumS,
                                    searchstring: searchStrS,
                                    sortbyfield: sortByTypeS
            				        }
                    });
                  return(request.then( handleSuccess, handleError ) );
            		}

                function getFirmStaffServiceData(matternumber) {
                 var request = $http({
                              method: "post",
                              url: "/AppBuilder/endpoint/AnalysisDataEndpoint",
                			        params: {
                                        FindFieldName: "staff_level",
                                        FilterValue: "matter_number>>"+matternumber,
                                        datefilter: ""
                				        }
                        });
                      return(request.then( handleSuccess, handleError ) );
                		}
              // Get the matter's spending by phase
              function getMatterSpendingByPhase(matternumber, datafilterL) {
                 var request = $http({
                              method: "post",
                              url: "/AppBuilder/endpoint/analysisjsonendpoint",
                			        params: {
                                        excludeothers: "Y",
                                        filters: "",
                                        noofresults : 10,
                                        selectedkpi : "net_amt",
                                        subcategory : "phase",
                                        charttype : "pie",
                                        category : "matter_number",
                                        categoryvalue : matternumber,
                                        datefilter : datafilterL
                				        }
                        });
                      return(request.then( handleSuccess, handleError ) );
                		}
             // start call to get firm list service data
          function  getMatterServiceData(matterNumberL, dateFileterL, kpiL, widgetNameL) {

            console.log("Passing parameters in getMatterServiceData " + "matterNumberL = " + matterNumberL + " dateFileterL = " + dateFileterL + " widgetNameL = "
            + widgetNameL);
           var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/matter_details",
          			        params: {
                                  matter_number: matterNumberL,
                                  datefilter: dateFileterL,
                                  widgetname: widgetNameL,
                                  kpi : kpiL
          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
          		}
            // Get the data for the matter spending graph
            function getMatterSpending(matterNumberL, dateFileterL){
              var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/apoorvanalysischarts",
          			        params: {
                                  category : 'matter_number',
                                  categoryvalue: matterNumberL,
                                  datefilter: dateFileterL,
                                  charttype : 'timeline',
                                  filters : '',
                                  selectedkpi : 'net_amt',
                                  subcategory : 'matter_number'

          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
            }

             // start call to get firm time keeper summary data
          function  getTimekeperData(matterIdL, timekeeperL , dateFileterL, widgetNameL) {

            console.log("Passing parameters in getTimekeperData " + "matterIdL = " + matterIdL + " timekeeperL = " + timekeeperL + " dateFileterL = " + dateFileterL + " widgetNameL = "
            + widgetNameL);
           var request = $http({
                        method: "post",
                        url: "/AppBuilder/endpoint/matter_timekeeper_details",
          			        params: {
                                  matternumber: matterIdL,
                                  datefilter: dateFileterL,
                                  widgetname: widgetNameL,
                                  timekeeper : timekeeperL
          				        }
                  });
            	  return(request.then( handleSuccess, handleError ) );
          		}

        // start call to get billing activity data
            function  getBillingActivity(matterIdL, timekeeperL, dateFilterL) {
             var request = $http({
                          method: "post",
                          url: "/AppBuilder/endpoint/apoorvanalysischarts",
                          params: {
                                    category: "full_name",
                                    categoryvalue : timekeeperL+"||",
                                    charttype:"timeline",
                                    datefilter : dateFilterL,
                                    filters : "matter_number>>"+matterIdL,
                                    selectedkpi : "hours",
                                    subcategory : "full_name"
                            }
                    });
                  return(request.then( handleSuccess, handleError ) );
                }

      // Common method to handle the request from the server
      function handleError( response ) {
          if (
              ! angular.isObject( response.data ) ||
              ! response.data.message
              ) {
              return( $q.reject( "An unknown error occurred." ) );
          }
          return( $q.reject( response.data.message ) );
      }
      function handleSuccess( response ) {
		  return( response.data);
      }
	   // end call to get data from service.
	  });

(function() {
    console.clear();
'use strict';
angular.module('wexdashboard')

.controller('firmdrilldowncontroller', function($scope,$timeout,HierarchyNodeService) {

    //console.log(HierarchyNodeService);
    var dList = [];

    currentYear = moment().format("YYYY");
    for( i = 0 ; i < 3; i++)
    {
            var item = new Object();
            item.id = (currentYear - i)+"-01-01" + "::" + moment((currentYear - i)+"-01-01").endOf("year").format("YYYY-MM-DD");
            item.title = (currentYear - i);
            item.items = [];
            for(j = 1 ; j < 12; j+=3)
            {
                    qDateStr = (currentYear - i)+"-0"+j +"-01";
                    if(moment().fquarter(1).start > moment(qDateStr).fquarter(1).start)
                    {
                            var qItem = new Object();
                            qItem.id = moment(qDateStr).fquarter(1).start +"::"+ moment(qDateStr).fquarter(1).end;
                            qItem.title = moment(qDateStr).fquarter(1).toString();
                            qItem.items = [];
                            for(k = j ; k < j+3; k++)
                            {
                                    var mItem = new Object();
                                    startDateStr = "";
                                    if(k < 10)
                                    {
                                            startDateStr = (currentYear - i)+"-0"+k +"-01";
                                        }
                                        else
                                        {
                                                startDateStr = (currentYear - i)+ "-" + k +"-01";
                                        }
                                        //console.log(startDateStr);
                                        mItem.id = moment(startDateStr).format("YYYY-MM-DD") +"::"+ moment(startDateStr).endOf("month").format("YYYY-MM-DD");
                                        mItem.title = moment(startDateStr).format("MMM");
                                    qItem.items.push(mItem)
                            }
                            item.items.push(qItem)
                    }
            }
            dList.push(item);
    }
    //console.log(JSON.stringify(dList));
    $scope.baseList = dList;
    $scope.list = $scope.baseList;
    $scope.setPeriod = function(selected)
    {
       //alert('selected'+selected);
    }



})
.directive('indeterminateCheckbox',function(HierarchyNodeService) {
    return {
        restrict:'A',
        scope: {
          node:'='
        },
        link: function(scope, element, attr) {

            scope.$watch('node',function(nv) {

                var flattenedTree = HierarchyNodeService.getAllChildren(scope.node,[]);
                flattenedTree = flattenedTree.map(function(n){ return n.isSelected });
                var initalLength = flattenedTree.length;
                var compactedTree = _.compact(flattenedTree);

                var r = compactedTree.length > 0 && compactedTree.length < flattenedTree.length;
                element.prop('indeterminate', r);

            },true);

        }
    }
})

})();

var DEFAULT_ID = '__default';
function getPeriodHierarchy()
{
     var dList = [{id:'', title:'All Time'}];

    currentYear = moment().format("YYYY");
    i = 0;
    while( currentYear - i >= 2012)
    {

            var item = new Object();
            item.id = "01/01/" + (currentYear - i) + "-" + moment((currentYear - i)+"-01-01").endOf("year").format("MM/DD/YYYY");
            item.title = (currentYear - i);
            item.items = [];
            for(j = 1 ; j < 12; j+=3)
            {
                    qDateStr = "0"+j +"/01/" + (currentYear - i);
                    if(moment().fquarter(1).start > moment(qDateStr).fquarter(1).start)
                    {
                            var qItem = new Object();
                            qItem.id = moment(moment(qDateStr).fquarter(1).start).format("MM/DD/YYYY") +"-"+ moment(moment(qDateStr).fquarter(1).end).format("MM/DD/YYYY");
                            qItem.title = moment(qDateStr).fquarter(1).toString();
                            qItem.displayTitle = qItem.title + " " + (currentYear - i);
                            qItem.items = [];
                            for(k = j ; k < j+3; k++)
                            {
                                    var mItem = new Object();
                                    startDateStr = "";
                                    if(k < 10)
                                    {
                                            startDateStr = "0"+k +"/01" +"/"  + (currentYear - i);
                                        }
                                        else
                                        {
                                                startDateStr =  k +"/01"+ "/" +(currentYear - i);
                                        }
                                        //console.log(startDateStr);
                                        mItem.id = moment(startDateStr).format("MM/DD/YYYY") +"-"+ moment(startDateStr).endOf("month").format("MM/DD/YYYY");
                                        mItem.title = moment(startDateStr).format("MMM");
                                        mItem.displayTitle = mItem.title + " " + (currentYear - i);
                                    qItem.items.push(mItem)
                            }
                            item.items.push(qItem)
                    }
            }
            dList.push(item);
            i++;
    }
    return dList;
}

</script>
