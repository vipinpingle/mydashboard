
<script type="text/javascript">

  //$('select').select2();
 $(function() {

     var start = moment().subtract(29, 'days');
     var end = moment();

    //function cb(start, end) {
     //  $('#reportrange span').html(('01/01/2016') + ' - ' + ('12/31/2016'));
    //}

    $('input[name="daterange"]').daterangepicker({
        //startDate: start,
        //endDate: end,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
		   '2016': ['1/1/2016', '12/31/2016'],
		   '2015': ['1/1/2015', '12/31/2015'],
		    '2015-2016': ['1/1/2015', '12/31/2016']


        }
	});
    //}, cb);

      //cb(start, end);

	  function cb1(start, end) {
			$('#compTime1 span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
		}

		$('#compTime1').daterangepicker({
			startDate: '1/1/2016',
			endDate: '12/31/2016',
			ranges: {
			   'Today': [moment(), moment()],
			   'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
			   'Last 7 Days': [moment().subtract(6, 'days'), moment()],
			   'Last 30 Days': [moment().subtract(29, 'days'), moment()],
			   'This Month': [moment().startOf('month'), moment().endOf('month')],
			   'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
			   '2016': ['1/1/2016', '12/31/2016'],
			   '2015': ['1/1/2015', '12/31/2015'],
				'2015-2016': ['1/1/2015', '12/31/2016']


			}
		}, cb1);

		  cb1(start, end);

		  function cb2(start, end) {
			$('#compTime2 span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
		}

		$('#compTime2').daterangepicker({
			startDate: start,
			endDate: end,
			ranges: {
			   'Today': [moment(), moment()],
			   'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
			   'Last 7 Days': [moment().subtract(6, 'days'), moment()],
			   'Last 30 Days': [moment().subtract(29, 'days'), moment()],
			   'This Month': [moment().startOf('month'), moment().endOf('month')],
			   'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
			   '2016': ['1/1/2016', '12/31/2016'],
			   '2015': ['1/1/2015', '12/31/2015'],
				'2015-2016': ['1/1/2015', '12/31/2016']


			}
		}, cb2);

		  cb2(start, end);

		  function cb3(start, end) {
			$('#compTime3 span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
		}

		$('#compTime3').daterangepicker({
			startDate: start,
			endDate: end,
			ranges: {
			   'Today': [moment(), moment()],
			   'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
			   'Last 7 Days': [moment().subtract(6, 'days'), moment()],
			   'Last 30 Days': [moment().subtract(29, 'days'), moment()],
			   'This Month': [moment().startOf('month'), moment().endOf('month')],
			   'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
			   '2016': ['1/1/2016', '12/31/2016'],
			   '2015': ['1/1/2015', '12/31/2015'],
				'2015-2016': ['1/1/2015', '12/31/2016']


			}
		}, cb3);

		  cb3(start, end);
	  function cb4(start, end) {
			$('#compTime4 span').html(start.format('MM/DD/YYYY') + ' - ' + end.format('MM/DD/YYYY'));
		}

		$('#compTime4').daterangepicker({
			startDate: start,
			endDate: end,
			ranges: {
			   'Today': [moment(), moment()],
			   'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
			   'Last 7 Days': [moment().subtract(6, 'days'), moment()],
			   'Last 30 Days': [moment().subtract(29, 'days'), moment()],
			   'This Month': [moment().startOf('month'), moment().endOf('month')],
			   'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')],
			   '2016': ['1/1/2016', '12/31/2016'],
			   '2015': ['1/1/2015', '12/31/2015'],
				'2015-2016': ['1/1/2015', '12/31/2016']


			}
		}, cb4);

		  cb4(start, end);



    });


  var app = angular.module('wexdashboard',['AnalysisDataService','ui.bootstrap']);

  app.controller('analysisController',['$scope','$http','analysisService',function($scope, $http,analysisService) {

  $scope.barChartDataUrl = "/AppBuilder/endpoint/timeComparisionEndpoint";

  $scope.stateselect = "";
  $scope.kpiSelected= "";
	$scope.categorySelected = "";
	$scope.subcategorySelected= "";
	$scope.valueSelected = [];
	$scope.filtersSelected = "";
	$scope.timeselected = [];
	$scope.subcategoryvalues = [];
	$scope.subcategoryselect = '';
	$scope.datarange = "";
	$scope.comptimeselect = "";

	$scope.showcompTimeCategory = false;
	$scope.showSubCategory = false;
  $scope.showStateCategory = false;
	$scope.showCountyCategory = false;
	$scope.showFirmCategory = false;
	$scope.showPhaseCategory = false;
	$scope.showTimeKeeperCategory = false;
	$scope.showMatterNameCategory = false;
	$scope.showExpenseCategory = false;

	$scope.showPhaseCategory = false;
	$scope.showTaskCategory = false;
	$scope.showStaffCategory = false;
	$scope.showrateCategory = false;
	$scope.showtrialdateCategory= false;
	$scope.showcaselengthCategory= false;
	$scope.showmattertypeCategory= false;
	$scope.showdisputetypeCategory= false;
	$scope.showcourttypeCategory= false;
	$scope.showteamleadCategory= false;
	$scope.showsupervisingattorneyCategory= false;
	$scope.showplaintiffcounselCategory= false;
	$scope.showassignedcounselCategory= false;
	$scope.showjudgeCategory= false;
	$scope.showmatterstatusCategory= false;
	$scope.showmatteropenCategory= false;
	$scope.showmattercloseCategory= false;
	$scope.showanomalytypeCategory= false;


	$scope.spending = false;
	$scope.hours = false;
	$scope.rate = false;
	$scope.blended = false;
	$scope.spendbudget = false;
	$scope.cpm = false;
	$scope.comparisions = false;
	$scope.anomalies = false;
  $scope.countyfieldname = "county";
  $scope.expensefieldname = "disbcode";
  $scope.firmfieldname = "firmname";
  $scope.timekeeperfieldname = "fullname";
  $scope.taskcodefieldname = "taskcode";
  $scope.phasefieldname = "phase";
  $scope.stafffieldname = "tklevel";
  $scope.ratebucketfieldname = "rate_bucket";
  $scope.trialdatefieldname = "trialdate";
  $scope.lengthbucketfieldname = "length_bucket";
  $scope.mattertypefieldname = "mattertype";
  $scope.disputetypefieldname = "suittype";
  $scope.courttypefieldname = "courttype";
  $scope.teamleadfieldname = "team_lead";
  $scope.attorneyfieldname = "attorney";
  $scope.opposingcounselfieldname = "opposing_counsel";
  $scope.assignedcounselfieldname = "assigned_counsel";
  $scope.judgefieldname = "judge";
  $scope.opendatefieldname = "opendate";
  $scope.closedatefieldname = "closedate";
  $scope.anomalyfieldname = "anomaly";
  $scope.statusfieldname = "status";

	$scope.states = [{id:'state1'}];
	$scope.counties = [{id:'county1'}];
	$scope.firms = [{id:'firm1'}];
	$scope.timekeepers = [{id:'timekeeper1'}];
	$scope.matternames = [{id:'mattername1'}];
	$scope.tasks = [{id:'task1'}];
	$scope.phases = [{id:'phase1'}];
  $scope.comptimes = [{id:'compTime1'}];
	$scope.staff = [{id:'staff1'}];
	$scope.expenses = [{id:'expense1'}];
	$scope.rates = [{id:'rate1'}];
	$scope.traildates = [{id:'traildate1'}];
	$scope.caselengths = [{id:'caselength1'}];
	$scope.mattertypes = [{id:'mattertype1'}];
	$scope.disputetypes = [{id:'disputetype1'}];
	$scope.courttypes = [{id:'courttype1'}];
	$scope.teamleads = [{id:'teamlead1'}];
	$scope.supervisingattorneys = [{id:'supervisingattorney1'}];
	$scope.plaintiffcounsels = [{id:'plaintiffcounsel1'}];
	$scope.assignedcounsels = [{id:'assignedcounsel1'}];
	$scope.judges = [{id:'judge1'}];
	$scope.matterstatuses = [{id:'matterstatus1'}];
	$scope.matteropens = [{id:'matteropen1'}];
	$scope.mattercloses = [{id:'matterclose1'}];
	$scope.judges = [{id:'judge1'}];
	$scope.anomalytypes = [{id:'anomalytype1'}];

	$scope.legendheader = "";
	$scope.legendmiddle = "";
	$scope.legendright = "";
	$scope.stateList = [];
	$scope.countyList = [];
	$scope.firmList = [];
	$scope.timekeeperList = [];
	$scope.matternameList = [];
	$scope.taskList = [];
	$scope.phaseList = [];
	$scope.staffList = [];
	$scope.expenseList = [];
	$scope.rateList = [];
	$scope.traildateList = [];
	$scope.caselengthList = [];
	$scope.mattertypeList = [];
	$scope.disputetypeList = [];
	$scope.courttypeList = [];
	$scope.teamleadList = [];
	$scope.supervisingattorneyList = [];
	$scope.plaintiffcounselList = [];
	$scope.assignedcounselList = [];
	$scope.judgeList = [];
	$scope.anomalytypeList = [];
	$scope.matterstatusList = [];
	$scope.matteropenList = [];
	$scope.anomalytypeList = [];
  $scope.mattercloseList = [];
	$scope.selectionList = [];
  $scope.selectionListOrder = ["state","county","firm","timekeeper","mattername","task","expense"];
  $scope.selectionListOrdercolumnname = ["state","county","firm","judge","mattername","task","itemtype"];
	$scope.matterTableData = "";
	$scope.dataForMatterTableLoaded = false;

	$scope.fillStateList = function() {
	//console.log("Get the states list ");
  analysisService.getStatesList()
        .then(
          function( mydata ) {
            // for(var i in mydata) {
            //   console.log(mydata[i].properties.state[0]);
            //   $scope.stateList.push(mydata[i].properties.state[0]);
            // }
          $scope.stateList = mydata;
      //    console.log("returned data = " + JSON.stringify(mydata));
		    });
    };

    $scope.updateAllDropDowns = function(selecteditem,category) {
      console.log("updatealldropdowns");
	  if(category == 'firm')
		  $scope.updateAllFilters(selecteditem,'firmname');
	  else
		$scope.updateAllFilters(selecteditem,category);
			// get the last element in the list
		var last = '';
		if($scope.selectionList.length > 0) {
			// last = $scope.selectionList[$scope.selectionList.length-1]
			// console.log('Last selected element is'+last);
			console.log('state selection is:'+selecteditem);
			$scope.eraseAllSelections(selecteditem,category,false);
			//for(var listelement in $scope.selectionListOrdercolumnname) {
			//  console.log(last + ',' + selecteditem + ',' +listelement);

		}
      // callendpoint to update dropdown
	};

  // common function to get different lists from the backend service based on the params passed.
  function getFiltersList(selecteditem,category,findfieldname){
       var dataList = [];
       console.log("updating filterlist" + selecteditem + "," + category + "," + findfieldname);
       analysisService.getAnalysisData(selecteditem,category,findfieldname)
         .then(
           function( mydata ) {

             for(var i in mydata) {
                console.log(i);
                dataList.push(i);
               }
             });
        return dataList;
    };

  $scope.updateCountyList = function(selecteditem,category) {
     $scope.countyList = [];
     $scope.countyList = getFiltersList(selecteditem,category,$scope.countyfieldname);
  };

	$scope.updateExpenseList = function(selecteditem,category) {
	   $scope.expenseList = [];
     $scope.expenseList = getFiltersList(selecteditem,category,$scope.expensefieldname);
	};

	$scope.updateFirmList = function(selecteditem,category) {
		 $scope.firmList = [];
     $scope.firmList = getFiltersList(selecteditem,category,$scope.firmfieldname);
  };

	$scope.updateTimeKeeperList = function(selecteditem,category) {
     $scope.timekeeperList = [];
     $scope.timekeeperList = getFiltersList(selecteditem,category,$scope.timekeeperfieldname);
	};

	$scope.updateMatterNameList = function(selecteditem,category) {
		 console.log("updating mattername list"+selecteditem +","+category);
     analysisService.getMatterList(selecteditem,category)
         .then(
           function( mydata ) {
             $scope.matternameList = [];
             for(var i in mydata) {
   					   console.log(i);
   					   //$scope.matternameList.push(i+ "||" +jsondata[i]); {id:'expense1'}
   					   $scope.matternameList.push({matternumber: i, mattername: mydata[i]}) ;
   					  }
          });
	};

	$scope.updateTaskList = function(selecteditem,category) {
    $scope.taskList = [];
    $scope.taskList = getFiltersList(selecteditem,category,$scope.taskcodefieldname);
	};

	$scope.updatePhaseList = function(selecteditem,category) {
    $scope.phaseList = [];
    $scope.phaseList = getFiltersList(selecteditem,category,$scope.phasefieldname);
	};

	$scope.updateStaffList = function(selecteditem,category) {
    $scope.staffList = [];
    $scope.staffList = getFiltersList(selecteditem,category,$scope.stafffieldname);
    // console.log("updating staff list"+selecteditem +","+category);
  };

	$scope.updateAllFilters = function(selecteditem,category) {
		if($scope.selectionList.length > 0) {
			console.log('updating filters now: '+ category + ', value: '+selecteditem);

			// update the show hide filterselection
			$scope.showrateCategory = false;
			$scope.showtrialdateCategory= false;
			$scope.showcaselengthCategory= false;
			$scope.showmattertypeCategory= false;
			$scope.showdisputetypeCategory= false;
			$scope.showcourttypeCategory= false;
			$scope.showteamleadCategory= false;
			$scope.showsupervisingattorneyCategory= false;
			$scope.showplaintiffcounselCategory= false;
			$scope.showassignedcounselCategory= false;
			$scope.showjudgeCategory= false;
			$scope.showmatterstatusCategory= false;
			$scope.showmatteropenCategory= false;
			$scope.showmattercloseCategory= false;
			$scope.showanomalytypeCategory= false;
			$scope.rates = [];
			$scope.traildates = [];
			$scope.caselengths = [];
			$scope.mattertypes = [];
			$scope.disputetypes = [];
			$scope.courttypes = [];
			$scope.teamleads = [];
			$scope.supervisingattorneys = [];
			$scope.plaintiffcounsels = [];
			$scope.assignedcounsels = [];
			$scope.judges = [];
			$scope.matterstatuses = [];
			$scope.matteropens = [];
			$scope.mattercloses = [];
			$scope.anomalytypes = [];

      $scope.rateList = [];
      $scope.rateList = getFiltersList(selecteditem,category,$scope.ratebucketfieldname);
      $scope.traildateList = [];
      $scope.traildateList = getFiltersList(selecteditem,category,$scope.trialdatefieldname);
      $scope.caselengthList= [];
      $scope.caselengthList = getFiltersList(selecteditem,category,$scope.lengthbucketfieldname);
      $scope.mattertypeList= [];
      $scope.mattertypeList = getFiltersList(selecteditem,category,$scope.mattertypefieldname);
      $scope.disputetypeList= [];
      $scope.disputetypeList = getFiltersList(selecteditem,category,$scope.disputetypefieldname);
      $scope.courttypeList= [];
      $scope.courttypeList = getFiltersList(selecteditem,category,$scope.courttypefieldname);
      $scope.teamleadList= [];
      $scope.teamleadList = getFiltersList(selecteditem,category,$scope.teamleadfieldname);
      $scope.supervisingattorneyList= [];
      $scope.supervisingattorneyList = getFiltersList(selecteditem,category,$scope.attorneyfieldname);
      $scope.plaintiffcounselList= [];
      $scope.plaintiffcounselList = getFiltersList(selecteditem,category,$scope.opposingcounselfieldname);
      $scope.assignedcounselList= [];
      $scope.assignedcounselList = getFiltersList(selecteditem,category,$scope.assignedcounselfieldname);
      $scope.judgeList= [];
      $scope.judgeList = getFiltersList(selecteditem,category,$scope.judgefieldname);
      $scope.matteropenList= [];
      $scope.matteropenList = getFiltersList(selecteditem,category,$scope.opendatefieldname);
      $scope.mattercloseList= [];
      $scope.mattercloseList = getFiltersList(selecteditem,category,$scope.closedatefieldname);
      $scope.anomalytypeList= [];
      $scope.anomalytypeList = getFiltersList(selecteditem,category,$scope.anomalyfieldname);
      $scope.matterstatusList= [];
      $scope.matterstatusList = getFiltersList(selecteditem,category,$scope.statusfieldname);

		}
      // callendpoint to update dropdown
	};
	$scope.fillStateList();

	$scope. eraseAllSelections = function(selecteditem,category,erasecategory) {
			if(category == 'state') {
				if(!$scope.showStateCategory || !erasecategory ) {

					if(erasecategory)
					  $scope.states = [];

					$scope.counties = [];
					$scope.firms = [];
					$scope.timekeepers = [];
					$scope.matternames = [];
					$scope.tasks = [];
					$scope.staff = [];
					$scope.phases = [];
					$scope.expenses = [];
					$scope.showExpenseCategory = false;
					$scope.showCountyCategory = false;
					$scope.showFirmCategory = false;
					$scope.showTimeKeeperCategory = false;
					$scope.showMatterNameCategory = false;
					$scope.showTaskCategory = false;
					$scope.showPhaseCategory = false;
					$scope.showStaffCategory = false;

					var index = $scope.selectionList.indexOf('state');
					if(erasecategory)
						if(index > -1)
							$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('county');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('firm');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('timekeeper');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('mattername');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('task');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('staff');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('phase');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('expense');
					if(index > -1)
						$scope.selectionList.splice(index,1);

				}
				else {
				  $scope.selectionList.push(category);
				}
				if(selecteditem != "") {
					$scope.updateCountyList(selecteditem,category);
					$scope.updateFirmList(selecteditem,category);
					$scope.updateTimeKeeperList(selecteditem,category);
					$scope.updateMatterNameList(selecteditem,category);
					$scope.updateTaskList(selecteditem,category);
					$scope.updatePhaseList(selecteditem,category);
					$scope.updateStaffList(selecteditem,category);
					$scope.updateExpenseList(selecteditem,category);
				}
			}

			else if(category == 'county') {
				if(!$scope.showCountyCategory || !erasecategory) {
					if(erasecategory)
						$scope.counties = [];
					$scope.firms = [];
					$scope.timekeepers = [];
					$scope.matternames = [];
					$scope.tasks = [];
					$scope.staff = [];
					$scope.phases = [];
					$scope.expenses = [];
					   $scope.showExpenseCategory = false;
					$scope.showFirmCategory = false;
					$scope.showTimeKeeperCategory = false;
					$scope.showMatterNameCategory = false;
					$scope.showTaskCategory = false;
					$scope.showPhaseCategory = false;
					$scope.showStaffCategory = false;

					var index = $scope.selectionList.indexOf('county');
					if(erasecategory)
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('firm');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('timekeeper');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('mattername');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('task');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('staff');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('phase');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('expense');
					if(index > -1)
						$scope.selectionList.splice(index,1);
				}
				else {
					$scope.selectionList.push(category);
				}
				if(selecteditem != "") {
				$scope.updateFirmList(selecteditem,category);
				$scope.updateTimeKeeperList(selecteditem,category);
				$scope.updateMatterNameList(selecteditem,category);
				$scope.updateTaskList(selecteditem,category);
				$scope.updatePhaseList(selecteditem,category);
				$scope.updateStaffList(selecteditem,category);
									$scope.updateExpenseList(selecteditem,category);

				}
			}

			else if(category == 'mattername') {
				if(!$scope.showMatterNameCategory || !erasecategory) {
					if(erasecategory)
					$scope.matternames = [];
					$scope.timekeepers = [];
					$scope.tasks = [];
					$scope.staff = [];
					$scope.phases = [];
					$scope.expenses = [];
					   $scope.showExpenseCategory = false;
					$scope.showTimeKeeperCategory = false;

					$scope.showTaskCategory = false;
					$scope.showPhaseCategory = false;
					$scope.showStaffCategory = false;

					var index = $scope.selectionList.indexOf('mattername');
					if(erasecategory)
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('timekeeper');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('firm');
					if($scope.selectionList.indexOf('firm') < $scope.selectionList.indexOf('mattername')) {
						console.log("if");
					}
					else {
						if(index > -1) {
							$scope.firms = [];
							console.log("else and if");
							$scope.selectionList.splice(index,1);
							$scope.showFirmCategory = false;
						}
					}
					index = $scope.selectionList.indexOf('task');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('staff');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('phase');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('expense');
					if(index > -1)
						$scope.selectionList.splice(index,1);
				}
				else {
				  $scope.selectionList.push(category);
				}
				if(selecteditem != "") {
				$scope.updateFirmList(selecteditem,category);
				$scope.updateTimeKeeperList(selecteditem,category);
				$scope.updateTaskList(selecteditem,category);
				$scope.updatePhaseList(selecteditem,category);
				$scope.updateStaffList(selecteditem,category);
									$scope.updateExpenseList(selecteditem,category);

				}
			}

			else if(category == 'firm') {
				if(!$scope.showFirmCategory || !erasecategory) {
					if(erasecategory)
					$scope.firms = [];
					$scope.timekeepers = [];

					$scope.tasks = [];
					$scope.staff = [];
					$scope.phases = [];
					 $scope.expenses = [];
					   $scope.showExpenseCategory = false;
					$scope.showTimeKeeperCategory = false;

					$scope.showTaskCategory = false;
					$scope.showPhaseCategory = false;
					$scope.showStaffCategory = false;

					var index = $scope.selectionList.indexOf('firm');
					if(erasecategory)
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('timekeeper');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					 index = $scope.selectionList.indexOf('expense');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('mattername');
					if($scope.selectionList.indexOf('mattername') < $scope.selectionList.indexOf('firm')) {
						console.log("if");

					}
					else {
						if(index > -1) {
							console.log("else and if");
							$scope.matternames = [];
							$scope.showMatterNameCategory = false;
							$scope.selectionList.splice(index,1);
					}
					}


					index = $scope.selectionList.indexOf('task');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('staff');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('phase');
					if(index > -1)
						$scope.selectionList.splice(index,1);
				}
				else {
				  $scope.selectionList.push(category);
				}
				if(selecteditem != "") {
				$scope.updateTimeKeeperList(selecteditem,'firmname');
				$scope.updateMatterNameList(selecteditem,'firmname');
				$scope.updateTaskList(selecteditem,'firmname');
				$scope.updatePhaseList(selecteditem,'firmname');
				$scope.updateStaffList(selecteditem,'firmname');
									$scope.updateExpenseList(selecteditem,'firmname');

				}
			}

			else if(category == 'staff' ) {
				if(!$scope.showStaffCategory || !erasecategory) {
					if(erasecategory)
					$scope.staff = [];
					$scope.timekeepers = [];
					$scope.matternames = [];
					$scope.tasks = [];
					$scope.phases = [];
					 $scope.expenses = [];
					   $scope.showExpenseCategory = false;
					$scope.showTimeKeeperCategory = false;
					$scope.showMatterNameCategory = false;
					$scope.showTaskCategory = false;
					$scope.showPhaseCategory = false;

					var index = $scope.selectionList.indexOf('staff');
					if(erasecategory)
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('timekeeper');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('mattername');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('task');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('phase');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('expense');
					if(index > -1)
						$scope.selectionList.splice(index,1);
				}
				else {
				  $scope.selectionList.push(category);
				}
				if(selecteditem != "") {
				$scope.updateTimeKeeperList(selecteditem,'tklevel');
				$scope.updateMatterNameList(selecteditem,'tklevel');
				$scope.updateTaskList(selecteditem,'tklevel');
				$scope.updatePhaseList(selecteditem,'tklevel');
									$scope.updateExpenseList(selecteditem,'tklevel');

				}
			}

			else if(category == 'timekeeper') {
				if(!$scope.showTimeKeeperCategory || !erasecategory) {
					if(erasecategory)
					$scope.timekeepers = [];
					$scope.matternames = [];
					$scope.tasks = [];
					$scope.phases = [];
					$scope.expenses = [];
					   $scope.showExpenseCategory = false;
					$scope.showMatterNameCategory = false;
					$scope.showTaskCategory = false;
					$scope.showPhaseCategory = false;

					var index = $scope.selectionList.indexOf('timekeeper');
					if(erasecategory)
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('mattername');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('task');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('phase');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('expense');
					if(index > -1)
						$scope.selectionList.splice(index,1);
				}
				else {
				  $scope.selectionList.push(category);
				}
				if(selecteditem != "") {
				$scope.updateMatterNameList(selecteditem,'fullname');
				$scope.updateTaskList(selecteditem,'fullname');
				$scope.updatePhaseList(selecteditem,'fullname');
				$scope.updateExpenseList(selecteditem,'fullname');

				}
			}

			else if(category == 'phase') {
				if(!$scope.showPhaseCategory || !erasecategory) {
					$scope.firms = [];
					$scope.timekeepers = [];
					$scope.matternames = [];
					$scope.tasks = [];
					$scope.staff = [];
					if(erasecategory)
					$scope.phases = [];
					$scope.expenses = [];
					   $scope.showExpenseCategory = false;
					$scope.showFirmCategory = false;
					$scope.showTimeKeeperCategory = false;
					$scope.showMatterNameCategory = false;
					$scope.showTaskCategory = false;
					$scope.showStaffCategory = false;

					index = $scope.selectionList.indexOf('firm');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('timekeeper');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('mattername');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('task');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('staff');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('expense');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('phase');
					if(erasecategory)
						if(index > -1)
							$scope.selectionList.splice(index,1);
				}
				else {
					$scope.selectionList.push(category);
				}
				if(selecteditem != "") {
				$scope.updateFirmList(selecteditem,category);
				$scope.updateTimeKeeperList(selecteditem,category);
				$scope.updateMatterNameList(selecteditem,category);
				$scope.updateTaskList(selecteditem,category);
				$scope.updateStaffList(selecteditem,category);
				$scope.updateExpenseList(selecteditem,category);

				}
			}

			else if(category == 'expense') {
				if(!$scope.showExpenseCategory || !erasecategory) {
					$scope.firms = [];
					$scope.timekeepers = [];
					$scope.matternames = [];
					$scope.tasks = [];
					$scope.staff = [];
					if(erasecategory)
					$scope.expenses = [];

					$scope.phases = [];
					$scope.showPhaseCategory = false;
					$scope.showFirmCategory = false;
					$scope.showTimeKeeperCategory = false;
					$scope.showMatterNameCategory = false;
					$scope.showTaskCategory = false;
					$scope.showStaffCategory = false;

					index = $scope.selectionList.indexOf('firm');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('timekeeper');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('mattername');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('task');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('staff');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('phase');

					index = $scope.selectionList.indexOf('expense');

					if(erasecategory)
						if(index > -1)
							$scope.selectionList.splice(index,1);
				}
				else {
					$scope.selectionList.push(category);
				}
				if(selecteditem != "") {
				$scope.updateFirmList(selecteditem,'disbcode');
				$scope.updateTimeKeeperList(selecteditem,'disbcode');
				$scope.updateMatterNameList(selecteditem,'disbcode');
				$scope.updateTaskList(selecteditem,'disbcode');
				$scope.updateStaffList(selecteditem,'disbcode');
				$scope.updatePhaseList(selecteditem,'disbcode');

				}
			}

			else if(category == 'task') {
				if(!$scope.showTaskCategory || !erasecategory) {
					$scope.firms = [];
					$scope.timekeepers = [];
					$scope.matternames = [];
					if(erasecategory)
					$scope.tasks = [];
					$scope.staff = [];
					$scope.showFirmCategory = false;
					$scope.showTimeKeeperCategory = false;
					$scope.showMatterNameCategory = false;
					$scope.showStaffCategory = false;

					index = $scope.selectionList.indexOf('firm');

					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('timekeeper');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('mattername');
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('task');
					if(erasecategory)
					if(index > -1)
						$scope.selectionList.splice(index,1);

					index = $scope.selectionList.indexOf('staff');
					if(index > -1)
						$scope.selectionList.splice(index,1);



				}
				else {
					$scope.selectionList.push(category);
				}
				if(selecteditem != "") {
				$scope.updateFirmList(selecteditem,'taskcode');
				$scope.updateTimeKeeperList(selecteditem,'taskcode');
				$scope.updateMatterNameList(selecteditem,'taskcode');
				$scope.updateStaffList(selecteditem,'taskcode');
				}
			}


      console.log($scope.selectionList);
    };

	$scope.addNewChoice = function(category) {
			if(category == 'state') {
				var itemNo = $scope.states.length + 1;
				$scope.states.push({'id':'state'+itemNo});
			}
			else if(category == 'county') {
				var itemNo = $scope.counties.length + 1;
				$scope.counties.push({'id':'county'+itemNo});
			}
			else if(category == 'firm') {
				var itemNo = $scope.firms.length + 1;
				$scope.firms.push({'id':'firm'+itemNo});
			}
			else if(category == 'timekeeper') {
				var itemNo = $scope.timekeepers.length + 1;
				$scope.timekeepers.push({'id':'timekeeper'+itemNo});
			}
			else if(category == 'mattername') {
				var itemNo = $scope.matternames.length + 1;
				$scope.matternames.push({'id':'mattername'+itemNo});
			}

			else if(category == 'task') {
				var itemNo = $scope.tasks.length + 1;
				$scope.tasks.push({'id':'task'+itemNo});
			}
			else if(category == 'phase') {
				var itemNo = $scope.phases.length + 1;
				$scope.phases.push({'id':'phase'+itemNo});
			}
			else if(category == 'expense') {
				var itemNo = $scope.expenses.length + 1;
				$scope.expenses.push({'id':'expense'+itemNo});
			}
			else if(category == 'staff') {
				var itemNo = $scope.staff.length + 1;
				$scope.staff.push({'id':'staff'+itemNo});
			}
			else if(category == 'rate') {
				var itemNo = $scope.rates.length + 1;
				$scope.rates.push({'id':'rate'+itemNo});
			}
			else if(category == 'traildate') {
				var itemNo = $scope.traildates.length + 1;
				$scope.traildates.push({'id':'traildate'+itemNo});
			}
			else if(category == 'caselength') {
				var itemNo = $scope.caselengths.length + 1;
				$scope.caselengths.push({'id':'caselength'+itemNo});
			}
			else if(category == 'mattertype') {
				var itemNo = $scope.mattertypes.length + 1;
				$scope.mattertypes.push({'id':'mattertype'+itemNo});
			}
			else if(category == 'disputetype') {
				var itemNo = $scope.disputetypes.length + 1;
				$scope.disputetypes.push({'id':'disputetype'+itemNo});
			}
			else if(category == 'courttype') {
				var itemNo = $scope.courttypes.length + 1;
				$scope.courttypes.push({'id':'courttype'+itemNo});
			}
			else if(category == 'teamlead') {
				var itemNo = $scope.teamleads.length + 1;
				$scope.teamleads.push({'id':'teamlead'+itemNo});
			}
			else if(category == 'supervisingattorney') {
				var itemNo = $scope.supervisingattorneys.length + 1;
				$scope.supervisingattorneys.push({'id':'supervisingattorney'+itemNo});
			}
			else if(category == 'plaintiffcounsel') {
				var itemNo = $scope.plaintiffcounsels.length + 1;
				$scope.plaintiffcounsels.push({'id':'plaintiffcounsel'+itemNo});
			}
			else if(category == 'assignedcounsel') {
				var itemNo = $scope.assignedcounsels.length + 1;
				$scope.assignedcounsels.push({'id':'assignedcounsel'+itemNo});
			}
			else if(category == 'judge') {
				var itemNo = $scope.judges.length + 1;
				$scope.judges.push({'id':'judge'+itemNo});
			}
			else if(category == 'matterstatus') {
				var itemNo = $scope.matterstatuses.length + 1;
				$scope.matterstatuses.push({'id':'matterstatus'+itemNo});
			}
			else if(category == 'matteropen') {
				var itemNo = $scope.matteropens.length + 1;
				$scope.matteropens.push({'id':'matteropen'+itemNo});
			}
			else if(category == 'matterclose') {
				var itemNo = $scope.mattercloses.length + 1;
				$scope.mattercloses.push({'id':'matterclose'+itemNo});
			}
			else if(category == 'anomalytype') {
				var itemNo = $scope.anomalytypes.length + 1;
				$scope.anomalytypes.push({'id':'anomalytype'+itemNo});
			}

		};
	$scope.removeChoice = function(category) {
			if(category == 'state') {
				var lastItem = $scope.states.length-1;
				$scope.states.splice(lastItem);
			}
			else if(category == 'county') {
				var lastItem = $scope.counties.length-1;
				$scope.counties.splice(lastItem);
			}
			else if(category == 'firm') {
				var lastItem = $scope.firms.length-1;
				$scope.firms.splice(lastItem);
			}
			else if(category == 'timekeeper') {
				var lastItem = $scope.timekeepers.length-1;
				$scope.timekeepers.splice(lastItem);
			}
			else if(category == 'mattername') {
				var lastItem = $scope.matternames.length-1;
				$scope.matternames.splice(lastItem);
			}

			else if(category == 'task') {
				var lastItem = $scope.tasks.length-1;
				$scope.tasks.splice(lastItem);
			}
			else if(category == 'staff') {
				var lastItem = $scope.staff.length-1;
				$scope.staff.splice(lastItem);
			}
			else if(category == 'phase') {
				var lastItem = $scope.phases.length-1;
				$scope.phases.splice(lastItem);
			}else if(category == 'expense') {
				var lastItem = $scope.expenses.length-1;
				$scope.expenses.splice(lastItem);
			}
			else if(category == 'rate') {
				var lastItem = $scope.rates.length-1;
				$scope.rates.splice(lastItem);
			}
			else if(category == 'traildate') {
				var lastItem = $scope.traildates.length-1;
				$scope.traildates.splice(lastItem);
			}
			else if(category == 'caselength') {
				var lastItem = $scope.caselengths.length-1;
				$scope.caselengths.splice(lastItem);
			}
			else if(category == 'mattertype') {
				var lastItem = $scope.mattertypes.length-1;
				$scope.mattertypes.splice(lastItem);
			}
			else if(category == 'disputetype') {
				var lastItem = $scope.disputetypes.length-1;
				$scope.disputetypes.splice(lastItem);
			}
			else if(category == 'courttype') {
				var lastItem = $scope.courttypes.length-1;
				$scope.courttypes.splice(lastItem);
			}
			else if(category == 'teamlead') {
				var lastItem = $scope.teamleads.length-1;
				$scope.teamleads.splice(lastItem);
			}
			else if(category == 'supervisingattorney') {
				var lastItem = $scope.supervisingattorneys.length-1;
				$scope.supervisingattorneys.splice(lastItem);
			}
			else if(category == 'plaintiffcounsel') {
				var lastItem = $scope.plaintiffcounsels.length-1;
				$scope.plaintiffcounsels.splice(lastItem);
			}
			else if(category == 'assignedcounsel') {
				var lastItem = $scope.assignedcounsels.length-1;
				$scope.assignedcounsels.splice(lastItem);
			}
			else if(category == 'judge') {
				var lastItem = $scope.judges.length-1;
				$scope.judges.splice(lastItem);
			}
			else if(category == 'matteropen') {
				var lastItem = $scope.matteropens.length-1;
				$scope.matteropens.splice(lastItem);
			}
			else if(category == 'matterclose') {
				var lastItem = $scope.mattercloses.length-1;
				$scope.mattercloses.splice(lastItem);
			}
			else if(category == 'matterstatus') {
				var lastItem = $scope.matterstatuses.length-1;
				$scope.matterstatuses.splice(lastItem);
			}
			else if(category == 'anomalytype') {
				var lastItem = $scope.anomalytypes.length-1;
				$scope.anomalytypes.splice(lastItem);
			}
			else if(category == 'compTime') {
				var lastItem = $scope.comptimes.length-1;
				$scope.comptimes.splice(lastItem);
			}

		};

	$scope.getCategorySelected = function() {
		$scope.categorySelected = $scope.selectionList[$scope.selectionList.length -1];
		if($scope.categorySelected == 'timekeeper')
			$scope.categorySelected = 'fullname';
		else if($scope.categorySelected == 'staff')
			$scope.categorySelected = 'tklevel';
		else if($scope.categorySelected == 'firm')
			$scope.categorySelected = 'firmname';

		else if($scope.categorySelected == 'expense')
			$scope.categorySelected = 'disbcode';

		else if($scope.categorySelected == 'task')
			$scope.categorySelected = 'taskcode';

	};

	$scope.getSelectedKPI = function() {
		if($scope.hours) {
			$scope.kpiSelected = 'hours';
		}
		else if($scope.spending) {
			$scope.kpiSelected = 'netamount';
		}
		else if($scope.anomalies) {
			$scope.kpiSelected = 'AnomalyCount';
		}

	};

	$scope.getFilters = function() {
		$scope.filtersSelected = "";
		if($scope.showrateCategory) {
			for(var i = 0; i < $scope.rates.length ; i ++) {
				var select = document.getElementById($scope.rates[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "rate_bucket--" +select.options[select.selectedIndex].value + ",,";
			}
		}

		if($scope.showtrialdateCategory) {
			for(var i = 0; i < $scope.traildates.length ; i ++) {
				var select = document.getElementById($scope.traildates[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "trialdate--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showcaselengthCategory) {
			for(var i = 0; i < $scope.caselengths.length ; i ++) {
				var select = document.getElementById($scope.caselengths[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "length_bucket--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showmattertypeCategory) {
			for(var i = 0; i < $scope.mattertypes.length ; i ++) {
				var select = document.getElementById($scope.mattertypes[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "mattertype--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showdisputetypeCategory) {
			for(var i = 0; i < $scope.disputetypes.length ; i ++) {
				var select = document.getElementById($scope.disputetypes[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "suittype--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showcourttypeCategory) {
			for(var i = 0; i < $scope.courttypes.length ; i ++) {
				var select = document.getElementById($scope.courttypes[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "courttype--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showteamleadCategory) {
			for(var i = 0; i < $scope.teamleads.length ; i ++) {
				var select = document.getElementById($scope.teamleads[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "team_lead--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showsupervisingattorneyCategory) {
			for(var i = 0; i < $scope.supervisingattorneys.length ; i ++) {
				var select = document.getElementById($scope.supervisingattorneys[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "attorney--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showplaintiffcounselCategory) {
			for(var i = 0; i < $scope.plaintiffcounsels.length ; i ++) {
				var select = document.getElementById($scope.plaintiffcounsels[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "opposing_counsel--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showassignedcounselCategory) {
			for(var i = 0; i < $scope.assignedcounsels.length ; i ++) {
				var select = document.getElementById($scope.assignedcounsels[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "assigned_counsel--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showjudgeCategory) {
			for(var i = 0; i < $scope.judges.length ; i ++) {
				var select = document.getElementById($scope.judges[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "judge--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showmatterstatusCategory) {
			for(var i = 0; i < $scope.matterstatuses.length ; i ++) {
				var select = document.getElementById($scope.matterstatuses[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "status--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showmatteropenCategory) {
			for(var i = 0; i < $scope.matteropens.length ; i ++) {
				var select = document.getElementById($scope.matteropens[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "opendate--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showmattercloseCategory) {
			for(var i = 0; i < $scope.mattercloses.length ; i ++) {
				var select = document.getElementById($scope.mattercloses[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "closedate--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		if($scope.showanomalytypeCategory) {
			for(var i = 0; i < $scope.anomalytypes.length ; i ++) {
				var select = document.getElementById($scope.anomalytypes[i].id);
				$scope.filtersSelected = $scope.filtersSelected + "anom_desc--" +select.options[select.selectedIndex].value + ",,";
			}
		}
		console.log('selection list length is'+$scope.selectionList.length);
		if($scope.selectionList.length > 1)
			for(var j = 0; j < $scope.selectionList.length -1 ; j++) {
				if($scope.selectionList[j] == 'state')
					for(var i = 0; i < $scope.states.length ; i ++) {
						console.log("Found state selected");
						var select = document.getElementById($scope.states[i].id);
						$scope.filtersSelected = $scope.filtersSelected + "state--" +select.options[select.selectedIndex].value+ ",,";
					}
				else if($scope.selectionList[j] == 'county')
					for(var i = 0; i < $scope.counties.length ; i ++) {
						console.log("Found county selected");
						var select = document.getElementById($scope.counties[i].id);
						$scope.filtersSelected = $scope.filtersSelected + "county--" +select.options[select.selectedIndex].value+ ",,";
					}
				else if($scope.selectionList[j] == 'firm')
					for(var i = 0; i < $scope.firms.length ; i ++) {
						console.log("Found firm selected");
						var select = document.getElementById($scope.firms[i].id);
						$scope.filtersSelected = $scope.filtersSelected + "firmname--" +select.options[select.selectedIndex].value+ ",,";
					}
				else if($scope.selectionList[j] == 'mattername')
					for(var i = 0; i < $scope.matternames.length ; i ++) {
						console.log("Found mattername selected");
						var select = document.getElementById($scope.matternames[i].id);
						$scope.filtersSelected = $scope.filtersSelected + "mattername--" +select.options[select.selectedIndex].value+ ",,";
					}
				else if($scope.selectionList[j] == 'phase')
					for(var i = 0; i < $scope.phases.length ; i ++) {
						console.log("Found phase selected");
						var select = document.getElementById($scope.phases[i].id);
						$scope.filtersSelected = $scope.filtersSelected + "phase--" +select.options[select.selectedIndex].value+ ",,";
					}
				else if($scope.selectionList[j] == 'expense')
					for(var i = 0; i < $scope.expenses.length ; i ++) {
						console.log("Found expenses selected");
						var select = document.getElementById($scope.expenses[i].id);
						$scope.filtersSelected = $scope.filtersSelected + "disbcode--" +select.options[select.selectedIndex].value+ ",,";
					}
				else if($scope.selectionList[j] == 'task')
					for(var i = 0; i < $scope.tasks.length ; i ++) {
						console.log("Found task selected");
						var select = document.getElementById($scope.tasks[i].id);
						$scope.filtersSelected = $scope.filtersSelected + "taskcode--" +select.options[select.selectedIndex].value+ ",,";
					}
				else if($scope.selectionList[j] == 'timekeeper')
					for(var i = 0; i < $scope.timekeepers.length ; i ++) {
						console.log("Found timekeeper selected");
						var select = document.getElementById($scope.timekeepers[i].id);
						$scope.filtersSelected = $scope.filtersSelected + "fullname--" +select.options[select.selectedIndex].value+ ",,";
					}
				else if($scope.selectionList[j] == 'staff')
					for(var i = 0; i < $scope.staff.length ; i ++) {
						console.log("Found staff selected");
						var select = document.getElementById($scope.staff[i].id);
						$scope.filtersSelected = $scope.filtersSelected + "staff--" +select.options[select.selectedIndex].value+ ",,";
					}
				}

		console.log("FILTER SELECTION IS:"+$scope.filtersSelected);
	};

	$scope.getValueSelected = function() {
		$scope.valueSelected = [];
		if($scope.categorySelected == 'state') {
			for(var i = 0; i < $scope.states.length ; i ++) {
				console.log("Found state selected");
				var select = document.getElementById($scope.states[i].id);
				$scope.valueSelected.push(select.options[select.selectedIndex].value);
			}
		}
		else if($scope.categorySelected == 'county') {
			for(var i = 0; i < $scope.counties.length ; i ++) {
				console.log("Found county selected");
				var select = document.getElementById($scope.counties[i].id);
				$scope.valueSelected.push(select.options[select.selectedIndex].value);
			}
		}
		else if($scope.categorySelected == 'firmname') {
			for(var i = 0; i < $scope.firms.length ; i ++) {
				console.log("Found firm selected");
				var select = document.getElementById($scope.firms[i].id);
				$scope.valueSelected.push(select.options[select.selectedIndex].value);
			}
		}
		else if($scope.categorySelected == 'mattername') {
			for(var i = 0; i < $scope.matternames.length ; i ++) {
				console.log("Found mattername selected");
				var select = document.getElementById($scope.matternames[i].id);
				$scope.valueSelected.push(select.options[select.selectedIndex].value);
			}
		}
		else if($scope.categorySelected == 'phase') {
			for(var i = 0; i < $scope.phases.length ; i ++) {
				console.log("Found phase selected");
				var select = document.getElementById($scope.phases[i].id);
				$scope.valueSelected.push(select.options[select.selectedIndex].value);
			}
		}
		else if($scope.categorySelected == 'disbcode') {
			for(var i = 0; i < $scope.expenses.length ; i ++) {
				console.log("Found expense selected");
				var select = document.getElementById($scope.expenses[i].id);
				$scope.valueSelected.push(select.options[select.selectedIndex].value);
			}
		}
		else if($scope.categorySelected == 'taskcode') {
			for(var i = 0; i < $scope.tasks.length ; i ++) {
				console.log("Found task selected");
				var select = document.getElementById($scope.tasks[i].id);
				$scope.valueSelected.push(select.options[select.selectedIndex].value);
			}
		}
		else if($scope.categorySelected == 'fullname') {
			for(var i = 0; i < $scope.timekeepers.length ; i ++) {
				console.log("Found timekeeper selected");
				var select = document.getElementById($scope.timekeepers[i].id);
				$scope.valueSelected.push(select.options[select.selectedIndex].value);
			}
		}
		else if($scope.categorySelected == 'tklevel') {
			for(var i = 0; i < $scope.staff.length ; i ++) {
				console.log("Found staff selected");
				var select = document.getElementById($scope.staff[i].id);
				$scope.valueSelected.push(select.options[select.selectedIndex].value);
			}
		}

		console.log($scope.valueSelected);
	};

	$scope.getDefaultSubcategory = function(subcategory) {
		console.log('get default subcategory:'+subcategory);
		if(subcategory != "") {
			if(subcategory == 'State') {
				$scope.subcategorySelected = 'state';
			}
			else if(subcategory == 'County') {
				$scope.subcategorySelected = 'county';
			}
			else if(subcategory == 'Firm') {
				$scope.subcategorySelected = 'firmname';
			}
			else if(subcategory == 'Matter') {
				$scope.subcategorySelected = 'mattername';
			}
			else if(subcategory == 'Phase') {
				$scope.subcategorySelected = 'phase';
			}
			else if(subcategory == 'Expense') {
				$scope.subcategorySelected = 'disbcode';
			}
			else if(subcategory == 'Task') {
				$scope.subcategorySelected = 'taskcode';
			}
			else if(subcategory == 'Time Keeper') {
				$scope.subcategorySelected = 'fullname';
			}
			else if(subcategory == 'Staff') {
				$scope.subcategorySelected = 'tklevel';
			}
			else if(subcategory == 'Anomaly') {
				$scope.subcategorySelected = 'anom_desc';
			}
		}
		else {
			if($scope.categorySelected == 'state') {
				$scope.subcategorySelected = 'mattername';
			}
			else if($scope.categorySelected == 'county') {
				$scope.subcategorySelected = 'mattername';
			}
			else if($scope.categorySelected == 'firmname') {
				$scope.subcategorySelected = 'fullname';
			}
			else if($scope.categorySelected == 'mattername') {
				$scope.subcategorySelected = 'fullname';
			}
			else if($scope.categorySelected == 'phase') {
				$scope.subcategorySelected = 'task';
			}
			else if($scope.categorySelected == 'disbcode') {
				$scope.subcategorySelected = 'fullname';
			}
			else if($scope.categorySelected == 'taskcode') {
				$scope.subcategorySelected = 'fullname';
			}
			else if($scope.categorySelected == 'fullname') {
				$scope.subcategorySelected = 'phase';
			}
			else if($scope.categorySelected == 'tklevel') {
				$scope.subcategorySelected = 'mattername';
			}
		}
		console.log('Sub category selected is'+$scope.subcategorySelected);
	};

	function getNameToBeDisplayed(name) {

		if(name == 'state') {
				return 'State';
			}
			else if(name == 'county') {
				return 'County';
			}
			else if(name == 'firmname') {
				return 'Firm Name';
			}
			else if(name == 'mattername') {
				return 'Matter';
			}
			else if(name == 'phase') {
				return 'Phase';
			}
			else if(name == 'disbcode') {
				return 'Expense';
			}
			else if(name == 'taskcode') {
				return 'Task';
			}
			else if(name == 'fullname') {
				return 'Time Keeper';
			}
			else if(name == 'tklevel') {
				return 'Staff Level';
			}
			else if(name == 'netamount') {
				return 'Spending ($)';
			}
			else if(name == 'hours') {
				return 'Hours';
			}
			else if(name == 'AnomalyCount') {
				return 'Anomaly Count';
			}
			else if(name == 'anom_desc') {
				return 'Anomaly Description';
			}
			return 'no mapping found';
	};


	function createPieHighChart(returneddata) {
		//var dataTmp = [];
		//dataTmp = dataTmp.map(function(returnedData) { return JSON.stringify(returnedData); });

		var json = eval("([" +returneddata+ "])");

		console.log(json);
		//var dataarray = JSON.parse(returneddata);
		//console.log(dataarray);
		//var dataarraymew = [];
		//dataarraymew.push(dataarray);
		//console.log(dataarraymew);
		var kpi = getNameToBeDisplayed($scope.kpiSelected);
		var cat = getNameToBeDisplayed($scope.categorySelected);
		var sub = getNameToBeDisplayed($scope.subcategorySelected);
		var title = cat + ' : ' +kpi + ' - Viewing By: '+sub;
			$(".legendArea2").html("<div></div>");
			$("#legendHeaderLeft2").html("<div>"+sub+"</div>");
			$("#legendHeaderMiddle2").html("<div>Percentage</div>");
			$("#legendHeaderRight2").html("<div>"+ kpi+"</div>");
    var tot=0;
			for (var j = 0; j < json.length; j++) {
				tot=tot+json[j].y;
			}
			var x=0;
			for(var i=1;i<json.length+1;i++) {
				if(i%10 == 1)x=0;
				$(".legendArea2").append("<div id='percLegendField' class='row displayBlock col-lg-2'><div class='circle displayBlock' id='colorLegend' style='" + "background:" + Highcharts.getOptions().colors[x] + "'></div>" + json[i-1].name + "</div><div id='nameLegendField' class='percentageBlock col-lg-2'>"+(((json[i-1].y)/tot)*100).toFixed(2) + "%</div><div class='col-lg-2' id='nameLegendField'>" + JSON.stringify(json[i-1].y) + "</div></br>");
				x++;
			}
			tot=0;


		Highcharts.setOptions({
			colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584']
		});

		Highcharts.chart('piechart', {
						chart: {
							plotBackgroundColor: null,
							plotBorderWidth: null,
							plotShadow: false,
							type: 'pie'
						},
						title: {
							text: title,
              margin: 7,
              style: {
        		fontFamily: 'Roboto',
            fontSize: 18,
            fontWeight: 600,
            color: '#6e6e6e'
        },
              align: 'left',
                      style: {
                    fontSize: '18px',
                    color: '#6e6e6e'
        }
						},
						tooltip: {
							pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
						},
      colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584'],
						plotOptions: {
							pie: {
								allowPointSelect: true,
								cursor: 'pointer',
                size: 250,
                center: ["50%", "50%"],
								dataLabels: {
									enabled: false,
									formatter: function() {
										return Math.round(this.percentage*100)/100 + ' %';
									},
									distance: -30,
									color:'white'
								},
								showInLegend: true
							}
						},
						credits: {
							enabled: false
						},
						legend: {
              enabled: false

						},

						series: [{
							name: kpi,
							colorByPoint: true,
							data: json
						}]
					});
	};

	function createBarChart(dataUrl,categorySelected,valueSelected,daterange,filtersSelected,kpiSelected,subcategorySelected) {
    var jsondata;
    analysisService.getChartData(dataUrl,categorySelected,valueSelected,daterange,filtersSelected,kpiSelected,subcategorySelected)
      .then(
        function( mydata ) {
        //  jsondata = eval("([" +mydata+ "])");
          jsondata = mydata;
          console.log("jsondataforcharts" + jsondata);
      });
//		var json = eval("([" +returneddata+ "])");

		var kpi = getNameToBeDisplayed($scope.kpiSelected);
		var cat = getNameToBeDisplayed($scope.categorySelected);
		var sub = getNameToBeDisplayed($scope.subcategorySelected);
		var title = cat + ' : ' +kpi + ' - Viewing By: '+sub;

		$scope.legendheader = sub;
		$scope.legendmiddle = "Percentage(%)";
		$scope.legendright = kpi;

		var cats = [];
		if($scope.showcompTimeCategory) {
			cats = $scope.timeselected;
		}
		else {
			cats = $scope.valueSelected;
		}
		$('.tabLayout').empty();
		for(var i=0;i<cats.length;i++){
			$('.tabLayout').append("<a class='tabButton' id='tabBut"+i+"' tabindex='"+i+"'>"+cats[i]+"        </a>");
		}
		var tot =0;
		$(".legendArea").html("<div></div>");
		$(".legendHeaderLeft").html("<div></div>");
			$(".legendHeaderMiddle").html("<div></div>");
			$(".legendHeaderRight").html("<div></div>");
		$(".tabButton").click(function () {
			$(".legendMid").hide();
			$(".legendArea").html("<div></div>");
			$(".legendHeaderLeft").html("<div>"+ sub+"</div>");
			$(".legendHeaderMiddle").html("<div>Percentage</div>");
			$(".legendHeaderRight").html("<div>"+ kpi+"</div>");
			for (var j = 0; j < jsondata.length; j++) {
				tot=tot+jsondata[j].data[this.tabIndex];
			}
			var x=0;
			for(var i=1;i<jsondata.length+1;i++) {
				if(jsondata[i-1].data[this.tabIndex]==0){
					x=x+1;
					continue;
				}
				if(i%10 == 1)x=0;
				$(".legendArea").append("<div id='percLegendField' class='displayBlock'><div class='circle displayBlock' id='colorLegend' style='" + "background:" + Highcharts.getOptions().colors[x] + "'></div>" + jsondata[i-1].name + "</div><div id='nameLegendField' class='percentageBlock'>"+(((jsondata[i-1].data[this.tabIndex])/tot)*100).toFixed(2) + "%</div><div id='nameLegendField'>" + JSON.stringify(jsondata[i-1].data[this.tabIndex]) + "</div></br>");
				x++;
			}
			tot=0;
		});


		Highcharts.setOptions({
			colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584']
		});

		Highcharts.chart('barchart', {
		chart: {
			type: 'column'
		},
		title: {
							text: title,
              margin: 20,
              align: 'left',
                      style: {
                    fontSize: '18px',
                    color: '#6e6e6e'
                      }
        },
          colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584'],
		xAxis: {
			categories: cats
		},
		yAxis: {
			min: 0,
			title: {
				text: kpi
			},
			stackLabels: {
				enabled: true,
				style: {
					fontWeight: 'bold',
					color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
				}
			}
		},
		legend : {
			enabled: false

            },
		tooltip: {
			headerFormat: '<b>{point.x}</b><br/>',
			pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
		},
		credits: {
			enabled: false
		},

		plotOptions: {
			column: {
				stacking: 'normal',
				dataLabels: {
					enabled: false,
					color: (Highcharts.theme && Highcharts.theme.dataLabelsColor) || 'white'
				}
			}
		},
		series: jsondata

	});


	};

	function createTimeLineChart(returneddata) {

		var jsonData = eval("([" +returneddata+ "])");
		console.log("create timelinechart"+JSON.stringify(jsonData));
		var chart;

		var nameValues = [];
		for(var m=1;m<jsonData.length;m++) {
			nameValues.push(JSON.stringify(jsonData[m]));
		}
		console.log('namvalues:'+nameValues);

		var dates = [];
		for(var i=0;i<jsonData[0].data.length;i++) {
			dates.push(jsonData[0].data[i]);
		}
		console.log('dates'+dates);
		var categories = [];
		for(var j=0;j<dates.length;j++) {
//			if(dates[j].getMonth()+1<10) {
//				if(dates[j].getDate()+1<10) {
//					categories.push("0" + (dates[j].getMonth() + 1) + "/0" + dates[j].getDate() + "/" + dates[j].getFullYear());
//				}
//				else categories.push("0" + (dates[j].getMonth() + 1) + "/" + dates[j].getDate() + "/" + dates[j].getFullYear());
//			}
//			else categories.push(dates[j].getMonth() + 1 + "/" + dates[j].getDate() + "/" + dates[j].getFullYear());
			categories.push(dates[j]);
		}
		console.log('categories1'+categories);

		var obj = {};
		var arr = [];
		for(var z=0;z<categories.length;z++){
			obj[categories[z]] = z;
		}
		categories.sort(function(s1,s2){
//			var aa = a.split('/').reverse().join(),
//			bb = b.split('/').reverse().join();
//			return aa < bb ? -1 : (aa > bb ? 1 : 0);
			var sdate1 = s1.split('/');
			var sdate2 = s2.split('/');
			var date1 = sdate1[1]+'/'+sdate1[0]+'/'+sdate1[2];
			var date2 = sdate2[1]+'/'+sdate2[0]+'/'+sdate2[2];
			var aa = date1.split('/').reverse().join(),
			bb = date2.split('/').reverse().join();
			return aa < bb ? -1 : (aa > bb ? 1 : 0);

		});

				console.log('categories after sort'+categories);
                for(var c=0;c<categories.length;c++){
                    arr.push(JSON.stringify(obj[categories[c]]));
                }
				console.log('arr is'+arr);

                var arr1 = [];
                for(var m=0;m<JSON.parse("["+nameValues+"]").length;m++) {
                    for(var b=0;b<JSON.parse("["+nameValues+"]")[0].data.length;b++){
                        arr1.push(JSON.parse("["+nameValues+"]")[m].data[b]);
                    }
                }
                var x = 0;
                for(var r=0;r<nameValues.length;r++) {
                    var arr2 = {};
                    for (var w = x; w < x+arr.length; w++) {
                        arr2[arr[w-x]] = arr1[w];
                    }
                    var jsonArrayData = [];
                    /*console.log(jsonData[r+1].data.length);*/
                    for(var v=0;v<jsonData[r+1].data.length;v++) {
                        /*console.log("arr2 "+arr2[v]);*/
                        jsonArrayData.push(arr2[v]);
                    }
                    jsonData[r+1].data = jsonArrayData;
                    /*console.log(JSON.stringify(jsonData));*/
                    x=x+arr.length;
                }
                var max = arr1.reduce(function(a, b) {
                    return Math.max(a, b);
                });
                var min = arr1.reduce(function (a, b) {
                    return Math.min(a,b);
                });
                var finalJson = [];
                for(var t=1;t<jsonData.length;t++){
                    finalJson.push(JSON.stringify(jsonData[t]));
                }

                var finaldatatodisplay = JSON.parse("["+finalJson+"]");

				var kpi = getNameToBeDisplayed($scope.kpiSelected);
				var cat = getNameToBeDisplayed($scope.categorySelected);
				var sub = getNameToBeDisplayed($scope.subcategorySelected);
				var title = cat + ' : ' +kpi;
				Highcharts.chart('timelinechart', {
                chart: {

                },
                title: {
							text: title,
             margin: 20,
              align: 'left',
                      style: {
                    fontSize: '18px',
                    color: '#6e6e6e'
        }
                },
                plotOptions: {
                    line: {
                        marker: {
                            enabled: false
                        }
                    }
                },
              colors: ['#029fdb','#be00f3','#92cd0d','#e9b918','#c31820','#6f5df7','#f25214','#fff800','#00b9ff','#d01584'],
                subtitle: {
                    text: ''
                },
                yAxis: {
                    title: {
                        text: kpi
                    },
                    minorGridLineWidth: 0,
                    gridLineWidth: 0,
					max: max,
					min: min
                },
                xAxis: {
                    title: {
                        text: 'Date'
                    },
                    categories: categories
                },
                series: finaldatatodisplay,
                navigation: {
                    menuItemStyle: {
                        fontSize: '10px'
                    }
                },
				credits: {
					enabled: false
				},

                legend : {
                    itemWidth: 800,
                    x: 90,
                    useHTML: true,
                    labelFormatter: function() {
                        var total = 0;
                        for(var i=this.yData.length; i--;) { total += this.yData[i]; };
                        return "<div style='display: inline-table; width: 500px;'>"+this.name+ "</div><div style='text-align:right;display: inline-table; width:50px;'>"+ total.toFixed(2)+"</div>";
                    }
                }

            });

	};

	$scope.populateSubCategorySelection = function() {
		$scope.subcategoryvalues = [];
		$scope.showSubCategory = true;
		if($scope.categorySelected == 'state') {
			$scope.subcategoryvalues.push('County');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
				$scope.subcategoryvalues.push('Anomaly');
		}
		else if($scope.categorySelected == 'county') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
				$scope.subcategoryvalues.push('Anomaly');
			}
		else if($scope.categorySelected == 'firmname') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'mattername') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'phase') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'disbcode') {
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'task') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Firm');
			$scope.subcategoryvalues.push('Time Keeper');
			$scope.subcategoryvalues.push('Staff');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'fullname') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Task');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');

		}
		else if($scope.categorySelected == 'tklevel') {
			$scope.subcategoryvalues.push('Matter');
			$scope.subcategoryvalues.push('Task');
			$scope.subcategoryvalues.push('Phase');
			$scope.subcategoryvalues.push('Time Keeper');
			if($scope.kpiSelected == 'AnomalyCount' )
						$scope.subcategoryvalues.push('Anomaly');
		}
		console.log('Array of values is'+$scope.subcategoryvalues);
	};
	$scope.getDateFilter = function() {
		$scope.datarange = document.getElementById("daterange").value;
		$scope.timeselected.push($scope.datarange);
		if($scope.showcompTimeCategory) {
			 startDate = $('#compTime1').data('daterangepicker').startDate.format('MM/DD/YYYY');
			 endDate = $('#compTime1').data('daterangepicker').endDate.format('MM/DD/YYYY');
			$scope.datarange = $scope.datarange + '||' + startDate + '-' + endDate;
			console.log("Date range selected is:"+$scope.datarange);
			$scope.timeselected.push(startDate + '-' + endDate);
		}
};

	function createMattertable(data) {
		//console.log("data in createMatterTable = " + data);
		var jsonData = eval(data);
		//console.log("create matter table "+JSON.stringify(jsonData));
		$scope.matterTableData = jsonData;
		$scope.dataForMatterTableLoaded = true;
		$scope.$apply();
	};

	$scope.convertTime = function(datetoconvert) {
		var d = new Date(datetoconvert);
		var t= d.getTime();

		return Math.round(t /1000);
	};

	$scope.executeReport = function() {
		// get the last entered filter from selectionList.  TODO - change the name for staff and timekeeper
		$scope.getCategorySelected();
		$scope.getValueSelected();
		$scope.getFilters();
		// returns the KPI that has been selected
		$scope.getSelectedKPI();
		// returns the default SubCategory
		$scope.getDefaultSubcategory($scope.subcategoryselect);

		$scope.populateSubCategorySelection();
		// get all the filters put them in this format filtername-filtervalue,filtername-filtervalue
		$scope.getDateFilter();
		console.log('filters is:'+$scope.filtersSelected);
		console.log("category is"+ $scope.categorySelected + ", category value is: "+$scope.valueSelected[0] + ", selected kpi:" + $scope.kpiSelected +", sub category is:" + $scope.subcategorySelected);
		var categoryString = "";
			for(var i in $scope.valueSelected ) {
				categoryString = categoryString + $scope.valueSelected[i] + "||";
			}
		// piechart
		if($scope.showcompTimeCategory) {
      console.log("drawing bar chart in showcomptime ");
				  createBarChart($scope.barChartDataUrl,$scope.categorySelected,$scope.valueSelected[0],$scope.datarange,$scope.filtersSelected,$scope.kpiSelected,$scope.subcategorySelected);
          console.log("drawing bar chart in showcomptime completed ");
			  }
		else if($scope.valueSelected.length == 1) {
			$.ajax({
				  url      : "/AppBuilder/endpoint/piechartendpoint",
				  type     : "POST",
				  data     : {category: $scope.categorySelected, categoryvalue: $scope.valueSelected[0], datefilter: $scope.datarange, filters: $scope.filtersSelected,  selectedkpi: $scope.kpiSelected, subcategory: $scope.subcategorySelected},
				  success  : function(data) {

						console.log("rOutput:"+ data);

						createPieHighChart(data);
				  }
			});
		}
		else {

		console.log('asfkndasflnkldsf:'+categoryString);
		$.ajax({
		  url      : "/AppBuilder/endpoint/barchartendpoint",
		  type     : "POST",
		  data     : {category: $scope.categorySelected, categoryvalue: categoryString, filters: $scope.filtersSelected, datefilter: $scope.datarange, selectedkpi: $scope.kpiSelected, subcategory: $scope.subcategorySelected},
		  success  : function(data) {
						console.log("Output for bar chart is:"+ data);
						createBarChart(data);
		  }
		});
		}
		// timelinechart - category and sub category are the same
		if(!$scope.showcompTimeCategory) {
			$.ajax({
				  url      : "/AppBuilder/endpoint/timelinechartendpoint",
				  type     : "POST",
				  data     : {category: $scope.categorySelected, categoryvalue: categoryString, filters: $scope.filtersSelected, datefilter: $scope.datarange, selectedkpi: $scope.kpiSelected, subcategory: $scope.categorySelected},
				  success  : function(data) {
					console.log("Output:"+ data);
					createTimeLineChart(data);
				  }
			});
		}

		if($scope.valueSelected.length == 1 && $scope.categorySelected == "mattername") {
			console.log("data for this mattername is:"+$scope.valueSelected[0] );

			$.ajax({
			  url      : "/AppBuilder/endpoint/scenario5",
			  type     : "POST",
			  data     : {mattername: $scope.valueSelected[0]},
			  success  : function(data) {
				  createMattertable(data);
			  }
			});
		}
	};
}]);

// Analysis data service

var AnalysisDataService = angular.module('AnalysisDataService', [])
    .service('analysisService', function ($http,$q) {

    // Service method to get the analysis data
    // Return service methodes.
    return({
          getStatesList: getStatesList,
          getAnalysisData: getAnalysisData,
          getMatterList: getMatterList,
          getChartData:getChartData
    });

    // start call to get state list
    function  getStatesList() {
        var request = $http({
                  method: "post",
                  url: "/AppBuilder/endpoint/GetStates",
            });
          return(request.then( handleSuccess, handleError ) );
        }

    // start call to get analysis data
    function getAnalysisData(selecteditem,category,findfieldname) {
      console.log("getAnalysisData for fields category = " + category + " selecteditem = " + selecteditem + " findfieldname = " + findfieldname);
      var request = $http({
                method: "post",
                url: "/AppBuilder/endpoint/AnalysisEndpoint",
                params: {
                          FilterName: category,
                          FilterValue: selecteditem,
                          FindFieldName: findfieldname
                      }
              });
            return(request.then( handleSuccess, handleError ) );
        }
        // start call to get matter list
        function getMatterList(selecteditem,category) {
          console.log("getMatterList for fields category = " + category + " selecteditem = " + selecteditem);
          var request = $http({
                    method: "post",
                    url: "/AppBuilder/endpoint/getMatterDropDown",
                    params: {
                              FilterName: category,
                              FilterValue: selecteditem
                          }
                  });
                return(request.then( handleSuccess, handleError ) );
            }
            // start call to get data for different graphs chart based on the data url and params
          function getChartData(dataurlC,categoryC,categoryvalueC,datefilterC,filtersC,selectedkpiC,subcategoryC) {
              console.log("getChartData for fields dataurl =" + dataurlC + " category =" + categoryC + " categoryvalue =" + categoryvalueC + "datefilter=" + datefilterC  + "filters =" + filtersC + "selectedkpi=" + selectedkpiC + " subcategory=" + subcategoryC);
              var request = $http({
                        method: "post",
                        url: dataurlC,
                        params: {
                              category: categoryC,
                              categoryvalue: categoryvalueC,
                              datefilter: datefilterC,
                              filters: filtersC,
                              selectedkpi: selectedkpiC,
                              subcategory: subcategoryC
                            }
                      });
                    return(request.then( handleSuccess, handleError ) );
                }

    // Common method to handle the request from the server
    function handleError( response ) {
        if (
            ! angular.isObject( response.data ) ||
            ! response.data.message
            ) {
                console.log("Returning the error " + response.data);
            return( $q.reject( "An unknown error occurred." ) );
        }
        return( $q.reject( response.data.message ) );
    }
    function handleSuccess( response ) {
      console.log("Returning the response " + response.data);
      return( response.data);
    }
   // end call to get data from service.
  });


</script>
