var chart = Highcharts.chart('container', {
    chart: {
                    type: 'column',
                    renderTo: 'container',

                },
    series: [{
    	  name: "Dormat",
        data: [29.9, 71.5]
      }, {
       name: "Open", data:[44,35]
       }
    ]
});


// the button action
$('#button').click(function () {
console.log("kick ass");
var newdata = [{
    	  name: "Dormat",
        data: [29.9, 71.5]
      }, {
       name: "Open", data:[44,35]
       }
    ];
    chart.update({series : newdata});
    chart.redraw()
});
